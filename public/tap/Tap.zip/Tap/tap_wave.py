"""Portable RIFF/PCM waveform readers for Ableton Live Remote Scripts."""

import struct
import time


_PCM_SUBFORMAT_GUID = bytes((
    0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00,
    0x80, 0x00, 0x00, 0xAA, 0x00, 0x38, 0x9B, 0x71,
))


def pcm16_peak(frame_data, audioop_module=None):
    """Return a PCM16 peak, using audioop only as an optional fast path."""
    if len(frame_data) % 2:
        raise ValueError('Incomplete 16-bit PCM sample')
    if not frame_data:
        return 0
    if audioop_module is not None:
        try:
            return audioop_module.max(frame_data, 2)
        except Exception:
            pass
    return max(abs(sample[0]) for sample in struct.iter_unpack('<h', frame_data))


class PCMWaveReader:
    """Read uncompressed little-endian PCM WAVE without importing wave.py."""

    def __init__(self, path):
        self._file = open(path, 'rb')
        self._frames_read = 0
        self._channels = 0
        self._sample_width = 0
        self._block_alignment = 0
        self._frame_count = 0
        try:
            header = self._file.read(12)
            if (len(header) != 12 or header[:4] != b'RIFF'
                    or header[8:12] != b'WAVE'):
                raise ValueError('Not a RIFF WAVE file')
            riff_size = struct.unpack('<I', header[4:8])[0]
            if riff_size < 4:
                raise ValueError('Invalid RIFF size')

            self._file.seek(0, 2)
            file_size = self._file.tell()
            riff_end = 8 + riff_size
            scan_end = min(riff_end, file_size)
            self._file.seek(12)

            format_info = None
            data_offset = None
            data_size = None
            while self._file.tell() + 8 <= scan_end:
                chunk_header = self._file.read(8)
                if len(chunk_header) != 8:
                    break
                chunk_id, chunk_size = struct.unpack('<4sI', chunk_header)
                chunk_start = self._file.tell()
                chunk_end = chunk_start + chunk_size + (chunk_size & 1)
                if chunk_end > riff_end:
                    raise ValueError('WAVE chunk exceeds RIFF boundary')

                if chunk_id == b'fmt ':
                    if chunk_size < 16:
                        raise ValueError('Invalid WAVE format chunk')
                    format_data = self._file.read(min(chunk_size, 40))
                    if len(format_data) < 16:
                        raise ValueError('Truncated WAVE format chunk')
                    format_code, channels, rate, _, block_alignment, bits = struct.unpack(
                        '<HHIIHH', format_data[:16]
                    )
                    if format_code == 0xFFFE:
                        if chunk_size < 40 or len(format_data) < 40:
                            raise ValueError('Incomplete extensible WAVE format')
                        extension_size = struct.unpack('<H', format_data[16:18])[0]
                        valid_bits = struct.unpack('<H', format_data[18:20])[0]
                        subformat = format_data[24:40]
                        if (extension_size < 22
                                or 18 + extension_size > chunk_size
                                or subformat != _PCM_SUBFORMAT_GUID
                                or valid_bits < 1
                                or valid_bits > bits):
                            raise ValueError('Unsupported extensible WAVE format')
                        format_code = 1
                    sample_width = bits // 8
                    if (
                        format_code != 1
                        or channels < 1
                        or rate < 1
                        or bits not in (8, 16, 24, 32)
                        or block_alignment != channels * sample_width
                    ):
                        raise ValueError('Expected uncompressed PCM WAVE')
                    format_info = (channels, sample_width, block_alignment)
                elif chunk_id == b'data' and data_offset is None:
                    data_offset = chunk_start
                    data_size = chunk_size

                if format_info is not None and data_offset is not None:
                    break
                self._file.seek(chunk_end)

            if format_info is None or data_offset is None:
                raise ValueError('Missing WAVE format or data chunk')

            self._channels, self._sample_width, self._block_alignment = format_info
            if data_size % self._block_alignment:
                raise ValueError('Incomplete PCM frame in WAVE data')
            self._frame_count = data_size // self._block_alignment
            self._file.seek(data_offset)
        except Exception:
            self._file.close()
            raise

    def getnchannels(self):
        return self._channels

    def getsampwidth(self):
        return self._sample_width

    def getnframes(self):
        return self._frame_count

    def getcomptype(self):
        return 'NONE'

    def tell(self):
        return self._frames_read

    def readframes(self, count):
        remaining = self._frame_count - self._frames_read
        frames = min(max(0, count), remaining)
        length = frames * self._block_alignment
        data = self._file.read(length)
        if len(data) != length:
            raise EOFError('Truncated WAVE data chunk')
        self._frames_read += frames
        return data

    def close(self):
        self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


class PCM16MonoWaveReader(PCMWaveReader):
    """Read the 16-bit mono PCM WAVE produced by macOS afconvert."""

    def __init__(self, path):
        super().__init__(path)
        if self.getnchannels() != 1 or self.getsampwidth() != 2:
            self.close()
            raise ValueError('Expected 16-bit mono PCM WAVE')


def _pcm_block_peak(frame_data, sample_width, audioop_module=None):
    """Return the largest absolute PCM sample in one complete frame block."""
    if sample_width < 1 or len(frame_data) % sample_width:
        raise ValueError('Incomplete PCM sample')
    if not frame_data:
        return 0
    if audioop_module is not None:
        try:
            if sample_width == 1:
                # WAVE 8-bit PCM is unsigned; audioop treats 8-bit samples as signed.
                frame_data = audioop_module.bias(frame_data, 1, -128)
            return audioop_module.max(frame_data, sample_width)
        except Exception:
            pass
    if sample_width == 1:
        return max(
            (abs(sample[0] - 128) for sample in struct.iter_unpack('B', frame_data)),
            default=0,
        )
    if sample_width == 2:
        samples = struct.iter_unpack('<h', frame_data)
    elif sample_width == 3:
        peak = 0
        for offset in range(0, len(frame_data), 3):
            sample = (
                frame_data[offset] |
                (frame_data[offset + 1] << 8) |
                (frame_data[offset + 2] << 16)
            )
            if sample & 0x800000:
                sample -= 0x1000000
            peak = max(peak, abs(sample))
        return peak
    elif sample_width == 4:
        samples = struct.iter_unpack('<i', frame_data)
    else:
        raise ValueError('Unsupported PCM sample width')
    return max((abs(sample[0]) for sample in samples), default=0)


def decode_pcm_waveform(path, cancelled=None, audioop_module=None):
    """Decode little-endian PCM WAVE into at most 512 normalized peaks.

    Parsing is self-contained so it works in Live runtimes without wave.py or
    audioop. audioop is used only when a caller supplies it as an optional
    native acceleration; the struct implementation always remains available.
    Unsupported, malformed, compressed, or unreadable files return no peaks.
    """
    cancelled = cancelled or (lambda: False)
    try:
        if cancelled():
            return []
        with PCMWaveReader(path) as audio_file:
            channels = audio_file.getnchannels()
            sample_width = audio_file.getsampwidth()
            frame_count = audio_file.getnframes()
            if (
                channels < 1
                or sample_width not in (1, 2, 3, 4)
                or audio_file.getcomptype() != 'NONE'
                or frame_count <= 0
            ):
                return []

            point_count = min(512, frame_count)
            peaks = []
            bytes_per_frame = channels * sample_width
            frames_read = 0
            bytes_since_yield = 0

            for point_index in range(point_count):
                end_frame = ((point_index + 1) * frame_count) // point_count
                remaining = end_frame - frames_read
                point_peak = 0
                while remaining > 0:
                    if cancelled():
                        return []
                    frames_per_chunk_limit = max(1, 65536 // bytes_per_frame)
                    chunk_frames = min(8192, frames_per_chunk_limit, remaining)
                    frame_data = audio_file.readframes(chunk_frames)
                    if len(frame_data) != chunk_frames * bytes_per_frame:
                        raise EOFError('Truncated PCM WAVE data')
                    point_peak = max(
                        point_peak,
                        _pcm_block_peak(frame_data, sample_width, audioop_module),
                    )
                    frames_read += chunk_frames
                    remaining -= chunk_frames
                    bytes_since_yield += len(frame_data)
                    if bytes_since_yield >= 1024 * 1024:
                        time.sleep(0.001)
                        bytes_since_yield = 0
                peaks.append(point_peak)

            maximum_peak = max(peaks) if peaks else 0
            if maximum_peak > 0:
                return [
                    max(0, min(127, int(round(float(value) * 127.0 / maximum_peak))))
                    for value in peaks
                ]
            return [0 for _ in peaks]
    except Exception:
        return []
