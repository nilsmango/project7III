"""Read the exact PCM format requested from afconvert without wave."""

import struct


def pcm16_peak(frame_data, audioop_module=None):
    """Use Live's fast path when present; otherwise scan the same PCM samples."""
    if len(frame_data) % 2:
        raise ValueError('Incomplete 16-bit PCM sample')
    if not frame_data:
        return 0
    if audioop_module is not None:
        return audioop_module.max(frame_data, 2)
    return max(abs(sample[0]) for sample in struct.iter_unpack('<h', frame_data))


class PCM16MonoWaveReader:
    def __init__(self, path):
        self._file = open(path, 'rb')
        self._frames_read = 0
        try:
            header = self._file.read(12)
            if len(header) != 12 or header[:4] != b'RIFF' or header[8:] != b'WAVE':
                raise ValueError('Not a RIFF WAVE file')

            format_found = False
            while True:
                chunk_header = self._file.read(8)
                if len(chunk_header) != 8:
                    raise ValueError('Missing WAVE data chunk')
                chunk_id, chunk_size = struct.unpack('<4sI', chunk_header)
                if chunk_id == b'fmt ':
                    format_data = self._file.read(chunk_size)
                    if len(format_data) != chunk_size or chunk_size < 16:
                        raise ValueError('Invalid WAVE format chunk')
                    encoding, channels, rate, _, alignment, bits = struct.unpack(
                        '<HHIIHH', format_data[:16]
                    )
                    if (encoding, channels, alignment, bits) != (1, 1, 2, 16) or rate == 0:
                        raise ValueError('Expected 16-bit mono PCM WAVE')
                    format_found = True
                elif chunk_id == b'data':
                    if not format_found or chunk_size % 2:
                        raise ValueError('Invalid 16-bit PCM data chunk')
                    self._frame_count = chunk_size // 2
                    break
                else:
                    self._file.seek(chunk_size, 1)
                if chunk_size % 2:
                    self._file.seek(1, 1)
        except Exception:
            self._file.close()
            raise

    def getnframes(self):
        return self._frame_count

    def tell(self):
        return self._frames_read

    def readframes(self, count):
        length = 2 * min(max(0, count), self._frame_count - self._frames_read)
        data = self._file.read(length)
        if len(data) != length:
            raise EOFError('Truncated WAVE data chunk')
        self._frames_read += len(data) // 2
        return data

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self._file.close()
