"""Helpers for decoding PCM waveforms from Live audio files."""

import struct
import time
import wave


def pcm16_peak(frame_data, audioop_module=None):
    """Use Live's fast path when present; otherwise scan the same PCM samples."""
    if len(frame_data) % 2:
        raise ValueError('Incomplete 16-bit PCM sample')
    if not frame_data:
        return 0
    if audioop_module is not None:
        return audioop_module.max(frame_data, 2)
    return max(abs(sample[0]) for sample in struct.iter_unpack('<h', frame_data))


class PCM16MonoWaveReader:
    def __init__(self, path):
        self._file = open(path, 'rb')
        self._frames_read = 0
        try:
            header = self._file.read(12)
            if len(header) != 12 or header[:4] != b'RIFF' or header[8:] != b'WAVE':
                raise ValueError('Not a RIFF WAVE file')

            format_found = False
            while True:
                chunk_header = self._file.read(8)
                if len(chunk_header) != 8:
                    raise ValueError('Missing WAVE data chunk')
                chunk_id, chunk_size = struct.unpack('<4sI', chunk_header)
                if chunk_id == b'fmt ':
                    format_data = self._file.read(chunk_size)
                    if len(format_data) != chunk_size or chunk_size < 16:
                        raise ValueError('Invalid WAVE format chunk')
                    encoding, channels, rate, _, alignment, bits = struct.unpack(
                        '<HHIIHH', format_data[:16]
                    )
                    if (encoding, channels, alignment, bits) != (1, 1, 2, 16) or rate == 0:
                        raise ValueError('Expected 16-bit mono PCM WAVE')
                    format_found = True
                elif chunk_id == b'data':
                    if not format_found or chunk_size % 2:
                        raise ValueError('Invalid 16-bit PCM data chunk')
                    self._frame_count = chunk_size // 2
                    break
                else:
                    self._file.seek(chunk_size, 1)
                if chunk_size % 2:
                    self._file.seek(1, 1)
        except Exception:
            self._file.close()
            raise

    def getnframes(self):
        return self._frame_count

    def tell(self):
        return self._frames_read

    def readframes(self, count):
        length = 2 * min(max(0, count), self._frame_count - self._frames_read)
        data = self._file.read(length)
        if len(data) != length:
            raise EOFError('Truncated WAVE data chunk')
        self._frames_read += len(data) // 2
        return data

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self._file.close()


def _pcm_block_peak(frame_data, sample_width, audioop_module=None):
    """Return the largest absolute PCM sample in one complete frame block."""
    if len(frame_data) % sample_width:
        raise ValueError('Incomplete PCM sample')
    if not frame_data:
        return 0
    if audioop_module is not None:
        try:
            if sample_width == 1:
                # WAVE 8-bit PCM is unsigned; audioop treats 8-bit samples as signed.
                frame_data = audioop_module.bias(frame_data, 1, -128)
            return audioop_module.max(frame_data, sample_width)
        except Exception:
            # Keep the fallback usable on alternate runtimes or audioop builds.
            pass
    if sample_width == 1:
        return max(
            (abs(sample[0] - 128) for sample in struct.iter_unpack('B', frame_data)),
            default=0,
        )
    if sample_width == 2:
        samples = struct.iter_unpack('<h', frame_data)
    elif sample_width == 3:
        peak = 0
        for offset in range(0, len(frame_data), 3):
            sample = (
                frame_data[offset] |
                (frame_data[offset + 1] << 8) |
                (frame_data[offset + 2] << 16)
            )
            if sample & 0x800000:
                sample -= 0x1000000
            peak = max(peak, abs(sample))
        return peak
    elif sample_width == 4:
        samples = struct.iter_unpack('<i', frame_data)
    else:
        raise ValueError('Unsupported PCM sample width')
    return max((abs(sample[0]) for sample in samples), default=0)


def decode_pcm_waveform(path, cancelled=None, audioop_module=None):
    """Best-effort decode of an uncompressed PCM WAV into at most 512 peaks.

    Reads each output bin sequentially and exactly. When available, audioop's C
    implementation accelerates peak scans; struct keeps this portable without it.
    Returns an empty list for compressed, unsupported, malformed, or unreadable
    files.
    """
    cancelled = cancelled or (lambda: False)
    try:
        if cancelled():
            return []
        with wave.open(path, 'rb') as audio_file:
            channels = audio_file.getnchannels()
            sample_width = audio_file.getsampwidth()
            frame_count = audio_file.getnframes()
            if (
                channels < 1 or
                sample_width not in (1, 2, 3, 4) or
                audio_file.getcomptype() != 'NONE' or
                frame_count <= 0
            ):
                return []

            point_count = min(512, frame_count)
            peaks = []
            bytes_per_frame = channels * sample_width
            frames_read = 0
            bytes_since_yield = 0

            for point_index in range(point_count):
                end_frame = ((point_index + 1) * frame_count) // point_count
                remaining = end_frame - frames_read
                point_peak = 0
                while remaining > 0:
                    if cancelled():
                        return []
                    frames_per_chunk_limit = max(1, 65536 // bytes_per_frame)
                    chunk_frames = min(8192, frames_per_chunk_limit, remaining)
                    frame_data = audio_file.readframes(chunk_frames)
                    if len(frame_data) != chunk_frames * bytes_per_frame:
                        raise EOFError('Truncated PCM WAVE data')
                    point_peak = max(
                        point_peak,
                        _pcm_block_peak(frame_data, sample_width, audioop_module),
                    )
                    frames_read += chunk_frames
                    remaining -= chunk_frames
                    bytes_since_yield += len(frame_data)
                    if bytes_since_yield >= 1024 * 1024:
                        time.sleep(0.001)
                        bytes_since_yield = 0
                peaks.append(point_peak)

            maximum_peak = max(peaks) if peaks else 0
            if maximum_peak > 0:
                return [
                    max(0, min(127, int(round(float(value) * 127.0 / maximum_peak))))
                    for value in peaks
                ]
            return [0 for _ in peaks]
    except Exception:
        return []
