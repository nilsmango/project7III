# 7III Tap 2.0.3

from __future__ import with_statement
import Live
from _Framework.ControlSurface import ControlSurface
from _Framework.MixerComponent import MixerComponent
from _Framework.TransportComponent import TransportComponent
from _Framework.SessionComponent import SessionComponent
from _Framework.EncoderElement import *
from _Framework.ButtonElement import ButtonElement
from _Framework.SliderElement import SliderElement
from _Framework.InputControlElement import MIDI_NOTE_TYPE, MIDI_NOTE_ON_STATUS, MIDI_NOTE_OFF_STATUS, MIDI_CC_TYPE
from _Framework.DeviceComponent import DeviceComponent
from ableton.v2.base import listens, liveobj_valid, liveobj_changed
try:
    from ableton.v2.control_surface import SimplerDeviceDecorator
except ImportError:
    SimplerDeviceDecorator = None
try:
    from ableton.v2.control_surface.simpler_slice_nudging import SimplerSliceNudging
except ImportError:
    SimplerSliceNudging = None
try:
    # Push's decorator exposes all of Drift's API-backed selectors (mod
    # sources/targets, shape source, voice mode/count, and on/off options).
    # The generic decorator only exposes four of these controls.
    from Push2.drift import DriftDeviceDecorator
    from ableton.v2.control_surface.drift_decoration import DriftDeviceDecorator as BaseDriftDeviceDecorator
except ImportError:
    try:
        from ableton.v2.control_surface.drift_decoration import DriftDeviceDecorator
        BaseDriftDeviceDecorator = DriftDeviceDecorator
    except ImportError:
        DriftDeviceDecorator = None
        BaseDriftDeviceDecorator = None
try:
    from Push2.meld import MeldDeviceDecorator
except ImportError:
    MeldDeviceDecorator = None
try:
    from Push2.hybrid_reverb import HybridReverbDeviceDecorator
except ImportError:
    HybridReverbDeviceDecorator = None
try:
    from ableton.v2.control_surface import BankingInfo, DescribedDeviceParameterBank
    from Push2.custom_bank_definitions import BANK_DEFINITIONS as PUSH_BANK_DEFINITIONS
    from Push2.device_decorator_factory import DeviceDecoratorFactory as PushDeviceDecoratorFactory
except Exception:
    BankingInfo = None
    DescribedDeviceParameterBank = None
    PUSH_BANK_DEFINITIONS = {}
    PushDeviceDecoratorFactory = None
try:
    from Push2.device_parameter_bank_with_options import DescribedDeviceParameterBankWithOptions
except Exception:
    DescribedDeviceParameterBankWithOptions = None
try:
    from Move.custom_bank_definitions import CUSTOM_BANK_DEFINITIONS as MOVE_BANK_DEFINITIONS
except Exception:
    MOVE_BANK_DEFINITIONS = {}
from Live.Clip import MidiNoteSpecification

import threading
import random
import re
import math
import os
import shutil
import struct
import subprocess
import tempfile
import wave
from urllib.parse import unquote, urlparse
try:
    import audioop
except ImportError:
    audioop = None
from itertools import zip_longest
import time

secret_version_number = 33

mixer, transport, session_component = None, None, None
quantize_grid_value = 5
quantize_strength_value = 1.0
swing_amount_value = 0.0


class TapDeviceComponent(DeviceComponent):
    SAFE_PARAMETER_BANK_SIZE = 8
    CURATED_PUSH_BANK_CLASSES = frozenset((
        'Chorus2',
        'Tube',
        'PhaserNew',
        'Reverb',
        'Roar',
        'Shifter',
        'Transmute',
        'Spectral',
        'Saturator',
        'MidiRandom',
        'MidiScale',
        'Eq8',
    ))
    CURATED_MOVE_BANK_CLASSES = frozenset((
        'AutoPan2',
        'AutoShift',
        'FilterEQ3',
        'Redux2',
        'Resonator',
        'Vinyl',
    ))
    AUTO_SHIFT_DETAILS_BANK_NAME = "Shift"
    AUTO_PAN_MODE_BANK_NAME = "Mode"
    CHORUS_MODE_BANK_NAME = "Mode"
    CHORD_SHIFT_SCALE_BANK_NAME = "Shift Scale"
    CHORD_STRUM_BANK_NAME = "Strum"
    CURATED_OPTIONS_BANK_NAME = "Options"
    OPERATOR_WAVES_BANK_NAME = "Waveforms"
    OPERATOR_FILTER_PLUS_BANK_NAME = "Filter +"
    OPERATOR_LFO_PLUS_BANK_NAME = "LFO +"
    WAVETABLE_OSC_BANK_NAME = "Waves"
    WAVETABLE_ENV_2_BANK_NAME = "Envelope 2"
    WAVETABLE_ENV_3_BANK_NAME = "Envelope 3"
    SIMPLER_MAIN_BANK_NAME = "Main"
    SIMPLER_ACTIONS_BANK_NAME = "Actions"
    SIMPLER_WARP_BANK_NAME = "Controls"
    SIMPLER_CONTROLS_2_BANK_NAME = "Controls 2"
    SIMPLER_BROWSE_BANK_NAME = "Browse"
    SIMPLER_BROWSE_PLUS_BANK_NAME = "Browse +"
    SIMPLER_AMP_BANK_NAME = "Volume"
    SIMPLER_SLICE_DETAIL_BANK_NAME = "Pitch & Fade"
    SIMPLER_AMP_BANK_INDEX = 3
    DRUMCELL_SAMPLE_BANK_NAME = "Sample"
    DRUMCELL_FX_FILTER_BANK_NAME = "FX & Filter"
    DRUMCELL_REST_BANK_NAME = "Main & Mod"
    DRUMCELL_FX_2_BANK_NAME = "FX P"
    DRUMCELL_FX_3_BANK_NAME = "FX P2"
    DELAY_BANK_NAMES = ("Main", "Time / Flt", "Flt / LFO", "LFO Wave")
    GRAIN_DELAY_BANK_NAMES = ("Pitch", "Time")
    AUTO_FILTER_BANK_NAMES = ("Main", "Envelope", "LFO", "Sidechain")
    AUTO_FILTER_2_BANK_NAMES = ("Main", "LFO", "Envelope", "Quantization")
    BEAT_REPEAT_BANK_NAMES = ("Main", "Filt/Mix", "Repeat Rate")
    HYBRID_REVERB_BANK_NAMES = (
        "Main", "Convolution", "Algorithm Pg1", "Algorithm Pg2",
        "EQ Pg1", "EQ Pg2", "Global",
    )
    DRIFT_BANK_NAMES = (
        "Main", "Oscillators", "Osc 2 / Noise", "Osc Mod", "Filters", "Filter Mod",
        "Envelope 1", "Envelope 2", "Envelope 2 Cyc", "LFO", "Mod 1 & 2", "Mod 3",
        "Global", "Global / Out",
    )
    MELD_ENGINE_BANK_NAME = "A | B"
    MELD_BANK_NAMES = (
        MELD_ENGINE_BANK_NAME,
        "Main",
        "Osc / Mix",
        "Filter",
        "Amp Envelope",
        "Mod Envelope",
        "Envelope Setup",
        "LFO 1 Generator",
        "LFO 1 FX",
        "LFO 2",
        "Global / Out",
    )
    ANALOG_OSC_1_BANK_NAME = "OSC 1"
    ANALOG_OSC_2_BANK_NAME = "OSC 2"
    ANALOG_NOISE_BANK_NAME = "Noise"
    ANALOG_OSC_PLUS_BANK_NAME = "OSC +"
    ANALOG_MIX_LFO_BANK_NAME = "Mix / LFO"
    ANALOG_LFO_PLUS_BANK_NAME = "LFO +"
    ANALOG_LOOPS_FILTER_BANK_NAME = "Loops / Filter"

    def __init__(self, *a, **k):
        DeviceComponent.__init__(self, *a, **k)
        self._use_safe_parameter_banks = False
        self._parameter_bank_cache = None
        self._parameter_bank_cache_device = None
        self._curated_parameter_display_names = ()
        self._curated_bank_names_cache = None
        self._curated_option_pages_cache = None
        self._curated_dynamic_parameter_keys_cache = None
        self._drift_decorator = None
        self._drift_decorator_device = None
        self._drift_base_decorator = None
        self._meld_decorator = None
        self._meld_decorator_device = None
        self._hybrid_reverb_decorator = None
        self._hybrid_reverb_decorator_device = None
        self._simpler_bank_decorator = None
        self._simpler_bank_decorator_device = None
        self._curated_decorator_factory = None
        if PushDeviceDecoratorFactory is not None:
            try:
                self._curated_decorator_factory = PushDeviceDecoratorFactory()
            except Exception:
                pass

    def invalidate_parameter_bank_cache(self):
        self._parameter_bank_cache = None
        self._parameter_bank_cache_device = None
        self._curated_parameter_display_names = ()
        self._curated_bank_names_cache = None
        self._curated_option_pages_cache = None
        self._curated_dynamic_parameter_keys_cache = None

    def set_device(self, device):
        if device != getattr(self, '_device', None):
            self._disconnect_drift_decorator()
            self._disconnect_meld_decorator()
            self._disconnect_hybrid_reverb_decorator()
            self._disconnect_simpler_bank_decorator()
            self._sync_curated_decorators(device)
        self.invalidate_parameter_bank_cache()
        self._use_safe_parameter_banks = False
        try:
            result = DeviceComponent.set_device(self, device)
            if self._is_meld() and self._bank_index == 0:
                self._bank_index = 1
                self.update()
            return result
        except IndexError:
            self._use_safe_parameter_banks = True
            self._bank_index = 1 if self._is_meld() else 0
            try:
                self.update()
            except Exception:
                pass
            try:
                self.notify_device()
            except Exception:
                pass

    def disconnect(self):
        self._disconnect_drift_decorator()
        self._disconnect_meld_decorator()
        self._disconnect_hybrid_reverb_decorator()
        self._disconnect_simpler_bank_decorator()
        factory = self._curated_decorator_factory
        self._curated_decorator_factory = None
        if factory:
            try:
                factory.disconnect()
            except Exception:
                pass
        DeviceComponent.disconnect(self)

    def update(self):
        try:
            return DeviceComponent.update(self)
        except IndexError:
            self._use_safe_parameter_banks = True
            self._clamp_bank_index_to_safe_banks()
            try:
                return DeviceComponent.update(self)
            except IndexError:
                pass

    def _current_bank_details(self):
        try:
            return DeviceComponent._current_bank_details(self)
        except IndexError:
            self._use_safe_parameter_banks = True
            self._clamp_bank_index_to_safe_banks()
            try:
                return DeviceComponent._current_bank_details(self)
            except IndexError:
                return '', tuple([None] * self.SAFE_PARAMETER_BANK_SIZE)

    def _parameter_banks(self):
        device = getattr(self, '_device', None)
        uses_curated_banks = self._uses_curated_banks()
        uses_cache = (
            self._is_operator() or self._is_chord() or self._is_drift() or self._is_meld() or
            self._is_hybrid_reverb() or uses_curated_banks
        )
        if (uses_cache and self._parameter_bank_cache is not None and
                self._parameter_bank_cache_device == device):
            return list(self._parameter_bank_cache)

        if uses_curated_banks:
            curated_banks = self._curated_parameter_banks()
            if curated_banks:
                self._parameter_bank_cache = tuple(curated_banks)
                self._parameter_bank_cache_device = device
                return list(curated_banks)
            try:
                return list(DeviceComponent._parameter_banks(self))
            except IndexError:
                self._use_safe_parameter_banks = True
                return self._safe_parameter_banks()

        base_names = self._base_parameter_bank_names()
        if self._use_safe_parameter_banks:
            banks = self._safe_parameter_banks()
        else:
            try:
                banks = DeviceComponent._parameter_banks(self)
            except IndexError:
                self._use_safe_parameter_banks = True
                base_names = self._safe_parameter_bank_names_base()
                banks = self._safe_parameter_banks()
        banks = self._add_tap_custom_banks(banks, base_names)
        if uses_cache:
            self._parameter_bank_cache = tuple(banks)
            self._parameter_bank_cache_device = device
        return banks

    def _parameter_bank_names(self):
        if self._uses_curated_banks():
            curated_names = self._curated_bank_names()
            if curated_names:
                return curated_names
        return self._add_tap_custom_bank_names(self._base_parameter_bank_names())

    def _best_of_parameter_bank(self):
        if self._use_safe_parameter_banks:
            return []
        try:
            return DeviceComponent._best_of_parameter_bank(self)
        except IndexError:
            self._use_safe_parameter_banks = True
            return []

    def _number_of_parameter_banks(self):
        return len(self._parameter_banks())

    def _base_parameter_bank_names(self):
        if self._use_safe_parameter_banks:
            # Simpler's native parameter lookup can briefly fail while its
            # sample mode is changing.  Keep Live's curated names even when
            # the safer parameter lookup is needed; otherwise the fallback
            # leaks unstable "Bank 1" ... "Bank 7" labels to Tap.
            if self._is_simpler():
                try:
                    return tuple(DeviceComponent._parameter_bank_names(self))
                except IndexError:
                    pass
            return self._safe_parameter_bank_names_base()
        try:
            return tuple(DeviceComponent._parameter_bank_names(self))
        except IndexError:
            self._use_safe_parameter_banks = True
            return self._safe_parameter_bank_names_base()

    def _safe_parameter_bank_names_base(self):
        bank_count = len(self._safe_parameter_banks())
        device = getattr(self, '_device', None)
        names = []
        for index in range(bank_count):
            name = None
            if device and hasattr(device, 'get_bank_name'):
                try:
                    name = device.get_bank_name(index)
                except Exception:
                    pass
            if name:
                name = ''.join(char for char in str(name) if ord(char) < 128)
            names.append(name or "Bank {}".format(index + 1))
        return tuple(names)

    def _device_class_name(self):
        try:
            return str(self._device.class_name)
        except Exception:
            return ""

    def _is_operator(self):
        return self._device_class_name() == 'Operator'

    def _is_chord(self):
        return self._device_class_name() == 'MidiChord'

    def _is_wavetable(self):
        device = getattr(self, '_device', None)
        try:
            return (
                self._device_class_name() in ('Wavetable', 'InstrumentVector') or
                str(device.class_display_name) == 'Wavetable' or
                hasattr(device, 'oscillator_1_wavetables')
            )
        except Exception:
            return False

    def _is_simpler(self):
        return self._device_class_name() == 'OriginalSimpler'

    def _simpler_uses_native_banks(self):
        if not self._is_simpler():
            return False
        try:
            return bool(self._device.multi_sample_mode)
        except Exception:
            # If this Live version cannot expose multisample mode, a missing
            # sample is ambiguous. Keep the normal parameter banks instead of
            # presenting Simpler as empty; Browse remains available in its own
            # bank.
            try:
                return not liveobj_valid(self._device.sample)
            except Exception:
                return True

    def _is_drumcell(self):
        return self._device_class_name() == 'DrumCell'

    def _is_delay(self):
        return self._device_class_name() == 'Delay'

    def _is_grain_delay(self):
        return self._device_class_name() == 'GrainDelay'

    def _is_analog(self):
        return self._device_class_name() == 'UltraAnalog'

    def _is_auto_filter(self):
        try:
            return (
                self._device_class_name() == 'AutoFilter' or
                (str(self._device.class_display_name) == 'Auto Filter' and
                 not self._is_auto_filter_2())
            )
        except Exception:
            return False

    def _is_auto_filter_2(self):
        return self._device_class_name() == 'AutoFilter2'

    def _is_beat_repeat(self):
        try:
            return (
                self._device_class_name() == 'BeatRepeat' or
                str(self._device.class_display_name) == 'Beat Repeat'
            )
        except Exception:
            return False

    def _is_hybrid_reverb(self):
        try:
            return (
                self._device_class_name() in ('Hybrid', 'HybridReverb') or
                str(self._device.class_display_name) == 'Hybrid Reverb'
            )
        except Exception:
            return False

    def _is_drift(self):
        try:
            return self._device_class_name() == 'Drift' or str(self._device.class_display_name) == 'Drift'
        except Exception:
            return False

    def _is_meld(self):
        device = getattr(self, '_device', None)
        try:
            return (
                self._device_class_name() in ('InstrumentMeld', 'Meld') or
                str(device.class_display_name) == 'Meld' or
                hasattr(device, 'selected_engine')
            )
        except Exception:
            return False

    def _curated_bank_source(self):
        class_name = self._device_class_name()
        if class_name in self.CURATED_MOVE_BANK_CLASSES and class_name in MOVE_BANK_DEFINITIONS:
            return MOVE_BANK_DEFINITIONS
        if class_name in self.CURATED_PUSH_BANK_CLASSES and class_name in PUSH_BANK_DEFINITIONS:
            return PUSH_BANK_DEFINITIONS
        return None

    def _curated_bank_definition(self):
        source = self._curated_bank_source()
        return source.get(self._device_class_name()) if source else None

    def _curated_dynamic_parameter_keys(self):
        cached = self._curated_dynamic_parameter_keys_cache
        if cached is not None:
            return cached

        condition_names = set()
        definitions = []
        for definition in (
                self._curated_bank_definition(),
                PUSH_BANK_DEFINITIONS.get(self._device_class_name())):
            if definition and not any(definition is existing for existing in definitions):
                definitions.append(definition)
        for definition in definitions:
            for bank_definition in definition.values():
                for slots in bank_definition.values():
                    if not isinstance(slots, (tuple, list)):
                        continue
                    for slot in slots:
                        for condition in getattr(slot, '_conditions', ()) or ():
                            condition_list = condition.get('ConditionsListName', ())
                            for subcondition in condition_list:
                                name = subcondition.get('ConditionName')
                                if name:
                                    condition_names.add(str(name))

        # These custom pages switch parameter identity with the device mode.
        if self._device_class_name() in ('AutoPan2', 'Chorus2'):
            condition_names.add('Mode')

        self._curated_dynamic_parameter_keys_cache = frozenset(
            re.sub(r'[^a-z0-9]+', '', name.lower())
            for name in condition_names
        )
        return self._curated_dynamic_parameter_keys_cache

    def curated_parameter_drives_bank(self, parameter):
        if parameter is None or not self._uses_curated_banks():
            return False
        names = (
            str(getattr(parameter, 'name', '')),
            str(getattr(parameter, 'original_name', '')),
        )
        parameter_keys = set(
            re.sub(r'[^a-z0-9]+', '', name.lower())
            for name in names
        )
        return bool(parameter_keys.intersection(self._curated_dynamic_parameter_keys()))

    def _uses_curated_banks(self):
        return (
            BankingInfo is not None and
            DescribedDeviceParameterBank is not None and
            self._curated_bank_definition() is not None
        )

    def _sync_curated_decorators(self, device):
        factory = self._curated_decorator_factory
        if not factory:
            return
        try:
            factory.sync_decorated_objects([device] if liveobj_valid(device) else [])
        except Exception:
            pass

    def _curated_decorated_device(self):
        device = getattr(self, '_device', None)
        factory = self._curated_decorator_factory
        if not factory or not liveobj_valid(device):
            return device
        try:
            return factory.decorate(device)
        except Exception:
            return device

    def _curated_bank_names(self):
        if self._curated_bank_names_cache is not None:
            return self._curated_bank_names_cache
        definition = self._curated_bank_definition()
        names = list(definition.keys()) if definition else []
        if self._device_class_name() == 'AutoShift' and names:
            names.append(self.AUTO_SHIFT_DETAILS_BANK_NAME)
        elif self._device_class_name() == 'AutoPan2' and names:
            names.append(self.AUTO_PAN_MODE_BANK_NAME)
        elif self._device_class_name() == 'Chorus2' and names:
            names.append(self.CHORUS_MODE_BANK_NAME)
        option_page_count = len(self._curated_option_pages())
        if option_page_count == 1:
            names.append(self.CURATED_OPTIONS_BANK_NAME)
        elif option_page_count > 1:
            names.extend(
                "{} {}".format(self.CURATED_OPTIONS_BANK_NAME, index + 1)
                for index in range(option_page_count)
            )
        self._curated_bank_names_cache = tuple(names)
        return self._curated_bank_names_cache

    def _set_curated_shift_state(self, bank, shifted):
        has_shift_slots = False
        for slot in getattr(bank, '_dynamic_slots', ()):
            setter = getattr(slot, 'set_shifted_state', None)
            if callable(setter):
                has_shift_slots = True
                try:
                    setter(bool(shifted))
                except Exception:
                    pass
        if has_shift_slots:
            try:
                bank._update_parameters()
            except Exception:
                pass

    def _curated_bank_parameters(self, bank, index, shifted=False):
        bank.index = index
        self._set_curated_shift_state(bank, shifted)
        parameters = []
        display_names = []
        for item in getattr(bank, 'parameters', ()) or ():
            if isinstance(item, (tuple, list)):
                parameters.append(item[0] if item else None)
                display_names.append(item[1] if len(item) > 1 and item[1] else None)
            else:
                parameters.append(item)
                display_names.append(None)
        parameters.extend([None] * (self.SAFE_PARAMETER_BANK_SIZE - len(parameters)))
        display_names.extend([None] * (self.SAFE_PARAMETER_BANK_SIZE - len(display_names)))
        return (
            tuple(parameters[:self.SAFE_PARAMETER_BANK_SIZE]),
            tuple(display_names[:self.SAFE_PARAMETER_BANK_SIZE]),
        )

    def _curated_option_parameter(self, option):
        parameter = getattr(option, '_parameter', None)
        if parameter is None:
            parameter = getattr(option, '_property_host', None)
        return parameter

    def _curated_option_pages(self):
        if self._curated_option_pages_cache is not None:
            return self._curated_option_pages_cache
        definition = PUSH_BANK_DEFINITIONS.get(self._device_class_name())
        has_option_slots = bool(definition) and any(
            any(bool(slot) for slot in bank_definition.get('Options', ()))
            for bank_definition in definition.values()
        )
        if not has_option_slots:
            self._curated_option_pages_cache = ()
            return ()
        device = self._curated_decorated_device()
        if (
            not liveobj_valid(device) or
            BankingInfo is None or
            DescribedDeviceParameterBankWithOptions is None
        ):
            self._curated_option_pages_cache = ()
            return ()
        banking_info = BankingInfo({self._device_class_name(): definition})
        bank = None
        try:
            bank = DescribedDeviceParameterBankWithOptions(
                device=device,
                size=self.SAFE_PARAMETER_BANK_SIZE,
                banking_info=banking_info,
            )
            option_parameters = []
            option_names = []
            seen_parameters = set()
            for index in range(len(definition)):
                bank.index = index
                for option in getattr(bank, 'options', ()) or ():
                    if option is None:
                        continue
                    parameter = self._curated_option_parameter(option)
                    if parameter is None:
                        continue
                    parameter_key = id(parameter)
                    if parameter_key in seen_parameters:
                        continue
                    seen_parameters.add(parameter_key)
                    option_parameters.append(parameter)
                    name = str(getattr(option, 'name', '') or getattr(parameter, 'name', ''))
                    if name == 'frequency_dial_mode_opt':
                        name = 'Frequency Mode'
                    option_names.append(name)
            pages = []
            for start in range(0, len(option_parameters), self.SAFE_PARAMETER_BANK_SIZE):
                parameters = option_parameters[start:start + self.SAFE_PARAMETER_BANK_SIZE]
                display_names = option_names[start:start + self.SAFE_PARAMETER_BANK_SIZE]
                parameters.extend([None] * (self.SAFE_PARAMETER_BANK_SIZE - len(parameters)))
                display_names.extend([None] * (self.SAFE_PARAMETER_BANK_SIZE - len(display_names)))
                pages.append((tuple(parameters), tuple(display_names)))
            self._curated_option_pages_cache = tuple(pages)
            return self._curated_option_pages_cache
        except Exception:
            self._curated_option_pages_cache = ()
            return ()
        finally:
            if bank:
                try:
                    bank.disconnect()
                except Exception:
                    pass

    def _curated_auto_pan_mode_bank(self):
        mode = self._parameter_by_names('Mode')
        mode_name = self._parameter_display(mode).strip().lower()
        is_tremolo = 'tremolo' in mode_name
        is_panning = 'panning' in mode_name or 'pan' in mode_name
        parameters = (
            mode,
            self._parameter_by_names('Vintage') if is_tremolo else None,
            self._parameter_by_names('Stereo Mode') if is_panning else None,
        ) + tuple([None] * 5)
        display_names = ('Mode', 'Vintage' if is_tremolo else None,
                         'Stereo Mode' if is_panning else None) + tuple([None] * 5)
        return parameters, display_names

    def _curated_chorus_mode_bank(self):
        mode = self._parameter_by_names('Mode')
        mode_name = self._parameter_display(mode).strip().lower()
        is_chorus = 'classic' in mode_name or 'chorus' in mode_name
        parameters = (
            mode,
            self._parameter_by_names('Delay Time') if is_chorus else None,
            self._parameter_by_names('Delay Taps') if is_chorus else None,
            self._parameter_by_names('HP Enabled', 'HP On'),
            self._parameter_by_names('HP Freq'),
            None,
            None,
            self._parameter_by_names('Dry/Wet'),
        )
        display_names = (
            'Mode',
            'Delay Time' if is_chorus else None,
            'Delay Taps' if is_chorus else None,
            'HP On',
            'HP Freq',
            None,
            None,
            None,
        )
        return parameters, display_names

    def _add_internal_scale_parameter(self, resolved_banks):
        if self._device_class_name() != 'MidiScale' or not resolved_banks:
            return
        internal_scale = self._parameter_by_names('Internal Scale', 'InternalScale', 'Scale')
        if internal_scale is None:
            return
        parameters, display_names = resolved_banks[0]
        parameters = tuple((parameters[0], internal_scale) + parameters[1:7])
        display_names = tuple((display_names[0], 'Internal Scale') + display_names[1:7])
        resolved_banks[0] = parameters, display_names

    def _curated_parameter_banks(self):
        definition = self._curated_bank_definition()
        device = self._curated_decorated_device()
        if not definition or not liveobj_valid(device):
            return ()
        banking_info = BankingInfo({self._device_class_name(): definition})
        bank = None
        try:
            bank = DescribedDeviceParameterBank(
                device=device,
                size=self.SAFE_PARAMETER_BANK_SIZE,
                banking_info=banking_info,
            )
            resolved_banks = [
                self._curated_bank_parameters(bank, index)
                for index in range(len(definition))
            ]
            if self._device_class_name() == 'AutoShift' and resolved_banks:
                resolved_banks.append(self._curated_bank_parameters(bank, 0, shifted=True))
            elif self._device_class_name() == 'AutoPan2' and resolved_banks:
                resolved_banks.append(self._curated_auto_pan_mode_bank())
            elif self._device_class_name() == 'Chorus2' and resolved_banks:
                resolved_banks.append(self._curated_chorus_mode_bank())
            self._add_internal_scale_parameter(resolved_banks)
            resolved_banks.extend(self._curated_option_pages())
            self._curated_parameter_display_names = tuple(
                display_names for _, display_names in resolved_banks
            )
            return tuple(parameters for parameters, _ in resolved_banks)
        except Exception:
            self._curated_parameter_display_names = ()
            return ()
        finally:
            if bank:
                try:
                    bank.disconnect()
                except Exception:
                    pass

    def curated_parameter_display_name(self, parameter):
        try:
            bank_index = self._bank_index
            display_names = self._curated_parameter_display_names[bank_index]
            parameter_bank = self._parameter_bank_cache[bank_index]
            for index, candidate in enumerate(parameter_bank):
                if candidate is parameter and index < len(display_names):
                    return display_names[index]
        except Exception:
            pass
        return None

    def _disconnect_drift_decorator(self):
        decorator = self._drift_decorator
        base_decorator = self._drift_base_decorator
        self._drift_decorator = None
        self._drift_decorator_device = None
        self._drift_base_decorator = None
        if decorator:
            try:
                decorator.disconnect()
            except Exception:
                pass
        if base_decorator and base_decorator is not decorator:
            try:
                base_decorator.disconnect()
            except Exception:
                pass

    def _disconnect_meld_decorator(self):
        decorator = self._meld_decorator
        self._meld_decorator = None
        self._meld_decorator_device = None
        if decorator:
            try:
                decorator.disconnect()
            except Exception:
                pass

    def _disconnect_hybrid_reverb_decorator(self):
        decorator = self._hybrid_reverb_decorator
        self._hybrid_reverb_decorator = None
        self._hybrid_reverb_decorator_device = None
        if decorator:
            try:
                decorator.disconnect()
            except Exception:
                pass

    def _disconnect_simpler_bank_decorator(self):
        decorator = self._simpler_bank_decorator
        self._simpler_bank_decorator = None
        self._simpler_bank_decorator_device = None
        if decorator:
            try:
                decorator.disconnect()
            except Exception:
                pass

    def _decorated_parameters(self):
        device = getattr(self, '_device', None)
        if self._uses_curated_banks():
            decorated = self._curated_decorated_device()
            return tuple(getattr(decorated, 'parameters', getattr(device, 'parameters', ())))
        if self._is_hybrid_reverb() and HybridReverbDeviceDecorator is not None:
            if (self._hybrid_reverb_decorator is None or
                    self._hybrid_reverb_decorator_device != device):
                self._disconnect_hybrid_reverb_decorator()
                try:
                    self._hybrid_reverb_decorator = HybridReverbDeviceDecorator(live_object=device)
                    self._hybrid_reverb_decorator_device = device
                except TypeError:
                    try:
                        self._hybrid_reverb_decorator = HybridReverbDeviceDecorator(
                            live_object=device, additional_properties={}
                        )
                        self._hybrid_reverb_decorator_device = device
                    except Exception:
                        self._hybrid_reverb_decorator = None
                except Exception:
                    self._hybrid_reverb_decorator = None
            if self._hybrid_reverb_decorator:
                return tuple(self._hybrid_reverb_decorator.parameters)
        if self._is_simpler():
            decorated = []
            if SimplerDeviceDecorator is not None:
                if self._simpler_bank_decorator is None or self._simpler_bank_decorator_device != device:
                    self._disconnect_simpler_bank_decorator()
                    try:
                        self._simpler_bank_decorator = SimplerDeviceDecorator(
                            live_object=device, additional_properties={}
                        )
                        self._simpler_bank_decorator_device = device
                    except Exception:
                        self._simpler_bank_decorator = None
                if self._simpler_bank_decorator:
                    decorated.extend(self._simpler_bank_decorator.parameters)

            decorated_ids = set(id(parameter) for parameter in decorated)
            decorated.extend(
                parameter for parameter in getattr(device, 'parameters', ())
                if id(parameter) not in decorated_ids
            )
            # In multisample mode Simpler exposes the actual Sampler as a
            # nested device. Parameters such as "F On" and "Pe On" live there
            # rather than in OriginalSimpler's parameter list.
            sampler = getattr(device, 'sampler', None)
            if sampler and liveobj_valid(sampler):
                decorated_ids.update(id(parameter) for parameter in decorated)
                decorated.extend(
                    parameter for parameter in getattr(sampler, 'parameters', ())
                    if id(parameter) not in decorated_ids
                )
            return tuple(decorated)
        if self._is_drift() and DriftDeviceDecorator is not None:
            if self._drift_decorator is None or self._drift_decorator_device != device:
                self._disconnect_drift_decorator()
                try:
                    voice_mode = None
                    if BaseDriftDeviceDecorator is not None:
                        self._drift_base_decorator = BaseDriftDeviceDecorator(live_object=device)
                        voice_mode = next(
                            (parameter for parameter in self._drift_base_decorator.parameters
                             if str(getattr(parameter, 'name', '')) == 'Voice Mode'),
                            None
                        )
                    additional_properties = {'voice_mode': voice_mode} if voice_mode else {}
                    self._drift_decorator = DriftDeviceDecorator(
                        live_object=device, additional_properties=additional_properties
                    )
                    self._drift_decorator_device = device
                except Exception:
                    self._drift_decorator = None
            if self._drift_decorator:
                parameters = list(self._drift_decorator.parameters)
                if self._drift_base_decorator:
                    voice_mode = next(
                        (parameter for parameter in self._drift_base_decorator.parameters
                         if str(getattr(parameter, 'name', '')) == 'Voice Mode'),
                        None
                    )
                    if voice_mode:
                        parameters.append(voice_mode)
                return tuple(parameters)
        if self._is_meld() and MeldDeviceDecorator is not None:
            if self._meld_decorator is None or self._meld_decorator_device != device:
                self._disconnect_meld_decorator()
                try:
                    self._meld_decorator = MeldDeviceDecorator(live_object=device)
                    self._meld_decorator_device = device
                except Exception:
                    self._meld_decorator = None
            if self._meld_decorator:
                return tuple(self._meld_decorator.parameters)
        return tuple(getattr(device, 'parameters', ()))

    def _simpler_is_classic(self):
        try:
            return self._is_simpler() and int(self._device.playback_mode) == 0
        except Exception:
            return False

    def _simpler_is_slice(self):
        try:
            return self._is_simpler() and int(self._device.playback_mode) == 2
        except Exception:
            return False

    def _simpler_is_warped(self):
        try:
            sample = self._device.sample
            return liveobj_valid(sample) and bool(sample.warping)
        except Exception:
            return False

    def _simpler_browse_bank_name(self):
        return (
            self.SIMPLER_BROWSE_PLUS_BANK_NAME
            if self._simpler_uses_native_banks()
            else self.SIMPLER_BROWSE_BANK_NAME
        )

    def _custom_bank_insert_index(self, bank_names, anchor_name):
        anchor_name = re.sub(r'[^a-z0-9]+', '', anchor_name.lower())
        for index, name in enumerate(bank_names):
            normalized_name = re.sub(r'[^a-z0-9]+', '', str(name).lower())
            if anchor_name in normalized_name:
                return index + 1
        return len(bank_names)

    def _operator_waves_insert_index(self, bank_names):
        for index, name in enumerate(bank_names):
            normalized = re.sub(r'[^a-z0-9]+', '', str(name).lower())
            if normalized in ('oscd', 'oscillatord') or normalized.endswith('oscillatord'):
                return index + 1
        return len(bank_names)

    def _add_tap_custom_bank_names(self, bank_names):
        names = list(bank_names)
        if self._uses_curated_banks():
            names = list(self._curated_bank_names())
        elif self._is_auto_filter_2():
            names = list(self.AUTO_FILTER_2_BANK_NAMES)
        elif self._is_auto_filter():
            names = list(self.AUTO_FILTER_BANK_NAMES)
        elif self._is_beat_repeat():
            names = list(self.BEAT_REPEAT_BANK_NAMES)
        elif self._is_hybrid_reverb():
            names = list(self.HYBRID_REVERB_BANK_NAMES)
        elif self._is_drift():
            names = list(self.DRIFT_BANK_NAMES)
        elif self._is_meld():
            names = list(self.MELD_BANK_NAMES)
        elif self._is_chord():
            names.extend((
                self.CHORD_SHIFT_SCALE_BANK_NAME,
                self.CHORD_STRUM_BANK_NAME,
            ))
        elif self._is_operator():
            index = self._operator_waves_insert_index(names)
            names.insert(index, self.OPERATOR_WAVES_BANK_NAME)
            filter_index = self._operator_filter_bank_insert_index(names)
            names.insert(filter_index, self.OPERATOR_FILTER_PLUS_BANK_NAME)
            lfo_index = self._operator_lfo_bank_insert_index(names)
            names.insert(lfo_index, self.OPERATOR_LFO_PLUS_BANK_NAME)
        elif self._is_wavetable():
            self._replace_wavetable_envelope_bank_names(names)
            index = self._wavetable_waves_insert_index(names)
            names.insert(index, self.WAVETABLE_OSC_BANK_NAME)
        elif self._is_simpler():
            if not self._simpler_uses_native_banks():
                # Keep Live's native bank count and indices intact. Tap's
                # Push-like page replaces bank zero in place instead of
                # inserting a bank.
                if names:
                    names[0] = self.SIMPLER_MAIN_BANK_NAME
                else:
                    names.append(self.SIMPLER_MAIN_BANK_NAME)
                if self._simpler_is_classic() and len(names) > self.SIMPLER_AMP_BANK_INDEX:
                    names[self.SIMPLER_AMP_BANK_INDEX] = self.SIMPLER_AMP_BANK_NAME
                elif self._simpler_is_slice() and len(names) > self.SIMPLER_AMP_BANK_INDEX:
                    names[self.SIMPLER_AMP_BANK_INDEX] = self.SIMPLER_SLICE_DETAIL_BANK_NAME
                self._configure_simpler_control_bank_names(names)
                names.insert(1, self.SIMPLER_ACTIONS_BANK_NAME)
            names.append(self._simpler_browse_bank_name())
        elif self._is_analog():
            names = self._analog_bank_names(names)
        elif self._is_drumcell():
            custom_names = (
                self.DRUMCELL_SAMPLE_BANK_NAME,
                self.DRUMCELL_FX_FILTER_BANK_NAME,
                self.DRUMCELL_REST_BANK_NAME,
            )
            while len(names) < len(custom_names):
                names.append('Bank {}'.format(len(names) + 1))
            names[:len(custom_names)] = custom_names
            if len(names) > 3:
                names[3] = self.DRUMCELL_FX_2_BANK_NAME
            if len(names) > 4:
                names[4] = self.DRUMCELL_FX_3_BANK_NAME
        elif self._is_grain_delay():
            names = list(self.GRAIN_DELAY_BANK_NAMES)
        elif self._is_delay():
            names = list(self.DELAY_BANK_NAMES)
        return tuple(names)

    def _add_tap_custom_banks(self, banks, base_names):
        banks = list(banks)
        names = list(base_names)
        if self._uses_curated_banks():
            curated_banks = self._curated_parameter_banks()
            if curated_banks:
                banks = list(curated_banks)
        elif self._is_auto_filter_2():
            banks = list(self._auto_filter_2_parameter_banks())
        elif self._is_auto_filter():
            banks = list(self._auto_filter_parameter_banks())
        elif self._is_beat_repeat():
            banks = list(self._beat_repeat_parameter_banks())
        elif self._is_hybrid_reverb():
            banks = list(self._hybrid_reverb_parameter_banks())
        elif self._is_drift():
            banks = list(self._drift_parameter_banks())
        elif self._is_meld():
            banks = list(self._meld_parameter_banks())
        elif self._is_chord():
            banks.extend((
                self._chord_shift_scale_parameters(),
                self._chord_strum_parameters(),
            ))
        elif self._is_operator():
            self._replace_operator_lfo_bank(banks, names)
            waves = self._operator_wave_parameters(banks)
            index = self._operator_waves_insert_index(names)
            banks.insert(index, tuple(waves + [None] * (self.SAFE_PARAMETER_BANK_SIZE - len(waves))))
            names.insert(index, self.OPERATOR_WAVES_BANK_NAME)
            filter_index = self._operator_filter_bank_insert_index(names)
            banks.insert(filter_index, self._operator_filter_plus_parameters())
            names.insert(filter_index, self.OPERATOR_FILTER_PLUS_BANK_NAME)
            lfo_index = self._operator_lfo_bank_insert_index(names)
            banks.insert(lfo_index, self._operator_lfo_plus_parameters())
        elif self._is_wavetable():
            self._replace_wavetable_envelope_banks(banks, names)
            # These are Live.WavetableDevice properties, not DeviceParameters.
            # Tap handles their MIDI mapping and feedback directly.
            index = self._wavetable_waves_insert_index(names)
            banks.insert(index, tuple([None] * self.SAFE_PARAMETER_BANK_SIZE))
        elif self._is_simpler():
            uses_native_banks = self._simpler_uses_native_banks()
            if not uses_native_banks:
                if not banks:
                    banks.append(tuple([None] * self.SAFE_PARAMETER_BANK_SIZE))
                banks[0] = tuple([None] * self.SAFE_PARAMETER_BANK_SIZE)
                if self._simpler_is_classic() and len(banks) > self.SIMPLER_AMP_BANK_INDEX:
                    banks[self.SIMPLER_AMP_BANK_INDEX] = self._simpler_amp_parameters()
                elif self._simpler_is_slice() and len(banks) > self.SIMPLER_AMP_BANK_INDEX:
                    banks[self.SIMPLER_AMP_BANK_INDEX] = self._simpler_slice_detail_parameters()
                self._replace_simpler_lfo_bank(banks, names)
                self._configure_simpler_control_banks(banks, names)
                banks.insert(1, tuple([None] * self.SAFE_PARAMETER_BANK_SIZE))
            else:
                # DeviceComponent can expose more resolved C++ banks than its
                # stable curated name table. Keep only the banks represented by
                # that table, then add Browse + at the matching final index.
                visible_bank_count = len(names)
                banks = banks[:visible_bank_count]
                while len(banks) < visible_bank_count:
                    banks.append(tuple([None] * self.SAFE_PARAMETER_BANK_SIZE))
            banks.append(self._simpler_browse_parameters())
        elif self._is_analog():
            banks = self._analog_parameter_banks(banks, names)
        elif self._is_drumcell():
            custom_banks = (
                self._drumcell_sample_parameters(),
                self._drumcell_fx_filter_parameters(),
                self._drumcell_rest_parameters(),
            )
            while len(banks) < len(custom_banks):
                banks.append(tuple([None] * self.SAFE_PARAMETER_BANK_SIZE))
            banks[:len(custom_banks)] = custom_banks
        elif self._is_grain_delay():
            banks = list(self._grain_delay_parameter_banks())
        elif self._is_delay():
            banks = list(self._delay_parameter_banks())
        return banks

    def _normalized_bank_name(self, name):
        return re.sub(r'[^a-z0-9]+', '', str(name).lower())

    def _bank_index_named(self, bank_names, *wanted_names):
        wanted = set(self._normalized_bank_name(name) for name in wanted_names)
        return next(
            (index for index, name in enumerate(bank_names)
             if self._normalized_bank_name(name) in wanted),
            None,
        )

    def _replace_simpler_lfo_bank(self, banks, bank_names):
        index = self._bank_index_named(bank_names, 'LFO')
        if index is None or index >= len(banks):
            return
        bank = list(banks[index])
        bank.extend([None] * (self.SAFE_PARAMETER_BANK_SIZE - len(bank)))
        sync = self._parameter_by_names('L Sync')
        sync_on = False
        if sync:
            try:
                display = str(sync.str_for_value(sync.value)).strip().lower()
                sync_on = display in ('on', 'yes', 'true', 'sync', 'synced')
                if display in ('off', 'no', 'false', 'free'):
                    sync_on = False
            except Exception:
                try:
                    sync_on = float(sync.value) > float(sync.min)
                except Exception:
                    pass
        rate = self._parameter_by_names('L Sync Rate' if sync_on else 'L Rate')
        for control_index, parameter in enumerate(bank):
            key = self._normalized_bank_name(getattr(parameter, 'name', '')) if parameter else ''
            original_key = self._normalized_bank_name(getattr(parameter, 'original_name', '')) if parameter else ''
            if key == 'lrate' or original_key == 'lrate':
                bank[control_index] = rate
            elif key == 'lrkey' or original_key == 'lrkey':
                bank[control_index] = sync
        banks[index] = tuple(bank[:self.SAFE_PARAMETER_BANK_SIZE])

    def _simpler_warp_mode_name(self):
        try:
            value = int(self._device.sample.warp_mode)
            modes = (
                (Live.Clip.WarpMode.beats, 'beats'),
                (Live.Clip.WarpMode.tones, 'tones'),
                (Live.Clip.WarpMode.texture, 'texture'),
                (Live.Clip.WarpMode.repitch, 'repitch'),
                (Live.Clip.WarpMode.complex, 'complex'),
                (Live.Clip.WarpMode.complex_pro, 'complexpro'),
            )
            return next((name for mode, name in modes if int(mode) == value), '')
        except Exception:
            return ''

    def _simpler_control_parameters(self):
        mode = self._simpler_warp_mode_name() if self._simpler_is_warped() else ''
        mode_parameters = {
            'beats': ('Preserve', 'Loop Mode', 'Envelope'),
            'tones': ('Grain Size Tones',),
            'texture': ('Grain Size Texture', 'Flux'),
            'complexpro': ('Formants', 'Envelope Complex Pro'),
        }.get(mode, ())
        parameters = [None]
        parameters.extend(self._parameter_by_names(name) for name in mode_parameters)
        parameters.append(self._parameter_by_names('Filter Drive'))
        parameters.extend([None] * max(0, 5 - len(parameters)))
        parameters.extend((
            self._parameter_by_names('Pe < Env'),
            self._parameter_by_names('Pe Attack'),
            self._parameter_by_names('Pe Decay'),
        ))
        return tuple(parameters[:self.SAFE_PARAMETER_BANK_SIZE])

    def _simpler_controls_2_parameters(self):
        return (
            self._parameter_by_names('Transpose'),
            self._parameter_by_names('Detune'),
            self._parameter_by_names('Glide Mode', 'Glide', 'Glide On'),
            self._parameter_by_names('Glide Time'),
            self._parameter_by_names('L R < Key'),
            self._parameter_by_names('L Retrig'),
            # Live 12.4 exposes Simpler's filter switch as "F On".
            self._parameter_by_names('F On', 'Filter On', 'Filter On/Off', 'Filter Enable'),
            self._parameter_by_names('Pe On', 'Pitch Envelope On'),
        )

    def _simpler_browse_parameters(self):
        if not self._simpler_uses_native_banks():
            return tuple([None] * self.SAFE_PARAMETER_BANK_SIZE)
        return (
            None,  # Browse Samples is handled as a Tap action.
            self._parameter_by_names('F On', 'Filter On', 'Filter On/Off', 'Filter Enable'),
            self._parameter_by_names('Filter Type', 'Filter Type (Legacy)'),
            self._parameter_by_names('Pe On', 'Pitch Envelope On'),
            self._parameter_by_names('Pe < Env', 'Pitch Envelope Amount'),
            self._parameter_by_names('Transpose'),
            self._parameter_by_names('Detune'),
            self._parameter_by_names('Volume'),
        )

    def _simpler_control_bank_indices(self, bank_names):
        wanted = {
            self._normalized_bank_name(self.SIMPLER_WARP_BANK_NAME),
            self._normalized_bank_name(self.SIMPLER_CONTROLS_2_BANK_NAME),
            self._normalized_bank_name('Pitch Env'),
            self._normalized_bank_name('Controls 3'),
            self._normalized_bank_name('Options'),
            self._normalized_bank_name('Warp'),
        }
        return [
            index for index, name in enumerate(bank_names)
            if self._normalized_bank_name(name) in wanted
        ]

    def _configure_simpler_control_bank_names(self, bank_names):
        indices = self._simpler_control_bank_indices(bank_names)
        insertion_index = min(indices) if indices else min(1, len(bank_names))
        for index in reversed(indices):
            bank_names.pop(index)
        bank_names.insert(insertion_index, self.SIMPLER_WARP_BANK_NAME)
        bank_names.insert(insertion_index + 1, self.SIMPLER_CONTROLS_2_BANK_NAME)

    def _configure_simpler_control_banks(self, banks, bank_names):
        indices = self._simpler_control_bank_indices(bank_names)
        insertion_index = min(indices) if indices else min(1, len(banks))
        for index in reversed(indices):
            bank_names.pop(index)
            if index < len(banks):
                banks.pop(index)
        bank_names.insert(insertion_index, self.SIMPLER_WARP_BANK_NAME)
        banks.insert(insertion_index, self._simpler_control_parameters())
        bank_names.insert(insertion_index + 1, self.SIMPLER_CONTROLS_2_BANK_NAME)
        banks.insert(insertion_index + 1, self._simpler_controls_2_parameters())

    def _analog_bank_names(self, bank_names):
        names = list(bank_names)
        oscillator_index = self._bank_index_named(names, 'Oscillators')
        custom = [
            self.ANALOG_OSC_1_BANK_NAME,
            self.ANALOG_OSC_2_BANK_NAME,
            self.ANALOG_NOISE_BANK_NAME,
            self.ANALOG_OSC_PLUS_BANK_NAME,
        ]
        if oscillator_index is None:
            names = custom + names
        else:
            names[oscillator_index:oscillator_index + 1] = custom
        mix_index = self._bank_index_named(names, 'Mix')
        if mix_index is not None:
            names[mix_index] = self.ANALOG_MIX_LFO_BANK_NAME
            names.insert(mix_index + 1, self.ANALOG_LFO_PLUS_BANK_NAME)
        else:
            names.extend((self.ANALOG_MIX_LFO_BANK_NAME, self.ANALOG_LFO_PLUS_BANK_NAME))
        names.append(self.ANALOG_LOOPS_FILTER_BANK_NAME)
        return tuple(names)

    def _analog_parameter_banks(self, banks, bank_names):
        result = list(banks)
        oscillator_index = self._bank_index_named(bank_names, 'Oscillators')
        custom = [
            self._parameter_bank(
                'OSC1 Level', 'OSC1 Octave', 'OSC1 Semi', 'OSC1 Detune',
                'OSC1 Shape', 'PEG1 Amount', 'PEG1 Time', 'Volume',
            ),
            self._parameter_bank(
                'OSC2 Level', 'OSC2 Octave', 'OSC2 Semi', 'OSC2 Detune',
                'OSC2 Shape', 'PEG2 Amount', 'PEG2 Time', 'Volume',
            ),
            self._parameter_bank(
                'Noise On/Off', 'Noise Level', 'Noise Balance', 'Noise Color',
                None, None, None, None,
            ),
            self._parameter_bank(
                'OSC1 Mode', 'O1 Sub/Sync', 'OSC1 PW', 'O1 PW < LFO',
                'OSC2 Mode', 'O2 Sub/Sync', 'OSC2 PW', 'O2 PW < LFO',
            ),
        ]
        if oscillator_index is None:
            result = custom + result
            working_names = [
                self.ANALOG_OSC_1_BANK_NAME, self.ANALOG_OSC_2_BANK_NAME,
                self.ANALOG_NOISE_BANK_NAME, self.ANALOG_OSC_PLUS_BANK_NAME,
            ] + list(bank_names)
        else:
            result[oscillator_index:oscillator_index + 1] = custom
            working_names = list(bank_names)
            working_names[oscillator_index:oscillator_index + 1] = [
                self.ANALOG_OSC_1_BANK_NAME, self.ANALOG_OSC_2_BANK_NAME,
                self.ANALOG_NOISE_BANK_NAME, self.ANALOG_OSC_PLUS_BANK_NAME,
            ]

        mix_index = self._bank_index_named(working_names, 'Mix')
        mix_bank = self._parameter_bank(
            'AMP1 Level', 'AMP1 Pan', 'AMP2 Level', 'AMP2 Pan',
            'LFO1 Shape', 'LFO1 Speed', 'LFO1 SncRate', 'LFO1 Sync',
        )
        lfo_plus_bank = self._parameter_bank(
            'LFO2 Shape', 'LFO2 Speed', 'LFO2 SncRate', 'LFO2 Sync',
            'LFO1 On/Off', 'LFO2 On/Off', None, None,
        )
        if mix_index is None:
            result.extend((mix_bank, lfo_plus_bank))
            working_names.extend((self.ANALOG_MIX_LFO_BANK_NAME, self.ANALOG_LFO_PLUS_BANK_NAME))
        else:
            result[mix_index] = mix_bank
            result.insert(mix_index + 1, lfo_plus_bank)
            working_names[mix_index] = self.ANALOG_MIX_LFO_BANK_NAME
            working_names.insert(mix_index + 1, self.ANALOG_LFO_PLUS_BANK_NAME)

        output_index = self._bank_index_named(working_names, 'Output')
        if output_index is not None and output_index < len(result):
            result[output_index] = self._parameter_bank(
                'Volume', 'Glide On/Off', 'Glide Time', 'Glide Legato',
                'Unison On/Off', 'Unison Detune', 'Vib On/Off', 'Vib Amount',
            )
        result.append(self._parameter_bank(
            'FEG1 Loop', 'F1 Drive', 'FEG2 Loop', 'F2 Drive',
            'AEG1 Loop', 'AEG2 Loop', 'F1 On/Off', 'F2 On/Off',
        ))
        return result

    def _parameter_bank(self, *specifications):
        parameters = []
        for specification in specifications:
            if not specification:
                parameters.append(None)
            elif isinstance(specification, (tuple, list)):
                parameters.append(self._parameter_by_names(*specification))
            elif isinstance(specification, str):
                parameters.append(self._parameter_by_names(specification))
            else:
                parameters.append(specification)
        parameters.extend([None] * (self.SAFE_PARAMETER_BANK_SIZE - len(parameters)))
        return tuple(parameters[:self.SAFE_PARAMETER_BANK_SIZE])

    def _auto_filter_2_parameter_banks(self):
        filter_type = self._parameter_value_text('Filter Type')
        filter_type_key = re.sub(r'[^a-z0-9]+', '', filter_type)
        uses_morph = any(
            name in filter_type_key
            for name in ('morph', 'comb', 'notchlp', 'notchlowpass', 'vowel')
        )
        slope = self._parameter_by_names('Slope', 'Filter Slope')
        morph_or_slope = self._parameter_by_names('Filter Morph') if uses_morph else slope
        if 'dj' in filter_type:
            frequency = self._parameter_by_names('Control')
        elif 'vowel' in filter_type:
            frequency = self._parameter_by_names('Pitch')
        else:
            frequency = self._parameter_by_names('Frequency')
        resonance = self._parameter_by_names('Formant') if 'vowel' in filter_type else self._parameter_by_names('Resonance')

        lfo_time_mode = self._parameter_value_text('LFO T Mode')
        if 'sixteenth' in lfo_time_mode or '16' in lfo_time_mode:
            lfo_rate = self._parameter_by_names('LFO 16th')
        elif 'time' in lfo_time_mode:
            lfo_rate = self._parameter_by_names('LFO Time')
        elif lfo_time_mode == 'rate':
            lfo_rate = self._parameter_by_names('LFO Freq')
        else:
            lfo_rate = self._parameter_by_names('LFO Rate')
        lfo_spatial_mode = self._parameter_value_text('LFO S Mode')
        lfo_phase_or_spin = self._parameter_by_names('LFO Phase') if 'phase' in lfo_spatial_mode else self._parameter_by_names('LFO Spin')

        sidechain_eq_type = self._parameter_value_text('S/C EQ Type')
        sidechain_q_or_gain = self._parameter_by_names('S/C EQ Q') if 'pass' in sidechain_eq_type else self._parameter_by_names('S/C EQ Gain')
        quantize_mode = self._parameter_value_text('LFO Q Mode')
        quantize_amount = self._parameter_by_names('LFO Steps') if 'step' in quantize_mode else self._parameter_by_names('LFO S&H')

        return (
            self._parameter_bank(
                'Filter Type', frequency, resonance, morph_or_slope,
                'Circuit', 'Drive', 'Output', ('Dry/Wet', 'Dry Wet'),
            ),
            self._parameter_bank(
                'LFO Wave', 'LFO Amount', 'LFO T Mode', lfo_rate,
                'LFO S Mode', lfo_phase_or_spin, 'LFO Offset', 'LFO Morph',
            ),
            self._parameter_bank(
                'Env Amount', 'Env Hold On', 'Env Attack', 'Env Release',
                'S/C EQ On', 'S/C EQ Type', 'S/C EQ Freq', sidechain_q_or_gain,
            ),
            self._parameter_bank(
                'LFO Q Mode', quantize_amount, 'Env S&H On', 'Env S&H',
                None, None, None, None,
            ),
        )

    def _auto_filter_parameter_banks(self):
        filter_type_text = self._parameter_value_text('Filter Type', 'Filter Type (Legacy)')
        filter_type_key = re.sub(r'[^a-z0-9]+', '', filter_type_text)
        if 'lowpass' in filter_type_key or 'highpass' in filter_type_key:
            circuit = self._parameter_by_names('Filter Circuit - LP/HP')
        else:
            circuit = self._parameter_by_names('Filter Circuit - BP/NO/Morph')
        morph_or_drive = self._parameter_by_names('Morph') if 'morph' in filter_type_key else self._parameter_by_names('Drive')

        lfo_sync_text = self._parameter_value_text('LFO Sync')
        lfo_rate = self._parameter_by_names('LFO Frequency') if 'free' in lfo_sync_text else self._parameter_by_names('LFO Sync Rate')
        lfo_is_synced = 'sync' in lfo_sync_text and 'free' not in lfo_sync_text
        stereo_mode_text = self._parameter_value_text('LFO Stereo Mode')
        lfo_stereo = self._parameter_by_names('LFO Offset') if lfo_is_synced else self._parameter_by_names('LFO Stereo Mode')
        lfo_phase = self._parameter_by_names('LFO Phase') if lfo_is_synced or 'phase' in stereo_mode_text else self._parameter_by_names('LFO Spin')

        return (
            self._parameter_bank(
                ('Filter Type', 'Filter Type (Legacy)'), 'Frequency',
                ('Resonance', 'Resonance (Legacy)'), circuit, morph_or_drive,
                'LFO Amount', 'LFO Sync', lfo_rate,
            ),
            self._parameter_bank(
                ('Filter Type', 'Filter Type (Legacy)'), 'Frequency',
                ('Resonance', 'Resonance (Legacy)'), morph_or_drive, 'Slope',
                'Env. Attack', 'Env. Release', 'Env. Modulation',
            ),
            self._parameter_bank(
                'LFO Amount', 'LFO Waveform', 'LFO Sync', lfo_rate,
                lfo_stereo, lfo_phase, 'LFO Quantize On', 'LFO Quantize Rate',
            ),
            self._parameter_bank(
                'S/C On', 'S/C Mix', 'S/C Gain', None, None, None, None, None,
            ),
        )

    def _beat_repeat_parameter_banks(self):
        return (
            self._parameter_bank(
                'Grid', 'Interval', 'Offset', 'Gate',
                'Pitch', 'Pitch Decay', 'Variation', 'Chance',
            ),
            self._parameter_bank(
                'Filter On', 'Filter Freq', 'Filter Width', None,
                'Mix Type', 'Volume', 'Decay', 'Chance',
            ),
            self._parameter_bank(
                'Repeat', 'Interval', 'Offset', 'Gate',
                'Grid', 'Block Triplets', 'Variation', 'Variation Type',
            ),
        )

    def _hybrid_algorithm_type_key(self):
        return re.sub(r'[^a-z0-9]+', '', self._parameter_value_text('Algo Type'))

    def _hybrid_algorithm_modulation_parameter(self, algorithm):
        if 'prism' in algorithm:
            return None
        if 'tides' in algorithm:
            return self._parameter_by_names('Ti Waveform')
        return self._parameter_by_names('Modulation')

    def _hybrid_algorithm_page_one_parameters(self, algorithm):
        if 'darkhall' in algorithm:
            character_one = self._parameter_by_names('DH Shape')
            character_two = self._parameter_by_names('DH BassMult', 'DH Bass Mult')
        elif 'quartz' in algorithm:
            character_one = self._parameter_by_names('Qz Low Damp')
            character_two = self._parameter_by_names('Qz Distance')
        elif 'shimmer' in algorithm:
            character_one = self._parameter_by_names('Sh Pitch Shift')
            character_two = self._parameter_by_names('Sh Shimmer')
        elif 'tides' in algorithm:
            character_one = self._parameter_by_names('Ti Tide')
            character_two = self._parameter_by_names('Ti Rate')
        elif 'prism' in algorithm:
            character_one = self._parameter_by_names('Pr High Mult')
            character_two = self._parameter_by_names('Pr X Over')
        else:
            character_one = None
            character_two = None
        return character_one, character_two

    def _hybrid_algorithm_page_two_character(self, algorithm):
        if 'darkhall' in algorithm:
            return self._parameter_by_names('DH Bass X')
        if 'quartz' in algorithm or 'shimmer' in algorithm:
            return self._parameter_by_names('Diffusion')
        if 'tides' in algorithm:
            return self._parameter_by_names('Ti Phase')
        return None

    def _hybrid_predelay_is_synced(self):
        text = self._parameter_value_text('P.Dly Sync', 'Predelay Sync')
        return 'sync' in text or text == 'on'

    def _hybrid_reverb_parameter_banks(self):
        algorithm = self._hybrid_algorithm_type_key()
        algorithm_one, algorithm_two = self._hybrid_algorithm_page_one_parameters(algorithm)
        algorithm_modulation = self._hybrid_algorithm_modulation_parameter(algorithm)
        damping_or_low_mult = self._parameter_by_names('Pr Low Mult') if 'prism' in algorithm else self._parameter_by_names('Damping')

        low_type = self._parameter_value_text('EQ Low Type', 'EQ Lo Type')
        low_gain_or_slope = self._parameter_by_names(
            'EQ Low Slope', 'EQ Lo Slope'
        ) if 'cut' in low_type else self._parameter_by_names('EQ Low Gain', 'EQ Lo Gain')
        high_type = self._parameter_value_text('EQ High Type', 'EQ Hi Type')
        high_gain_or_slope = self._parameter_by_names(
            'EQ High Slope', 'EQ Hi Slope'
        ) if 'cut' in high_type else self._parameter_by_names('EQ High Gain', 'EQ Hi Gain')
        predelay_synced = self._hybrid_predelay_is_synced()
        predelay = self._parameter_by_names(
            'P.Dly 16th', 'Predelay 16th'
        ) if predelay_synced else self._parameter_by_names('P.Dly Time', 'Predelay')
        predelay_feedback = self._parameter_by_names(
            'P.Dly Fb 16th', 'Predel. FB 16th', 'Predelay FB 16th'
        ) if predelay_synced else self._parameter_by_names('P.Dly Fb Time', 'Predelay FB')

        return (
            self._parameter_bank(
                ('Send Gain', 'Send'), 'Routing', 'Blend', 'Algo Type',
                'Decay', 'Size', algorithm_modulation, ('Dry/Wet', 'Dry Wet'),
            ),
            self._parameter_bank(
                'IR Category', 'IR', 'Ir Attack Time', 'Ir Decay Time',
                'Ir Size Factor', 'Blend', 'Routing', ('Dry/Wet', 'Dry Wet'),
            ),
            self._parameter_bank(
                'Algo Type', 'Decay', 'Size', algorithm_one,
                algorithm_two, algorithm_modulation, 'Width', ('Dry/Wet', 'Dry Wet'),
            ),
            self._parameter_bank(
                'Algo Type', damping_or_low_mult,
                self._hybrid_algorithm_page_two_character(algorithm), 'EQ Pre Algo',
                ('Send Gain', 'Send'), 'Blend', 'Routing', ('Dry/Wet', 'Dry Wet'),
            ),
            self._parameter_bank(
                'EQ Pre Algo', ('EQ Low Type', 'EQ Lo Type'),
                ('EQ Low Freq', 'EQ Lo Freq'), low_gain_or_slope,
                ('EQ High Type', 'EQ Hi Type'), ('EQ High Freq', 'EQ Hi Freq'),
                high_gain_or_slope, ('Dry/Wet', 'Dry Wet'),
            ),
            self._parameter_bank(
                'EQ Pre Algo', ('EQ P1 Freq', 'EQ Peak 1 Freq'),
                ('EQ P1 Q', 'EQ Peak 1 Q'), ('EQ P1 Gain', 'EQ Peak 1 Gain'),
                ('EQ P2 Freq', 'EQ Peak 2 Freq'), ('EQ P2 Q', 'EQ Peak 2 Q'),
                ('EQ P2 Gain', 'EQ Peak 2 Gain'), ('Dry/Wet', 'Dry Wet'),
            ),
            self._parameter_bank(
                ('Send Gain', 'Send'), ('P.Dly Sync', 'Predelay Sync'),
                predelay, predelay_feedback, ('Vintage', 'Vintage Copy'),
                'Width', 'Blend', ('Dry/Wet', 'Dry Wet'),
            ),
        )

    def _drift_parameter_banks(self):
        envelope_2 = self._drift_envelope_2_parameters()
        return (
            self._parameter_bank(
                'Osc 1 Wave', 'Osc 1 Shape', 'Osc 1 Gain', 'Osc 2 Gain',
                'LP Freq', 'LP Res', 'LP Mod Amt 1', 'LP Mod Amt 2',
            ),
            self._parameter_bank(
                'Osc 1 Wave', 'Osc 1 Shape', 'Osc 1 Oct', 'Osc 1 Gain',
                'Osc 2 Wave', 'Osc 2 Oct', 'Osc 2 Detune', 'Osc 2 Gain',
            ),
            self._parameter_bank(
                'Osc Retrig On', None, 'Noise Gain', 'Noise On',
                'Noise Flt On', None, None, None,
            ),
            self._parameter_bank(
                'Pitch Mod Src 1', 'Pitch Mod Amt 1', 'Pitch Mod Src 2', 'Pitch Mod Amt 2',
                'Shape Mod Src', 'Osc 1 Shape Mod Amt', 'Osc Retrig On', 'Noise Gain',
            ),
            self._parameter_bank(
                'LP Freq', 'LP Res', 'LP Type', 'HP Freq',
                'Osc 1 Flt On', 'Osc 2 Flt On', 'Noise Flt On', 'Noise On',
            ),
            self._parameter_bank(
                'Key > LPF', 'LP Mod Src 1', 'LP Mod Amt 1', 'LP Mod Src 2',
                'LP Mod Amt 2', None, None, None,
            ),
            self._parameter_bank(
                'Env 1 Attack', 'Env 1 Decay', 'Env 1 Sustain', 'Env 1 Release',
                None, None, None, None,
            ),
            envelope_2,
            self._parameter_bank(
                'Env 2 Cyc On', ('Cyc Env Tilt', 'Cyc Tilt'), ('Cyc Env Hold', 'Cyc Hold'),
                ('Cyc Env Time Mode', 'Cyc Mode'), ('Cyc Env Rate', 'Cyc Rate'),
                ('Cyc Env Ratio', 'Cyc Ratio'), ('Cyc Env Time', 'Cyc Time'),
                ('Cyc Env Synced', 'Cyc Synced'),
            ),
            self._parameter_bank(
                'LFO Wave', 'LFO Time Mode', self._drift_lfo_rate_parameter(),
                'LFO Amt', 'LFO Retrig On', 'LFO Mod Src', 'LFO Mod Amt', None,
            ),
            self._parameter_bank(
                'Mod Source 1', 'Mod Dest 1', 'Mod Matrix Amt 1',
                'Mod Source 2', 'Mod Dest 2', 'Mod Matrix Amt 2', None, None,
            ),
            self._parameter_bank(
                'Mod Source 3', 'Mod Dest 3', 'Mod Matrix Amt 3', 'Vel > Vol',
                None, None, None, None,
            ),
            self._parameter_bank(
                'Voice Mode', 'Voice Count', 'Thickness', 'Spread',
                'Strength', 'Legato On', 'Glide Time', 'Drift',
            ),
            self._parameter_bank(
                'Transpose', 'Volume', 'PB Range', 'Note Pitch Bend On',
                None, None, None, None,
            ),
        )

    def _drift_envelope_2_parameters(self):
        cycle_enabled = self._parameter_by_names('Env 2 Cyc On')
        try:
            is_cycling = cycle_enabled.value > cycle_enabled.min
        except Exception:
            is_cycling = 'on' in self._parameter_display(cycle_enabled).lower()
        if is_cycling:
            return self._parameter_bank(
                'Env 2 Cyc On', ('Cyc Env Tilt', 'Cyc Tilt'), ('Cyc Env Hold', 'Cyc Hold'),
                ('Cyc Env Time Mode', 'Cyc Mode'), ('Cyc Env Rate', 'Cyc Rate'),
                ('Cyc Env Ratio', 'Cyc Ratio'), ('Cyc Env Time', 'Cyc Time'),
                ('Cyc Env Synced', 'Cyc Synced'),
            )
        return self._parameter_bank(
            'Env 2 Attack', 'Env 2 Decay', 'Env 2 Sustain', 'Env 2 Release',
            'Env 2 Cyc On', None, None, None,
        )

    def _parameter_value_text(self, *names):
        return self._parameter_display(self._parameter_by_names(*names)).lower()

    def _drift_lfo_rate_parameter(self):
        mode = self._parameter_value_text('LFO Time Mode')
        if 'ratio' in mode:
            return self._parameter_by_names('LFO Ratio')
        if 'time' in mode:
            return self._parameter_by_names('LFO Time')
        if 'sync' in mode:
            return self._parameter_by_names('LFO Synced')
        return self._parameter_by_names('LFO Rate')

    def _drift_voice_mode_parameter(self):
        mode = self._parameter_value_text('Voice Mode')
        if 'mono' in mode:
            return self._parameter_by_names('Thickness')
        if 'stereo' in mode:
            return self._parameter_by_names('Spread')
        if 'unison' in mode:
            return self._parameter_by_names('Strength')
        return None

    def _meld_engine_letter(self):
        try:
            return 'B' if int(self._device.selected_engine) == 1 else 'A'
        except Exception:
            return 'A'

    def _meld_original_name(self, suffix):
        return 'MeldVoice_Engine{}_{}'.format(self._meld_engine_letter(), suffix)

    def _meld_parameter(self, suffix, *aliases):
        return self._parameter_by_names(self._meld_original_name(suffix), *aliases)

    def _meld_parameter_banks(self):
        engine = self._meld_engine_letter()
        sync_1 = self._parameter_by_names('LFO 1 {} Sync'.format(engine), self._meld_original_name('Lfo1_Sync'))
        retrigger_1 = self._meld_parameter('Lfo1_Retrigger', 'LFO 1 {} Retrigger'.format(engine))
        sync_2 = self._parameter_by_names('LFO 2 {} Sync'.format(engine), self._meld_original_name('Lfo2_Sync'))
        retrigger_2 = self._meld_parameter('Lfo2_Retrigger', 'LFO 2 {} Retrigger'.format(engine))
        glide_mode = self._parameter_by_names('Glide {}'.format(engine))
        mono_poly = self._parameter_by_names('Mono Poly')
        try:
            mono_voice_parameter = self._parameter_by_names('Legato', 'MonoLegato') if int(mono_poly.value) == 0 else self._parameter_by_names('Poly Voices')
        except Exception:
            mono_voice_parameter = self._parameter_by_names('Poly Voices')
        envelope_delay_aliases = ('MeldVoice_EngineBDelay',) if engine == 'B' else ()
        return (
            tuple([None] * self.SAFE_PARAMETER_BANK_SIZE),
            self._parameter_bank(
                (self._meld_original_name('Oscillator_OscillatorType'),),
                (self._meld_original_name('Oscillator_Macro1'),),
                (self._meld_original_name('Oscillator_Macro2'),),
                (self._meld_original_name('Filter_Frequency'),),
                (self._meld_original_name('Filter_Macro1'),),
                (self._meld_original_name('ToneFilter'),),
                (self._meld_original_name('Pan'),),
                (self._meld_original_name('Volume'),),
            ),
            self._parameter_bank(
                (self._meld_original_name('Oscillator_OscillatorType'),),
                (self._meld_original_name('Oscillator_Pitch_Transpose'),),
                (self._meld_original_name('Oscillator_Pitch_Detune'),),
                (self._meld_original_name('Oscillator_Macro1'),),
                (self._meld_original_name('Oscillator_Macro2'),),
                (self._meld_original_name('ToneFilter'),),
                (self._meld_original_name('Pan'),),
                (self._meld_original_name('Volume'),),
            ),
            self._parameter_bank(
                (self._meld_original_name('Filter_FilterType'),),
                (self._meld_original_name('Filter_Frequency'),),
                (self._meld_original_name('Filter_Macro1'),),
                (self._meld_original_name('Filter_Macro2'),),
                (self._meld_original_name('ToneFilter'),),
                (self._meld_original_name('Pan'),),
                (self._meld_original_name('Volume'),),
                None,
            ),
            self._parameter_bank(
                (self._meld_original_name('AmpEnvelope_Times_Attack'),),
                (self._meld_original_name('AmpEnvelope_Slopes_Attack'),),
                (self._meld_original_name('AmpEnvelope_Times_Decay'),),
                (self._meld_original_name('AmpEnvelope_Slopes_Decay'),),
                (self._meld_original_name('AmpEnvelope_Sustain'),),
                (self._meld_original_name('AmpEnvelope_Times_Release'),),
                (self._meld_original_name('AmpEnvelope_Slopes_Release'),),
                (self._meld_original_name('AmpEnvelope_LoopMode'),),
            ),
            self._parameter_bank(
                (self._meld_original_name('FilterEnvelope_Times_Attack'),),
                (self._meld_original_name('FilterEnvelope_Slopes_Attack'),),
                (self._meld_original_name('FilterEnvelope_Times_Decay'),),
                (self._meld_original_name('FilterEnvelope_Slopes_Decay'),),
                (self._meld_original_name('FilterEnvelope_Values_Sustain'),),
                (self._meld_original_name('FilterEnvelope_Times_Release'),),
                (self._meld_original_name('FilterEnvelope_Values_Peak'),),
                (self._meld_original_name('FilterEnvelope_LoopMode'),),
            ),
            self._parameter_bank(
                (self._meld_original_name('EnvelopeDelay'),) + envelope_delay_aliases,
                ('Link Envelopes',), None, None, None, None, None, None,
            ),
            (
                self._meld_parameter('Lfo1_GeneratorType'),
                sync_1,
                self._meld_parameter('Lfo1_SyncedRate'),
                self._meld_parameter('Lfo1_Rate'),
                self._meld_parameter('Lfo1_PhaseOffset'),
                self._meld_parameter('Lfo1_GeneratorMacro1'),
                self._meld_parameter('Lfo1_GeneratorMacro2'),
                retrigger_1,
            ),
            self._parameter_bank(
                (self._meld_original_name('Lfo1_Transformer1Type'),),
                (self._meld_original_name('Lfo1_Transformer1Macro'),),
                (self._meld_original_name('Lfo1_Transformer2Type'),),
                (self._meld_original_name('Lfo1_Transformer2Macro'),),
                None, None, None, None,
            ),
            (
                self._meld_parameter('Lfo2_Waveform'),
                sync_2,
                self._meld_parameter('Lfo2_SyncedRate'),
                self._meld_parameter('Lfo2_Rate'),
                retrigger_2,
                self._meld_parameter('Lfo2_PhaseOffset'),
                None, None,
            ),
            (
                self._parameter_by_names('Stack Voices'),
                self._parameter_by_names('MeldVoice_VoiceSpreadAmount'),
                mono_poly,
                mono_voice_parameter,
                self._meld_parameter('GlideTime'),
                glide_mode,
                self._parameter_by_names('MeldVoice_Drive'),
                self._parameter_by_names('Volume'),
            ),
        )

    def _delay_parameter_banks(self):
        main = tuple(self._parameter_by_names(*names) for names in (
            ('Feedback',),
            ('Dry/Wet', 'Dry Wet'),
            ('Smoothing', 'Delay Smoothing Mode'),
            ('Link', 'Stereo Time Link'),
            ('Ping Pong',),
            ('Freeze',),
            ('L Sync', 'L Delay Sync'),
            ('R Sync', 'R Delay Sync'),
        ))
        time_bank = tuple(self._parameter_by_names(*names) for names in (
            ('L Time', 'L Delay Time'),
            ('R Time', 'R Delay Time'),
            ('L 16th', 'L Delay 16th'),
            ('R 16th', 'R Delay 16th'),
            ('L Offset', 'L Delay Offset'),
            ('R Offset', 'R Delay Offset'),
            ('Filter Freq', 'Filter Frequency'),
            ('Filter Width', 'Filter Bandwidth'),
        ))

        filter_lfo_bank = tuple(self._parameter_by_names(*names) for names in (
            ('Filter On', 'Filter On/Off'),
            ('LFO Mode', 'LF Mode', 'Mod LFO Mode', 'LFO Time Mode'),
            ('LFO Freq', 'Mod LFO Freq', 'Modulation Frequency', 'LFO Rate'),
            ('LFO Time', 'Mod LFO Time', 'Modulation Time'),
            ('LFO Synced', 'LFO Sync', 'Mod LFO Synced', 'Modulation Synced Rate', 'LFO Synced Rate'),
            ('LFO 16th', 'Mod LFO 16th', 'Modulation 16th'),
            ('LFO > Delay', 'Delay < Modulation'),
            ('LFO > Filter', 'Filter < Modulation'),
        ))
        lfo_wave_bank = (
            self._parameter_by_names('LFO Wave', 'Mod LFO Wave', 'Modulation Waveform', 'LFO Waveform'),
            self._parameter_by_names('LFO Morph', 'Mod LFO Morph', 'Modulation Morph'),
        ) + tuple([None] * 6)
        return (
            main,
            time_bank,
            filter_lfo_bank,
            lfo_wave_bank,
        )

    def _grain_delay_uses_beat_delay(self):
        mode = self._parameter_by_names('Delay Mode')
        display = self._parameter_display(mode).lower()
        if display in ('off', 'no', 'false', 'time'):
            return False
        if display in ('on', 'yes', 'true', 'sync', 'beat'):
            return True
        try:
            return float(mode.value) > float(mode.min)
        except Exception:
            return False

    def _grain_delay_parameter_banks(self):
        delay_time = (
            self._parameter_by_names('Beat Delay')
            if self._grain_delay_uses_beat_delay()
            else self._parameter_by_names('Time Delay')
        )
        return (
            self._parameter_bank(
                'Frequency', 'Pitch', 'Delay Mode', delay_time,
                'Random', 'Spray', 'Feedback', ('DryWet', 'Dry/Wet', 'Dry Wet'),
            ),
            self._parameter_bank(
                'Delay Mode', delay_time, 'Beat Swing', 'Feedback',
                None, None, None, ('DryWet', 'Dry/Wet', 'Dry Wet'),
            ),
        )

    def _simpler_amp_parameters(self):
        names = (
            'Ve Attack', 'Ve Decay', 'Ve Sustain', 'Ve Release',
            'Glide Time', 'Spread', 'Pan', 'Volume',
        )
        return tuple(self._parameter_by_names(name) for name in names)

    def _simpler_slice_detail_parameters(self):
        names = ('Transpose', 'Detune', 'Fade In', 'Fade Out')
        parameters = [self._parameter_by_names(name) for name in names]
        return tuple(parameters + [None] * (self.SAFE_PARAMETER_BANK_SIZE - len(parameters)))

    def _parameter_display(self, parameter):
        if not parameter:
            return ''
        try:
            return str(parameter.str_for_value(parameter.value)).strip()
        except Exception:
            pass
        try:
            display_value = parameter.display_value
            if display_value is not None:
                return str(display_value).strip()
        except Exception:
            pass
        return str(getattr(parameter, 'value', '')).strip()

    def _drumcell_sample_parameters(self):
        env_mode = self._parameter_by_names('Env Mode')
        hold = self._parameter_by_names('Hold') if 'trigger' in self._parameter_display(env_mode).lower() else None
        return (
            self._parameter_by_names('Start'),
            self._parameter_by_names('Length'),
            self._parameter_by_names('Attack'),
            hold,
            self._parameter_by_names('Decay'),
            self._parameter_by_names('Transpose'),
            self._parameter_by_names('Detune'),
            env_mode,
        )

    def _drumcell_effect_parameter_names(self):
        fx_type = self._parameter_display(self._parameter_by_names('FX Type')).lower()
        if 'pitch' in fx_type:
            return 'Pitch Env Amt', 'Pitch Env Decay'
        if 'sub' in fx_type:
            return 'Sub Amt', 'Sub Freq'
        if 'noise' in fx_type:
            return 'Noise Amt', 'Noise Color'
        if 'loop' in fx_type:
            return 'Loop Offset', 'Loop Length'
        if 'stretch' in fx_type:
            return 'Stretch Factor', 'Grain Size'
        if 'punch' in fx_type:
            return 'Punch Amt', 'Punch Release'
        if '8-bit' in fx_type or '8 bit' in fx_type:
            return '8-Bit Rate', '8-Bit Flt Decay'
        if fx_type == 'fm' or 'frequency mod' in fx_type:
            return 'FM Amt', 'FM Freq'
        return 'RM Amt', 'RM Freq'

    def _drumcell_filter_gain_or_resonance(self):
        filter_type = self._parameter_display(self._parameter_by_names('Filter Type')).lower()
        return self._parameter_by_names('Filter Gain') if 'peak' in filter_type else self._parameter_by_names('Filter Res')

    def _drumcell_fx_filter_parameters(self):
        effect_one, effect_two = self._drumcell_effect_parameter_names()
        return (
            self._parameter_by_names('FX On'),
            self._parameter_by_names('FX Type'),
            self._parameter_by_names(effect_one),
            self._parameter_by_names(effect_two),
            self._parameter_by_names('Filter On'),
            self._parameter_by_names('Filter Type'),
            self._parameter_by_names('Filter Freq'),
            self._drumcell_filter_gain_or_resonance(),
        )

    def _drumcell_rest_parameters(self):
        return (
            self._parameter_by_names('Volume'),
            self._parameter_by_names('Pan'),
            self._parameter_by_names('Vel > Vol'),
            self._parameter_by_names('Mod Src', 'Mod Source', 'Modulation Source'),
            self._parameter_by_names('Mod Dest'),
            self._parameter_by_names('Mod Amt'),
            None,
            None,
        )

    def _chord_shift_scale_parameters(self):
        parameters = [
            self._parameter_by_names(
                'Shift{} Scale Degrees'.format(index),
                'ShiftScaleDegrees{}'.format(index),
            )
            for index in range(1, 7)
        ]
        return tuple(parameters + [None, None])

    def _chord_strum_parameters(self):
        return (
            self._parameter_by_names('Strum'),
            self._parameter_by_names('Tension', 'Strum Tension', 'StrumTension'),
            self._parameter_by_names('Crescendo', 'Strum Crescendo', 'StrumCrescendo'),
            None,
            None,
            None,
            None,
            None,
        )

    def _parameter_by_names(self, *names):
        wanted = set(re.sub(r'[^a-z0-9]+', '', name.lower()) for name in names)
        fallback = None
        for parameter in self._decorated_parameters():
            parameter_names = (str(getattr(parameter, 'name', '')), str(getattr(parameter, 'original_name', '')))
            if any(re.sub(r'[^a-z0-9]+', '', name.lower()) in wanted for name in parameter_names):
                if self._operator_parameter_is_active(parameter):
                    return parameter
                if fallback is None:
                    fallback = parameter
        return fallback

    def _operator_filter_bank_insert_index(self, bank_names):
        for index, name in enumerate(bank_names):
            if re.sub(r'[^a-z0-9]+', '', str(name).lower()) == 'filter':
                return index + 1
        return self._custom_bank_insert_index(bank_names, 'filter')

    def _operator_lfo_bank_insert_index(self, bank_names):
        for index, name in enumerate(bank_names):
            if re.sub(r'[^a-z0-9]+', '', str(name).lower()) == 'lfo':
                return index + 1
        return len(bank_names)

    def _operator_filter_plus_parameters(self):
        filter_type = self._parameter_by_names('Filter Type', 'Filter Type (Legacy)')
        circuit_candidates = (
            self._parameter_by_names('Filter Circuit - LP/HP'),
            self._parameter_by_names('Filter Circuit - BP/NO/Morph'),
        )
        filter_type_display = self._operator_filter_type_display(filter_type)
        preferred_circuit_index = 0 if any(name in filter_type_display for name in ('lowpass', 'highpass')) else 1
        circuit = circuit_candidates[preferred_circuit_index]
        if not circuit:
            circuit = next((parameter for parameter in circuit_candidates if parameter and self._operator_parameter_is_active(parameter)), None)
        circuit = circuit or next((parameter for parameter in circuit_candidates if parameter), None)
        slope = self._parameter_by_names('Filter Slope')
        # Live's Operator schema calls these AntiAlias and Interpolation, but
        # some versions do not expose either one as a DeviceParameter.
        quality = (
            self._parameter_by_names('AntiAlias', 'Antialias', 'Anti Alias') or
            self._parameter_by_names('Interpolation', 'Interpol', 'UseLinearInterpolation') or
            self._parameter_by_names('Fe Amount')
        )
        return (
            filter_type,
            circuit,
            slope,
            self._parameter_by_names('Filter Drive'),
            self._parameter_by_names('LFO Retrigger'),
            self._parameter_by_names('Filter On'),
            quality,
            self._parameter_by_names('Pe On'),
        )

    def _operator_filter_type_display(self, filter_type):
        try:
            return str(filter_type.str_for_value(filter_type.value)).strip().lower()
        except Exception:
            return ''

    def _operator_lfo_plus_parameters(self):
        return tuple(self._parameter_by_names(name) for name in (
            'Osc-A < LFO',
            'Osc-B < LFO',
            'Osc-C < LFO',
            'Osc-D < LFO',
            'Filt < LFO',
            'LFO Dst B',
            'LFO Amt B',
            'LFO On',
        ))

    def _wavetable_waves_insert_index(self, bank_names):
        for index, name in enumerate(bank_names):
            normalized = re.sub(r'[^a-z0-9]+', '', str(name).lower())
            if normalized in ('osc2', 'oscillator2') or normalized.endswith('oscillator2'):
                return index + 1
        return min(2, len(bank_names))

    def _wavetable_envelope_bank_index(self, bank_names):
        for index, name in enumerate(bank_names):
            normalized = re.sub(r'[^a-z0-9]+', '', str(name).lower())
            if normalized in ('env23', 'envelope23', 'envelopes23'):
                return index
        return None

    def _replace_wavetable_envelope_bank_names(self, bank_names):
        index = self._wavetable_envelope_bank_index(bank_names)
        if index is not None:
            bank_names[index] = self.WAVETABLE_ENV_2_BANK_NAME
            bank_names.insert(index + 1, self.WAVETABLE_ENV_3_BANK_NAME)

    def _wavetable_envelope_parameters(self, envelope_number):
        prefix = 'Env {}'.format(envelope_number)
        return tuple(self._parameter_by_names(name) for name in (
            '{} Attack'.format(prefix),
            '{} Decay'.format(prefix),
            '{} Sustain'.format(prefix),
            '{} Release'.format(prefix),
            '{} Peak'.format(prefix),
            '{} Loop Mode'.format(prefix),
            '{} A Slope'.format(prefix),
            'LFO {} Retrigger'.format(envelope_number - 1),
        ))

    def _replace_wavetable_envelope_banks(self, banks, bank_names):
        index = self._wavetable_envelope_bank_index(bank_names)
        if index is not None and index < len(banks):
            banks[index] = self._wavetable_envelope_parameters(2)
            banks.insert(index + 1, self._wavetable_envelope_parameters(3))
            bank_names[index] = self.WAVETABLE_ENV_2_BANK_NAME
            bank_names.insert(index + 1, self.WAVETABLE_ENV_3_BANK_NAME)

    def _operator_lfo_is_synced(self, range_parameter):
        try:
            return str(range_parameter.str_for_value(range_parameter.value)).strip().lower() == 'sync'
        except Exception:
            return False

    def _replace_operator_lfo_bank(self, banks, bank_names):
        if banks is None:
            return
        for index, name in enumerate(bank_names):
            if re.sub(r'[^a-z0-9]+', '', str(name).lower()) != 'lfo' or index >= len(banks):
                continue
            bank = list(banks[index])
            bank.extend([None] * (self.SAFE_PARAMETER_BANK_SIZE - len(bank)))
            lfo_range = self._parameter_by_names('LFO Range')
            lfo_rate = self._parameter_by_names('LFO Sync' if self._operator_lfo_is_synced(lfo_range) else 'LFO Rate')
            bank[4] = lfo_rate
            bank[7] = lfo_range
            banks[index] = tuple(bank[:self.SAFE_PARAMETER_BANK_SIZE])
            return

    def _operator_source_parameters(self, raw_banks=None):
        parameters = list(getattr(self._device, 'parameters', ()))
        identities = set(id(parameter) for parameter in parameters)
        for bank in raw_banks or ():
            for parameter in bank or ():
                if parameter is not None and id(parameter) not in identities:
                    identities.add(id(parameter))
                    parameters.append(parameter)
        return parameters

    def _operator_wave_parameters(self, raw_banks=None):
        try:
            by_name = {}
            parameters = self._operator_source_parameters(raw_banks)
            for parameter in parameters:
                by_name[parameter.name] = parameter
                try:
                    by_name[parameter.original_name] = parameter
                except Exception:
                    pass
            feedback_by_oscillator = self._operator_feedback_parameters(parameters, by_name)
            parameters = []
            for oscillator in ('A', 'B', 'C', 'D'):
                wave = by_name.get('Osc-{} Wave'.format(oscillator))
                feedback = feedback_by_oscillator.get(oscillator)
                parameters.extend((wave, feedback))
            return parameters
        except Exception:
            return []

    def _operator_feedback_parameters(self, parameters=None, by_name=None):
        parameters = list(parameters if parameters is not None else self._operator_source_parameters())
        by_name = by_name or {}
        if not by_name:
            for parameter in parameters:
                by_name[parameter.name] = parameter
                try:
                    by_name[parameter.original_name] = parameter
                except Exception:
                    pass

        result = {}
        feedback_parameters = []
        for index, parameter in enumerate(parameters):
            names = [str(getattr(parameter, 'name', ''))]
            try:
                names.append(str(parameter.original_name))
            except Exception:
                pass
            normalized_names = [re.sub(r'[^a-z0-9]+', '', name.lower()) for name in names]
            if any(
                    'feedback' in name or 'feedb' in name or 'fdbk' in name or 'feedbk' in name or
                    name.endswith('fb') for name in normalized_names):
                feedback_parameters.append((index, parameter, normalized_names))

        for oscillator in ('A', 'B', 'C', 'D'):
            key = oscillator.lower()
            for _, parameter, normalized_names in feedback_parameters:
                if any(name in (
                        '{}feedback'.format(key), 'osc{}feedback'.format(key),
                        'oscillator{}feedback'.format(key),
                        '{}feedb'.format(key), 'osc{}feedb'.format(key),
                        'oscillator{}feedb'.format(key),
                        '{}fdbk'.format(key), 'osc{}fdbk'.format(key),
                        'oscillator{}fdbk'.format(key),
                        '{}feedbk'.format(key), 'osc{}feedbk'.format(key),
                        'oscillator{}feedbk'.format(key),
                        '{}fb'.format(key), 'osc{}fb'.format(key),
                        'oscillator{}fb'.format(key),
                        'feedback{}'.format(key), 'fdbk{}'.format(key),
                        'feedbk{}'.format(key), 'fb{}'.format(key),
                ) for name in normalized_names):
                    result[oscillator] = parameter
                    break

        wave_positions = {}
        for index, parameter in enumerate(parameters):
            names = (str(getattr(parameter, 'name', '')), str(getattr(parameter, 'original_name', '')))
            for oscillator in ('A', 'B', 'C', 'D'):
                normalized_wave_name = 'osc{}wave'.format(oscillator.lower())
                if any(re.sub(r'[^a-z0-9]+', '', name.lower()) == normalized_wave_name for name in names):
                    wave_positions[oscillator] = index

        unassigned = [(index, parameter) for index, parameter, _ in feedback_parameters if parameter not in result.values()]
        for oscillator_index, oscillator in enumerate(('A', 'B', 'C', 'D')):
            if oscillator in result or oscillator not in wave_positions:
                continue
            start = wave_positions[oscillator]
            next_positions = [wave_positions[name] for name in ('A', 'B', 'C', 'D')[oscillator_index + 1:] if name in wave_positions]
            end = min(next_positions) if next_positions else len(parameters)
            for parameter_index, parameter in unassigned:
                if start <= parameter_index < end:
                    result[oscillator] = parameter
                    unassigned.remove((parameter_index, parameter))
                    break

        unresolved = [oscillator for oscillator in ('A', 'B', 'C', 'D') if oscillator not in result]
        if len(unassigned) == len(unresolved):
            for oscillator, (_, parameter) in zip(unresolved, unassigned):
                result[oscillator] = parameter
        return result

    def _operator_parameter_is_active(self, parameter):
        try:
            if hasattr(parameter, 'is_enabled') and not parameter.is_enabled:
                return False
            if hasattr(parameter, 'state'):
                return parameter.state == Live.DeviceParameter.ParameterState.enabled
        except Exception:
            return False
        return True

    def tap_custom_bank_kind(self):
        names = self._parameter_bank_names()
        try:
            name = names[self._bank_index]
        except Exception:
            return None
        if name == self.WAVETABLE_OSC_BANK_NAME:
            return 'wavetable_osc'
        if name == self.OPERATOR_WAVES_BANK_NAME:
            return 'operator_waves'
        if name == self.OPERATOR_FILTER_PLUS_BANK_NAME:
            return 'operator_filter_plus'
        if name == self.OPERATOR_LFO_PLUS_BANK_NAME:
            return 'operator_lfo_plus'
        custom_simpler = self._is_simpler() and not self._simpler_uses_native_banks()
        if name == self.SIMPLER_MAIN_BANK_NAME and custom_simpler:
            return 'simpler_main'
        if name == self.SIMPLER_ACTIONS_BANK_NAME and custom_simpler:
            return 'simpler_actions'
        if name == self.SIMPLER_WARP_BANK_NAME and custom_simpler:
            return 'simpler_warp'
        if (
                name in (self.SIMPLER_BROWSE_BANK_NAME, self.SIMPLER_BROWSE_PLUS_BANK_NAME)
                and self._is_simpler()):
            return 'simpler_browse'
        if self._is_drumcell():
            if name == self.DRUMCELL_SAMPLE_BANK_NAME:
                return 'drumcell_sample'
            if name == self.DRUMCELL_FX_FILTER_BANK_NAME:
                return 'drumcell_fx_filter'
            if name == self.DRUMCELL_REST_BANK_NAME:
                return 'drumcell_rest'
        return None

    def _clamp_bank_index_to_safe_banks(self):
        bank_count = len(self._parameter_banks())
        if bank_count == 0:
            self._bank_index = 0
        else:
            self._bank_index = max(0, min(self._bank_index, bank_count - 1))

    def _safe_parameter_banks(self):
        device = getattr(self, '_device', None)
        if not device or not liveobj_valid(device) or not hasattr(device, 'parameters'):
            return []

        parameters = list(device.parameters)
        if not parameters:
            return []

        live_banks = self._safe_live_parameter_banks(device, parameters)
        if live_banks:
            return live_banks

        parameters = parameters[1:]
        if not parameters:
            return []

        banks = []
        for index in range(0, len(parameters), self.SAFE_PARAMETER_BANK_SIZE):
            bank = list(parameters[index:index + self.SAFE_PARAMETER_BANK_SIZE])
            bank.extend([None] * (self.SAFE_PARAMETER_BANK_SIZE - len(bank)))
            banks.append(tuple(bank))
        return banks

    def _safe_live_parameter_banks(self, device, parameters):
        if not hasattr(device, 'get_bank_count') or not hasattr(device, 'get_bank_parameters'):
            return []

        try:
            bank_count = int(device.get_bank_count())
        except Exception:
            bank_count = 0

        if bank_count <= 0:
            return []

        banks = []
        empty_bank = tuple([None] * self.SAFE_PARAMETER_BANK_SIZE)
        for bank_index in range(bank_count):
            try:
                parameter_indices = list(device.get_bank_parameters(bank_index))
            except Exception:
                parameter_indices = []

            if len(parameter_indices) != self.SAFE_PARAMETER_BANK_SIZE:
                banks.append(empty_bank)
                continue

            bank = []
            for parameter_index in parameter_indices:
                if parameter_index == -1:
                    bank.append(None)
                elif 0 <= parameter_index < len(parameters):
                    bank.append(parameters[parameter_index])
                else:
                    bank.append(None)
            banks.append(tuple(bank))

        return banks

    def _safe_parameter_bank_names(self):
        return self._safe_parameter_bank_names_base()


class TapScheduledCall:
    """Cancellable adapter for ControlSurface.schedule_message."""

    TICKS_PER_SECOND = 10.0

    def __init__(self, surface, delay_seconds, callback, args=()):
        self._active = True
        self._callback = callback
        self._args = tuple(args)
        delay_ticks = max(1, int(math.ceil(max(0.0, delay_seconds) * self.TICKS_PER_SECOND)))
        surface.schedule_message(delay_ticks, self._run)

    def _run(self):
        if not self._active:
            return
        self._active = False
        self._callback(*self._args)

    def cancel(self):
        self._active = False

    def is_alive(self):
        return self._active


class Tap(ControlSurface):
    SYSEX_STRING_ESCAPE_CHAR = "\\"
    SYSEX_STRING_RESERVED_SYMBOLS = (",", "|", ";", "^", "-", "%", ":", "/", "<", "*", "$", "_", "&", "(", ")", "\\")
    MUTATOR_GENERATION_COOLDOWN_SECONDS = 1.25
    FOLLOW_ACTION_NAME_MARKER_RE = re.compile(r"\s*\[TapFA:v1\|([^\]]*)\]")
    DECOUPLED_AUTOMATION_NAME_MARKER_RE = re.compile(r"\s*\[TapAuto:v2\|([^\]]*)\]")
    DECOUPLED_AUTOMATION_ANY_NAME_MARKER_RE = re.compile(r"\s*\[TapAuto:v[0-9]+\|([^\]]*)\]")
    MUTATOR_NAME_MARKER_RE = re.compile(r"\s*\[(?:TapComp|TapMut):v1\|([^\]]*)\]")
    MUTATOR_ANY_NAME_MARKER_RE = re.compile(r"\s*\[(?:TapComp|TapMut):v[0-9]+\|([^\]]*)\]")
    FLIN_NAME_MARKER_RE = re.compile(r"\s*\[TapFlin:v1\|([^\]]*)\]")
    FLIN_ANY_NAME_MARKER_RE = re.compile(r"\s*\[TapFlin:v[0-9]+\|([^\]]*)\]")
    SYSEX_TEXT_SYMBOL_REPLACEMENTS = (
        ('♭', 'b'),
        ('♯', '#'),
        ('♮', 'nat'),
        ('𝄫', 'bb'),
        ('𝄪', '##'),
    )
    SYSEX_ROUND_BRACKET_TEXT_RE = re.compile(r'\(([^()]*)\)')
    SYSEX_SQUARE_BRACKET_TEXT_RE = re.compile(r'\[([^\[\]]*)\]')
    SYSEX_CURLY_BRACKET_TEXT_RE = re.compile(r'\{([^{}]*)\}')
    SYSEX_MULTI_SPACE_RE = re.compile(r'\s{2,}')
    MUTATOR_ALGORITHMS = (
        "mutator",
        "verse_weaver",
        "motif_ladder",
        "sparse_echo",
        "chorus_lift",
        "middle_eight",
        "tension_break",
        "skylight_hook",
        "glass_steps",
        "nocturne_line",
        "modal_drift",
        "circle_resolve",
        "backbeat_engine",
        "broken_garage",
        "four_floor_bloom",
    )
    MUTATOR_SCALE_NAMES = (
        "Chromatic",
        "Major",
        "Minor",
        "Dorian",
        "Mixolydian",
        "Lydian",
        "Phrygian",
        "Locrian",
        "Whole Tone",
        "Half-whole Dim.",
        "Whole-half Dim.",
        "Minor Blues",
        "Minor Pentatonic",
        "Major Pentatonic",
        "Harmonic Minor",
        "Harmonic Major",
        "Dorian #4",
        "Phrygian Dominant",
        "Melodic Minor",
        "Lydian Augmented",
        "Lydian Dominant",
        "Super Locrian",
        "8-Tone Spanish",
        "Bhairav",
        "Hungarian Minor",
        "Hirajoshi",
        "In-Sen",
        "Iwato",
        "Kumoi",
        "Pelog Selisir",
        "Pelog Tembung",
        "Messiaen 3",
        "Messiaen 4",
        "Messiaen 5",
        "Messiaen 6",
        "Messiaen 7",
    )
    DECOUPLED_AUTOMATION_MAX_PHYSICAL_BARS = 16
    PARAMETER_DISPLAY_FEEDBACK_INTERVAL = 0.03
    VISUAL_FEEDBACK_INTERVAL = 0.1
    CLIP_PLAYING_STATUS_CC = 70
    CLIP_PLAYING_STATUS_CHANNEL = 11
    CHUNKED_INCOMING_SYSEX_IDS = (14, 15, 16, 35, 36, 49, 50, 51, 55, 57, 58, 60, 62, 82)
    SYSEX_21_BIT_MAX_MAGNITUDE = 0x1FFFFF
    NOTE_FLAG_MUTE = 0x01
    NOTE_FLAG_NEGATIVE_START = 0x02
    NOTE_FLAG_NEGATIVE_DURATION = 0x04
    MARKER_ID_MASK = 0x3F
    MARKER_FLAG_NEGATIVE_TIME = 0x40
    DECOUPLED_FLAG_ACTIVE = 0x01
    DECOUPLED_FLAG_NEGATIVE_NOTE_START = 0x02
    DECOUPLED_FLAG_NEGATIVE_NOTE_END = 0x04
    DECOUPLED_FLAG_NEGATIVE_NOTE_LENGTH = 0x08
    DECOUPLED_FLAG_NEGATIVE_PHYSICAL_END = 0x10
    MUTATOR_SECTION_ROLE_MASK = 0x3F
    MUTATOR_SECTION_FLAG_NEGATIVE_START = 0x40
    DISPLAY_VALUE_NUMBER_PATTERN = re.compile(r'(?<![\d.])([+-]?\d+)\.(\d+)(?![\d.])')
    PARAMETER_METADATA_RECHECK_INTERVAL = 0.1
    PARAMETER_METADATA_RECHECK_DURATION = 1.2
    UNMAPPED_PARAMETER_METADATA_ITEM = "*--&&-|0|127|0.0|0.0|32|"
    UNMAPPED_PARAMETER_METADATA = ",".join([UNMAPPED_PARAMETER_METADATA_ITEM] * 8)
    TRACK_DEVICE_NAV_NAME = "line.3.horizontal"
    TRACK_DEVICE_MAIN_BANK_NAME = "Main"
    TRACK_DEVICE_SEND_BANK_NAME = "Sends"
    TRACK_DEVICE_BANK_SIZE = 8
    TRACK_DEVICE_PITCH_BEND_CENTER = 8192.0
    TRACK_DEVICE_PITCH_BEND_MAX = 16383.0
    NOTE_REPEAT_RATES = (1.0, 2.0 / 3.0, 0.5, 1.0 / 3.0, 0.25, 1.0 / 6.0, 0.125, 1.0 / 12.0)
    NOTE_REPEAT_DEFAULT_INDEX = 2
    NOTE_REPEAT_ENABLED_DATA_KEY = "tap-note-repeat-enabled"
    NOTE_REPEAT_RATE_DATA_KEY = "tap-note-repeat-rate"
    MPE_MEMBER_CHANNEL_COUNT = 14
    MPE_PITCH_BEND_RANGE = 48
    TRACK_DEVICE_MIDI_CONTROLS = (
        {"name": "Mod Wheel", "kind": "mod_wheel", "min": 0.0, "max": 127.0, "default": 0.0, "automatable": False},
        {"name": "Pressure", "kind": "pressure", "min": 0.0, "max": 127.0, "default": 0.0, "automatable": False},
        {"name": "Pitch Bend", "kind": "pitch_bend", "min": 0.0, "max": 16383.0, "default": 8192.0, "automatable": False},
        {"name": "Velocity", "kind": "velocity", "min": 1.0, "max": 127.0, "default": 100.0, "automatable": False},
    )
    TRACK_DEVICE_SLIDE_CONTROL = {
        "name": "Slide",
        "kind": "slide",
        "min": 0.0,
        "max": 127.0,
        "default": 0.0,
        "automatable": False,
    }
    AUTOMATION_ENVELOPE_MAX_SAMPLES = 1024
    AUTOMATION_ENVELOPE_LINEAR_EPSILON = 0.0015
    AUTOMATION_ENVELOPE_JUMP_THRESHOLD = 0.1
    AUTOMATION_FOLDED_ENDPOINT_ORDER = 2147483647
    

    def __init__(self, c_instance):
        ControlSurface.__init__(self, c_instance)
        with self.component_guard():
            global mixer
            global transport
            global session_component
            self.mixer_status = False
            self.mixer_reset = True
            self.visible_channels = (0, 3)
            self.device_status = True
            self.seq_status = False
            self.seq_clip_playing_status = 2
            track_count = 127
            return_count = 12  # Maximum of 12 Sends and 12 Returns
            max_clip_slots = 800  # Adjust this number based on your needs
            self.playing_position_listeners = [None] * max_clip_slots
            self._playing_position_listener_clips = {}
            self._playing_note_cache = {}
            self._playing_note_cache_listeners = {}
            self._playing_note_cache_dirty = set()
            self.current_clip_notes = []
            self.last_selected_clip_slot = None
            self._step_seq_listener_clip = None
            self.last_raw_notes = None
            self.currently_playing_notes = [False] * 128
            self.last_playing_position = 0.0
            self.last_sent_out_playing_pos = 0.0
            self._last_sent_playing_pos_cc_pair = None
            self.clip_length_trick = 110.0
            mixer = MixerComponent(track_count, return_count)
            transport = TransportComponent()
            session_component = SessionComponent()
            self.old_clips_array = []
            self._drum_rack_device = None
            self.was_initialized = False
            self._track_level_listeners = {}
            self._return_level_listeners = {}
            self._master_level_listeners = {}
            self._mixer_meter_targets = {}
            self._last_meter_values = {}
            self._disabled_parameter_listeners = {}
            self._disabled_parameters = []
            self._current_disabled_controls = []
            self._automation_state_listeners = {}
            self._automation_metadata_update_timer = None
            self._automation_metadata_retry_count = 0
            self._automation_metadata_retry_start = None
            self._last_automation_signature = None
            # browser pagination state
            self.browser_current_items = []
            self.browser_current_page = 0
            self.browser_pages_count = 0
            self.browser_items_per_page = 12
            self.browser_insert_after_device_index = None
            self.browser_audio_clip_target = None
            self.browser_current_path = []
            self.browser_search_restore_state = None
            self.browser_search_query = ''
            self.browser_search_tag_indices = []
            self.browser_search_generation = 0
            self.browser_search_work = None
            self.browser_search_batch_size = 100
            self.browser_search_max_items = 50000
            self.browser_previewable_keys = set()
            self.browser_search_group_by_key = {}
            self.browser_search_result_items = []
            self.browser_showing_search_results = False
            self.browser_search_scope = ''
            # browser navigation history for back button
            self.browser_history = []
            self.browser_folder_mapping = {
                0: 'audio_effects',
                1: 'colors',
                2: 'current_project',
                3: 'drums',
                4: 'instruments',
                5: 'max_for_live',
                6: 'midi_effects',
                7: 'packs',
                8: 'plugins',
                9: 'sounds',
                10: 'user_folders',
                11: 'user_library',
                12: 'samples',
                13: 'clips'
            }
            self.browser_folder_labels = {
                0: 'Audio Effects',
                1: 'Colors',
                2: 'Current Project',
                3: 'Drums',
                4: 'Instruments',
                5: 'Max For Live',
                6: 'MIDI Effects',
                7: 'Packs',
                8: 'Plug-Ins',
                9: 'Sounds',
                10: 'User Folders',
                11: 'User Library',
                12: 'Samples',
                13: 'Clips',
                14: 'Drum Hits'
            }
            # These are the content tags exposed by Live's control-surface Browser API.
            # The desktop browser's arbitrary user tag database is not part of that API.
            self.browser_searchable_tag_indices = (0, 3, 4, 5, 6, 8, 9, 12, 13, 14)
            self._metadata_recheck_timer = None
            self._last_sent_metadata = None
            self._last_drum_pad_metadata = None
            self._drum_pad_change_recheck_count = 0
            self._drum_pad_recheck_start = None
            self._last_drum_pad_note = None
            self._last_drum_pad_change_at = 0.0
            self._device_recheck_start = None
            self._device_recheck_count = 0
            self._debug_mode = False
            self._metadata_cache = {}
            self._metadata_send_seq = 0
            self._metadata_send_seq_by_device = {}
            self._automation_metadata_device_id = None
            self._automation_timer_lock = threading.Lock()
            self._mixer_disconnect_timer = None
            self._follow_action_rules = {}
            self._active_follow_actions = {}
            self._handled_follow_action_launches = set()
            self._active_high_resolution_gestures = set()
            self._active_high_resolution_undo_steps = set()
            self._parameter_value_listeners = {}
            self._parameter_name_listeners = {}
            self._parameter_name_update_timer = None
            self._active_bank_parameter_refresh_pending = False
            self._bank_metadata_refresh_timers = []
            self._parameter_source_device = None
            self._parameter_source_listener = None
            self._bank_parameter_source_device = None
            self._bank_parameter_source_listener = None
            self._wavetable_virtual_property_listeners = []
            self._dynamic_parameter_state_listeners = []
            self._dynamic_parameter_refresh_pending = False
            self._dynamic_parameter_remap_pending = False
            self._meld_engine_listener_device = None
            self._meld_engine_listener = None
            self._meld_engine_refresh_pending = False
            self._last_sent_parameter_displays = {}
            self._last_sent_parameter_normalized_values = {}
            self._last_sent_parameter_cc_values = {}
            self._last_parameter_display_feedback_times = {}
            self._follow_action_track_signature = None
            self._follow_action_missing_clip_counts = {}
            self._last_follow_action_state = None
            self._last_song_is_playing = False
            self._last_sent_transport_state = None
            self._last_sent_session_record_state = None
            self._note_repeat = getattr(c_instance, "note_repeat", None)
            self._note_repeat_last_record_quantization = None
            self._last_note_repeat_feedback = None
            if self._note_repeat is not None:
                try:
                    self._note_repeat.enabled = False
                    self._note_repeat.repeat_rate = self.NOTE_REPEAT_RATES[self.NOTE_REPEAT_DEFAULT_INDEX]
                except Exception:
                    self._note_repeat = None
            self._decoupled_automation_recording_active = False
            self._decoupled_automation_recording_snapshots = {}
            self._decoupled_automation_recording_generation = 0
            self._follow_action_scene_triggered_listeners = {}
            self._follow_action_clip_slot_runtime_listeners = {}
            self._follow_action_scene_name_listeners = {}
            self._follow_action_clip_name_listeners = {}
            self._follow_action_clip_has_clip_listeners = {}
            self._follow_action_clip_timing_listeners = {}
            self._follow_action_song_listener_subject = None
            self._mutator_regeneration_states = {}
            self._mutator_generation_in_progress = set()
            self._mutator_generation_scheduled = set()
            self._queued_mutator_work = {}
            self._last_mutator_generation_times = {}
            self._last_mutator_generation_request_times = {}
            self._last_mutator_generation_signatures = {}
            self._mutator_playing_clip_keys = set()
            self._mutator_triggered_clip_keys = set()
            self._has_mutator_clips = False
            self._mutator_clip_presence_dirty = True
            self._mutator_generation_lock = threading.RLock()
            self._last_mutator_scale_root_signature = None
            self._mutator_scale_root_sync_scheduled = False
            self._selected_clip_update_suppression_depth = 0
            self._selected_clip_update_pending_metadata = False
            self._selected_clip_update_pending_notes = False
            self._clip_slot_listeners = {}
            self._registered_track_ids = set()
            self._clip_color_listeners = {}
            self._clip_listener_track_slots = {}
            self._clip_slot_color_map = {}
            self._track_list_signature = None
            self._last_group_fold_states = None
            self._last_group_hidden_states = None
            self._previous_selected_track = None
            self._periodic_timer_ref = None
            self._last_clip_slot_integrity_check = 0.0
            self._clip_position_feedback_enabled = False
            self._clip_position_feedback_track_indexes = ()
            self._last_clip_position_feedback_time = 0.0
            self._last_visual_feedback_payload = None
            self._smooth_macro_randomize_token = 0
            self._smooth_macro_randomize_state = None
            self._re_enable_automation_enabled_state = None
            self._remove_automation_from_next_encoder = False
            self._automation_parameter_action = None
            self._automation_removal_suppressed_controls = set()
            self._automation_authored_steps = {}
            self._mixer_automation_controls = []
            self._mixer_automation_status_specs = []
            self._mixer_automation_state_listeners = []
            self._mixer_automation_status_timers = []
            self._track_device_selected = False
            self._track_control_selection_by_track = {}
            self._track_control_bank_index_by_track = {}
            self._track_midi_control_values_by_track = {}
            self._track_expression_control_kind = "slide"
            self._simpler_device = None
            self._simpler_sample = None
            self._simpler_decorator = None
            self._simpler_slice_nudging = None
            self._simpler_zoom = 0.0
            self._simpler_waveform_center = 0.5
            self._simpler_listener_bindings = []
            self._simpler_waveform_generation = 0
            self._simpler_waveform_cache = {}
            self._simpler_waveform_cache_order = []
            self._simpler_waveform_failures = {}
            self._simpler_waveform_failure_order = []
            self._simpler_waveform_lock = threading.Lock()
            self._simpler_waveform_pending = set()
            self._simpler_waveform_polling = set()
            self._simpler_warp_as_beats = 2.0
            self._simpler_playhead_high = -1
            self._simpler_playhead_low = -1
            self._simpler_playhead_enabled = None
            self._last_track_simpler_slice_signature = None
            self._audio_clip_waveform_generation = 0
            self._audio_clip_listener_bindings = []
            self._audio_clip_listener_clip = None
            self._last_audio_clip_state = None
            self._last_audio_clip_position_state_time = 0.0
            self._last_audio_clip_action_result = None
            self.periodic_timer = 1
            # connection check button
            connection_check_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 94)
            connection_check_button.add_value_listener(self._connection_established)
            self.transport_toggle_button = ButtonElement(1, MIDI_CC_TYPE, 0, 116)
            self.transport_toggle_button.add_value_listener(self._transport_toggle_value)
            # send project again button
            send_project_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 88)
            send_project_button.add_value_listener(self._send_project)

            # making a song instance
            self.song_instance = self.song()
            
            self._last_playing_pos_sent = 0.0
            self._ensure_follow_action_song_listeners(self.song_instance)
            self._sync_follow_action_name_listeners()
            self._load_follow_actions_from_names(force_send=True)
            self._sync_follow_action_runtime_listeners()
            self._start_periodic_execution()

    def _schedule_main_thread(self, delay_seconds, callback, args=()):
        """Run Live API work on ControlSurface's main scheduling thread."""
        return TapScheduledCall(self, delay_seconds, callback, args)

    def _setup_device_control(self):
        self._device = TapDeviceComponent()
        self._device.name = 'Device_Component'
        
        self._device_controls = []
        for index in range(8):
            control = EncoderElement(MIDI_CC_TYPE, 8, 72 + index, Live.MidiMap.MapMode.absolute)
            control.name = 'Ctrl_' + str(index)
            control.add_value_listener(lambda value, control=control: self._on_device_control_value(value, control))
            self._device_controls.append(control)
        
        nav_left_button = ButtonElement(1, MIDI_CC_TYPE, 0, 33)
        nav_right_button = ButtonElement(1, MIDI_CC_TYPE, 0, 32)
        self._device.set_bank_nav_buttons(nav_left_button, nav_right_button)
        
        # Set up device change listener
        self._on_device_changed.subject = self._device
        self.set_device_component(self._device)
        
        # Register button listeners for navigation buttons
        nav_left_button.add_value_listener(self._on_nav_button_pressed)
        nav_right_button.add_value_listener(self._on_nav_button_pressed)
        
        # Initially connect the controls (assuming we start in device mode)
        self._connect_device_controls()

    def _connect_device_controls(self):
        if hasattr(self, '_device_controls'):
            for control in self._device_controls:
                try:
                    control.suppress_script_forwarding = False
                except Exception:
                    pass
            # API-backed virtual parameters (Drift/Meld/Hybrid selectors) are
            # normal Python control-surface objects, not Live ATimeableValues.
            # Passing them to Live's native MIDI mapper raises a Boost.Python
            # ArgumentError on every rebuild. Leave those slots script-driven.
            controls = list(self._device_controls)
            try:
                _, bank_parameters = self._device._current_bank_details()
                selected_device = self._selected_device()
                for index, parameter in enumerate(bank_parameters or ()):
                    if index < len(controls) and self._parameter_is_tap_virtual(parameter, selected_device):
                        controls[index] = None
            except Exception:
                pass
            self._device.set_parameter_controls(tuple(controls))
        self._refresh_parameter_value_listeners_current_bank()
        self._refresh_parameter_name_listeners_current_bank()
        self._readd_disabled_parameter_listeners()
    
    def _disconnect_device_controls(self):
        if hasattr(self, '_device'):
            self._device.set_parameter_controls([])
        self._remove_parameter_value_listeners()
        self._remove_parameter_name_listeners()
        self._remove_disabled_parameter_listeners()
        self._remove_automation_state_listeners()

    def _connect_track_device_parameter_controls(self, track=None):
        if not hasattr(self, "_device") or not hasattr(self, "_device_controls"):
            return

        controls = []
        for control_index, control in enumerate(self._device_controls):
            entry = self._track_device_parameter_entry_for_control(control_index, track)
            is_parameter = bool(entry and entry.get("kind") == "parameter")
            try:
                control.suppress_script_forwarding = False
            except Exception:
                pass
            controls.append(control if is_parameter else None)
        self._device.set_parameter_controls(tuple(controls))

    def _on_nav_button_pressed(self, value):
        if value:
            self._on_device_changed(False)
            self._schedule_bank_metadata_refreshes()

    def _mapped_parameter_for_device_control(self, control_index):
        try:
            if not hasattr(self, '_device_controls') or control_index < 0 or control_index >= len(self._device_controls):
                return None
            control = self._device_controls[control_index]
            mapped_parameter = control.mapped_parameter() if control else None
            return mapped_parameter if mapped_parameter and liveobj_valid(mapped_parameter) else None
        except Exception:
            return None

    def _tap_device_kind(self, device):
        try:
            class_name = str(device.class_name)
            display_name = str(device.class_display_name)
            if class_name == 'Operator' or display_name == 'Operator':
                return 'operator_waves'
            if (class_name in ('Wavetable', 'InstrumentVector') or display_name == 'Wavetable' or
                    hasattr(device, 'oscillator_1_wavetables')):
                return 'wavetable_osc'
        except Exception:
            pass
        return None

    def _tap_visible_bank_info(self, device):
        device = device or getattr(self._device, '_device', None)
        names = list(self._device._parameter_bank_names())
        kind = self._tap_device_kind(device)
        if kind == 'operator_waves':
            name = self._device.OPERATOR_WAVES_BANK_NAME
        elif kind == 'wavetable_osc':
            name = self._device.WAVETABLE_OSC_BANK_NAME
        else:
            return names, None, None, None
        try:
            insert_index = names.index(name)
        except ValueError:
            return names, None, None, None
        return names, kind, insert_index, name

    def _tap_active_custom_kind(self, device=None):
        try:
            component_device = getattr(self._device, '_device', None)
            device = device or component_device
            if (device and component_device and
                    self._live_object_identity(device) == self._live_object_identity(component_device)):
                return self._device.tap_custom_bank_kind()
        except Exception:
            pass
        return None

    def _active_wavetable_virtual_specs(self):
        """The Wavetable chooser properties are intentionally outside device.parameters."""
        try:
            device = self._device._device
            active_kind = self._tap_active_custom_kind(device)
            if not device or not liveobj_valid(device) or active_kind != 'wavetable_osc':
                return []
        except Exception:
            return []

        if not self._device._is_wavetable():
            return []

        sub_tone = None
        try:
            for parameter in device.parameters:
                if (parameter.name in ('Sub Tone', 'Sub Tone ', 'Tone') or
                        parameter.original_name in ('Sub Tone', 'Tone')):
                    sub_tone = parameter
                    break
        except Exception:
            pass

        return [
            {'name': 'Osc 1 Category', 'values': 'oscillator_wavetable_categories', 'index': 'oscillator_1_wavetable_category'},
            {'name': 'Osc 1 Table', 'values': 'oscillator_1_wavetables', 'index': 'oscillator_1_wavetable_index'},
            {'name': 'Osc 2 Category', 'values': 'oscillator_wavetable_categories', 'index': 'oscillator_2_wavetable_category'},
            {'name': 'Osc 2 Table', 'values': 'oscillator_2_wavetables', 'index': 'oscillator_2_wavetable_index'},
            {'name': 'Osc 1 Effect', 'items': ('None', 'FM', 'Sync & PW', 'Warp & Fold'), 'index': 'oscillator_1_effect_mode'},
            {'name': 'Osc 2 Effect', 'items': ('None', 'FM', 'Sync & PW', 'Warp & Fold'), 'index': 'oscillator_2_effect_mode'},
            {'name': 'Sub Tone', 'parameter': sub_tone},
            {'name': 'Unison', 'items': ('None', 'Classic', 'Slow Shimmer', 'Fast Shimmer', 'Phase Sync', 'Position Spread', 'Random Note'), 'index': 'unison_mode'},
        ]

    def _wavetable_virtual_spec(self, control_index):
        specs = self._active_wavetable_virtual_specs()
        return specs[control_index] if 0 <= control_index < len(specs) else None

    def _wavetable_virtual_items(self, spec):
        if not spec:
            return ()
        if spec.get('parameter'):
            parameter = spec['parameter']
            try:
                return tuple(parameter.value_items) if parameter.is_quantized else ()
            except Exception:
                return ()
        try:
            device = self._device._device
            return tuple(spec.get('items') or getattr(device, spec['values']))
        except Exception:
            return tuple(spec.get('items') or ())

    def _wavetable_virtual_index(self, spec):
        if spec.get('parameter'):
            return self._parameter_current_value_item_index(spec['parameter'], len(self._wavetable_virtual_items(spec)))
        try:
            return int(getattr(self._device._device, spec['index']))
        except Exception:
            return 0

    def _set_wavetable_virtual_normalized(self, control_index, normalized):
        spec = self._wavetable_virtual_spec(control_index)
        if not spec:
            return False
        items = self._wavetable_virtual_items(spec)
        parameter = spec.get('parameter')
        if parameter and not items:
            try:
                parameter.value = self._parameter_target_value_from_normalized(parameter, normalized)
                self._send_wavetable_virtual_feedback(control_index)
                return True
            except Exception:
                return False
        if not items:
            return False
        index = max(0, min(len(items) - 1, int(math.floor(float(normalized) * (len(items) - 1) + 0.5))))
        try:
            if spec.get('parameter'):
                parameter = spec['parameter']
                parameter.value = self._parameter_target_value_from_normalized(parameter, float(index) / max(1, len(items) - 1))
            else:
                setattr(self._device._device, spec['index'], index)
            self._send_wavetable_virtual_feedback(control_index)
            return True
        except Exception as error:
            self._debug_log('Error setting Wavetable {}: {}'.format(spec['name'], error))
            return False

    def _send_wavetable_virtual_feedback(self, control_index):
        spec = self._wavetable_virtual_spec(control_index)
        if not spec:
            return
        items = self._wavetable_virtual_items(spec)
        parameter = spec.get('parameter')
        if parameter and not items:
            normalized = self._parameter_normalized_value(parameter)
            self.send_cc(72 + control_index, 8, int(round(normalized * 127)))
            self._send_sys_ex_message('{}|{}|{}'.format(control_index, normalized, self._escape_sysex_string(self._parameter_display_value(parameter))), 0x28)
            return
        if not items:
            return
        index = max(0, min(len(items) - 1, self._wavetable_virtual_index(spec)))
        normalized = float(index) / float(max(1, len(items) - 1))
        display = self._escape_sysex_string(str(items[index]))
        cc_value = int(round(normalized * 127))
        self.send_cc(72 + control_index, 8, cc_value)
        self._send_sys_ex_message('{}|{}|{}'.format(control_index, normalized, display), 0x28)

    def _send_wavetable_virtual_feedback_all(self):
        for control_index in range(len(self._active_wavetable_virtual_specs())):
            self._send_wavetable_virtual_feedback(control_index)

    def _remove_wavetable_virtual_property_listeners(self):
        for device, property_name, listener in list(getattr(self, '_wavetable_virtual_property_listeners', [])):
            remove_listener = getattr(device, 'remove_{}_listener'.format(property_name), None)
            if remove_listener and liveobj_valid(device):
                try:
                    remove_listener(listener)
                except Exception:
                    pass
        self._wavetable_virtual_property_listeners = []

    def _on_wavetable_virtual_property_changed(self):
        if not self._active_wavetable_virtual_specs():
            return
        self._send_sys_ex_message(self._wavetable_virtual_metadata(), 0x7D)
        self._send_wavetable_virtual_feedback_all()

    def _setup_wavetable_virtual_property_listeners(self):
        self._remove_wavetable_virtual_property_listeners()
        if not self._active_wavetable_virtual_specs():
            return

        device = self._device._device
        property_names = (
            'oscillator_1_wavetable_category',
            'oscillator_1_wavetable_index',
            'oscillator_1_wavetables',
            'oscillator_2_wavetable_category',
            'oscillator_2_wavetable_index',
            'oscillator_2_wavetables',
            'oscillator_1_effect_mode',
            'oscillator_2_effect_mode',
            'unison_mode',
        )
        for property_name in property_names:
            add_listener = getattr(device, 'add_{}_listener'.format(property_name), None)
            if not add_listener:
                continue
            listener = lambda: self._on_wavetable_virtual_property_changed()
            try:
                add_listener(listener)
                self._wavetable_virtual_property_listeners.append((device, property_name, listener))
            except Exception:
                pass

    def _remove_dynamic_parameter_state_listeners(self):
        for parameter, listener_type, listener in list(getattr(self, '_dynamic_parameter_state_listeners', [])):
            remove_listener = getattr(parameter, 'remove_{}_listener'.format(listener_type), None)
            has_listener = getattr(parameter, '{}_has_listener'.format(listener_type), None)
            if remove_listener and liveobj_valid(parameter):
                try:
                    if not has_listener or has_listener(listener):
                        remove_listener(listener)
                except Exception:
                    pass
        self._dynamic_parameter_state_listeners = []

    def _schedule_dynamic_parameter_refresh(self, remap=False):
        self._dynamic_parameter_remap_pending = self._dynamic_parameter_remap_pending or remap
        if self._dynamic_parameter_refresh_pending:
            return
        self._dynamic_parameter_refresh_pending = True
        self.schedule_message(1, self._refresh_dynamic_parameter_state)

    def _refresh_dynamic_parameter_state(self):
        self._dynamic_parameter_refresh_pending = False
        remap = self._dynamic_parameter_remap_pending
        self._dynamic_parameter_remap_pending = False
        if not liveobj_valid(self._device):
            return

        if remap:
            self._device.invalidate_parameter_bank_cache()
            self._connect_device_controls()
            self._device.update()
            try:
                self.request_rebuild_midi_map()
            except Exception:
                pass
            if self._device._is_drift() or self._device._is_meld():
                self._force_send_current_bank_metadata()
                self._setup_dynamic_parameter_state_listeners()
            elif self._device._uses_curated_banks():
                self._force_send_current_bank_metadata()
                self._setup_dynamic_parameter_state_listeners()
            else:
                self._on_device_changed(False)
        else:
            self._force_send_current_bank_metadata()

    def _setup_dynamic_parameter_state_listeners(self):
        self._remove_dynamic_parameter_state_listeners()
        device = getattr(self._device, '_device', None)
        if not device or not liveobj_valid(device):
            return

        try:
            bank_name, bank_parameters = self._device._current_bank_details()
        except Exception:
            return

        seen_bindings = set()

        def add_parameter_listener(parameter, listener_type, remap=False):
            add_listener = getattr(parameter, 'add_{}_listener'.format(listener_type), None) if parameter else None
            if not add_listener:
                return
            binding = (id(parameter), listener_type, bool(remap))
            if binding in seen_bindings:
                return
            seen_bindings.add(binding)
            listener = lambda remap=remap: self._schedule_dynamic_parameter_refresh(remap)
            try:
                add_listener(listener)
                self._dynamic_parameter_state_listeners.append((parameter, listener_type, listener))
            except Exception:
                pass

        # Live exposes parameter relevance through DeviceParameter.state.  Listen
        # only to the eight visible parameters and update metadata when Live
        # changes their state; no device-specific activity rules are needed.
        remap_dynamic_bank = (
            self._device._is_drift() or self._device._is_meld() or
            self._device._is_auto_filter() or self._device._is_auto_filter_2() or
            self._device._is_hybrid_reverb()
        )
        for parameter in bank_parameters or ():
            add_parameter_listener(parameter, 'state', remap=remap_dynamic_bank)

        if self._device._uses_curated_banks():
            # Listen only to selectors referenced by conditional slots.
            for parameter in self._device._decorated_parameters():
                if self._device.curated_parameter_drives_bank(parameter):
                    add_parameter_listener(parameter, 'value', remap=True)

        if self._device._is_simpler():
            normalized_bank_name = re.sub(r'[^a-z0-9]+', '', str(bank_name).lower())
            if normalized_bank_name == 'lfo':
                add_parameter_listener(self._device._parameter_by_names('L Sync'), 'value', remap=True)
            elif normalized_bank_name == 'controls':
                add_parameter_listener(self._device._parameter_by_names('Warp Mode'), 'value', remap=True)
            return

        if self._device._is_delay():
            # Delay does not publish relevance changes for all of its dependent
            # parameters, so refresh the visible metadata when the selectors
            # that drive Tap's explicit rules change.
            for names in (
                ('Link', 'Stereo Time Link'),
                ('L Sync', 'L Delay Sync'),
                ('R Sync', 'R Delay Sync'),
                ('LFO Mode', 'LF Mode', 'Mod LFO Mode', 'LFO Time Mode'),
            ):
                add_parameter_listener(self._device._parameter_by_names(*names), 'value')
            return

        if self._device._is_auto_filter_2():
            for names in (
                ('Filter Type',),
                ('LFO T Mode',),
                ('LFO S Mode',),
                ('S/C EQ Type',),
                ('LFO Q Mode',),
            ):
                add_parameter_listener(self._device._parameter_by_names(*names), 'value', remap=True)
            return

        if self._device._is_auto_filter():
            for names in (
                ('Filter Type', 'Filter Type (Legacy)'),
                ('LFO Sync',),
                ('LFO Stereo Mode',),
            ):
                add_parameter_listener(self._device._parameter_by_names(*names), 'value', remap=True)
            return

        if self._device._is_hybrid_reverb():
            normalized_bank_name = re.sub(r'[^a-z0-9]+', '', str(bank_name).lower())
            if normalized_bank_name in ('main', 'algorithmpg1', 'algorithmpg2'):
                add_parameter_listener(self._device._parameter_by_names('Algo Type'), 'value', remap=True)
            elif normalized_bank_name == 'eqpg1':
                add_parameter_listener(
                    self._device._parameter_by_names('EQ Low Type', 'EQ Lo Type'),
                    'value', remap=True
                )
                add_parameter_listener(
                    self._device._parameter_by_names('EQ High Type', 'EQ Hi Type'),
                    'value', remap=True
                )
            elif normalized_bank_name == 'global':
                add_parameter_listener(
                    self._device._parameter_by_names('P.Dly Sync', 'Predelay Sync'),
                    'value', remap=True
                )
            return

        if self._device._is_drift():
            normalized_bank_name = re.sub(r'[^a-z0-9]+', '', str(bank_name).lower())
            if normalized_bank_name == 'lfo':
                add_parameter_listener(self._device._parameter_by_names('LFO Time Mode'), 'value', remap=True)
            elif normalized_bank_name in ('envelope2', 'envelope2cyc'):
                add_parameter_listener(
                    self._device._parameter_by_names('Env 2 Cyc On'),
                    'value',
                    remap=normalized_bank_name == 'envelope2'
                )
                add_parameter_listener(self._device._parameter_by_names('Cyc Env Time Mode', 'Cyc Mode'), 'value')
            elif normalized_bank_name == 'global':
                add_parameter_listener(self._device._parameter_by_names('Voice Mode'), 'value')
            return

        if self._device._is_meld():
            normalized_bank_name = re.sub(r'[^a-z0-9]+', '', str(bank_name).lower())
            if normalized_bank_name == 'globalout':
                add_parameter_listener(self._device._parameter_by_names('Mono Poly'), 'value', remap=True)
            return

        if not self._device._is_operator():
            return

        if bank_name == self._device.OPERATOR_WAVES_BANK_NAME:
            add_parameter_listener(self._device._parameter_by_names('Algorithm'), 'value')
        elif bank_name == self._device.OPERATOR_FILTER_PLUS_BANK_NAME:
            add_parameter_listener(
                self._device._parameter_by_names('Filter Type', 'Filter Type (Legacy)'),
                'value',
                remap=True
            )
        elif re.sub(r'[^a-z0-9]+', '', str(bank_name).lower()) == 'lfo':
            add_parameter_listener(self._device._parameter_by_names('LFO Range'), 'value', remap=True)

    def _wavetable_virtual_metadata(self):
        metadata = []
        for spec in self._active_wavetable_virtual_specs():
            items = self._wavetable_virtual_items(spec)
            parameter = spec.get('parameter')
            if parameter and not items:
                try:
                    min_value = parameter.str_for_value(parameter.min)
                    max_value = parameter.str_for_value(parameter.max)
                    default_value = getattr(parameter, 'default_value', parameter.min)
                    default_display = parameter.str_for_value(default_value)
                    value_range = parameter.max - parameter.min
                    default_normalized = ((default_value - parameter.min) / value_range) if value_range else 0.0
                    quarter_display = parameter.str_for_value(parameter.min + (parameter.max - parameter.min) * 32.0 / 127.0)
                    automatable = self._parameter_is_automatable(parameter)
                    metadata.append('{}|{}|{}|{}|{}|{}||{}|{}'.format(
                        self._parameter_metadata_name(self._escape_sysex_string(spec['name']), automatable),
                        self._escape_sysex_string(min_value), self._escape_sysex_string(max_value),
                        self._escape_sysex_string(default_display),
                        default_normalized, self._escape_sysex_string(quarter_display),
                        self._escape_sysex_string(self._parameter_display_value(parameter)),
                        self._parameter_normalized_value(parameter)))
                    continue
                except Exception:
                    metadata.append(self.UNMAPPED_PARAMETER_METADATA_ITEM)
                    continue
            if not items:
                metadata.append(self.UNMAPPED_PARAMETER_METADATA_ITEM)
                continue
            index = max(0, min(len(items) - 1, self._wavetable_virtual_index(spec)))
            normalized = float(index) / float(max(1, len(items) - 1))
            metadata.append('{}|{}|{}|{}|0.0|{}|{}|{}|{}'.format(
                self._parameter_metadata_name(self._escape_sysex_string(spec['name']), False),
                self._escape_sysex_string(str(items[0])),
                self._escape_sysex_string(str(items[-1])),
                self._escape_sysex_string(str(items[0])),
                self._escape_sysex_string(str(items[min(len(items) - 1, int(round((len(items) - 1) * 32 / 127.0)))])),
                ';'.join(self._escape_sysex_string(str(item)) for item in items),
                self._escape_sysex_string(str(items[index])),
                normalized,
            ))
        metadata.extend([self.UNMAPPED_PARAMETER_METADATA_ITEM] * (8 - len(metadata)))
        return ','.join(metadata[:8])

    def _parameter_normalized_value(self, device_param):
        try:
            if not device_param or not hasattr(device_param, 'value') or not hasattr(device_param, 'min') or not hasattr(device_param, 'max'):
                return 0.0
            min_val = device_param.min
            max_val = device_param.max
            if max_val == min_val:
                return 0.0
            normalized = (device_param.value - min_val) / (max_val - min_val)
            return max(0.0, min(1.0, normalized))
        except Exception:
            return 0.0

    def _parameter_display_value(self, device_param):
        try:
            if device_param and hasattr(device_param, 'str_for_value') and hasattr(device_param, 'value'):
                return self._format_display_value_numbers(device_param.str_for_value(device_param.value).replace('∞', 'Inf'))
        except Exception:
            pass
        try:
            display_value = device_param.display_value
            if display_value is not None:
                return self._format_display_value_numbers(str(display_value).replace('∞', 'Inf'))
        except Exception:
            pass
        try:
            return self._format_display_value_numbers(str(device_param.value).replace('∞', 'Inf'))
        except Exception:
            return ""

    def _parameter_value_items(self, device_param):
        if not getattr(device_param, 'is_quantized', False):
            try:
                if not self._parameter_is_tap_virtual(device_param):
                    return ()
            except Exception:
                return ()
        try:
            return tuple(str(item) for item in device_param.value_items)
        except Exception:
            return ()

    def _parameter_is_quantized(self, device_param):
        return bool(getattr(device_param, 'is_quantized', False) or self._parameter_value_items(device_param))

    def _format_display_value_numbers(self, display_value):
        def format_match(match):
            integer_part = match.group(1)
            fractional_part = match.group(2)
            decimals = 1 if len(integer_part.lstrip('+-')) > 1 else 2
            if len(fractional_part) <= decimals:
                return match.group(0)
            try:
                value = float("{}.{}".format(integer_part, fractional_part))
                return "{:.{}f}".format(value, decimals)
            except Exception:
                return match.group(0)

        try:
            return self.DISPLAY_VALUE_NUMBER_PATTERN.sub(format_match, str(display_value))
        except Exception:
            return display_value

    def _parameter_target_value_from_normalized(self, device_param, normalized):
        min_val = device_param.min
        max_val = device_param.max
        if max_val == min_val:
            return min_val

        normalized = max(0.0, min(1.0, float(normalized)))

        quantized_without_items = False
        if self._parameter_is_quantized(device_param):
            item_count = len(self._parameter_value_items(device_param))
            if item_count > 1:
                item_index = int(math.floor(normalized * (item_count - 1) + 0.5))
                normalized = float(item_index) / float(item_count - 1)
            else:
                quantized_without_items = True

        target_value = min_val + (max_val - min_val) * normalized
        if quantized_without_items:
            target_value = round(target_value)
        return max(min_val, min(max_val, target_value))

    def _normalized_option_text(self, value):
        try:
            return str(value).strip().lower()
        except Exception:
            return ""

    def _parameter_current_value_item_index(self, device_param, item_count):
        display_value = self._normalized_option_text(self._parameter_display_value(device_param))
        value_items = self._parameter_value_items(device_param)
        if display_value and value_items:
            for index, item in enumerate(value_items):
                if self._normalized_option_text(item) == display_value:
                    return index

        try:
            normalized = self._parameter_normalized_value(device_param)
            return max(0, min(item_count - 1, int(math.floor(normalized * (item_count - 1) + 0.5))))
        except Exception:
            return 0

    def _set_device_control_next_option(self, control_index, device_param):
        value_items = self._parameter_value_items(device_param)
        item_count = len(value_items)
        if item_count <= 1:
            return

        current_index = self._parameter_current_value_item_index(device_param, item_count)
        next_index = (current_index + 1) % item_count
        normalized = float(next_index) / float(item_count - 1)
        target_value = self._parameter_target_value_from_normalized(device_param, normalized)

        if hasattr(device_param, 'begin_gesture'):
            device_param.begin_gesture()
        device_param.value = target_value
        if hasattr(device_param, 'end_gesture'):
            device_param.end_gesture()

        self._send_parameter_feedback(control_index, device_param, send_cc=False, force_display=True)

    def _send_parameter_display_value(self, control_index, device_param, force=False, throttle=False):
        if not device_param or not liveobj_valid(device_param):
            return

        now = time.time()
        if throttle and not force:
            last_sent_at = self._last_parameter_display_feedback_times.get(control_index, 0.0)
            if now - last_sent_at < self.PARAMETER_DISPLAY_FEEDBACK_INTERVAL:
                return

        display_value = self._parameter_display_value(device_param)
        normalized_value = round(self._parameter_normalized_value(device_param), 9)

        if (not force and
            self._last_sent_parameter_displays.get(control_index) == display_value and
            self._last_sent_parameter_normalized_values.get(control_index) == normalized_value):
            return

        payload = "{}|{}|{}".format(
            control_index,
            normalized_value,
            self._escape_sysex_string(display_value)
        )
        self._send_sys_ex_message(payload, 0x28)
        self._last_sent_parameter_displays[control_index] = display_value
        self._last_sent_parameter_normalized_values[control_index] = normalized_value
        self._last_parameter_display_feedback_times[control_index] = now

    def _send_parameter_feedback(self, control_index, device_param, send_cc=False, force_display=False, throttle_display=False):
        if not device_param or not liveobj_valid(device_param):
            return
        if not self._is_current_parameter_for_control(control_index, device_param):
            return

        if send_cc:
            cc_value = self._parameter_value_to_cc(device_param)
            if self._last_sent_parameter_cc_values.get(control_index) != cc_value:
                self.send_cc(72 + control_index, 8, cc_value)
                self._last_sent_parameter_cc_values[control_index] = cc_value

        self._send_parameter_display_value(
            control_index,
            device_param,
            force=force_display,
            throttle=throttle_display
        )

    def _select_parameter_if_possible(self, mapped_parameter):
        try:
            song_view = self.song().view
            if (mapped_parameter and liveobj_valid(mapped_parameter) and
                    hasattr(song_view, 'selected_parameter') and
                    song_view.selected_parameter != mapped_parameter):
                song_view.selected_parameter = mapped_parameter
        except Exception:
            pass

    def _arm_remove_automation_from_next_encoder(self, value):
        if value:
            self._remove_automation_from_next_encoder = True
            self._automation_parameter_action = "remove"
            self._automation_removal_suppressed_controls.clear()

    def _arm_re_enable_automation_from_next_encoder(self, value):
        if value:
            self._remove_automation_from_next_encoder = False
            self._automation_parameter_action = "re_enable"
            self._automation_removal_suppressed_controls.clear()

    def _pending_parameter_automation_action(self):
        if self._automation_parameter_action:
            return self._automation_parameter_action
        return "remove" if self._remove_automation_from_next_encoder else None

    def _consume_remove_automation_request(self, device_param, track=None):
        action = self._pending_parameter_automation_action()
        if not action:
            return False

        self._remove_automation_from_next_encoder = False
        self._automation_parameter_action = None
        if not device_param or not liveobj_valid(device_param):
            return True

        self._select_parameter_if_possible(device_param)
        if action == "re_enable":
            self._re_enable_automation_for_parameter(device_param)
        else:
            self._remove_automation_for_parameter(device_param, track)
        return True

    def _playing_clip_slot_for_track(self, track):
        try:
            if track is None or not hasattr(track, 'clip_slots'):
                return None
            for clip_slot in track.clip_slots:
                if clip_slot is not None and clip_slot.has_clip and clip_slot.is_playing:
                    return clip_slot
        except Exception:
            pass
        return None

    def _remove_automation_for_parameter(self, device_param, track=None):
        try:
            song = self.song()
            clip_slot = self._playing_clip_slot_for_track(track or song.view.selected_track)
            envelope_was_cleared = False
            decoupled_length_was_reset = False
            if clip_slot is not None and clip_slot.has_clip:
                clip = clip_slot.clip
                envelope = None
                if hasattr(clip, 'automation_envelope'):
                    try:
                        envelope = clip.automation_envelope(device_param)
                    except Exception:
                        envelope = None
                if envelope is not None:
                    self._clear_clip_automation_envelope(clip, envelope, device_param, self._parameter_normalized_value(device_param))
                    envelope_was_cleared = True
                self._clear_authored_automation_steps_for_parameter(clip, device_param)
                decoupled_length_was_reset = self._reset_decoupled_automation_length_for_parameter(
                    clip,
                    device_param,
                    send_updates=self._clip_is_highlighted(clip)
                )

            if envelope_was_cleared or decoupled_length_was_reset:
                self._refresh_parameter_metadata_on_automation_change()
        except Exception as e:
            self._debug_log("Error removing automation: {}".format(str(e)))

    def _clip_is_highlighted(self, clip):
        try:
            clip_slot = self.song().view.highlighted_clip_slot
            return bool(clip_slot is not None and clip_slot.has_clip and clip_slot.clip == clip)
        except Exception:
            return False

    def _reset_decoupled_automation_length_for_parameter(self, clip, device_param, send_updates=True):
        info = self._decoupled_automation_info(clip, device_param)
        if not info or not info.get("has_parameter_length"):
            return False

        self._apply_decoupled_automation_length(
            clip,
            device_param,
            info["note_length"],
            send_updates=send_updates
        )
        return True

    def _automation_clear_end_time(self, clip):
        try:
            end_time = max(
                float(getattr(clip, "loop_end", 0.0)),
                float(getattr(clip, "end_marker", 0.0)),
                float(getattr(clip, "length", 0.0)),
                float(getattr(clip, "start_marker", 0.0)),
                float(getattr(clip, "loop_start", 0.0))
            )
        except Exception:
            end_time = 0.0

        info = self._decoupled_automation_info(clip)
        if info:
            try:
                end_time = max(end_time, float(info.get("physical_end", 0.0)))
            except Exception:
                pass

        return max(0.0001, end_time)

    def _clear_clip_automation_envelope(self, clip, envelope, device_param, normalized_value):
        if clip is None or envelope is None or device_param is None:
            return False

        if hasattr(clip, "clear_envelope"):
            try:
                clip.clear_envelope(device_param)
                return True
            except Exception:
                pass

        try:
            raw_value = self._parameter_target_value_from_normalized(device_param, normalized_value)
            envelope.insert_step(0.0, self._automation_clear_end_time(clip), raw_value)
            return True
        except Exception:
            pass

        return False

    def _neutralize_automation_span(self, envelope, device_param, start_time, end_time, normalized_value):
        if envelope is None or device_param is None:
            return False

        minimum_duration = 0.0001
        try:
            start_time = max(0.0, float(start_time))
            end_time = max(start_time + minimum_duration, float(end_time))
            raw_value = self._parameter_target_value_from_normalized(device_param, normalized_value)
            envelope.insert_step(start_time, max(minimum_duration, end_time - start_time), raw_value)
            return True
        except Exception:
            pass

        return False

    def _re_enable_automation_for_parameter(self, device_param):
        try:
            if hasattr(device_param, 're_enable_automation'):
                device_param.re_enable_automation()
                self._refresh_parameter_metadata_on_automation_change()
                self._send_re_enable_automation_enabled(force=True)
        except Exception as e:
            self._debug_log("Error re-enabling parameter automation: {}".format(str(e)))

    def _automation_envelope_key(self, clip, device_param, control_index):
        if clip is None or device_param is None:
            return None

        try:
            clip_identity = self._live_object_identity(clip)
        except Exception:
            clip_identity = id(clip)

        try:
            parameter_identity = self._live_object_identity(device_param)
        except Exception:
            parameter_identity = id(device_param)

        # A parameter keeps the same authored envelope when the user changes
        # device bank or the parameter appears under another encoder slot.
        return (clip_identity, parameter_identity)

    def _authored_automation_steps(self, clip, device_param, control_index):
        key = self._automation_envelope_key(clip, device_param, control_index)
        if key is None:
            return None
        return self._automation_authored_steps.get(key)

    def _store_authored_automation_steps(self, clip, device_param, control_index, steps):
        key = self._automation_envelope_key(clip, device_param, control_index)
        if key is None:
            return
        self._automation_authored_steps[key] = self._automation_sorted_steps(steps)

    def _automation_step_id(self, step, fallback_index=0):
        try:
            if len(step) >= 5:
                return max(0, int(step[4]))
        except Exception:
            pass
        return max(0, int(fallback_index) + 1)

    def _automation_step_order(self, step, fallback_index=0):
        try:
            if len(step) >= 6:
                return max(0, int(step[5]))
        except Exception:
            pass
        return self._automation_step_id(step, fallback_index)

    def _automation_step_tuple(self, step, fallback_index=0):
        return (
            float(step[0]),
            float(step[1]),
            max(0.0, min(1.0, float(step[2]))),
            max(-1.0, min(1.0, float(step[3]) if len(step) >= 4 else 0.0)),
            self._automation_step_id(step, fallback_index),
            self._automation_step_order(step, fallback_index)
        )

    def _automation_sort_key(self, indexed_step):
        index, step = indexed_step
        return (float(step[0]), self._automation_step_order(step, index), self._automation_step_id(step, index), index)

    def _automation_sorted_steps(self, steps):
        return tuple(
            self._automation_step_tuple(step, index)
            for index, step in sorted(enumerate(tuple(steps or ())), key=self._automation_sort_key)
        )

    def _automation_step_entry(self, step):
        normalized_step = self._automation_step_tuple(step)
        time_value, duration, normalized, curve, step_id, step_order = normalized_step
        return "{:.6f}:{:.6f}:{:.6f}:{:.6f}:{}:{}".format(
            time_value,
            duration,
            normalized,
            curve,
            step_id,
            step_order
        )

    def _automation_payload_checksum(self, value):
        checksum = 0
        try:
            data = value.encode('ascii', errors='ignore')
        except Exception:
            data = bytes()
        for byte in data:
            checksum = ((checksum * 31) + byte) & 0x7fffffff
        return checksum

    def _clear_authored_automation_steps(self, clip, device_param, control_index):
        key = self._automation_envelope_key(clip, device_param, control_index)
        if key is None:
            return
        self._automation_authored_steps.pop(key, None)

    def _clear_authored_automation_steps_for_parameter(self, clip, device_param):
        if clip is None or device_param is None:
            return

        try:
            clip_identity = self._live_object_identity(clip)
            parameter_identity = self._live_object_identity(device_param)
        except Exception:
            return

        for key in list(self._automation_authored_steps.keys()):
            if len(key) >= 2 and key[0] == clip_identity and key[1] == parameter_identity:
                self._automation_authored_steps.pop(key, None)

    def _clear_authored_automation_steps_for_clip(self, clip):
        if clip is None:
            return

        try:
            clip_identity = self._live_object_identity(clip)
        except Exception:
            return

        for key in list(self._automation_authored_steps.keys()):
            if len(key) >= 1 and key[0] == clip_identity:
                self._automation_authored_steps.pop(key, None)

    def _on_device_control_value(self, value, control):
        try:
            control_index = self._device_controls.index(control) if hasattr(self, '_device_controls') and control in self._device_controls else -1
            if control_index >= 0 and self._set_track_midi_control_value_for_control(control_index, value=value):
                return
            if control_index >= 0 and self._set_simpler_action_normalized(control_index, float(value) / 127.0):
                return
            if control_index >= 0 and self._set_simpler_virtual_normalized(control_index, float(value) / 127.0):
                return
            if control_index >= 0 and self._set_wavetable_virtual_normalized(control_index, float(value) / 127.0):
                return

            if control_index >= 0:
                virtual_parameter = self._current_bank_parameter_for_control(self._selected_device(), control_index)
                if self._parameter_is_tap_virtual(virtual_parameter):
                    target_value = self._parameter_target_value_from_normalized(
                        virtual_parameter, float(value) / 127.0
                    )
                    if virtual_parameter.value != target_value:
                        virtual_parameter.value = target_value
                    self._send_parameter_feedback(
                        control_index, virtual_parameter, send_cc=False, force_display=True
                    )
                    return

            mapped_parameter = self._current_connected_parameter_for_control(control_index) if control_index >= 0 else None
            self._remove_parameter_from_smooth_macro_randomize(mapped_parameter)
            if self._consume_remove_automation_request(mapped_parameter):
                return
            self._select_parameter_if_possible(mapped_parameter)
        except Exception as e:
            self._debug_log("Error selecting touched parameter: {}".format(str(e)))

    def _begin_high_resolution_undo_step(self, control_index):
        if control_index in self._active_high_resolution_undo_steps:
            return
        try:
            song = self.song()
            if hasattr(song, 'begin_undo_step'):
                song.begin_undo_step()
                self._active_high_resolution_undo_steps.add(control_index)
        except Exception as e:
            self._debug_log("Error beginning high resolution undo step: {}".format(str(e)))

    def _end_high_resolution_undo_step(self, control_index):
        if control_index not in self._active_high_resolution_undo_steps:
            return
        try:
            song = self.song()
            if hasattr(song, 'end_undo_step'):
                song.end_undo_step()
        except Exception as e:
            self._debug_log("Error ending high resolution undo step: {}".format(str(e)))
        self._active_high_resolution_undo_steps.discard(control_index)

    def _set_device_control_high_resolution(self, message):
        try:
            if len(message) < 7:
                return

            control_index = int(message[2])
            gesture_state = int(message[3])
            if (control_index < 0 or not hasattr(self, '_device_controls') or
                    control_index >= len(self._device_controls) or gesture_state not in (0, 1, 2, 3, 4)):
                return
            raw_value = ((int(message[4]) & 0x7F) << 14) | ((int(message[5]) & 0x7F) << 7) | (int(message[6]) & 0x7F)
            raw_value = max(0, min(65535, raw_value))

            if gesture_state == 4:
                track = self.song().view.selected_track
                kind = {
                    0: "mod_wheel",
                    1: getattr(self, "_track_expression_control_kind", "slide"),
                }.get(control_index)
                entry = self._track_midi_control_entry_for_kind(kind, track)
                if entry:
                    self._set_track_midi_control_normalized_value(
                        entry,
                        float(raw_value) / 65535.0,
                        track
                    )
                return

            if self._track_device_is_selected():
                entry = self._track_device_parameter_entry_for_control(control_index)
                if entry and entry.get("kind") != "parameter":
                    if gesture_state in (0, 1, 2):
                        self._set_track_midi_control_value_for_control(
                            control_index,
                            normalized=float(raw_value) / 65535.0
                        )
                    elif gesture_state == 3:
                        self._set_track_midi_control_value_for_control(
                            control_index,
                            normalized=self._track_midi_control_default_normalized(entry)
                        )
                    return

            virtual_spec = self._wavetable_virtual_spec(control_index)
            simpler_spec = self._simpler_virtual_spec(control_index)
            simpler_action_spec = self._simpler_action_spec(control_index)
            if simpler_action_spec:
                if gesture_state == 0:
                    self._set_simpler_action_normalized(control_index, float(raw_value) / 65535.0)
                elif gesture_state == 3:
                    if simpler_action_spec.get('enabled', True):
                        self._trigger_simpler_action(int(simpler_action_spec['action']))
                    else:
                        self._send_simpler_action_feedback(control_index)
                elif gesture_state in (1, 2):
                    self._send_simpler_action_feedback(control_index)
                return
            if simpler_spec:
                if gesture_state == 0:
                    self._set_simpler_virtual_normalized(control_index, float(raw_value) / 65535.0)
                elif gesture_state == 3:
                    parameter = simpler_spec.get('parameter')
                    if parameter and getattr(parameter, 'is_quantized', False):
                        items = tuple(getattr(parameter, 'value_items', ()))
                        if items:
                            current = int(round(self._parameter_normalized_value(parameter) * max(1, len(items) - 1)))
                            self._set_simpler_virtual_normalized(control_index, float((current + 1) % len(items)) / max(1, len(items) - 1))
                    else:
                        self._send_simpler_virtual_feedback(control_index)
                elif gesture_state in (1, 2):
                    self._send_simpler_virtual_feedback(control_index)
                return

            if virtual_spec:
                if gesture_state == 0:
                    self._set_wavetable_virtual_normalized(control_index, float(raw_value) / 65535.0)
                elif gesture_state == 3:
                    items = self._wavetable_virtual_items(virtual_spec)
                    if items:
                        current = self._wavetable_virtual_index(virtual_spec)
                        self._set_wavetable_virtual_normalized(control_index, float((current + 1) % len(items)) / max(1, len(items) - 1))
                elif gesture_state in (1, 2):
                    self._send_wavetable_virtual_feedback(control_index)
                return

            mapped_parameter = self._current_connected_parameter_for_control(control_index)
            if not mapped_parameter:
                if gesture_state == 2:
                    self._end_high_resolution_undo_step(control_index)
                    self._active_high_resolution_gestures.discard(control_index)
                return

            if control_index in self._automation_removal_suppressed_controls:
                if gesture_state == 2:
                    self._automation_removal_suppressed_controls.discard(control_index)
                    self._end_high_resolution_undo_step(control_index)
                    self._active_high_resolution_gestures.discard(control_index)
                return

            if self._consume_remove_automation_request(mapped_parameter):
                self._automation_removal_suppressed_controls.add(control_index)
                return

            if not self._parameter_is_control_available(mapped_parameter):
                if gesture_state == 2:
                    self._end_high_resolution_undo_step(control_index)
                    self._active_high_resolution_gestures.discard(control_index)
                return

            if gesture_state == 3:
                self._select_parameter_if_possible(mapped_parameter)
                self._set_device_control_next_option(control_index, mapped_parameter)
                return

            if gesture_state == 1:
                self._select_parameter_if_possible(mapped_parameter)
                self._send_parameter_feedback(control_index, mapped_parameter, send_cc=False, force_display=True)
                return

            if gesture_state == 0:
                self._remove_parameter_from_smooth_macro_randomize(mapped_parameter)
                
                if control_index not in self._active_high_resolution_gestures:
                    self._select_parameter_if_possible(mapped_parameter)
                    self._begin_high_resolution_undo_step(control_index)
                    if hasattr(mapped_parameter, 'begin_gesture'):
                        mapped_parameter.begin_gesture()
                    self._active_high_resolution_gestures.add(control_index)

                if mapped_parameter.max == mapped_parameter.min:
                    return

                normalized = float(raw_value) / 65535.0
                target_value = self._parameter_target_value_from_normalized(mapped_parameter, normalized)
                if mapped_parameter.value != target_value:
                    mapped_parameter.value = target_value

            if gesture_state == 2 and control_index in self._active_high_resolution_gestures:
                if hasattr(mapped_parameter, 'end_gesture'):
                    mapped_parameter.end_gesture()
                self._active_high_resolution_gestures.discard(control_index)
                self._end_high_resolution_undo_step(control_index)
                self._send_parameter_feedback(control_index, mapped_parameter, send_cc=False, force_display=True)
        except Exception as e:
            self._debug_log("Error setting high resolution parameter: {}".format(str(e)))

    def _bank_select(self, value):
        offset = value - 64
        if offset == 0:
            return

        if self._track_device_is_selected():
            all_bank_names = self._track_device_bank_names()
            if not all_bank_names:
                return

            current_index = max(0, min(len(all_bank_names) - 1, self._track_control_bank_index()))
            new_index = max(0, min(len(all_bank_names) - 1, current_index + offset))
            if new_index != current_index:
                self._set_track_control_bank_index(new_index)
                self._connect_track_device_parameter_controls()
                try:
                    self.request_rebuild_midi_map()
                except Exception:
                    pass
                self._on_device_changed(False)
            return

        if not liveobj_valid(self._device):
            return
        
        selected_track = self.song().view.selected_track
        selected_device = selected_track.view.selected_device if selected_track else None
        selected_device = selected_device or getattr(self._device, '_device', None)
        all_bank_names, _, _, _ = self._tap_visible_bank_info(selected_device)
        if not all_bank_names:
            return

        current_index = self._device._bank_index
        new_index = max(0, min(len(all_bank_names) - 1, current_index + offset))
        if (self._device._is_meld() and
                all_bank_names[new_index] == self._device.MELD_ENGINE_BANK_NAME):
            self._toggle_meld_engine()
            return
        if new_index != current_index:
            self._device._bank_index = new_index
            self._connect_device_controls()
            self._device.update()
            try:
                self.request_rebuild_midi_map()
            except Exception:
                pass
            self._on_device_changed(False)
            self._schedule_bank_metadata_refreshes()

    def _remove_meld_engine_listener(self):
        device = self._meld_engine_listener_device
        listener = self._meld_engine_listener
        self._meld_engine_listener_device = None
        self._meld_engine_listener = None
        if device and listener:
            try:
                if (not hasattr(device, 'selected_engine_has_listener') or
                        device.selected_engine_has_listener(listener)):
                    device.remove_selected_engine_listener(listener)
            except Exception:
                pass

    def _setup_meld_engine_listener(self, device):
        self._remove_meld_engine_listener()
        if not device or not liveobj_valid(device) or not self._device._is_meld():
            return
        listener = lambda: self._schedule_meld_engine_refresh()
        try:
            device.add_selected_engine_listener(listener)
            self._meld_engine_listener_device = device
            self._meld_engine_listener = listener
        except Exception:
            pass

    def _meld_engine_letter(self, device=None):
        device = device or getattr(self._device, '_device', None)
        try:
            return 'B' if int(device.selected_engine) == 1 else 'A'
        except Exception:
            return ''

    def _send_meld_engine_state(self, device=None):
        device = device or getattr(self._device, '_device', None)
        if not device or not liveobj_valid(device) or not self._device._is_meld():
            self._send_sys_ex_message('', 0x4A)
            return
        self._send_sys_ex_message(self._meld_engine_letter(device), 0x4A)

    def _toggle_meld_engine(self):
        device = getattr(self._device, '_device', None)
        if not device or not liveobj_valid(device) or not self._device._is_meld():
            return
        try:
            device.selected_engine = 0 if int(device.selected_engine) == 1 else 1
        except Exception as error:
            self._debug_log('Meld engine switch failed: {}'.format(str(error)))
            return
        self._send_meld_engine_state(device)
        self._schedule_meld_engine_refresh()

    def _schedule_meld_engine_refresh(self):
        if self._meld_engine_refresh_pending:
            return
        self._meld_engine_refresh_pending = True
        self.schedule_message(1, self._refresh_meld_engine_selection)

    def _refresh_meld_engine_selection(self):
        self._meld_engine_refresh_pending = False
        device = getattr(self._device, '_device', None)
        if not device or not liveobj_valid(device) or not self._device._is_meld():
            return
        if self._device._bank_index == 0:
            self._device._bank_index = 1
        self._device.invalidate_parameter_bank_cache()
        self._connect_device_controls()
        self._device.update()
        try:
            self.request_rebuild_midi_map()
        except Exception:
            pass
        self._send_meld_engine_state(device)
        self._force_send_current_bank_metadata()
        self._setup_dynamic_parameter_state_listeners()

    def _find_drum_rack_in_track(self, track):
        for device in track.devices:
            if device.can_have_drum_pads:
                return device
            elif isinstance(device, Live.RackDevice.RackDevice):
                # If the device is a RackDevice (e.g., Instrument Rack), recursively search inside its chains
                for chain in device.chains:
                    drum_rack = self._find_drum_rack_in_track(chain)
                    if drum_rack is not None:
                        return drum_rack
        return None
    
    def _setup_drum_pad_listeners(self):
        if self._drum_rack_device:
            self._send_all_drum_pad_names()
            self._send_selected_drum_pad_number()
            for pad in self._drum_rack_device.drum_pads:
                if not pad.name_has_listener(self._send_all_drum_pad_names):
                    pad.add_name_listener(self._send_all_drum_pad_names)
            if not self._drum_rack_device.view.selected_drum_pad_has_listener(self._send_selected_drum_pad_number):
                self._drum_rack_device.view.add_selected_drum_pad_listener(self._send_selected_drum_pad_number)

    def _remove_drum_pad_name_listeners(self):
        if self._drum_rack_device:
            for pad in self._drum_rack_device.drum_pads:
                if pad.name_has_listener(self._send_all_drum_pad_names):
                    pad.remove_name_listener(self._send_all_drum_pad_names)
            if self._drum_rack_device.view.selected_drum_pad_has_listener(self._send_selected_drum_pad_number):
                self._drum_rack_device.view.remove_selected_drum_pad_listener(self._send_selected_drum_pad_number)

    def _send_all_drum_pad_names(self):
        if not self._drum_rack_device:
            return
    
        pads = self._drum_rack_device.drum_pads
    
        # Find the first and last pad with chains using the .note property
        first_with_chain = None
        last_with_chain = None
    
        for pad in pads:
            if pad.chains:
                first_with_chain = pad
                break
    
        for pad in reversed(pads):
            if pad.chains:
                last_with_chain = pad
                break
                
        if first_with_chain and last_with_chain:
            first_index = first_with_chain.note
            last_index = last_with_chain.note
        
            pad_names = []
            
            # Add index of first chain pad
            pad_names.append(str(first_index))
            for pad in pads[first_index:last_index + 1]:
                if pad.chains:
                    pad_names.append(self._escape_sysex_string(pad.name))
                else:
                    pad_names.append(str(pad.note))
            payload = ",".join(pad_names)
            self._send_sys_ex_message(payload, 0x11)
    
    def _update_tempo(self):
        new_tempo = round(self.song().tempo, 2)
        self._send_sys_ex_message(str(new_tempo), 0x12)

    def _selected_note_repeat_track(self):
        try:
            selected_track = self.song().view.selected_track
            if (selected_track is not None
                    and liveobj_valid(selected_track)
                    and bool(getattr(selected_track, "has_midi_input", False))):
                return selected_track
        except Exception:
            pass
        return None

    def _note_repeat_rate_index(self, rate):
        try:
            numeric_rate = float(rate)
        except Exception:
            return self.NOTE_REPEAT_DEFAULT_INDEX
        return min(
            range(len(self.NOTE_REPEAT_RATES)),
            key=lambda index: abs(self.NOTE_REPEAT_RATES[index] - numeric_rate)
        )

    def _track_note_repeat_state(self, track):
        if track is None or self._note_repeat is None:
            return False, self.NOTE_REPEAT_DEFAULT_INDEX

        try:
            enabled = bool(track.get_data(self.NOTE_REPEAT_ENABLED_DATA_KEY, False))
        except Exception:
            enabled = False
        try:
            stored_rate = track.get_data(
                self.NOTE_REPEAT_RATE_DATA_KEY,
                self.NOTE_REPEAT_RATES[self.NOTE_REPEAT_DEFAULT_INDEX]
            )
        except Exception:
            stored_rate = self.NOTE_REPEAT_RATES[self.NOTE_REPEAT_DEFAULT_INDEX]
        return enabled, self._note_repeat_rate_index(stored_rate)

    def _set_track_note_repeat_data(self, track, enabled=None, rate_index=None):
        if track is None:
            return
        try:
            if enabled is not None:
                track.set_data(self.NOTE_REPEAT_ENABLED_DATA_KEY, bool(enabled))
            if rate_index is not None:
                track.set_data(
                    self.NOTE_REPEAT_RATE_DATA_KEY,
                    self.NOTE_REPEAT_RATES[rate_index]
                )
        except Exception:
            pass

    def _apply_note_repeat_engine(self, enabled, rate_index):
        note_repeat = self._note_repeat
        if note_repeat is None:
            return

        rate_index = max(0, min(len(self.NOTE_REPEAT_RATES) - 1, int(rate_index)))
        try:
            note_repeat.repeat_rate = self.NOTE_REPEAT_RATES[rate_index]
        except Exception:
            pass
        if enabled:
            # Match Live's own Move repeat model. This lets polyphonic
            # aftertouch update the velocity of already-held repeating notes.
            try:
                note_repeat.aftertouch_ramp_start = 300
                note_repeat.aftertouch_ramp_length = 250
            except Exception:
                pass

        try:
            was_enabled = bool(note_repeat.enabled)
        except Exception:
            was_enabled = False

        song = self.song()
        if enabled and not was_enabled:
            try:
                self._note_repeat_last_record_quantization = song.midi_recording_quantization
                song.midi_recording_quantization = False
            except Exception:
                self._note_repeat_last_record_quantization = None
        elif not enabled and was_enabled:
            try:
                if (not song.midi_recording_quantization
                        and self._note_repeat_last_record_quantization):
                    song.midi_recording_quantization = self._note_repeat_last_record_quantization
            except Exception:
                pass
            self._note_repeat_last_record_quantization = None

        try:
            note_repeat.enabled = bool(enabled)
        except Exception:
            pass

    def _restore_note_repeat_for_selected_track(self, force_feedback=False):
        track = self._selected_note_repeat_track()
        enabled, rate_index = self._track_note_repeat_state(track)
        self._apply_note_repeat_engine(enabled if track is not None else False, rate_index)
        self._send_note_repeat_state(force=force_feedback)

    def _swing_percent(self):
        try:
            return max(0, min(100, int(round(float(self.song().swing_amount) * 100.0))))
        except Exception:
            return 0

    def _send_note_repeat_state(self, force=False):
        track = self._selected_note_repeat_track()
        available = track is not None and self._note_repeat is not None
        enabled, rate_index = self._track_note_repeat_state(track)
        if not available:
            enabled = False
            rate_index = self.NOTE_REPEAT_DEFAULT_INDEX
        swing_percent = self._swing_percent()
        signature = (available, enabled, rate_index, swing_percent)
        if not force and signature == self._last_note_repeat_feedback:
            return
        self._last_note_repeat_feedback = signature
        self._send_sys_ex_message(
            "{}|{}|{}|{}".format(
                1 if available else 0,
                1 if enabled else 0,
                rate_index,
                swing_percent
            ),
            0x4C
        )

    def _update_swing_amount(self):
        self._send_note_repeat_state(force=True)

    def _handle_note_repeat_command(self, message):
        values = list(message[2:-1])
        if not values:
            return

        command = values[0]
        track = self._selected_note_repeat_track()
        if command == 0 and len(values) >= 2:
            enabled = bool(values[1]) and track is not None and self._note_repeat is not None
            if track is not None:
                self._set_track_note_repeat_data(track, enabled=enabled)
                _, rate_index = self._track_note_repeat_state(track)
                self._apply_note_repeat_engine(enabled, rate_index)
        elif command == 1 and len(values) >= 2 and track is not None:
            rate_index = max(0, min(len(self.NOTE_REPEAT_RATES) - 1, int(values[1])))
            self._set_track_note_repeat_data(track, rate_index=rate_index)
            enabled, _ = self._track_note_repeat_state(track)
            self._apply_note_repeat_engine(enabled, rate_index)
        elif command == 2 and len(values) >= 2:
            try:
                self.song().swing_amount = max(0.0, min(1.0, float(values[1]) / 100.0))
            except Exception:
                pass
        elif command != 3:
            return

        self._send_note_repeat_state(force=True)

    def _metronome_value(self):
        try:
            return bool(self.song().metronome)
        except Exception:
            return False

    def _update_metronome(self):
        self._send_sys_ex_message("1" if self._metronome_value() else "0", 0x17)
    
    def _is_bank_connected(self, device, bank_name):
        if not isinstance(device, Live.RackDevice.RackDevice):
            return True
        
        if bank_name not in ("Macros", "Macros 2"):
            return True
        
        if not hasattr(device, 'macros_mapped'):
            return True
        
        macro_ranges = {
            "Macros": (0, 8),
            "Macros 2": (8, 16)
        }
        
        if bank_name not in macro_ranges:
            return True
        
        start_idx, end_idx = macro_ranges[bank_name]
        return any(device.macros_mapped[start_idx:end_idx])

    def _app_device_index_to_live_index(self, value):
        try:
            return int(value) - 1
        except Exception:
            return -1

    def _track_control_key(self, track=None):
        try:
            track = track or self.song().view.selected_track
            return self._live_object_identity(track) if track else None
        except Exception:
            return None

    def _track_device_is_selected(self, track=None):
        key = self._track_control_key(track)
        if key is None:
            return False
        selections = getattr(self, "_track_control_selection_by_track", {})
        if key in selections:
            return bool(selections[key])
        try:
            track = track or self.song().view.selected_track
            has_devices = track and hasattr(track, "devices") and len(track.devices) > 0
            return not has_devices
        except Exception:
            return False

    def _set_track_device_selected(self, selected, track=None):
        key = self._track_control_key(track)
        if key is not None:
            self._track_control_selection_by_track[key] = bool(selected)
        self._track_device_selected = bool(selected)

    def _track_control_bank_index(self, track=None):
        key = self._track_control_key(track)
        if key is None:
            return 0
        return int(getattr(self, "_track_control_bank_index_by_track", {}).get(key, 0))

    def _set_track_control_bank_index(self, index, track=None):
        key = self._track_control_key(track)
        if key is not None:
            self._track_control_bank_index_by_track[key] = int(index)
        self._track_device_bank_index = int(index)

    def _send_name_for_index(self, index):
        if index < 0:
            return "Send"
        if index < 26:
            return "Send {}".format(chr(ord("A") + index))
        return "Send {}".format(index + 1)

    def _track_device_parameters(self, track=None):
        try:
            track = track or self.song().view.selected_track
    
            if track is None or not hasattr(track, "mixer_device"):
                return []
    
            mixer_device = track.mixer_device
    
            track_has_midi_input = bool(getattr(track, "has_midi_input", False))
            midi_controls = [
                dict(control)
                for control in self._track_device_midi_controls()
            ] if track_has_midi_input else []
    
            mixer_controls = [
                {
                    "name": "Volume",
                    "parameter": mixer_device.volume,
                    "kind": "parameter",
                    "automatable": True,
                },
                {
                    "name": "Pan",
                    "parameter": mixer_device.panning,
                    "kind": "parameter",
                    "automatable": True,
                },
            ]
    
            sends = [
                {
                    "name": self._send_name_for_index(send_index),
                    "parameter": send,
                    "kind": "parameter",
                    "automatable": True,
                }
                for send_index, send in enumerate(mixer_device.sends)
                if send and liveobj_valid(send)
            ]
    
            entries = midi_controls[:4] + mixer_controls + sends
    
            return [
                entry
                for entry in entries
                if entry.get("kind") != "parameter"
                or (
                    entry.get("parameter")
                    and liveobj_valid(entry.get("parameter"))
                )
            ]
    
        except Exception:
            return []

    def _track_device_midi_controls(self):
        controls = [dict(control) for control in self.TRACK_DEVICE_MIDI_CONTROLS]
        if (len(controls) > 1
                and getattr(self, "_track_expression_control_kind", "slide") == "slide"):
            controls[1] = dict(self.TRACK_DEVICE_SLIDE_CONTROL)
        return controls

    def _track_device_main_entries(self, track=None):
        return self._track_device_parameters(track)[:self.TRACK_DEVICE_BANK_SIZE]

    def _track_device_extra_send_entries(self, track=None):
        return [
            entry for entry in self._track_device_parameters(track)[self.TRACK_DEVICE_BANK_SIZE:]
            if entry.get("name", "").startswith("Send ")
        ]

    def _track_device_bank_names(self, track=None):
        extra_sends = self._track_device_extra_send_entries(track)
        names = [self.TRACK_DEVICE_MAIN_BANK_NAME]
        if not extra_sends:
            return names

        send_bank_count = int(math.ceil(float(len(extra_sends)) / float(self.TRACK_DEVICE_BANK_SIZE)))
        if send_bank_count == 1:
            names.append(self.TRACK_DEVICE_SEND_BANK_NAME)
        else:
            for bank_index in range(send_bank_count):
                names.append("{} {}".format(self.TRACK_DEVICE_SEND_BANK_NAME, bank_index + 1))
        return names

    def _track_device_current_bank_index(self, track=None):
        bank_names = self._track_device_bank_names(track)
        if not bank_names:
            self._set_track_control_bank_index(0, track)
            return 0

        index = max(0, min(len(bank_names) - 1, self._track_control_bank_index(track)))
        self._set_track_control_bank_index(index, track)
        return index

    def _track_device_parameter_entry_for_control(self, control_index, track=None):
        bank_index = self._track_device_current_bank_index(track)
        if bank_index == 0:
            entries = self._track_device_main_entries(track)
        else:
            start = (bank_index - 1) * self.TRACK_DEVICE_BANK_SIZE
            entries = self._track_device_extra_send_entries(track)[start:start + self.TRACK_DEVICE_BANK_SIZE]
        if control_index >= 0 and control_index < len(entries):
            return entries[control_index]
        return None

    def _track_device_parameter_for_control(self, control_index, track=None):
        entry = self._track_device_parameter_entry_for_control(control_index, track)
        if entry and entry.get("kind") == "parameter":
            return entry.get("parameter")
        return None

    def _track_midi_control_state(self, track=None):
        key = self._track_control_key(track) or "global"
        state_by_track = getattr(self, "_track_midi_control_values_by_track", {})
        if key not in state_by_track:
            state_by_track[key] = {}
            self._track_midi_control_values_by_track = state_by_track
        return state_by_track[key]

    def _track_midi_control_default_normalized(self, entry):
        try:
            minimum = float(entry.get("min", 0.0))
            maximum = float(entry.get("max", 127.0))
            default = float(entry.get("default", minimum))
            if maximum == minimum:
                return 0.0
            return max(0.0, min(1.0, (default - minimum) / (maximum - minimum)))
        except Exception:
            return 0.0

    def _track_midi_control_normalized_value(self, entry, track=None):
        if not entry:
            return 0.0
        kind = entry.get("kind", "")
        return max(0.0, min(1.0, float(self._track_midi_control_state(track).get(kind, self._track_midi_control_default_normalized(entry)))))

    def _track_midi_control_entry_for_kind(self, kind, track=None):
        if not kind:
            return None
        try:
            track = track or self.song().view.selected_track
            if not bool(getattr(track, "has_midi_input", False)):
                return None
            controls = self._track_device_midi_controls()
            if kind in ("pressure", "slide") and len(controls) > 1:
                controls = [controls[1]]
            for control in controls:
                if control.get("kind") == kind:
                    return dict(control)
        except Exception:
            pass
        return None

    def _set_track_midi_control_normalized_value(self, entry, normalized, track=None):
        if not entry:
            return
        kind = entry.get("kind", "")
        if not kind:
            return
        self._track_midi_control_state(track)[kind] = max(0.0, min(1.0, float(normalized)))

    def _track_midi_control_raw_value(self, entry, normalized):
        try:
            minimum = float(entry.get("min", 0.0))
            maximum = float(entry.get("max", 127.0))
            normalized = max(0.0, min(1.0, float(normalized)))
            return minimum + ((maximum - minimum) * normalized)
        except Exception:
            return 0.0

    def _track_midi_control_display_value(self, entry, normalized):
        raw_value = self._track_midi_control_raw_value(entry, normalized)
        try:
            if entry.get("kind") == "pitch_bend":
                offset = raw_value - self.TRACK_DEVICE_PITCH_BEND_CENTER
                denominator = (self.TRACK_DEVICE_PITCH_BEND_MAX - self.TRACK_DEVICE_PITCH_BEND_CENTER) if offset >= 0 else self.TRACK_DEVICE_PITCH_BEND_CENTER
                percent = int(round((offset / denominator) * 100.0)) if denominator else 0
                if percent == 0:
                    return "0"
                return "+{}".format(percent) if percent > 0 else str(percent)
            if entry.get("kind") == "velocity":
                return str(max(1, min(127, int(round(raw_value)))))
            return str(int(round(raw_value)))
        except Exception:
            return "0"

    def _send_track_midi_control_feedback(self, control_index, entry=None, normalized=None, track=None):
        entry = entry or self._track_device_parameter_entry_for_control(control_index, track)
        if not entry or entry.get("kind") == "parameter":
            return

        if normalized is None:
            normalized = self._track_midi_control_normalized_value(entry, track)
        normalized = max(0.0, min(1.0, float(normalized)))
        cc_value = max(0, min(127, int(round(normalized * 127.0))))
        display_value = self._track_midi_control_display_value(entry, normalized)

        self.send_cc(72 + control_index, 8, cc_value)
        self._last_sent_parameter_cc_values[control_index] = cc_value
        self._send_sys_ex_message(
            "{}|{}|{}".format(control_index, normalized, self._escape_sysex_string(display_value)),
            0x28
        )

    def _send_track_local_control_state(self, track=None):
        try:
            track = track or self.song().view.selected_track
            has_midi_input = bool(getattr(track, "has_midi_input", False))
            state = self._track_midi_control_state(track) if has_midi_input else {}
            mod_wheel = max(0.0, min(1.0, float(state.get("mod_wheel", 0.0))))
            pressure = max(0.0, min(1.0, float(state.get("pressure", 0.0))))
            slide = max(0.0, min(1.0, float(state.get("slide", 0.0))))
            payload = "mod_wheel|{:.6f},pressure|{:.6f},slide|{:.6f}".format(
                mod_wheel,
                pressure,
                slide
            )
            self._send_sys_ex_message(payload, 0x3B)
        except Exception:
            pass

    def _handle_track_expression_control_command(self, message):
        values = self.extract_values_from_sysex_message(message)
        self._track_expression_control_kind = "slide" if values and values[0] else "pressure"
        track = self.song().view.selected_track
        self._send_track_local_control_state(track)
        if self._track_device_is_selected(track):
            self._send_track_device_parameter_metadata(track)

    def _set_track_midi_control_value_for_control(self, control_index, value=None, normalized=None, track=None, require_selected=True, send_feedback=True):
        if require_selected and not self._track_device_is_selected(track):
            return False

        entry = self._track_device_parameter_entry_for_control(control_index, track)
        if not entry or entry.get("kind") == "parameter":
            return False

        if normalized is None:
            normalized = max(0.0, min(1.0, float(value) / 127.0))
        normalized = max(0.0, min(1.0, float(normalized)))
        self._set_track_midi_control_normalized_value(entry, normalized, track)
        if send_feedback:
            self._send_track_midi_control_feedback(control_index, entry, normalized, track)
        return True

    def _track_device_parameter_metadata_item(self, control_index, track=None):
        entry = self._track_device_parameter_entry_for_control(control_index, track)
        if not entry:
            return self.UNMAPPED_PARAMETER_METADATA_ITEM

        if entry.get("kind") != "parameter":
            automatable = bool(entry.get("automatable", False))
            name = self._parameter_metadata_name(
                self._escape_sysex_string(entry.get("name", "")),
                automatable
            )
            minimum = float(entry.get("min", 0.0))
            maximum = float(entry.get("max", 127.0))
            default = float(entry.get("default", minimum))
            normalized = self._track_midi_control_normalized_value(entry, track)
            display_value = self._track_midi_control_display_value(entry, normalized)
            fields = [
                name,
                str(int(minimum)) if minimum == int(minimum) else str(minimum),
                str(int(maximum)) if maximum == int(maximum) else str(maximum),
                str(int(default)) if default == int(default) else str(default),
                str(max(0.0, min(1.0, round(self._track_midi_control_default_normalized(entry), 3)))),
                str(int(minimum + ((maximum - minimum) * 32 / 127))),
                "",
                display_value,
                str(max(0.0, min(1.0, normalized))),
                self._escape_sysex_string(entry.get("kind", "")),
            ]
            return "|".join(fields)

        fallback_name = entry.get("name", "")
        parameter = entry.get("parameter")
        name = self._get_parameter_display_name(parameter)
        try:
            escaped_parameter_name = self._escape_sysex_string(getattr(parameter, "name", ""))
            prefix = ""
            display_name = name
            for candidate_prefix in ("**", "*/", "*-", "*~", "*!"):
                if display_name.startswith(candidate_prefix):
                    prefix = candidate_prefix
                    display_name = display_name[len(candidate_prefix):]
                    break
            if display_name == escaped_parameter_name:
                name = prefix + self._escape_sysex_string(fallback_name)
        except Exception:
            pass
        name = self._parameter_metadata_name(name, self._parameter_is_automatable(parameter))

        min_val_str = None
        max_val_str = None
        default_val_str = None
        try:
            if hasattr(parameter, 'str_for_value') and hasattr(parameter, 'min') and hasattr(parameter, 'max'):
                min_val_str = parameter.str_for_value(parameter.min)
                max_val_str = parameter.str_for_value(parameter.max)
        except Exception:
            pass

        if min_val_str is None:
            min_val_str = str(parameter.min) if hasattr(parameter, 'min') else "0.0"
        if max_val_str is None:
            max_val_str = str(parameter.max) if hasattr(parameter, 'max') else "1.0"

        raw_default_value = 0.0
        quarter_str = "0.0"
        try:
            raw_default_value = getattr(parameter, "default_value", parameter.min if hasattr(parameter, "min") else 0.0)
            if hasattr(parameter, 'str_for_value'):
                default_val_str = parameter.str_for_value(raw_default_value)
                if hasattr(parameter, 'min') and hasattr(parameter, 'max'):
                    quarter_value = parameter.min + (parameter.max - parameter.min) * 32 / 127
                    quarter_str = parameter.str_for_value(quarter_value)
            else:
                default_val_str = str(round(raw_default_value, 2))
            if hasattr(parameter, 'min') and hasattr(parameter, 'max') and parameter.max != parameter.min:
                raw_default_value = round((raw_default_value - parameter.min) / (parameter.max - parameter.min), 3)
        except Exception:
            default_val_str = min_val_str

        parameter_value_items = self._parameter_value_items(parameter)
        value_items = ';'.join(self._escape_sysex_string(item) for item in parameter_value_items)
        if parameter_value_items and self._parameter_is_tap_virtual(parameter):
            min_val_str = parameter_value_items[0]
            max_val_str = parameter_value_items[-1]
            default_index = int(round(max(0.0, min(1.0, float(raw_default_value))) * (len(parameter_value_items) - 1)))
            quarter_index = int(round((32.0 / 127.0) * (len(parameter_value_items) - 1)))
            default_val_str = parameter_value_items[default_index]
            quarter_str = parameter_value_items[quarter_index]

        fields = [
            name.strip(),
            self._escape_sysex_string(str(min_val_str).strip()),
            self._escape_sysex_string(str(max_val_str).strip()),
            self._escape_sysex_string(str(default_val_str).strip()),
            str(raw_default_value).strip(),
            self._escape_sysex_string(str(quarter_str).strip()),
            value_items.strip(),
            self._escape_sysex_string(self._parameter_display_value(parameter)),
            str(self._parameter_normalized_value(parameter)),
        ]
        return "|".join(fields)

    def _build_track_device_parameter_metadata(self, track=None):
        return ",".join(
            self._track_device_parameter_metadata_item(index, track)
            for index in range(8)
        )

    def _send_track_device_bank_state(self, track_has_drums):
        bank_names = self._track_device_bank_names()
        bank_index = self._track_device_current_bank_index()
        current_bank_name = bank_names[bank_index] if bank_names else self.TRACK_DEVICE_MAIN_BANK_NAME
        bank_name_drum = self._escape_sysex_string(current_bank_name) + ";" + str(track_has_drums)
        self._send_sys_ex_message(bank_name_drum, 0x6D)
        self._send_sys_ex_message(",".join(self._escape_sysex_string(name) for name in bank_names), 0x5D)
        return current_bank_name, tuple(bank_names), tuple(bank_names)

    def _send_track_device_parameter_metadata(self, track=None):
        metadata = self._build_track_device_parameter_metadata(track)
        self._send_sys_ex_message(metadata, 0x7D)
        for control_index in range(8):
            entry = self._track_device_parameter_entry_for_control(control_index, track)
            parameter = entry.get("parameter") if entry and entry.get("kind") == "parameter" else None
            if parameter and liveobj_valid(parameter):
                self._send_parameter_feedback(control_index, parameter, send_cc=True, force_display=True)
            elif entry:
                self._send_track_midi_control_feedback(control_index, entry, track=track)
            else:
                self.send_cc(72 + control_index, 8, 0)

    def _send_bank_state(self, selected_device, track_has_drums):
        all_bank_names, _, _, _ = self._tap_visible_bank_info(selected_device)
        if self._device._is_meld() and self._device._bank_index == 0 and len(all_bank_names) > 1:
            self._device._bank_index = 1
        bank_index = self._device._bank_index
        current_bank_name = all_bank_names[bank_index] if 0 <= bank_index < len(all_bank_names) else ''
        connected_bank_names = [name for name in all_bank_names if self._is_bank_connected(selected_device, name)]

        # Handle case where current bank was filtered out
        if current_bank_name and isinstance(selected_device, Live.RackDevice.RackDevice):
            if current_bank_name in all_bank_names and current_bank_name not in connected_bank_names:
                # Current bank was filtered, navigate to first connected bank
                if connected_bank_names:
                    # Simulate bank navigation to trigger device change with valid bank
                    self._device._bank_index = all_bank_names.index(connected_bank_names[0])
                    current_bank_name = connected_bank_names[0]
                else:
                    current_bank_name = ""

        meld_engine = self._meld_engine_letter(selected_device) if self._device._is_meld() else ''
        bank_name_drum = (
            self._escape_sysex_string(current_bank_name) + ";" + str(track_has_drums) + ";" + meld_engine
        )
        bank_names_list = ','.join(self._escape_sysex_string(name) for name in connected_bank_names)

        self._send_sys_ex_message(bank_name_drum, 0x6D)
        self._send_sys_ex_message(bank_names_list, 0x5D)
        return current_bank_name, all_bank_names, connected_bank_names

    def _sanitize_sysex_text(self, value):
        sanitized_value = str(value)
        for symbol, replacement in self.SYSEX_TEXT_SYMBOL_REPLACEMENTS:
            sanitized_value = sanitized_value.replace(symbol, replacement)

        def remove_ascii_empty_bracket_group(match):
            inner_value = match.group(1)
            ascii_inner_value = inner_value.encode('ascii', errors='ignore').decode('ascii')
            if inner_value.strip() and not ascii_inner_value.strip():
                return ''
            return match.group(0)

        sanitized_value = self.SYSEX_ROUND_BRACKET_TEXT_RE.sub(remove_ascii_empty_bracket_group, sanitized_value)
        sanitized_value = self.SYSEX_SQUARE_BRACKET_TEXT_RE.sub(remove_ascii_empty_bracket_group, sanitized_value)
        sanitized_value = self.SYSEX_CURLY_BRACKET_TEXT_RE.sub(remove_ascii_empty_bracket_group, sanitized_value)
        sanitized_value = sanitized_value.encode('ascii', errors='ignore').decode('ascii')
        sanitized_value = self.SYSEX_MULTI_SPACE_RE.sub(' ', sanitized_value)
        return sanitized_value.strip()

    def _escape_sysex_string(self, value):
        escaped_value = self._sanitize_sysex_text(value)
        escaped_value = escaped_value.replace(
            self.SYSEX_STRING_ESCAPE_CHAR,
            self.SYSEX_STRING_ESCAPE_CHAR + self.SYSEX_STRING_ESCAPE_CHAR
        )
        for symbol in self.SYSEX_STRING_RESERVED_SYMBOLS:
            if symbol == self.SYSEX_STRING_ESCAPE_CHAR:
                continue
            escaped_value = escaped_value.replace(symbol, self.SYSEX_STRING_ESCAPE_CHAR + symbol)
        return escaped_value

    def _unescape_sysex_string(self, value):
        result = []
        escaping = False
        for char in str(value):
            if escaping:
                result.append(char)
                escaping = False
            elif char == self.SYSEX_STRING_ESCAPE_CHAR:
                escaping = True
            else:
                result.append(char)
        if escaping:
            result.append(self.SYSEX_STRING_ESCAPE_CHAR)
        return ''.join(result)

    def _split_escaped_sysex_fields(self, value, separator):
        fields = []
        field_chars = []
        escaping = False
        for char in str(value):
            if escaping:
                field_chars.append(self.SYSEX_STRING_ESCAPE_CHAR)
                field_chars.append(char)
                escaping = False
            elif char == self.SYSEX_STRING_ESCAPE_CHAR:
                escaping = True
            elif char == separator:
                fields.append(''.join(field_chars))
                field_chars = []
            else:
                field_chars.append(char)
        if escaping:
            field_chars.append(self.SYSEX_STRING_ESCAPE_CHAR)
        fields.append(''.join(field_chars))
        return fields

    def _get_parameter_display_name(self, device_param):
        curated_name = None
        try:
            curated_name = self._device.curated_parameter_display_name(device_param)
        except Exception:
            pass
        raw_name = self._escape_sysex_string(curated_name or device_param.name)
        if hasattr(device_param, 'is_enabled'):
            if self._parameter_is_inactive(device_param):
                return f"*~{raw_name}"
            if not self._parameter_is_control_available(device_param):
                return f"*-{raw_name}"
            if hasattr(device_param, 'automation_state') and device_param.automation_state != 0:
                if device_param.automation_state == 1:
                    return f"**{raw_name}"
                elif device_param.automation_state == 2:
                    return f"*/{raw_name}"
            return raw_name
        return raw_name

    def _parameter_metadata_name(self, name, automatable):
        name = str(name or "")
        if automatable or name.startswith(("*-", "*~", "*!")):
            return name
        return "*!" + name

    def _parameter_is_control_available(self, parameter):
        try:
            if self._parameter_is_inactive(parameter):
                return True
            if (hasattr(parameter, 'state') and
                    parameter.state == Live.DeviceParameter.ParameterState.disabled):
                return False
            if hasattr(parameter, 'is_enabled') and not parameter.is_enabled:
                return False
        except Exception:
            pass
        return True

    def _parameter_is_automatable(self, parameter):
        try:
            return bool(
                parameter
                and liveobj_valid(parameter)
                and hasattr(parameter, 'automation_state')
            )
        except Exception:
            return False

    def _parameter_is_inactive(self, parameter):
        try:
            if self._delay_parameter_is_inactive(parameter):
                return True
            if self._drift_parameter_is_inactive(parameter):
                return True
            return (
                hasattr(parameter, 'state') and
                parameter.state == Live.DeviceParameter.ParameterState.irrelevant
            )
        except Exception:
            return False

    def _parameter_name_key(self, parameter):
        names = (str(getattr(parameter, 'name', '')), str(getattr(parameter, 'original_name', '')))
        return tuple(re.sub(r'[^a-z0-9]+', '', name.lower()) for name in names)

    def _parameter_switch_is_on(self, *names):
        parameter = self._device._parameter_by_names(*names)
        if parameter is None:
            return False
        display = self._parameter_display_value(parameter).strip().lower()
        if display:
            if display in ('on', 'yes', 'true', 'enabled', 'link'):
                return True
            if display in ('off', 'no', 'false', 'disabled', 'unlinked'):
                return False
        try:
            return float(parameter.value) > float(parameter.min)
        except Exception:
            return False

    def _drift_parameter_is_inactive(self, parameter):
        if not hasattr(self, '_device') or not self._device._is_drift() or parameter is None:
            return False

        keys = set(self._parameter_name_key(parameter))
        target_mode = None
        if 'thickness' in keys:
            target_mode = 'mono'
        elif 'strength' in keys:
            target_mode = 'unison'
        elif 'spread' in keys:
            target_mode = 'stereo'
        if target_mode is None:
            return False

        mode_parameter = self._device._parameter_by_names('Voice Mode')
        mode = self._parameter_display_value(mode_parameter).strip().lower()
        for candidate in ('poly', 'mono', 'stereo', 'unison'):
            if candidate in mode:
                return candidate != target_mode

        # Drift's public voice_mode_list is ordered Poly, Mono, Stereo,
        # Unison.  This fallback keeps relevance correct if a future Live
        # wrapper temporarily exposes only the numeric enum index.
        try:
            mode = ('poly', 'mono', 'stereo', 'unison')[int(round(mode_parameter.value))]
            return mode != target_mode
        except Exception:
            return False

    def _delay_parameter_is_inactive(self, parameter):
        if not hasattr(self, '_device') or not self._device._is_delay() or parameter is None:
            return False

        keys = set(self._parameter_name_key(parameter))
        link_on = self._parameter_switch_is_on('Link', 'Stereo Time Link')
        left_sync_on = self._parameter_switch_is_on('L Sync', 'L Delay Sync')
        right_sync_on = self._parameter_switch_is_on('R Sync', 'R Delay Sync')

        if keys & {'rsync', 'rdelaysync'} and link_on:
            return True
        if keys & {'ltime', 'ldelaytime'}:
            return left_sync_on
        if keys & {'rtime', 'rdelaytime'}:
            return link_on or right_sync_on
        if keys & {'l16th', 'ldelay16th'}:
            return not left_sync_on
        if keys & {'r16th', 'rdelay16th'}:
            return link_on or not right_sync_on

        lfo_targets = {
            'freq': {'lfofreq', 'modlfofreq', 'modulationfrequency', 'lforate'},
            'time': {'lfotime', 'modlfotime', 'modulationtime'},
            'synced': {'lfosynced', 'lfosync', 'modlfosynced', 'modulationsyncedrate', 'lfosyncedrate'},
            '16th': {'lfo16th', 'modlfo16th', 'modulation16th'},
        }
        target = next((kind for kind, names in lfo_targets.items() if keys & names), None)
        if target is None:
            return False

        mode_parameter = self._device._parameter_by_names(
            'LFO Mode', 'LF Mode', 'Mod LFO Mode', 'LFO Time Mode'
        )
        mode = self._parameter_display_value(mode_parameter).strip().lower()
        if '16' in mode:
            active = '16th'
        elif 'sync' in mode or 'note' in mode or 'beat' in mode:
            active = 'synced'
        elif 'time' in mode or 'ms' in mode:
            active = 'time'
        elif 'freq' in mode or 'hz' in mode:
            active = 'freq'
        else:
            # Delay's mode enum is ordered Freq, Time, Sync, 16th.  Keep an
            # unknown/future label conservative instead of hiding everything.
            try:
                active = ('freq', 'time', 'synced', '16th')[int(round(mode_parameter.value))]
            except Exception:
                return False
        return target != active

    def _parameter_is_tap_virtual(self, parameter, selected_device=None):
        if parameter is None or not hasattr(self, '_device'):
            return False
        if not (
                self._device._is_drift() or self._device._is_meld() or
                self._device._is_hybrid_reverb() or self._device._is_simpler() or
                self._device._uses_curated_banks()):
            return False
        selected_device = selected_device or self._selected_device()
        try:
            native_parameters = self._native_parameters_for_device(selected_device)
            if any(native_parameter is parameter for native_parameter in native_parameters):
                return False
            # Decorator parameters such as Simpler's Preserve/Loop Mode are
            # Python wrappers.  Some of them compare equal to their host value,
            # which previously fooled this check and sent an EnumWrappingParameter
            # into Live's native MIDI mapper.  Only use proxy equality for real
            # Live objects; wrapper parameters stay script-driven.
            parameter_type = type(parameter)
            is_native_live_parameter = (
                getattr(parameter_type, '__name__', '') == 'DeviceParameter' or
                str(getattr(parameter_type, '__module__', '')).startswith('Live.')
            )
            if is_native_live_parameter:
                return not any(native_parameter == parameter for native_parameter in native_parameters)
            return True
        except Exception:
            return True

    def _native_parameters_for_device(self, device):
        parameters = list(getattr(device, 'parameters', ()))
        try:
            if self._is_simpler_device(device):
                sampler = getattr(device, 'sampler', None)
                if sampler and liveobj_valid(sampler):
                    parameter_ids = set(id(parameter) for parameter in parameters)
                    parameters.extend(
                        parameter for parameter in getattr(sampler, 'parameters', ())
                        if id(parameter) not in parameter_ids
                    )
        except Exception:
            pass
        return tuple(parameters)

    def _current_bank_parameter_for_control(self, selected_device, control_index):
        try:
            if not hasattr(self, '_device') or not liveobj_valid(self._device):
                return None
            if control_index < 0:
                return None

            _, bank_parameters = self._device._current_bank_details()
            if bank_parameters and control_index < len(bank_parameters):
                bank_param = bank_parameters[control_index]
                if self._parameter_is_tap_virtual(bank_param, selected_device):
                    return bank_param
                if bank_param and liveobj_valid(bank_param):
                    if selected_device and hasattr(selected_device, 'parameters'):
                        native_parameters = self._native_parameters_for_device(selected_device)
                        if not any(device_param == bank_param for device_param in native_parameters):
                            return None
                    return bank_param
        except Exception:
            pass
        return None

    def _selected_device(self):
        try:
            selected_track = self.song().view.selected_track
            return selected_track.view.selected_device if selected_track else None
        except Exception:
            return None

    def _current_connected_parameter_for_control(self, control_index, selected_device=None):
        if control_index < 0:
            return None
        if self._track_device_is_selected():
            track_parameter = self._track_device_parameter_for_control(control_index)
            return track_parameter if track_parameter and liveobj_valid(track_parameter) else None

        if self._simpler_main_active():
            simpler_spec = self._simpler_virtual_spec(control_index)
            if simpler_spec and simpler_spec.get('kind') == 'parameter':
                parameter = simpler_spec.get('parameter')
                if parameter and liveobj_valid(parameter):
                    return parameter

        selected_device = selected_device or self._selected_device()
        # EncoderElement owns the authoritative mapping.  Reading it is
        # constant-time; rebuilding a complete bank is only a fallback during
        # the brief remapping window after a device or bank change.
        mapped_param = self._mapped_parameter_for_device_control(control_index)
        if mapped_param and selected_device and hasattr(selected_device, 'parameters'):
            try:
                native_parameters = self._native_parameters_for_device(selected_device)
                if not any(device_param == mapped_param for device_param in native_parameters):
                    mapped_param = None
            except Exception:
                mapped_param = None
        if mapped_param:
            return mapped_param

        return self._current_bank_parameter_for_control(selected_device, control_index)

    def _is_current_parameter_for_control(self, control_index, device_param):
        if not device_param or not liveobj_valid(device_param):
            return False

        current_param = self._current_connected_parameter_for_control(control_index)
        return current_param and liveobj_valid(current_param) and current_param == device_param
    
    def _build_parameter_metadata(self, selected_device):
        if self._simpler_actions_active():
            return self._simpler_action_metadata()
        if self._simpler_warp_active():
            return self._simpler_warp_metadata()
        if self._simpler_browse_active():
            return self._simpler_browse_metadata()
        if self._simpler_main_active():
            return self._simpler_virtual_metadata()
        virtual_metadata = self._wavetable_virtual_metadata()
        if self._active_wavetable_virtual_specs():
            return virtual_metadata
        if self._track_device_is_selected():
            return self._build_track_device_parameter_metadata()

        if not hasattr(selected_device, 'parameters'):
            return ""
        
        param_data = []
        device_parameters = list(selected_device.parameters)
        device_param_map = {}
        for dp in device_parameters:
            if hasattr(dp, 'name'):
                device_param_map[dp.name] = dp
        unmapped_encoder_indices = []
        
        for control_index in range(8):
            mapped_param = self._current_connected_parameter_for_control(control_index, selected_device)
            
            if mapped_param:
                device_param = mapped_param
                if device_param is None or not hasattr(device_param, 'name'):
                    device_param = device_param_map.get(mapped_param.name)
                
                if device_param:
                    name = self._get_parameter_display_name(device_param)
                    if self._tap_active_custom_kind(selected_device) == 'drumcell_sample' and control_index == 7:
                        name = 'Mode'
                    
                    min_val_str = None
                    max_val_str = None
                    default_val_str = None
                    
                    if min_val_str is None or max_val_str is None:
                        try:
                            if hasattr(device_param, 'str_for_value'):
                                if hasattr(device_param, 'min') and hasattr(device_param, 'max'):
                                    min_val_str = device_param.str_for_value(device_param.min)
                                    max_val_str = device_param.str_for_value(device_param.max)
                                else:
                                    min_val_str = device_param.str_for_value(0.0)
                                    max_val_str = device_param.str_for_value(1.0)
                        except Exception:
                            pass
                    
                    if min_val_str is None:
                        min_val_str = str(device_param.min) if hasattr(device_param, 'min') else "0.0"
                    if max_val_str is None:
                        max_val_str = str(device_param.max) if hasattr(device_param, 'max') else "1.0"
                    
                    raw_default_value = None
                    quarter_str = "0.0"
                    if (not self._parameter_is_quantized(device_param) and hasattr(device_param, 'default_value')):
                        try:
                            raw_default_value = device_param.default_value
                            if hasattr(device_param, 'str_for_value'):
                                default_val_str = device_param.str_for_value(device_param.default_value)
                                try:
                                    num_val = float(default_val_str)
                                    default_val_str = str(round(num_val, 2))
                                except Exception:
                                    pass
                                if hasattr(device_param, 'min') and hasattr(device_param, 'max'):
                                    quarter_value = device_param.min + (device_param.max - device_param.min) * 32/127
                                    quarter_str = device_param.str_for_value(quarter_value)
                            else:
                                default_val_str = str(round(device_param.default_value, 2))
                            if hasattr(device_param, 'min') and hasattr(device_param, 'max') and device_param.max != device_param.min:
                                raw_default_value = round((raw_default_value - device_param.min) / (device_param.max - device_param.min), 3)
                        except Exception:
                            default_val_str = min_val_str
                            raw_default_value = device_param.min if hasattr(device_param, 'min') else 0.0
                    else:
                        default_val_str = min_val_str
                        raw_default_value = device_param.min if hasattr(device_param, 'min') else 0.0
                    
                    parameter_value_items = self._parameter_value_items(device_param)
                    value_items = ';'.join(self._escape_sysex_string(item) for item in parameter_value_items)
                    if parameter_value_items and self._parameter_is_tap_virtual(device_param, selected_device):
                        min_val_str = parameter_value_items[0]
                        max_val_str = parameter_value_items[-1]
                        default_index = int(round(max(0.0, min(1.0, float(raw_default_value))) * (len(parameter_value_items) - 1)))
                        quarter_index = int(round((32.0 / 127.0) * (len(parameter_value_items) - 1)))
                        default_val_str = parameter_value_items[default_index]
                        quarter_str = parameter_value_items[quarter_index]

                    default_raw_str = str(raw_default_value) if raw_default_value is not None else ""
                    min_val_str = self._escape_sysex_string(min_val_str.strip())
                    max_val_str = self._escape_sysex_string(max_val_str.strip())
                    default_val_str = self._escape_sysex_string(default_val_str.strip())
                    quarter_str = self._escape_sysex_string(quarter_str.strip())
                    name = self._parameter_metadata_name(
                        name.strip(),
                        self._parameter_is_automatable(device_param)
                    )
                    param_str = (
                        f"{name}|{min_val_str}|{max_val_str}|{default_val_str}|"
                        f"{default_raw_str.strip()}|{quarter_str}|{value_items.strip()}"
                    )
                    param_data.append(param_str)
                else:
                    param_str = self.UNMAPPED_PARAMETER_METADATA_ITEM
                    param_data.append(param_str)
                    unmapped_encoder_indices.append(control_index)
            else:
                param_str = self.UNMAPPED_PARAMETER_METADATA_ITEM
                param_data.append(param_str)
                unmapped_encoder_indices.append(control_index)
        
        return ','.join(param_data)
    
    def _metadata_has_only_numbers(self, metadata):
        if not metadata:
            return False
        
        params = self._split_escaped_sysex_fields(metadata, ',')
        
        for param in params:
            fields = self._split_escaped_sysex_fields(param, '|')
            for field_index in [1, 2, 3, 5]:
                if field_index < len(fields):
                    field_value = self._unescape_sysex_string(fields[field_index].strip())
                    if field_value:
                        try:
                            float(field_value)
                        except ValueError:
                            return False
        
        return True

    def _metadata_has_raw_0_127(self, metadata):
        if not metadata:
            return False
        
        params = self._split_escaped_sysex_fields(metadata, ',')
        for param in params:
            fields = self._split_escaped_sysex_fields(param, '|')
            for field_index in [1, 2, 3, 5]:
                if field_index < len(fields):
                    field_value = self._unescape_sysex_string(fields[field_index].strip())
                    if field_value in ("0", "127"):
                        return True
        return False

    def _metadata_has_unmapped(self, metadata):
        if not metadata:
            return False
        
        return "*--&&-" in metadata

    def _metadata_is_all_unmapped(self, metadata):
        if not metadata:
            return False

        params = self._split_escaped_sysex_fields(metadata, ',')
        if len(params) < 8:
            return False

        for param in params[:8]:
            fields = self._split_escaped_sysex_fields(param, '|')
            if not fields or fields[0] != "*--&&-":
                return False
        return True

    def _send_unmapped_parameter_metadata(self):
        self._send_sys_ex_message(self.UNMAPPED_PARAMETER_METADATA, 0x7D)

        for control_index in range(8):
            cc_number = 72 + control_index
            self.send_cc(cc_number, 8, 0)

    def _send_unmapped_parameter_metadata_for_device(self, device, metadata=None):
        self._send_unmapped_parameter_metadata()
        self._set_cached_metadata(device, metadata or self.UNMAPPED_PARAMETER_METADATA)
        self._mark_metadata_sent(device)

    def _schedule_parameter_metadata_recheck(self, delay=None):
        if self._metadata_recheck_timer:
            self._metadata_recheck_timer.cancel()

        self._drum_pad_change_recheck_count = 0
        self._drum_pad_recheck_start = time.time()

        recheck_delay = delay if delay is not None else self.PARAMETER_METADATA_RECHECK_INTERVAL
        self._metadata_recheck_timer = self._schedule_main_thread(
            recheck_delay, self._recheck_parameter_metadata
        )

    def _cancel_bank_metadata_refreshes(self):
        for timer in list(getattr(self, '_bank_metadata_refresh_timers', [])):
            try:
                timer.cancel()
            except Exception:
                pass
        self._bank_metadata_refresh_timers = []

    def _schedule_bank_metadata_refreshes(self):
        self._cancel_bank_metadata_refreshes()
        for delay in (0.05, 0.15, 0.35, 0.75):
            timer = self._schedule_main_thread(delay, self._refresh_active_bank_metadata)
            self._bank_metadata_refresh_timers.append(timer)

    def _refresh_active_bank_metadata(self):
        if not liveobj_valid(self._device):
            return

        try:
            if hasattr(self._device, 'update'):
                self._device.update()
            self._force_send_current_bank_metadata()
        except Exception as e:
            self._debug_log("Error refreshing bank metadata after bank change: {}".format(str(e)))

    def _force_send_current_bank_metadata(self):
        selected_track = self.song().view.selected_track
        selected_device = selected_track.view.selected_device if selected_track else None
        if not selected_device or not hasattr(selected_device, 'parameters') or not selected_device.parameters:
            return

        current_metadata = self._build_parameter_metadata(selected_device)
        if not current_metadata:
            return

        if self._metadata_is_all_unmapped(current_metadata):
            if self._get_cached_metadata(selected_device) != current_metadata:
                self._send_unmapped_parameter_metadata_for_device(selected_device, current_metadata)
            return

        if self._get_cached_metadata(selected_device) == current_metadata:
            return

        self._send_sys_ex_message(current_metadata, 0x7D)
        self._set_cached_metadata(selected_device, current_metadata)
        self._mark_metadata_sent(selected_device)
        self._refresh_parameter_value_listeners_current_bank(send_current_values=True)
        self._refresh_parameter_name_listeners_current_bank()
        self._refresh_automation_state_listeners_current_bank()

    def _metadata_needs_rack_recheck(self, metadata):
        return (
            self._metadata_has_unmapped(metadata)
            or self._metadata_has_only_numbers(metadata)
            or self._metadata_has_raw_0_127(metadata)
        )

    def _debug_log(self, message):
        if self._debug_mode:
            self.log_message(message)

    def _get_device_cache_key(self, device):
        if not device:
            return None
        return id(device)

    def _get_cached_metadata(self, device):
        key = self._get_device_cache_key(device)
        if key is None:
            return None
        return self._metadata_cache.get(key)

    def _set_cached_metadata(self, device, metadata):
        key = self._get_device_cache_key(device)
        if key is None:
            return
        self._metadata_cache[key] = metadata

    def _clear_cached_metadata(self, device):
        key = self._get_device_cache_key(device)
        if key is None:
            return
        if key in self._metadata_cache:
            del self._metadata_cache[key]

    def _mark_metadata_sent(self, device):
        key = self._get_device_cache_key(device)
        self._metadata_send_seq += 1
        if key is not None:
            self._metadata_send_seq_by_device[key] = self._metadata_send_seq
    
    def _recheck_parameter_metadata(self):
        self._metadata_recheck_timer = None
        
        if not liveobj_valid(self._device):
            return
        
        selected_track = self.song().view.selected_track
        selected_device = selected_track.view.selected_device
        metadata_device = selected_device
        
        if self._drum_rack_device and selected_device == self._drum_rack_device:
            mapped_device = self._find_mapped_device()
            if mapped_device and self._is_device_in_drum_pad(mapped_device):
                metadata_device = mapped_device
        
        is_rack_device = isinstance(metadata_device, Live.RackDevice.RackDevice)
        is_drum_rack = self._drum_rack_device and metadata_device == self._drum_rack_device
        is_drum_pad_device = self._drum_rack_device and self._is_device_in_drum_pad(metadata_device)

        current_metadata = self._build_parameter_metadata(metadata_device)
        has_unmapped = self._metadata_has_unmapped(current_metadata)
        has_only_numbers = self._metadata_has_only_numbers(current_metadata)
        all_unmapped = self._metadata_is_all_unmapped(current_metadata)
        
        if self._drum_pad_recheck_start is None:
            self._drum_pad_recheck_start = time.time()
        
        elapsed = time.time() - self._drum_pad_recheck_start
        self._debug_log(
            "Recheck metadata: "
            f"iter={self._drum_pad_change_recheck_count} "
            f"elapsed={round(elapsed, 3)}s "
            f"device='{metadata_device.name if metadata_device else 'None'}' "
            f"rack={is_rack_device} drum_rack={bool(is_drum_rack)} drum_pad_device={bool(is_drum_pad_device)} "
            f"unmapped={has_unmapped} all_unmapped={all_unmapped} only_numbers={has_only_numbers}"
        )
        
        if elapsed >= self.PARAMETER_METADATA_RECHECK_DURATION:
            self._debug_log("Recheck metadata: reached max duration {}s, stopping".format(self.PARAMETER_METADATA_RECHECK_DURATION))
            self._drum_pad_change_recheck_count = 0
            self._drum_pad_recheck_start = None
            return
        
        should_resend = False
        cached_metadata = self._get_cached_metadata(metadata_device)
        if current_metadata and cached_metadata != current_metadata:
            should_resend = True
        
        if should_resend:
            if all_unmapped:
                self._debug_log(f"Recheck metadata (iteration {getattr(self, '_drum_pad_change_recheck_count', 0)}): Sending unmapped metadata")
                self._send_unmapped_parameter_metadata_for_device(metadata_device, current_metadata)
            else:
                self._debug_log(f"Recheck metadata (iteration {getattr(self, '_drum_pad_change_recheck_count', 0)}): Resending changed metadata")
                self._send_sys_ex_message(current_metadata, 0x7D)
                self._set_cached_metadata(metadata_device, current_metadata)
                self._mark_metadata_sent(metadata_device)
                self._refresh_parameter_value_listeners_current_bank(send_current_values=True)
                self._refresh_parameter_name_listeners_current_bank()
                self._refresh_automation_state_listeners_current_bank()
            
            if is_drum_pad_device:
                self._last_drum_pad_metadata = current_metadata
            else:
                self._last_sent_metadata = current_metadata
            
            if not all_unmapped and hasattr(metadata_device, 'parameters') and metadata_device.parameters:
                for control_index in range(8):
                    mapped_param = self._current_connected_parameter_for_control(control_index, metadata_device)
                    if mapped_param:
                        self._send_parameter_feedback(control_index, mapped_param, force_display=True)
        
        max_iterations = int(self.PARAMETER_METADATA_RECHECK_DURATION / self.PARAMETER_METADATA_RECHECK_INTERVAL) + 1
        should_continue = False
        if is_drum_pad_device or is_drum_rack:
            should_continue = has_unmapped
        elif is_rack_device:
            should_continue = has_only_numbers
        else:
            should_continue = all_unmapped
        
        if should_continue:
            self._drum_pad_change_recheck_count += 1
            if self._drum_pad_change_recheck_count <= max_iterations:
                self._metadata_recheck_timer = self._schedule_main_thread(
                    self.PARAMETER_METADATA_RECHECK_INTERVAL,
                    self._recheck_parameter_metadata
                )
            else:
                if is_drum_pad_device:
                    self._debug_log(f"Drum pad recheck: Reached max iterations, last metadata: {current_metadata[:100]}...")
                    self._last_drum_pad_metadata = None
                else:
                    if is_drum_rack:
                        self._debug_log(f"Drum rack recheck: Reached max iterations, last metadata: {current_metadata[:100]}...")
                    else:
                        self._debug_log(f"Rack recheck: Reached max iterations, last metadata: {current_metadata[:100]}...")
                self._drum_pad_change_recheck_count = 0
                self._drum_pad_recheck_start = None
                return
        else:
            self._drum_pad_change_recheck_count = 0
            self._drum_pad_recheck_start = None
    
    def _is_simpler_device(self, device):
        if not liveobj_valid(device):
            return False
        try:
            if isinstance(device, Live.SimplerDevice.SimplerDevice):
                return True
        except Exception:
            pass
        return str(getattr(device, 'class_name', '')) in ('OriginalSimpler', 'Simpler')

    def _track_sliced_simpler(self, track=None):
        try:
            track = track or self.song().view.selected_track
            if not track or not hasattr(track, 'devices'):
                return None
            devices = self._get_all_nested_devices(track.devices)[0]
            for device in devices:
                if self._is_simpler_device(device) and int(device.playback_mode) == 2:
                    return device
        except Exception:
            pass
        return None

    def _send_track_simpler_slice_state(self, force=False):
        track = None
        try:
            track = self.song().view.selected_track
        except Exception:
            pass
        simpler = self._track_sliced_simpler(track)
        slice_count = 0
        if simpler:
            try:
                sample = simpler.sample
                if liveobj_valid(sample):
                    slice_count = min(128, len(tuple(sample.slices)))
            except Exception:
                pass
        signature = (
            id(track) if track else None,
            id(simpler) if simpler else None,
            slice_count,
        )
        if not force and signature == self._last_track_simpler_slice_signature:
            return
        self._last_track_simpler_slice_signature = signature
        self._send_sys_ex_message(
            '{}|{}'.format(1 if simpler else 0, slice_count),
            0x48,
        )

    def _is_drumcell_device(self, device):
        return liveobj_valid(device) and str(getattr(device, 'class_name', '')) == 'DrumCell'

    def _drumcell_dynamic_parameter(self, parameter):
        if not self._is_drumcell_device(self._selected_device()):
            return False
        names = (
            str(getattr(parameter, 'name', '')),
            str(getattr(parameter, 'original_name', '')),
        )
        normalized = set(re.sub(r'[^a-z0-9]+', '', name.lower()) for name in names)
        return bool(normalized.intersection(('envmode', 'fxtype', 'filtertype')))

    def _grain_delay_dynamic_parameter(self, parameter):
        device = self._selected_device()
        if not liveobj_valid(device) or str(getattr(device, 'class_name', '')) != 'GrainDelay':
            return False
        names = (
            str(getattr(parameter, 'name', '')),
            str(getattr(parameter, 'original_name', '')),
        )
        return 'delaymode' in set(
            re.sub(r'[^a-z0-9]+', '', name.lower()) for name in names
        )

    def _add_simpler_listener(self, subject, property_name, callback):
        if not liveobj_valid(subject):
            return
        if (subject, property_name, callback) in self._simpler_listener_bindings:
            return
        add_listener = getattr(subject, 'add_{}_listener'.format(property_name), None)
        if not callable(add_listener):
            return
        has_listener = getattr(subject, '{}_has_listener'.format(property_name), None)
        try:
            if not callable(has_listener) or not has_listener(callback):
                add_listener(callback)
            self._simpler_listener_bindings.append((subject, property_name, callback))
        except Exception:
            pass

    def _remove_simpler_listeners(self):
        for subject, property_name, callback in list(getattr(self, '_simpler_listener_bindings', [])):
            if not liveobj_valid(subject):
                continue
            remove_listener = getattr(subject, 'remove_{}_listener'.format(property_name), None)
            has_listener = getattr(subject, '{}_has_listener'.format(property_name), None)
            try:
                if callable(remove_listener) and (not callable(has_listener) or has_listener(callback)):
                    remove_listener(callback)
            except Exception:
                pass
        self._simpler_listener_bindings = []

    def _disconnect_simpler_decorator(self):
        nudging = getattr(self, '_simpler_slice_nudging', None)
        if nudging is not None:
            try:
                nudging.set_device(None)
            except Exception:
                pass
        decorator = getattr(self, '_simpler_decorator', None)
        self._simpler_decorator = None
        if decorator:
            try:
                decorator.disconnect()
            except Exception:
                pass

    def _create_simpler_decorator(self):
        self._disconnect_simpler_decorator()
        if not self._simpler_device or SimplerDeviceDecorator is None:
            return
        try:
            self._simpler_decorator = SimplerDeviceDecorator(
                live_object=self._simpler_device,
                additional_properties={}
            )
            if SimplerSliceNudging is not None:
                if self._simpler_slice_nudging is None:
                    self._simpler_slice_nudging = SimplerSliceNudging()
                self._simpler_slice_nudging.set_device(self._simpler_decorator)
        except Exception as error:
            self._debug_log('Could not create Simpler parameter decorator: {}'.format(str(error)))

    def _connect_simpler_parameter_listeners(self):
        parameter_names = (
            'S Loop On', 'Trigger Mode', 'Snap', 'Start', 'End', 'Fade In', 'Fade Out',
            'Transpose', 'Gain', 'Nudge', 'Playback', 'Slice by', 'Division', 'Regions',
            'Pad Slicing', 'Sensitivity', 'S Start', 'S Length', 'S Loop Length',
            'Detune', 'S Loop Fade',
        )
        for parameter_name in parameter_names:
            parameter = self._simpler_parameter(parameter_name)
            if parameter:
                self._add_simpler_listener(parameter, 'value', self._on_simpler_state_changed)

    def _set_simpler_device(self, device):
        if device == self._simpler_device and self._is_simpler_device(device):
            return

        self._remove_simpler_listeners()
        self._disconnect_simpler_decorator()
        self._simpler_waveform_generation += 1
        self._audio_clip_waveform_generation += 1
        self._remove_audio_clip_listeners()
        self._audio_clip_listener_clip = None
        self._simpler_device = device if self._is_simpler_device(device) else None
        self._simpler_sample = None
        self._simpler_playhead_high = -1
        self._simpler_playhead_low = -1
        self._simpler_playhead_enabled = None
        self._simpler_zoom = 0.0
        self._simpler_waveform_center = 0.5
        self._send_simpler_waveform_clear()

        if not self._simpler_device:
            self._send_sys_ex_message('0|0|1|0|1|', 0x42)
            self._send_simpler_playhead(force=True, hidden=True)
            return

        self._add_simpler_listener(self._simpler_device, 'sample', self._on_simpler_sample_changed)
        self._add_simpler_listener(self._simpler_device, 'playing_position', self._on_simpler_playhead_changed)
        self._add_simpler_listener(self._simpler_device, 'playing_position_enabled', self._on_simpler_playhead_changed)
        for property_name in ('playback_mode', 'slicing_playback_mode', 'pad_slicing', 'multi_sample_mode'):
            self._add_simpler_listener(self._simpler_device, property_name, self._on_simpler_configuration_changed)
        self._create_simpler_decorator()
        self._connect_simpler_parameter_listeners()
        self._connect_simpler_sample()

    def _connect_simpler_sample(self):
        device = self._simpler_device
        sample = getattr(device, 'sample', None) if liveobj_valid(device) else None
        self._simpler_sample = sample if liveobj_valid(sample) else None

        if self._simpler_sample:
            for property_name in (
                'file_path', 'start_marker', 'end_marker', 'slices', 'slicing_style',
                'slicing_sensitivity', 'slicing_beat_division', 'slicing_region_count',
                'warping', 'warp_mode',
            ):
                callback = self._on_simpler_file_changed if property_name == 'file_path' else self._on_simpler_state_changed
                if property_name in ('slicing_style', 'warping', 'warp_mode'):
                    callback = self._on_simpler_configuration_changed
                self._add_simpler_listener(self._simpler_sample, property_name, callback)

        view = getattr(device, 'view', None) if liveobj_valid(device) else None
        if liveobj_valid(view):
            for property_name in (
                'sample_start',
                'sample_end',
                'sample_loop_start',
                'sample_loop_end',
                'sample_env_fade_in',
                'sample_env_fade_out',
                'sample_loop_fade',
                'selected_slice',
            ):
                self._add_simpler_listener(view, property_name, self._on_simpler_state_changed)

        self._send_simpler_state()
        self._send_simpler_playhead(force=True)
        self._request_simpler_waveform()
        self.schedule_message(1, self._sync_simpler_pad_slicing)

    def _on_simpler_sample_changed(self):
        device = self._simpler_device
        self._remove_simpler_listeners()
        if liveobj_valid(device):
            self._add_simpler_listener(device, 'sample', self._on_simpler_sample_changed)
            self._add_simpler_listener(device, 'playing_position', self._on_simpler_playhead_changed)
            self._add_simpler_listener(device, 'playing_position_enabled', self._on_simpler_playhead_changed)
            for property_name in ('playback_mode', 'slicing_playback_mode', 'pad_slicing', 'multi_sample_mode'):
                self._add_simpler_listener(device, property_name, self._on_simpler_configuration_changed)
        self._create_simpler_decorator()
        self._connect_simpler_parameter_listeners()
        self._simpler_waveform_generation += 1
        self._send_simpler_waveform_clear()
        self._connect_simpler_sample()

    def _on_simpler_file_changed(self):
        self._simpler_waveform_generation += 1
        self._send_simpler_waveform_clear()
        self._send_simpler_state()
        self._request_simpler_waveform()

    def _on_simpler_state_changed(self):
        self._send_simpler_state()
        self._send_track_simpler_slice_state()
        self._send_simpler_virtual_feedback_all()
        if self._simpler_actions_active():
            self._send_sys_ex_message(self._simpler_action_metadata(), 0x7D)
        elif self._simpler_warp_active():
            self._send_sys_ex_message(self._simpler_warp_metadata(), 0x7D)
        self._send_simpler_action_feedback_all()

    def _on_simpler_configuration_changed(self):
        self.schedule_message(1, self._sync_simpler_pad_slicing)
        self._send_simpler_state()
        self._send_track_simpler_slice_state()
        try:
            selected_track = self.song().view.selected_track
            track_has_drums = 1 if self._find_drum_rack_in_track(selected_track) is not None else 0
            self._send_bank_state(self._simpler_device, track_has_drums)
        except Exception:
            pass
        if self._simpler_main_active():
            self._send_sys_ex_message(self._simpler_virtual_metadata(), 0x7D)
            self._send_simpler_virtual_feedback_all()
        elif self._simpler_actions_active():
            self._send_sys_ex_message(self._simpler_action_metadata(), 0x7D)
            self._send_simpler_action_feedback_all()
        elif self._simpler_warp_active():
            self._send_sys_ex_message(self._simpler_warp_metadata(), 0x7D)
            self._send_simpler_action_feedback_all()
        elif self._simpler_browse_active():
            self._send_sys_ex_message(self._simpler_browse_metadata(), 0x7D)

    def _sync_simpler_pad_slicing(self):
        device = self._simpler_device
        sample = self._simpler_sample
        if not liveobj_valid(device) or not liveobj_valid(sample):
            return
        try:
            manual = sample.slicing_style == Live.Sample.SlicingStyle.manual
            target = bool(int(device.playback_mode) == 2 and manual)
            if bool(device.pad_slicing) != target:
                device.pad_slicing = target
        except Exception as error:
            self._debug_log('Could not update Simpler pad slicing: {}'.format(str(error)))

    def _simpler_main_active(self):
        return bool(
            self._simpler_device and
            self._tap_active_custom_kind(self._simpler_device) == 'simpler_main'
        )

    def _simpler_actions_active(self):
        return bool(
            self._simpler_device and
            self._tap_active_custom_kind(self._simpler_device) == 'simpler_actions'
        )

    def _simpler_warp_active(self):
        return bool(
            self._simpler_device and
            self._tap_active_custom_kind(self._simpler_device) == 'simpler_warp'
        )

    def _simpler_browse_active(self):
        return bool(
            self._simpler_device and
            self._tap_active_custom_kind(self._simpler_device) == 'simpler_browse'
        )

    def _simpler_parameter(self, name):
        decorator = getattr(self, '_simpler_decorator', None)
        candidates = []
        try:
            candidates.extend(decorator.parameters)
        except Exception:
            pass
        try:
            candidates.extend(self._simpler_device.parameters)
        except Exception:
            pass
        wanted = re.sub(r'[^a-z0-9]+', '', name.lower())
        for parameter in candidates:
            try:
                parameter_names = (str(parameter.name), str(getattr(parameter, 'original_name', '')))
                if any(re.sub(r'[^a-z0-9]+', '', value.lower()) == wanted for value in parameter_names):
                    return parameter
            except Exception:
                pass
        return None

    def _simpler_main_spec_names(self):
        try:
            mode = int(self._simpler_device.playback_mode)
        except Exception:
            mode = 0
        if mode == 1:
            return ('Zoom', 'Start', 'End', 'Fade In', 'Fade Out', 'Transpose', 'Gain', 'Mode')
        if mode == 2:
            slice_by = self._simpler_parameter('Slice by')
            slice_by_name = self._parameter_display_value(slice_by).lower() if slice_by else ''
            if 'beat' in slice_by_name:
                slicing_control = 'Division'
            elif 'region' in slice_by_name:
                slicing_control = 'Regions'
            elif 'manual' in slice_by_name:
                slicing_control = 'Pad Slicing'
            else:
                slicing_control = 'Sensitivity'
            return ('Zoom', 'Start', 'End', 'Nudge', 'Playback', 'Slice by', slicing_control, 'Mode')
        warp_enabled = bool(getattr(self._simpler_sample, 'warping', False)) if liveobj_valid(self._simpler_sample) else False
        return ('Zoom', 'Start', 'End', 'S Start', 'S Length', 'S Loop Length', 'Detune' if warp_enabled else 'S Loop Fade', 'Mode')

    def _simpler_virtual_spec(self, control_index):
        if (not self._simpler_main_active() or not liveobj_valid(self._simpler_sample) or
                not 0 <= control_index < 8):
            return None
        name = self._simpler_main_spec_names()[control_index]
        if name == 'Zoom':
            return {'name': name, 'kind': 'zoom'}
        parameter = self._simpler_parameter(name)
        return {'name': name, 'kind': 'parameter', 'parameter': parameter} if parameter else None

    def _simpler_parameter_metadata_item(self, name, parameter):
        if not parameter:
            return self.UNMAPPED_PARAMETER_METADATA_ITEM
        try:
            min_value = self._simpler_display_for_value(name, parameter, parameter.min)
            max_value = self._simpler_display_for_value(name, parameter, parameter.max)
            default_value = getattr(parameter, 'default_value', parameter.min)
            default_display = self._simpler_display_for_value(name, parameter, default_value)
            value_range = float(parameter.max) - float(parameter.min)
            default_normalized = (float(default_value) - float(parameter.min)) / value_range if value_range else 0.0
            quarter_value = float(parameter.min) + value_range * 32.0 / 127.0
            quarter_display = self._simpler_display_for_value(name, parameter, quarter_value)
            value_items = ''
            if getattr(parameter, 'is_quantized', False):
                value_items = ';'.join(
                    self._escape_sysex_string(item)
                    for item in self._simpler_value_items(name, parameter)
                )
            display_name = name
            if not self._parameter_is_control_available(parameter):
                display_name = '*-' + display_name
            elif hasattr(parameter, 'automation_state'):
                if parameter.automation_state == 1:
                    display_name = '**' + display_name
                elif parameter.automation_state == 2:
                    display_name = '*/' + display_name
            automatable = self._parameter_is_automatable(parameter)
            return '{}|{}|{}|{}|{}|{}|{}|{}|{}'.format(
                self._parameter_metadata_name(self._escape_sysex_string(display_name), automatable),
                self._escape_sysex_string(min_value),
                self._escape_sysex_string(max_value),
                self._escape_sysex_string(default_display),
                default_normalized,
                self._escape_sysex_string(quarter_display),
                value_items,
                self._escape_sysex_string(self._simpler_display_value(name, parameter)),
                self._parameter_normalized_value(parameter),
            )
        except Exception:
            return self.UNMAPPED_PARAMETER_METADATA_ITEM

    def _simpler_value_items(self, name, parameter):
        try:
            mode = int(self._simpler_device.playback_mode)
        except Exception:
            mode = 0
        requested_items = {
            'Mode': ('Classic', '1-Shot', 'Slice'),
            'Playback': ('Mono', 'Poly', 'Thru') if mode == 2 else ('Gate', 'Trigger'),
            'Slice by': ('Transient', 'Beat', 'Region', 'Manual'),
        }.get(name)
        if requested_items:
            return requested_items
        if not getattr(parameter, 'is_quantized', False):
            return ()
        try:
            return tuple(str(item) for item in parameter.value_items)
        except Exception:
            return ()

    def _simpler_sample_position_display(self, name, parameter, value):
        if name not in ('Start', 'End') or not liveobj_valid(self._simpler_sample):
            return None
        try:
            position = float(value)
            parameter_min = float(parameter.min)
            parameter_max = float(parameter.max)
            if parameter_min >= 0.0 and parameter_max <= 1.0:
                position *= float(self._simpler_sample.length)
            return str(int(round(position)))
        except Exception:
            return None

    def _simpler_display_for_value(self, name, parameter, value):
        items = self._simpler_value_items(name, parameter)
        if items:
            try:
                value_range = float(parameter.max) - float(parameter.min)
                normalized = (float(value) - float(parameter.min)) / value_range if value_range else 0.0
                item_index = int(round(normalized * max(1, len(items) - 1)))
                return items[max(0, min(len(items) - 1, item_index))]
            except Exception:
                pass
        sample_position = self._simpler_sample_position_display(name, parameter, value)
        if sample_position is not None:
            return sample_position
        try:
            display = parameter.str_for_value(value) if hasattr(parameter, 'str_for_value') else str(value)
            return self._format_display_value_numbers(display)
        except Exception:
            return self._format_display_value_numbers(str(value))

    def _simpler_display_value(self, name, parameter):
        return self._simpler_display_for_value(name, parameter, parameter.value)

    def _simpler_warp_mode_items(self):
        return ('Beats', 'Tones', 'Texture', 'Re-Pitch', 'Complex', 'Complex Pro')

    def _simpler_action_specs(self):
        if not self._simpler_actions_active() or not liveobj_valid(self._simpler_sample):
            return tuple([None] * 8)
        try:
            mode = int(self._simpler_device.playback_mode)
        except Exception:
            mode = 0
        warp_enabled = bool(getattr(self._simpler_sample, 'warping', False))

        toggle_parameter = self._simpler_parameter('S Loop On' if mode == 0 else 'Trigger Mode')
        if mode == 0:
            toggle_items = self._simpler_value_items('S Loop On', toggle_parameter) if toggle_parameter else ()
            toggle_items = toggle_items or ('Off', 'On')
            toggle_display = self._parameter_display_value(toggle_parameter) if toggle_parameter else toggle_items[0]
            toggle_normalized = self._parameter_normalized_value(toggle_parameter) if toggle_parameter else 0.0
            toggle_name = 'Loop'
        else:
            toggle_items = ('Gate', 'Trigger')
            toggle_display = self._parameter_display_value(toggle_parameter) if toggle_parameter else toggle_items[0]
            is_trigger = 'trigger' in toggle_display.lower()
            toggle_display = 'Trigger' if is_trigger else 'Gate'
            toggle_normalized = 1.0 if is_trigger else 0.0
            toggle_name = 'Trigger Mode'

        def button(name, action, enabled=True):
            return {
                'name': name,
                'action': action,
                'kind': 'button',
                'items': ('Ready', 'Trigger'),
                'display': 'Ready',
                'normalized': 0.0,
                'enabled': enabled,
            }

        def toggle(name, action, items, display, normalized, enabled=True):
            return {
                'name': name,
                'action': action,
                'kind': 'toggle',
                'items': tuple(items),
                'display': display,
                'normalized': normalized,
                'enabled': enabled,
            }

        warp_modes = self._simpler_warp_mode_items()
        try:
            live_warp_modes = (
                Live.Clip.WarpMode.beats,
                Live.Clip.WarpMode.tones,
                Live.Clip.WarpMode.texture,
                Live.Clip.WarpMode.repitch,
                Live.Clip.WarpMode.complex,
                Live.Clip.WarpMode.complex_pro,
            )
            current_warp_mode = int(self._simpler_sample.warp_mode)
            warp_mode_index = next(
                (index for index, item in enumerate(live_warp_modes) if int(item) == current_warp_mode),
                0,
            )
        except Exception:
            warp_mode_index = 0
        warp_mode_spec = {
            'name': 'Warp Mode',
            'action': 8,
            'kind': 'warp_mode',
            'items': warp_modes,
            'display': warp_modes[warp_mode_index],
            'normalized': float(warp_mode_index) / float(len(warp_modes) - 1),
            'enabled': warp_enabled,
        }

        snap_parameter = self._simpler_parameter('Snap')
        snap_normalized = self._parameter_normalized_value(snap_parameter) if snap_parameter else 0.0
        snap_spec = toggle(
            'Snap', 7, ('Off', 'On'), 'On' if snap_normalized >= 0.5 else 'Off', snap_normalized
        )
        try:
            reset_name = 'Clear Slices' if int(self._simpler_sample.slicing_style) == 1 else 'Reset Slices'
        except Exception:
            reset_name = 'Reset Slices'

        specs = [
            toggle(toggle_name, 0, toggle_items, toggle_display, toggle_normalized),
            toggle('Warp', 1, ('Off', 'On'), 'On' if warp_enabled else 'Off', 1.0 if warp_enabled else 0.0),
            button(':2', 2, bool(getattr(self._simpler_device, 'can_warp_half', False))) if warp_enabled else None,
            button('*2', 3, bool(getattr(self._simpler_device, 'can_warp_double', False))) if warp_enabled else None,
            button(reset_name, 4) if mode == 2 else (warp_mode_spec if warp_enabled else None),
            button('Split' if mode == 2 else 'Crop', 5),
            button('Reverse', 6),
            (warp_mode_spec if warp_enabled else None) if mode == 2 else snap_spec,
        ]
        return tuple(specs)

    def _simpler_action_spec(self, control_index):
        if self._simpler_warp_active():
            if control_index != 0:
                return None
            enabled = bool(getattr(self._simpler_device, 'can_warp_as', False))
            warp_lengths = (0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0)
            warp_labels = ('1/2 Beat', '1 Beat', '2 Beats', '4 Beats', '8 Beats', '16 Beats', '32 Beats')
            selected_index = min(
                range(len(warp_lengths)),
                key=lambda index: abs(warp_lengths[index] - self._simpler_warp_as_beats),
            )
            return {
                'name': 'Warp As',
                'action': 13,
                'kind': 'warp_length',
                'items': warp_labels,
                'display': warp_labels[selected_index],
                'normalized': float(selected_index) / float(len(warp_lengths) - 1),
                'enabled': enabled,
            }
        specs = self._simpler_action_specs()
        return specs[control_index] if 0 <= control_index < len(specs) else None

    def _simpler_action_metadata_item(self, spec):
        if not spec:
            return self.UNMAPPED_PARAMETER_METADATA_ITEM
        if spec.get('kind') == 'button':
            name = str(spec.get('name', 'Action'))
            if not spec.get('enabled', True):
                name = '*~' + name
            return '{}||||0.0||||0.0|momentary_{}'.format(
                self._parameter_metadata_name(self._escape_sysex_string(name), False),
                int(spec.get('action', 0)),
            )
        items = tuple(spec.get('items') or ('Ready', 'Trigger'))
        name = str(spec.get('name', 'Action'))
        if not spec.get('enabled', True):
            name = '*~' + name
        normalized = max(0.0, min(1.0, float(spec.get('normalized', 0.0))))
        quarter_index = int(round((len(items) - 1) * 32.0 / 127.0))
        return '{}|{}|{}|{}|{}|{}|{}|{}|{}|action'.format(
            self._parameter_metadata_name(self._escape_sysex_string(name), False),
            self._escape_sysex_string(items[0]),
            self._escape_sysex_string(items[-1]),
            self._escape_sysex_string(items[0]),
            0.0,
            self._escape_sysex_string(items[quarter_index]),
            ';'.join(self._escape_sysex_string(item) for item in items),
            self._escape_sysex_string(spec.get('display', items[0])),
            normalized,
        )

    def _simpler_action_metadata(self):
        return ','.join(
            self._simpler_action_metadata_item(spec)
            for spec in self._simpler_action_specs()
        )

    def _simpler_warp_metadata(self):
        try:
            parameters = self._device._simpler_control_parameters()
        except Exception:
            parameters = ()
        metadata = [self._simpler_action_metadata_item(self._simpler_action_spec(0))]
        for control_index in range(1, 8):
            parameter = parameters[control_index] if control_index < len(parameters) else None
            name = str(getattr(parameter, 'name', '')) if parameter else ''
            normalized_name = re.sub(r'[^a-z0-9]+', '', name.lower())
            if normalized_name == 'loopmode':
                name = 'Transient Loop Mode'
            elif normalized_name == 'filtertypelegacy':
                name = 'Filter Type'
            metadata.append(self._simpler_parameter_metadata_item(name, parameter))
        return ','.join(metadata)

    def _send_simpler_action_feedback(self, control_index):
        spec = self._simpler_action_spec(control_index)
        if not spec:
            self.send_cc(72 + control_index, 8, 0)
            return
        normalized = max(0.0, min(1.0, float(spec.get('normalized', 0.0))))
        display = str(spec.get('display', 'Ready'))
        self.send_cc(72 + control_index, 8, int(round(normalized * 127.0)))
        self._send_sys_ex_message(
            '{}|{}|{}'.format(control_index, normalized, self._escape_sysex_string(display)),
            0x28,
        )

    def _send_simpler_action_feedback_all(self):
        if self._simpler_actions_active() or self._simpler_warp_active():
            for control_index in range(8):
                self._send_simpler_action_feedback(control_index)

    def _set_simpler_parameter_display_item(self, parameter, display_item):
        if not parameter:
            return False
        wanted = str(display_item).strip().lower()
        candidates = (parameter.min, parameter.max)
        try:
            value_items = tuple(parameter.value_items) if parameter.is_quantized else ()
            if len(value_items) > 2:
                value_range = float(parameter.max) - float(parameter.min)
                candidates = tuple(
                    float(parameter.min) + value_range * index / float(len(value_items) - 1)
                    for index in range(len(value_items))
                )
        except Exception:
            pass
        for value in candidates:
            try:
                if wanted in str(parameter.str_for_value(value)).strip().lower():
                    parameter.value = value
                    return True
            except Exception:
                pass
        return False

    def _set_simpler_action_normalized(self, control_index, normalized):
        spec = self._simpler_action_spec(control_index)
        if not spec or not spec.get('enabled', True):
            return False
        normalized = max(0.0, min(1.0, float(normalized)))
        action = int(spec['action'])
        try:
            if action == 0:
                parameter = self._simpler_parameter(
                    'S Loop On' if int(self._simpler_device.playback_mode) == 0 else 'Trigger Mode'
                )
                items = spec['items']
                item = items[int(round(normalized * (len(items) - 1)))]
                if not self._set_simpler_parameter_display_item(parameter, item):
                    parameter.value = self._parameter_target_value_from_normalized(parameter, normalized)
            elif action == 1:
                self._simpler_sample.warping = normalized >= 0.5
            elif action == 7:
                parameter = self._simpler_parameter('Snap')
                parameter.value = self._parameter_target_value_from_normalized(parameter, normalized)
            elif action == 8:
                warp_modes = (
                    Live.Clip.WarpMode.beats,
                    Live.Clip.WarpMode.tones,
                    Live.Clip.WarpMode.texture,
                    Live.Clip.WarpMode.repitch,
                    Live.Clip.WarpMode.complex,
                    Live.Clip.WarpMode.complex_pro,
                )
                index = int(round(normalized * (len(warp_modes) - 1)))
                self._simpler_sample.warp_mode = warp_modes[index]
            elif action == 13:
                warp_lengths = (0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0)
                index = int(round(normalized * (len(warp_lengths) - 1)))
                self._simpler_warp_as_beats = warp_lengths[index]
                if bool(getattr(self._simpler_device, 'can_warp_as', False)):
                    self._simpler_device.warp_as(self._simpler_warp_as_beats)
            else:
                self._send_simpler_action_feedback(control_index)
                return True
            self._send_simpler_state()
            self._send_sys_ex_message(self._simpler_action_metadata(), 0x7D)
            self._send_simpler_action_feedback_all()
            return True
        except Exception as error:
            self._debug_log('Error setting Simpler action {}: {}'.format(spec.get('name'), str(error)))
            return False

    def _simpler_virtual_metadata(self):
        if self._simpler_main_active() and not liveobj_valid(self._simpler_sample):
            browse = '*!Browse Samples||||0.0||||0.0|browse_sample'
            return ','.join([browse] + [self.UNMAPPED_PARAMETER_METADATA_ITEM] * 7)
        metadata = []
        for control_index in range(8):
            spec = self._simpler_virtual_spec(control_index)
            if not spec:
                metadata.append(self.UNMAPPED_PARAMETER_METADATA_ITEM)
            elif spec['kind'] == 'zoom':
                display = '{}%'.format(int(round(self._simpler_zoom * 100.0)))
                metadata.append('*!Zoom|Full|Close|Full|0.0|25%||{}|{}'.format(display, self._simpler_zoom))
            else:
                metadata.append(self._simpler_parameter_metadata_item(spec['name'], spec['parameter']))
        return ','.join(metadata)

    def _simpler_browse_metadata(self):
        browse = '*!Browse Samples||||0.0||||0.0|browse_sample'
        try:
            parameters = self._device._simpler_browse_parameters()
        except Exception:
            parameters = tuple([None] * 8)
        display_names = (
            '',
            'Filter On/Off',
            'Filter Type',
            'Pitch Envelope On/Off',
            'Pitch Envelope Amount',
            'Transpose',
            'Detune',
            'Volume',
        )
        metadata = [browse]
        for control_index in range(1, 8):
            parameter = parameters[control_index] if control_index < len(parameters) else None
            metadata.append(
                self._simpler_parameter_metadata_item(display_names[control_index], parameter)
            )
        return ','.join(metadata)

    def _send_simpler_virtual_feedback(self, control_index):
        spec = self._simpler_virtual_spec(control_index)
        if not spec:
            self.send_cc(72 + control_index, 8, 0)
            return
        if spec['kind'] == 'zoom':
            normalized = self._simpler_zoom
            display = '{}%'.format(int(round(normalized * 100.0)))
        else:
            normalized = self._parameter_normalized_value(spec['parameter'])
            display = self._simpler_display_value(spec['name'], spec['parameter'])
        self.send_cc(72 + control_index, 8, int(round(max(0.0, min(1.0, normalized)) * 127.0)))
        self._send_sys_ex_message('{}|{}|{}'.format(control_index, normalized, self._escape_sysex_string(display)), 0x28)

    def _send_simpler_virtual_feedback_all(self):
        if self._simpler_main_active():
            for control_index in range(8):
                self._send_simpler_virtual_feedback(control_index)

    def _set_simpler_virtual_normalized(self, control_index, normalized):
        spec = self._simpler_virtual_spec(control_index)
        if not spec:
            return False
        normalized = max(0.0, min(1.0, float(normalized)))
        try:
            if spec['kind'] == 'zoom':
                self._simpler_zoom = normalized
                self._clamp_simpler_waveform_center()
                self._send_simpler_state()
            else:
                parameter = spec['parameter']
                parameter.value = self._parameter_target_value_from_normalized(parameter, normalized)
            self._send_simpler_virtual_feedback(control_index)
            return True
        except Exception as error:
            self._debug_log('Error setting Simpler {}: {}'.format(spec['name'], str(error)))
            return False

    def _clamp_simpler_waveform_center(self):
        zoom = max(0.0, min(1.0, self._simpler_zoom))
        visible_width = max(0.04, math.pow(1.0 - zoom, 2.0))
        half_width = visible_width * 0.5
        self._simpler_waveform_center = max(
            half_width,
            min(1.0 - half_width, self._simpler_waveform_center),
        )

    def _set_simpler_viewport(self, values):
        if not self._simpler_main_active() or len(values) < 4:
            return
        zoom_raw = (int(values[0]) << 7) | int(values[1])
        center_raw = (int(values[2]) << 7) | int(values[3])
        self._simpler_zoom = max(0.0, min(1.0, float(zoom_raw) / 16383.0))
        self._simpler_waveform_center = max(0.0, min(1.0, float(center_raw) / 16383.0))
        self._clamp_simpler_waveform_center()
        self._send_simpler_state()
        self._send_simpler_virtual_feedback(0)

    def _on_simpler_playhead_changed(self):
        self._send_simpler_playhead()

    def _normalized_simpler_position(self, value, length, fallback):
        try:
            return max(0.0, min(1.0, float(value) / max(1.0, float(length))))
        except Exception:
            return fallback

    def _send_simpler_state(self):
        device = self._simpler_device
        sample = self._simpler_sample
        if not liveobj_valid(device) or not liveobj_valid(sample):
            self._send_sys_ex_message('1|0|1|0|1||0|0|0|0|0|0|0|0|0|0|0|0|0.5', 0x42)
            return

        try:
            length = max(1.0, float(sample.length))
        except Exception:
            length = 1.0
        view = getattr(device, 'view', None)
        sample_start = self._normalized_simpler_position(
            getattr(view, 'sample_start', getattr(sample, 'start_marker', 0.0)), length, 0.0
        )
        sample_end = self._normalized_simpler_position(
            getattr(view, 'sample_end', getattr(sample, 'end_marker', length)), length, 1.0
        )
        loop_start = self._normalized_simpler_position(
            getattr(view, 'sample_loop_start', sample_start * length), length, sample_start
        )
        loop_end = self._normalized_simpler_position(
            getattr(view, 'sample_loop_end', sample_end * length), length, sample_end
        )
        try:
            slices = [
                '{:.6f}'.format(max(0.0, min(1.0, float(value) / length)))
                for value in list(sample.slices)[:128]
            ]
        except Exception:
            slices = []

        try:
            mode = int(device.playback_mode)
        except Exception:
            mode = 0
        selected_slice = self._normalized_simpler_position(
            getattr(view, 'selected_slice', sample_start * length), length, sample_start
        )
        slice_by_parameter = self._simpler_parameter('Slice by')
        manual_slicing = 1 if slice_by_parameter and 'manual' in self._parameter_display_value(slice_by_parameter).lower() else 0
        toggle_parameter = self._simpler_parameter('S Loop On' if mode == 0 else 'Trigger Mode')
        toggle_normalized = self._parameter_normalized_value(toggle_parameter) if toggle_parameter else 0.0
        if mode == 0:
            loop_or_trigger_enabled = 1 if toggle_parameter and toggle_normalized >= 0.5 else 0
        else:
            toggle_display = self._parameter_display_value(toggle_parameter).lower() if toggle_parameter else ''
            if 'trigger' in toggle_display:
                loop_or_trigger_enabled = 1
            elif 'gate' in toggle_display:
                loop_or_trigger_enabled = 0
            else:
                # Trigger Mode's raw direction is opposite to the UI label in Live 12.
                loop_or_trigger_enabled = 1 if toggle_parameter and toggle_normalized < 0.5 else 0
        warp_enabled = 1 if bool(getattr(sample, 'warping', False)) else 0
        snap_parameter = self._simpler_parameter('Snap')
        snap_enabled = 1 if snap_parameter and self._parameter_normalized_value(snap_parameter) >= 0.5 else 0
        try:
            warp_mode = int(sample.warp_mode)
        except Exception:
            warp_mode = 0
        active_length = max(1.0, (sample_end - sample_start) * length)
        loop_length = max(1.0, (loop_end - loop_start) * length)
        fade_in = max(0.0, min(0.5, float(getattr(view, 'sample_env_fade_in', 0.0)) / active_length))
        fade_out = max(0.0, min(0.5, float(getattr(view, 'sample_env_fade_out', 0.0)) / active_length))
        loop_fade = self._normalized_simpler_position(
            getattr(view, 'sample_loop_fade', 0.0),
            length,
            0.0,
        )
        payload = '1|{:.6f}|{:.6f}|{:.6f}|{:.6f}|{}|{}|{:.6f}|{:.6f}|{}|{}|{}|{}|1|{}|{:.6f}|{:.6f}|{:.6f}|{:.6f}'.format(
            sample_start,
            sample_end,
            loop_start,
            loop_end,
            ','.join(slices),
            mode,
            self._simpler_zoom,
            selected_slice,
            manual_slicing,
            loop_or_trigger_enabled,
            warp_enabled,
            snap_enabled,
            warp_mode,
            fade_in,
            fade_out,
            loop_fade,
            self._simpler_waveform_center,
        )
        self._send_sys_ex_message(payload, 0x42)

    def _trigger_simpler_action(self, action_index):
        device = self._simpler_device
        sample = self._simpler_sample
        if not (self._simpler_main_active() or self._simpler_actions_active() or self._simpler_warp_active()) or not liveobj_valid(device) or not liveobj_valid(sample):
            return
        try:
            mode = int(device.playback_mode)
            if action_index == 0:
                parameter = self._simpler_parameter('S Loop On' if mode == 0 else 'Trigger Mode')
                if parameter:
                    if getattr(parameter, 'is_quantized', False) and getattr(parameter, 'value_items', None):
                        count = len(parameter.value_items)
                        current = int(round(self._parameter_normalized_value(parameter) * max(1, count - 1)))
                        parameter.value = self._parameter_target_value_from_normalized(
                            parameter, float((current + 1) % count) / max(1, count - 1)
                        )
                    else:
                        parameter.value = parameter.min if parameter.value > parameter.min else parameter.max
            elif action_index == 1:
                sample.warping = not bool(sample.warping)
            elif action_index == 2 and bool(device.can_warp_half):
                device.warp_half()
            elif action_index == 3 and bool(device.can_warp_double):
                device.warp_double()
            elif action_index == 4 and mode == 2:
                slice_by_parameter = self._simpler_parameter('Slice by')
                if slice_by_parameter and 'manual' in self._parameter_display_value(slice_by_parameter).lower():
                    sample.clear_slices()
                else:
                    sample.reset_slices()
            elif action_index == 5:
                if mode == 2:
                    slices = list(sample.slices) + [sample.end_marker]
                    selected = device.view.selected_slice
                    if selected in slices:
                        slice_index = slices.index(selected)
                        if slice_index + 1 < len(slices):
                            new_slice = int((slices[slice_index + 1] - selected) / 2.0) + selected
                            if new_slice not in slices:
                                sample.insert_slice(new_slice)
                                device.view.selected_slice = new_slice
                else:
                    device.crop()
            elif action_index == 6:
                device.reverse()
            elif action_index == 7 and mode in (0, 1):
                parameter = self._simpler_parameter('Snap')
                if parameter:
                    parameter.value = parameter.min if parameter.value > parameter.min else parameter.max
            elif action_index == 8 and bool(sample.warping):
                warp_modes = (
                    Live.Clip.WarpMode.beats,
                    Live.Clip.WarpMode.tones,
                    Live.Clip.WarpMode.texture,
                    Live.Clip.WarpMode.repitch,
                    Live.Clip.WarpMode.complex,
                    Live.Clip.WarpMode.complex_pro,
                )
                current_mode = int(sample.warp_mode)
                current_index = next((index for index, warp_mode in enumerate(warp_modes) if int(warp_mode) == current_mode), -1)
                sample.warp_mode = warp_modes[(current_index + 1) % len(warp_modes)]
            elif action_index == 9:
                self._simpler_zoom = min(1.0, self._simpler_zoom + 0.12)
                self._clamp_simpler_waveform_center()
            elif action_index == 10:
                self._simpler_zoom = max(0.0, self._simpler_zoom - 0.12)
                self._clamp_simpler_waveform_center()
            elif action_index in (11, 12):
                visible_width = max(0.04, math.pow(1.0 - self._simpler_zoom, 2.0))
                direction = -1.0 if action_index == 11 else 1.0
                self._simpler_waveform_center += direction * visible_width * 0.25
                self._clamp_simpler_waveform_center()
            elif action_index == 13 and bool(getattr(device, 'can_warp_as', False)):
                device.warp_as(self._simpler_warp_as_beats)
            self._send_simpler_state()
            self._send_sys_ex_message(str(action_index), 0x44)
            if self._simpler_actions_active():
                self._send_sys_ex_message(self._simpler_action_metadata(), 0x7D)
                self._send_simpler_action_feedback_all()
            elif self._simpler_warp_active():
                self._send_sys_ex_message(self._simpler_warp_metadata(), 0x7D)
                self._send_simpler_action_feedback_all()
            else:
                self._send_sys_ex_message(self._simpler_virtual_metadata(), 0x7D)
                self._send_simpler_virtual_feedback_all()
        except Exception as error:
            self._debug_log('Simpler action {} failed: {}'.format(action_index, str(error)))

    def _send_simpler_playhead(self, force=False, hidden=False):
        device = self._simpler_device
        enabled = False
        position = 0.0
        if not hidden and liveobj_valid(device):
            try:
                enabled = bool(device.playing_position_enabled)
                position = max(0.0, min(1.0, float(device.playing_position)))
            except Exception:
                enabled = False
                position = 0.0

        raw_position = max(0, min(16383, int(round(position * 16383.0))))
        high = (raw_position >> 7) & 0x7F
        low = raw_position & 0x7F
        enabled_value = 127 if enabled else 0
        if force or high != self._simpler_playhead_high:
            self.send_cc(67, 11, high)
            self._simpler_playhead_high = high
        if force or low != self._simpler_playhead_low:
            self.send_cc(68, 11, low)
            self._simpler_playhead_low = low
        if force or enabled_value != self._simpler_playhead_enabled:
            self.send_cc(69, 11, enabled_value)
            self._simpler_playhead_enabled = enabled_value

    def _send_simpler_waveform_clear(self):
        generation = self._simpler_waveform_generation & 0x7F
        self._send_binary_sys_ex_message((0x01, generation), 0x41)

    def _send_simpler_waveform(self, generation, peaks):
        if generation != self._simpler_waveform_generation:
            return
        peaks = list(peaks)
        target_count = min(112, len(peaks))
        if len(peaks) > target_count:
            reduced = []
            for point_index in range(target_count):
                start = int(float(point_index) * len(peaks) / target_count)
                end = max(start + 1, int(float(point_index + 1) * len(peaks) / target_count))
                reduced.append(max(peaks[start:end]))
            peaks = reduced
        else:
            peaks = peaks[:target_count]
        peaks = [max(0, min(127, int(peak))) for peak in peaks]
        self._debug_log('Sending Simpler waveform: {} raw 7-bit points'.format(len(peaks)))
        self._send_binary_sys_ex_message(
            (0x01, generation & 0x7F) + tuple(peaks),
            0x41
        )

    def _request_simpler_waveform(self):
        sample = self._simpler_sample
        if not liveobj_valid(sample):
            return
        try:
            file_path = str(sample.file_path)
        except Exception:
            file_path = ''
        if not file_path or not os.path.isfile(file_path):
            return

        generation = self._simpler_waveform_generation
        source_signature = self._simpler_waveform_source_signature(file_path)
        cached = self._simpler_waveform_cache.get(file_path)
        if cached:
            self._debug_log('Using cached Simpler waveform: {} points'.format(len(cached)))
            self._send_simpler_waveform(generation, cached)
            return
        if self._simpler_waveform_failures.get(file_path) == source_signature:
            return

        pending_key = (generation, file_path)
        if pending_key in self._simpler_waveform_pending:
            return
        self._simpler_waveform_pending.add(pending_key)
        self._simpler_waveform_polling.add(pending_key)
        self.schedule_message(5, lambda: self._poll_simpler_waveform(generation, file_path, 0))

        worker = threading.Thread(
            target=self._build_simpler_waveform,
            args=(generation, file_path, source_signature),
            name='TapSimplerWaveform',
        )
        worker.daemon = True
        worker.start()

    def _poll_simpler_waveform(self, generation, file_path, attempt):
        pending_key = (generation, file_path)
        if generation != self._simpler_waveform_generation:
            self._simpler_waveform_polling.discard(pending_key)
            return
        cached = self._simpler_waveform_cache.get(file_path)
        if cached:
            self._simpler_waveform_polling.discard(pending_key)
            self._send_simpler_waveform(generation, cached)
            return
        if pending_key not in self._simpler_waveform_pending:
            self._simpler_waveform_polling.discard(pending_key)
            return
        if attempt < 120 and pending_key in self._simpler_waveform_polling:
            self.schedule_message(5, lambda: self._poll_simpler_waveform(generation, file_path, attempt + 1))
        else:
            self._simpler_waveform_polling.discard(pending_key)

    def _simpler_waveform_source_signature(self, file_path):
        def file_signature(path):
            try:
                info = os.stat(path)
                return (info.st_size, getattr(info, 'st_mtime_ns', int(info.st_mtime * 1000000000)))
            except Exception:
                return None
        return (file_signature(file_path), file_signature(file_path + '.asd'))

    def _cache_simpler_waveform(self, file_path, peaks):
        self._debug_log('Cached Simpler waveform: {} points'.format(len(peaks)))
        self._simpler_waveform_cache[file_path] = tuple(peaks)
        self._simpler_waveform_failures.pop(file_path, None)
        if file_path in self._simpler_waveform_failure_order:
            self._simpler_waveform_failure_order.remove(file_path)
        if file_path in self._simpler_waveform_cache_order:
            self._simpler_waveform_cache_order.remove(file_path)
        self._simpler_waveform_cache_order.append(file_path)
        while len(self._simpler_waveform_cache_order) > 8:
            oldest = self._simpler_waveform_cache_order.pop(0)
            self._simpler_waveform_cache.pop(oldest, None)

    def _cache_simpler_waveform_failure(self, file_path, source_signature):
        self._simpler_waveform_failures[file_path] = source_signature
        if file_path in self._simpler_waveform_failure_order:
            self._simpler_waveform_failure_order.remove(file_path)
        self._simpler_waveform_failure_order.append(file_path)
        while len(self._simpler_waveform_failure_order) > 32:
            oldest = self._simpler_waveform_failure_order.pop(0)
            self._simpler_waveform_failures.pop(oldest, None)

    def _simpler_audio_file_has_supported_header(self, file_path):
        try:
            with open(file_path, 'rb') as audio_file:
                header = audio_file.read(12)
            return (
                (header[:4] in (b'RIFF', b'RF64', b'BW64') and header[8:12] == b'WAVE')
                or (header[:4] == b'FORM' and header[8:12] in (b'AIFF', b'AIFC'))
                or header[:4] in (b'fLaC', b'OggS', b'caff')
                or header[:3] == b'ID3'
                or (len(header) >= 2 and header[0] == 0xFF and (header[1] & 0xE0) == 0xE0)
                or header[4:8] == b'ftyp'
            )
        except Exception:
            return False

    def _decode_audio_waveform(self, file_path, temp_prefix):
        # Live's analysis file is both cheaper to read and the only available
        # source for encrypted Pack samples. Trying afconvert first can leave a
        # CPU-bound child process running for minutes on those files.
        peaks = self._simpler_waveform_from_asd(file_path)
        if peaks:
            return peaks
        if not self._simpler_audio_file_has_supported_header(file_path):
            self._debug_log('Skipping unsupported Simpler waveform source: {}'.format(file_path))
            return []

        temp_directory = tempfile.mkdtemp(prefix=temp_prefix)
        converted_path = os.path.join(temp_directory, 'waveform.wav')
        peaks = []
        try:
            subprocess.run(
                ['/usr/bin/afconvert', '-f', 'WAVE', '-d', 'LEI16@4000', '-c', '1', file_path, converted_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=True,
                timeout=10,
            )
            with wave.open(converted_path, 'rb') as audio_file:
                frame_count = audio_file.getnframes()
                point_count = max(1, min(512, frame_count))
                for point_index in range(point_count):
                    end_frame = int(round(float(point_index + 1) * frame_count / point_count))
                    frames_to_read = max(1, end_frame - audio_file.tell())
                    frame_data = audio_file.readframes(frames_to_read)
                    if not frame_data:
                        peaks.append(0)
                    elif audioop is not None:
                        peaks.append(audioop.max(frame_data, 2))
                    else:
                        maximum = 0
                        for byte_index in range(0, len(frame_data) - 1, 2):
                            value = int.from_bytes(frame_data[byte_index:byte_index + 2], 'little', signed=True)
                            maximum = max(maximum, abs(value))
                        peaks.append(maximum)
            maximum_peak = max(peaks) if peaks else 0
            if maximum_peak > 0:
                return [max(0, min(127, int(round(float(value) * 127.0 / maximum_peak)))) for value in peaks]
            return [0 for _ in peaks]
        except Exception as error:
            self._debug_log('Waveform decode failed for {}: {}'.format(file_path, str(error)))
            return []
        finally:
            shutil.rmtree(temp_directory, ignore_errors=True)

    def _build_simpler_waveform(self, generation, file_path, source_signature):
        pending_key = (generation, file_path)
        with self._simpler_waveform_lock:
            if generation != self._simpler_waveform_generation:
                self._simpler_waveform_pending.discard(pending_key)
                return
            peaks = self._decode_audio_waveform(file_path, 'tap-simpler-')
            if not peaks or generation != self._simpler_waveform_generation:
                if not peaks and generation == self._simpler_waveform_generation:
                    self._cache_simpler_waveform_failure(file_path, source_signature)
                self._simpler_waveform_pending.discard(pending_key)
                return
            self._cache_simpler_waveform(file_path, peaks)
            self._simpler_waveform_pending.discard(pending_key)

    def _simpler_waveform_from_asd(self, file_path):
        """Read Live's cached waveform overview when pack audio is encrypted."""
        analysis_path = file_path + '.asd'
        if not os.path.isfile(analysis_path):
            return []
        try:
            with open(analysis_path, 'rb') as analysis_file:
                data = analysis_file.read()
            tag = b'\x00\x13SampleOverViewLevel'
            search_from = 0
            candidates = []
            while True:
                offset = data.find(tag, search_from)
                if offset < 0:
                    break
                search_from = offset + len(tag)
                body = offset + len(tag)
                if body + 8 > len(data):
                    continue
                version, value_count = struct.unpack_from('<II', data, body)
                if value_count <= 0 or value_count > 65536:
                    continue
                if version == 0:
                    value_size = 2
                    value_format = 'e'
                elif version == 2:
                    value_size = 4
                    value_format = 'f'
                else:
                    continue
                values_start = body + 8
                values_end = values_start + value_count * value_size
                if values_end > len(data):
                    continue
                values = struct.unpack_from('<{}{}'.format(value_count, value_format), data, values_start)
                if any(not math.isfinite(value) for value in values):
                    continue
                # Overview values are interleaved min/max pairs per channel.
                # Four values collapse a stereo bin; on mono files this simply
                # combines two adjacent bins and keeps the same envelope shape.
                amplitudes = [
                    max(abs(value) for value in values[index:index + 4])
                    for index in range(0, len(values), 4)
                    if values[index:index + 4]
                ]
                if amplitudes:
                    candidates.append(amplitudes)
            if not candidates:
                return []

            amplitudes = max(candidates, key=len)
            if len(amplitudes) > 512:
                reduced = []
                for point_index in range(512):
                    start = int(float(point_index) * len(amplitudes) / 512.0)
                    end = max(start + 1, int(float(point_index + 1) * len(amplitudes) / 512.0))
                    reduced.append(max(amplitudes[start:end]))
                amplitudes = reduced
            maximum = max(amplitudes)
            if maximum <= 0.0:
                return [0 for _ in amplitudes]
            return [max(0, min(127, int(round(value * 127.0 / maximum)))) for value in amplitudes]
        except Exception as error:
            self._debug_log('Simpler ASD waveform decode failed for {}: {}'.format(analysis_path, str(error)))
            return []

    def _send_custom_device_navigation_state(self, selected_track, selected_device):
        if not selected_track:
            return
        all_devices, chain_info = self._get_all_nested_devices(selected_track.devices)
        starts_by_index = {}
        ends_by_index = {}
        for info in chain_info:
            starts_by_index.setdefault(info.get('start_index'), []).append(info)
            ends_by_index.setdefault(info.get('end_index'), []).append(info)

        names = [self._escape_sysex_string(self.TRACK_DEVICE_NAV_NAME)]
        selected_index = 'not found'
        for index, device in enumerate(all_devices):
            prefix = ''.join('||' if item['type'] == 'rack' else '|*' for item in starts_by_index.get(index, ()))
            endings = ends_by_index.get(index, ())
            suffix = ''.join('*|' for item in endings if item['type'] == 'chain')
            suffix += ''.join('||' for item in endings if item['type'] == 'rack')
            names.append(prefix + self._escape_sysex_string(device.name) + suffix)
            if device == selected_device:
                selected_index = str(index + 1)

        self._send_sys_ex_message(selected_index, 0x4D)
        self._send_sys_ex_message(','.join(names), 0x01)
        self._send_rack_snapshot_state(all_devices)

    @subject_slot('device')
    def _on_device_changed(self, send_device_navigation=True):
        self._remove_wavetable_virtual_property_listeners()
        self._remove_dynamic_parameter_state_listeners()
        self._remove_meld_engine_listener()
        if liveobj_valid(self._device):
            # get and send name of bank and device
            selected_track = self.song().view.selected_track
            selected_device = getattr(self._device, '_device', None)
            if not liveobj_valid(selected_device) and selected_track:
                selected_device = selected_track.view.selected_device
            track_device_selected = self._track_device_is_selected()
            self._send_track_simpler_slice_state(force=True)
            self._set_simpler_device(None if track_device_selected else selected_device)
            if track_device_selected:
                self._setup_meld_engine_listener(None)
                self._send_sys_ex_message('', 0x4A)
            else:
                self._setup_meld_engine_listener(selected_device)
                self._send_meld_engine_state(selected_device)

            # Send the light bank update before listener and metadata work.
            track_has_drums = 0
            drum_rack_device = self._find_drum_rack_in_track(selected_track) if selected_track else None
            if drum_rack_device is not None:
                track_has_drums = 1

            if track_device_selected:
                self._connect_track_device_parameter_controls(selected_track)
                self._send_track_device_bank_state(track_has_drums)
                self._remove_parameter_value_listeners()
                self._remove_parameter_name_listeners()
                self._remove_parameter_source_listener()
                self._remove_automation_state_listeners()
                self._automation_metadata_device_id = None
                if selected_track and hasattr(selected_track, "mixer_device"):
                    self._set_parameter_source_listener(selected_track.mixer_device)

                available_devices_string = self._escape_sysex_string(self.TRACK_DEVICE_NAV_NAME)
                all_devices = []
                chain_info = []
                if send_device_navigation and selected_track and hasattr(selected_track, "devices"):
                    all_devices, chain_info = self._get_all_nested_devices(selected_track.devices)
                    all_device_names = [self._escape_sysex_string(self.TRACK_DEVICE_NAV_NAME)]
                    starts_by_index = {}
                    ends_by_index = {}
                    for info in chain_info:
                        starts_by_index.setdefault(info.get('start_index'), []).append(info)
                        ends_by_index.setdefault(info.get('end_index'), []).append(info)
                    for i, device in enumerate(all_devices):
                        name = device.name
                        starts = starts_by_index.get(i, ())
                        ends = ends_by_index.get(i, ())

                        prefix = ""
                        for s in starts:
                            if s['type'] == 'rack':
                                prefix += "||"
                            elif s['type'] == 'chain':
                                prefix += "|*"

                        suffix = ""
                        for e in ends:
                            if e['type'] == 'chain':
                                suffix += "*|"
                        for e in ends:
                            if e['type'] == 'rack':
                                suffix += "||"

                        all_device_names.append(prefix + self._escape_sysex_string(name) + suffix)
                    available_devices_string = ','.join(all_device_names)

                    self._send_sys_ex_message("0", 0x4D)
                    self._send_sys_ex_message(available_devices_string, 0x01)
                    self._send_rack_snapshot_state(all_devices)

                self._send_track_device_parameter_metadata(selected_track)
                self._refresh_parameter_value_listeners_current_bank(send_current_values=True)
                self._refresh_parameter_name_listeners_current_bank()
                self._refresh_automation_state_listeners_current_bank()
                self._last_automation_signature = self._get_automation_signature()
                return

            current_bank_name, all_bank_names, connected_bank_names = self._send_bank_state(selected_device, track_has_drums)
            has_early_custom_surface = bool(
                self._active_wavetable_virtual_specs() or
                self._simpler_main_active() or
                self._simpler_actions_active() or
                self._simpler_warp_active()
            )
            if send_device_navigation and has_early_custom_surface:
                self._send_custom_device_navigation_state(selected_track, selected_device)
            if self._active_wavetable_virtual_specs():
                self._remove_parameter_value_listeners()
                self._remove_parameter_name_listeners()
                self._remove_parameter_source_listener()
                self._remove_automation_state_listeners()
                self._setup_wavetable_virtual_property_listeners()
                self._send_sys_ex_message(self._wavetable_virtual_metadata(), 0x7D)
                self._send_wavetable_virtual_feedback_all()
                return

            if self._simpler_main_active():
                self._remove_parameter_value_listeners()
                self._remove_parameter_name_listeners()
                self._remove_parameter_source_listener()
                self._refresh_automation_state_listeners_current_bank()
                self._last_automation_signature = self._get_automation_signature()
                self._send_sys_ex_message(self._simpler_virtual_metadata(), 0x7D)
                self._send_simpler_virtual_feedback_all()
                return

            if self._simpler_actions_active():
                self._remove_parameter_value_listeners()
                self._remove_parameter_name_listeners()
                self._remove_parameter_source_listener()
                self._remove_automation_state_listeners()
                self._last_automation_signature = None
                self._send_sys_ex_message(self._simpler_action_metadata(), 0x7D)
                self._send_simpler_action_feedback_all()
                return

            self._setup_dynamic_parameter_state_listeners()

            self._remove_parameter_value_listeners()
            self._remove_parameter_name_listeners()
            self._remove_parameter_source_listener()
            self._remove_automation_state_listeners()
            self._automation_metadata_device_id = None
            self._set_parameter_source_listener(selected_device)
            
            selected_device_index = "not found"
            available_devices_string = ""
            if send_device_navigation:
                # Get all available devices of the selected track, including nested devices
                all_devices, chain_info = self._get_all_nested_devices(selected_track.devices)
                starts_by_index = {}
                ends_by_index = {}
                for info in chain_info:
                    starts_by_index.setdefault(info.get('start_index'), []).append(info)
                    ends_by_index.setdefault(info.get('end_index'), []).append(info)
                
                # Convert device objects to names for display, adding chain markers
                all_device_names = []
                for i, device in enumerate(all_devices):
                    name = device.name
                    
                    # collect all starts/ends for this index
                    starts = starts_by_index.get(i, ())
                    ends = ends_by_index.get(i, ())
                    
                    # there should never be more than one rack or chain at the same index
                    prefix = ""
                    for s in starts:
                        if s['type'] == 'rack':
                            prefix += "||"
                        elif s['type'] == 'chain':
                            prefix += "|*"
                
                    # make sure chains come first, racks after
                    suffix = ""
                    for e in ends:
                        if e['type'] == 'chain':
                            suffix += "*|"
                    for e in ends:
                        if e['type'] == 'rack':
                            suffix += "||"
                
                    all_device_names.append(prefix + self._escape_sysex_string(name) + suffix)
                
                available_devices_string = ','.join(all_device_names)
                if all_device_names:
                    available_devices_string = self._escape_sysex_string(self.TRACK_DEVICE_NAV_NAME) + "," + available_devices_string
                else:
                    available_devices_string = self._escape_sysex_string(self.TRACK_DEVICE_NAV_NAME)
                
                # CHANGE 2: Find index of selected device in our comprehensive nested devices list
                for index, device in enumerate(all_devices):
                    if device == selected_device:
                        selected_device_index = str(index + 1)
                        break
            
            # set up drum pad listeners after the fast bank update
            if drum_rack_device is not None:
                if drum_rack_device != self._drum_rack_device:
                    if self._drum_rack_device:
                        self._remove_drum_pad_name_listeners()
                    self._drum_rack_device = drum_rack_device
                    self._setup_drum_pad_listeners()
            elif self._drum_rack_device:
                self._remove_drum_pad_name_listeners()
                self._drum_rack_device = None
                
            if send_device_navigation:
                # CHANGE 3: Send the index from our comprehensive device list
                self._send_sys_ex_message(selected_device_index, 0x4D)
                
                # Send the comprehensive list of available devices
                self._send_sys_ex_message(available_devices_string, 0x01)
                self._send_rack_snapshot_state(all_devices)
            
            # In mixer mode, temporarily reconnect device controls so we can
            # build parameter metadata. Do this early so the framework has more
            # time to remap parameters to the new device before we read them.
            if self.mixer_status:
                self._connect_device_controls()
            
            if hasattr(selected_device, 'parameters') and selected_device.parameters:
                def _build_parameter_names():
                    names = []
                    for control_index, control in enumerate(self._device._parameter_controls):
                        mapped_param = self._current_connected_parameter_for_control(control_index, selected_device)
                        if mapped_param:
                            
                            device_param = mapped_param
                            
                            if device_param and hasattr(device_param, 'is_enabled'):
                                names.append(self._get_parameter_display_name(device_param))
                            else:
                                # Fallback to mapped parameter name if DeviceParameter not found
                                names.append(self._escape_sysex_string(mapped_param.name))
                        else:
                            names.append("")
                    return [name for name in names if name != ""]
                
                parameter_names = _build_parameter_names()
                parameter_state_refreshed = False
                if not parameter_names and self.mixer_status:
                    if hasattr(self._device, 'set_device'):
                        try:
                            self._device.set_device(selected_device)
                        except Exception:
                            pass
                    if connected_bank_names:
                        try:
                            if current_bank_name and current_bank_name in all_bank_names:
                                self._device._bank_index = all_bank_names.index(current_bank_name)
                            else:
                                self._device._bank_index = all_bank_names.index(connected_bank_names[0])
                        except Exception:
                            pass
                    if hasattr(self._device, 'update'):
                        try:
                            self._device.update()
                        except Exception:
                            pass
                    parameter_names = _build_parameter_names()
                
                # Filter out empty names but keep "-" for disabled parameters
                
                if parameter_names:
                    parameter_state_refreshed = bool(self._send_parameter_info(parameter_names))
                else:
                    # parameter_names empty — try building metadata directly from
                    # _build_parameter_metadata, which may succeed even when the
                    # device component's own remapping is still in progress
                    current_metadata = self._build_parameter_metadata(selected_device)
                    if current_metadata and not self._metadata_is_all_unmapped(current_metadata):
                        self._send_sys_ex_message(current_metadata, 0x7D)
                        self._set_cached_metadata(selected_device, current_metadata)
                        self._mark_metadata_sent(selected_device)
                    else:
                        # Live sometimes needs another update tick after controls
                        # are reattached, so keep rechecking after sending the
                        # current empty state.
                        self._send_unmapped_parameter_metadata_for_device(selected_device, current_metadata)
                        self._schedule_parameter_metadata_recheck(delay=0.05)
                if not parameter_state_refreshed:
                    self._refresh_parameter_value_listeners_current_bank(send_current_values=True)
                    self._refresh_parameter_name_listeners_current_bank()
                    self._refresh_automation_state_listeners_current_bank()
                self._last_automation_signature = self._get_automation_signature()
            
            self._remove_disabled_parameter_listeners()
            
            if hasattr(selected_device, 'parameters') and selected_device.parameters:
                for control_index, control in enumerate(self._device._parameter_controls):
                    mapped_param = self._current_connected_parameter_for_control(control_index, selected_device)
                    if mapped_param:
                        
                        device_param = mapped_param
                        
                        if device_param and not self._parameter_is_control_available(device_param):
                            listener = self._create_disabled_param_listener(device_param, control_index)
                            if not device_param.value_has_listener(listener):
                                device_param.add_value_listener(listener)
                            
                            self._disabled_parameter_listeners[(device_param, control_index)] = listener
                            self._disabled_parameters.append(device_param)
                            self._current_disabled_controls.append(control_index)
                            
                            self._send_parameter_feedback(control_index, device_param, force_display=True)
            else:
                # Device has no parameters - send not mapped for all controls
                self._send_unmapped_parameter_metadata()

            # In mixer mode, disconnect device controls after a short delay
            # instead of immediately, so the framework has time to finish
            # remapping parameters to the new device.
            if self.mixer_status:
                if hasattr(self, '_mixer_disconnect_timer') and self._mixer_disconnect_timer:
                    self._mixer_disconnect_timer.cancel()
                self._mixer_disconnect_timer = self._schedule_main_thread(
                    0.2, self._disconnect_device_controls
                )

        else:
            self._set_simpler_device(None)
            # no device
            # sending sysex of bank name, device name, bank names
            bank_name_drum = ";0"
            bank_names_list = ""
            available_devices_string = ""
            self._send_sys_ex_message(bank_name_drum, 0x6D)
            self._send_sys_ex_message(bank_names_list, 0x5D)
            self._send_sys_ex_message(available_devices_string, 0x01)
            self._send_rack_snapshot_state([])
            # Send not mapped for all controls when no device is selected
            self._send_unmapped_parameter_metadata()
    
    def _get_all_nested_devices(self, devices):
        """
        Recursively collect all devices, including those inside instruments and drum racks.
        For drum racks, only include the selected drum pad chain (like Push behavior).
        Returns a tuple: (list of device objects, list of chain_info dicts)
        
        chain_info format: {'start_index': int, 'end_index': int, 'type': 'drum_rack'/'rack'}
        """
        all_devices = []
        chain_info = []
        
        for device in devices:
            if liveobj_valid(device):
                # Add the current device
                all_devices.append(device)
                
                # Check if device is a drum rack
                if hasattr(device, 'can_have_drum_pads') and device.can_have_drum_pads and hasattr(device, 'drum_pads') and device.drum_pads:
                    # For drum racks, only process the selected drum pad chain
                    selected_drum_pad = self._get_selected_drum_pad(device)
                    if selected_drum_pad and hasattr(selected_drum_pad, 'chains') and selected_drum_pad.chains:
                        for chain in selected_drum_pad.chains:
                            if liveobj_valid(chain) and hasattr(chain, 'devices'):
                                # Mark start of nested chain
                                start_index = len(all_devices)
                                
                                # Add devices from the selected drum pad chain
                                nested_devices, nested_chain_info = self._get_all_nested_devices(chain.devices)
                                all_devices.extend(nested_devices)
                                
                                # Mark end of nested chain (if any devices were added)
                                if nested_devices:
                                    end_index = len(all_devices) - 1
                                    chain_info.append({
                                        'start_index': start_index,
                                        'end_index': end_index,
                                        'type': 'rack'
                                    })
                                
                                # Add any nested chain info with adjusted indices
                                for info in nested_chain_info:
                                    chain_info.append({
                                        'start_index': info['start_index'] + start_index,
                                        'end_index': info['end_index'] + start_index,
                                        'type': info['type']
                                    })
                
                # Check if device is an instrument rack or effect rack (has chains)
                elif hasattr(device, 'chains') and device.chains:
                    num_chains = len([c for c in device.chains if liveobj_valid(c) and hasattr(c, 'devices')])
                    
                    for chain in device.chains:
                        if liveobj_valid(chain) and hasattr(chain, 'devices'):
                            # Mark start of nested chain
                            start_index = len(all_devices)
                            
                            # Add devices from this chain
                            nested_devices, nested_chain_info = self._get_all_nested_devices(chain.devices)
                            all_devices.extend(nested_devices)
                            
                            # Mark end of nested chain (if any devices were added)
                            # adding chain instead of rack if we have more than one chain
                            if nested_devices:
                                end_index = len(all_devices) - 1
                                chain_info.append({
                                    'start_index': start_index,
                                    'end_index': end_index,
                                    'type': 'chain' if num_chains > 1 else 'rack'
                                })
                            
                            # Add any nested chain info with adjusted indices
                            for info in nested_chain_info:
                                chain_info.append({
                                    'start_index': info['start_index'] + start_index,
                                    'end_index': info['end_index'] + start_index,
                                    'type': info['type']
                                })
                            
        return all_devices, chain_info
    
    def _rack_snapshot_info_for_device(self, device):
        if not liveobj_valid(device) or not isinstance(device, Live.RackDevice.RackDevice):
            return None
        
        has_mapped_macros = False
        try:
            if hasattr(device, 'has_macro_mappings'):
                has_mapped_macros = bool(device.has_macro_mappings)
        except Exception:
            has_mapped_macros = False
        
        if not has_mapped_macros and hasattr(device, 'macros_mapped'):
            try:
                has_mapped_macros = any(device.macros_mapped)
            except Exception:
                has_mapped_macros = False
        
        variation_count = 0
        if hasattr(device, 'variation_count'):
            try:
                variation_count = int(device.variation_count)
            except Exception:
                variation_count = 0
        
        selected_variation_index = -1
        if variation_count > 0 and hasattr(device, 'selected_variation_index'):
            try:
                selected_variation_index = int(device.selected_variation_index)
            except Exception:
                selected_variation_index = -1
        
        return has_mapped_macros, variation_count, selected_variation_index
    
    def _send_rack_snapshot_state(self, all_devices=None):
        if all_devices is None:
            selected_track = self.song().view.selected_track
            if not selected_track or not hasattr(selected_track, 'devices'):
                self._send_sys_ex_message("", 0x30)
                return
            all_devices = self._get_all_nested_devices(selected_track.devices)[0]
        
        entries = []
        for index, device in enumerate(all_devices):
            info = self._rack_snapshot_info_for_device(device)
            if info is None:
                continue
            has_mapped_macros, variation_count, selected_variation_index = info
            entries.append("{}|{}|{}|{}".format(
                index + 1,
                1 if has_mapped_macros else 0,
                variation_count,
                selected_variation_index
            ))
        
        self._send_sys_ex_message(",".join(entries), 0x30)
    
    def _get_selected_drum_pad(self, drum_rack):
        """
        Get the currently selected drum pad from a drum rack device.
        Returns the selected drum pad or None if none is selected.
        """
        if hasattr(drum_rack, 'view') and hasattr(drum_rack.view, 'selected_drum_pad'):
            return drum_rack.view.selected_drum_pad
        
        # Alternative: if the view approach doesn't work, we could try to find the 
        # currently playing pad or default to the first pad with a chain
        for pad in drum_rack.drum_pads:
            if liveobj_valid(pad) and hasattr(pad, 'chains') and pad.chains:
                return pad
                
        return None
    
    def _send_selected_drum_pad_number(self):
        """
        Gets the currently selected drum pad number and sends it as a MIDI note on message
        on channel 3, note number 3, with the pad number encoded in the velocity.
        """
        try:
            if self._drum_rack_device:
                selected_pad = self._drum_rack_device.view.selected_drum_pad
                if selected_pad:
                    pad_number = selected_pad.note
                    now = time.time()
                    if self._last_drum_pad_note == pad_number and (now - self._last_drum_pad_change_at) < 0.05:
                        return
                    self._last_drum_pad_note = pad_number
                    self._last_drum_pad_change_at = now
                    
                    channel = 3
                    midi_note_number = 3
                    self.send_note_on(midi_note_number, channel, pad_number)
                    
                    if hasattr(self, '_metadata_recheck_timer') and self._metadata_recheck_timer:
                        self._metadata_recheck_timer.cancel()
                    
                    self._drum_pad_change_recheck_count = 0
                    self._last_drum_pad_metadata = None
                    self._last_sent_metadata = None
                    self._drum_pad_recheck_start = time.time()
                    
                    # Only auto-follow pad if we're already on a pad device
                    self._select_device_in_selected_drum_pad()
                    
                    # Kick off a metadata recheck loop to wait for full pad loading
                    self._debug_log("Drum pad change: starting metadata recheck loop")
                    self._metadata_recheck_timer = self._schedule_main_thread(
                        0.1, self._recheck_parameter_metadata
                    )
            else:
                self._debug_log("No drum pad selected")
            
        except Exception as e:
            self._debug_log(f"Error sending drum pad number: {str(e)}")
    
    def _find_mapped_device(self):
        """
        Finds the device that controls are currently mapped to by checking
        the device that owns the mapped parameters.
        """
        if not hasattr(self, '_device_controls'):
            return None
        
        for control in self._device_controls:
            if control and control.mapped_parameter():
                mapped_param = control.mapped_parameter()
                if hasattr(mapped_param, 'canonical_parent'):
                    device = mapped_param.canonical_parent
                    if hasattr(device, 'canonical_parent') and hasattr(device.canonical_parent, 'canonical_parent'):
                        return device
        return None

    def _select_device_in_selected_drum_pad(self):
        if not self._drum_rack_device:
            return
        
        selected_track = self.song().view.selected_track
        current_device = selected_track.view.selected_device
        if not current_device or not self._is_device_in_any_drum_pad(current_device):
            return
        
        selected_drum_pad = self._get_selected_drum_pad(self._drum_rack_device)
        if not selected_drum_pad or not selected_drum_pad.chains:
            return
        
        target_device = None
        mapped_device = self._find_mapped_device()
        if mapped_device and self._is_device_in_drum_pad(mapped_device):
            target_device = mapped_device
        else:
            def _first_device_in_chain(chain):
                if not liveobj_valid(chain) or not hasattr(chain, 'devices'):
                    return None
                for chain_device in chain.devices:
                    if liveobj_valid(chain_device):
                        if hasattr(chain_device, 'parameters') and chain_device.parameters:
                            return chain_device
                        if hasattr(chain_device, 'chains') and chain_device.chains:
                            for inner_chain in chain_device.chains:
                                nested = _first_device_in_chain(inner_chain)
                                if nested:
                                    return nested
                        return chain_device
                return None
            
            for chain in selected_drum_pad.chains:
                target_device = _first_device_in_chain(chain)
                if target_device:
                    break
        
        if target_device and liveobj_valid(target_device):
            try:
                if hasattr(self.song().view, 'select_device'):
                    self.song().view.select_device(target_device)
                elif hasattr(self._device, 'set_device'):
                    self._device.set_device(target_device)
                else:
                    selected_track.view.selected_device = target_device
            except Exception as e:
                self._debug_log(f"Error selecting drum pad device: {str(e)}")

    def _is_device_in_any_drum_pad(self, device):
        if not self._drum_rack_device or not device:
            return False
        
        def _device_in_chain(chain):
            if not liveobj_valid(chain) or not hasattr(chain, 'devices'):
                return False
            for chain_device in chain.devices:
                if chain_device == device:
                    return True
                if hasattr(chain_device, 'chains') and chain_device.chains:
                    for inner_chain in chain_device.chains:
                        if _device_in_chain(inner_chain):
                            return True
            return False
        
        for pad in self._drum_rack_device.drum_pads:
            if liveobj_valid(pad) and hasattr(pad, 'chains') and pad.chains:
                for chain in pad.chains:
                    if _device_in_chain(chain):
                        return True
        
        return False

    def _is_device_in_rack_chain(self, device, track_devices):
        if not device or not track_devices:
            return False
        
        parent_chain, _ = self._find_parent_chain(track_devices, device)
        return parent_chain is not None
    
    def _is_device_in_drum_pad(self, device):
        """
        Checks if a device is inside a drum pad of the current drum rack.
        """
        if not self._drum_rack_device or not device:
            return False
        
        selected_drum_pad = self._get_selected_drum_pad(self._drum_rack_device)
        if not selected_drum_pad or not selected_drum_pad.chains:
            return False
        
        def _device_in_chain(chain):
            if not liveobj_valid(chain) or not hasattr(chain, 'devices'):
                return False
            for chain_device in chain.devices:
                if chain_device == device:
                    return True
                if hasattr(chain_device, 'chains') and chain_device.chains:
                    for inner_chain in chain_device.chains:
                        if _device_in_chain(inner_chain):
                            return True
            return False
        
        for chain in selected_drum_pad.chains:
            if _device_in_chain(chain):
                return True
        
        return False

    def _send_parameter_info(self, parameter_names):
        if parameter_names == "":
            self._send_unmapped_parameter_metadata()
        else:
            selected_track = self.song().view.selected_track
            selected_device = selected_track.view.selected_device
            
            current_metadata = self._build_parameter_metadata(selected_device)
            
            if current_metadata:
                if self._metadata_is_all_unmapped(current_metadata) and hasattr(selected_device, 'parameters') and selected_device.parameters:
                    self._debug_log("Parameter metadata is all unmapped; sending placeholder and scheduling recheck")
                    self._send_unmapped_parameter_metadata_for_device(selected_device, current_metadata)
                    self._schedule_parameter_metadata_recheck(delay=0.05)
                    return False

                cached_metadata = self._get_cached_metadata(selected_device)
                metadata_changed = cached_metadata != current_metadata
                if metadata_changed:
                    self._send_sys_ex_message(current_metadata, 0x7D)
                    self._set_cached_metadata(selected_device, current_metadata)
                    self._mark_metadata_sent(selected_device)
                
                if metadata_changed:
                    unmapped_encoder_indices = []
                    for control_index in range(8):
                        mapped_param = self._current_connected_parameter_for_control(control_index, selected_device)
                        if not mapped_param:
                            unmapped_encoder_indices.append(control_index)
                    
                    for control_index in unmapped_encoder_indices:
                        cc_number = 72 + control_index
                        self.send_cc(cc_number, 8, 0)
                
                is_rack_device = isinstance(selected_device, Live.RackDevice.RackDevice)
                is_drum_rack = self._drum_rack_device and selected_device == self._drum_rack_device
                is_drum_pad_device = self._drum_rack_device and self._is_device_in_drum_pad(selected_device)
                is_rack_related = is_rack_device or self._is_device_in_rack_chain(selected_device, selected_track.devices)
                
                should_iterate = False
                if is_drum_rack or is_drum_pad_device:
                    should_iterate = self._metadata_has_unmapped(current_metadata)
                elif is_rack_related:
                    should_iterate = self._metadata_needs_rack_recheck(current_metadata)
                
                if should_iterate:
                    if is_drum_pad_device:
                        self._last_drum_pad_metadata = current_metadata
                    else:
                        self._last_sent_metadata = current_metadata
                    
                    if is_drum_rack or is_drum_pad_device:
                        self._drum_pad_change_recheck_count = 0
                        self._drum_pad_recheck_start = time.time()
                    else:
                        self._device_recheck_count = 0
                        self._device_recheck_start = time.time()
                    
                    self._schedule_parameter_metadata_recheck()
                else:
                    self._last_sent_metadata = None
                    self._last_drum_pad_metadata = None
                    self._drum_pad_change_recheck_count = 0

                self._refresh_parameter_value_listeners_current_bank(send_current_values=True)
                self._refresh_parameter_name_listeners_current_bank()
                self._refresh_automation_state_listeners_current_bank()
                return True
        return False

    def _send_sys_ex_message(self, name_string, manufacturer_id):
        status_byte = 0xF0  # SysEx message start
        end_byte = 0xF7  # SysEx message end
        device_id = 0x01
        name_string = self._sanitize_sysex_text(name_string)
        data = name_string.encode('ascii', errors='ignore')
        max_chunk_length = 240
        if len(data) <= max_chunk_length:
            sys_ex_message = (status_byte, manufacturer_id, device_id) + tuple(data) + (end_byte, )
            self._send_midi(sys_ex_message)
        else:
            num_of_chunks = (len(data) + max_chunk_length - 1) // max_chunk_length
            for chunk_index in range(num_of_chunks):
                start_index = chunk_index * max_chunk_length
                end_index = start_index + max_chunk_length
                prefix = "$"
                if chunk_index == num_of_chunks - 1:
                    prefix = "_"
                chunk_data = prefix.encode('ascii') + data[start_index:end_index]

                sys_ex_message = (status_byte, manufacturer_id, device_id) + tuple(chunk_data) + (end_byte, )
                self._send_midi(sys_ex_message)

    def _initialize_buttons(self):
        transport.set_metronome_button(ButtonElement(1, MIDI_CC_TYPE, 0, 58))
        session_component.set_stop_all_clips_button(ButtonElement(1, MIDI_NOTE_TYPE, 15, 96))
        self.capture_button = ButtonElement(True, MIDI_NOTE_TYPE, 15, 100)
        self.capture_button.add_value_listener(self._capture_button_value)
        self.quantize_button = ButtonElement(True, MIDI_NOTE_TYPE, 15, 99)
        self.quantize_button.add_value_listener(self._quantize_button_value)
        # duplicate the active clip to a free slot
        self.duplicate_button = ButtonElement(True, MIDI_NOTE_TYPE, 15, 98)
        self.duplicate_button.add_value_listener(self._duplicate_button_value)
        # duplicate scene
        self.duplicate_scene_button = ButtonElement(True, MIDI_NOTE_TYPE, 15, 95)
        self.duplicate_scene_button.add_value_listener(self._duplicate_scene_button_value)
        # a session recording button
        self.sesh_record_button = ButtonElement(1, MIDI_CC_TYPE, 0, 119)
        self.sesh_record_button.add_value_listener(self._sesh_record_value)
        # quantize grid size button
        quantize_grid_button = ButtonElement(1, MIDI_CC_TYPE, 1, 0)
        quantize_grid_button.add_value_listener(self._quantize_grid_value)
        # quantize strength
        quantize_strength_button = ButtonElement(1, MIDI_CC_TYPE, 1, 1)
        quantize_strength_button.add_value_listener(self._quantize_strength_value)
        # swing percentage button
        swing_amount_button = ButtonElement(1, MIDI_CC_TYPE, 1, 2)
        swing_amount_button.add_value_listener(self._swing_amount_value)
        # # periodic check
        # periodic_check_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 97)
        # periodic_check_button.add_value_listener(self._periodic_check)
        # redo button
        self.redo_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 102)
        self.redo_button.add_value_listener(self._redo_button_value)
        # undo button
        self.undo_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 101)
        self.undo_button.add_value_listener(self._undo_button_value)
        # device selection
        device_selection_button = ButtonElement(1, MIDI_CC_TYPE, 1, 3)
        device_selection_button.add_value_listener(self._select_device_by_index)
        # track selection
        track_selection_button = ButtonElement(1, MIDI_CC_TYPE, 1, 4)
        track_selection_button.add_value_listener(self._select_track_by_index)
        # return and master track selection
        return_track_selection_button = ButtonElement(1, MIDI_CC_TYPE, 1, 5)
        return_track_selection_button.add_value_listener(self._select_return_track_by_index)
        # scene launch
        scene_launch_button = ButtonElement(1, MIDI_CC_TYPE, 1, 14)
        scene_launch_button.add_value_listener(self._fire_scene)
        # clip / scene select
        clip_scene_select_button = ButtonElement(1, MIDI_CC_TYPE, 1, 15)
        clip_scene_select_button.add_value_listener(self._select_clip_scene)
        # scene delete
        scene_delete_button = ButtonElement(1, MIDI_CC_TYPE, 1, 16)
        scene_delete_button.add_value_listener(self._delete_scene)
        # random device add button
        random_device_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 93)
        random_device_button.add_value_listener(self._add_random_sound)
        # random audio effect button
        random_effect_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 92)
        random_effect_button.add_value_listener(self._add_random_effect)
        # random synth button
        random_synth_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 103)
        random_synth_button.add_value_listener(self._add_random_synth)
        # random drums button
        random_drums_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 104)
        random_drums_button.add_value_listener(self._add_random_drums)
        # delete device button
        delete_device_button = ButtonElement(1, MIDI_CC_TYPE, 1, 17)
        delete_device_button.add_value_listener(self._delete_device)
        # select drum pad button
        select_drum_pad_button = ButtonElement(1, MIDI_CC_TYPE, 1, 24)
        select_drum_pad_button.add_value_listener(self._select_drum_pad)
        # move device left
        move_device_left_button = ButtonElement(1, MIDI_CC_TYPE, 1, 18)
        move_device_left_button.add_value_listener(self._move_device_left)
        # move device right
        move_device_right_button = ButtonElement(1, MIDI_CC_TYPE, 1, 19)
        move_device_right_button.add_value_listener(self._move_device_right)
        # add midi track
        add_midi_track_button = ButtonElement(1, MIDI_CC_TYPE, 1, 21)
        add_midi_track_button.add_value_listener(self._add_midi_track)
        # delete midi track
        delete_midi_track_button = ButtonElement(1, MIDI_CC_TYPE, 1, 22)
        delete_midi_track_button.add_value_listener(self._delete_midi_track)
        # add return track
        add_return_track_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 91)
        add_return_track_button.add_value_listener(self._add_return_track)
        # delete return track
        delete_return_track_button = ButtonElement(1, MIDI_CC_TYPE, 1, 23)
        delete_return_track_button.add_value_listener(self._delete_return_track)
        # mixer view status
        mixer_view_status = ButtonElement(1, MIDI_NOTE_TYPE, 15, 90)
        mixer_view_status.add_value_listener(self._update_mixer_status)
        # device view status
        device_view_status = ButtonElement(1, MIDI_NOTE_TYPE, 15, 89)
        device_view_status.add_value_listener(self._update_device_status)
        # step seq status
        step_seq_status = ButtonElement(1, MIDI_NOTE_TYPE, 15, 87)
        step_seq_status.add_value_listener(self._update_step_seq)
        # adding empty clip
        add_empty_clip_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 86)
        add_empty_clip_button.add_value_listener(self._add_empty_clip)
        # creating new empty clip
        create_empty_clip_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 85)
        create_empty_clip_button.add_value_listener(self._create_new_empty_clip)
        # selecting playing clip
        select_playing_clip_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 84)
        select_playing_clip_button.add_value_listener(self._select_playing_clip)
        # cropping selected clip
        crop_clip_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 83)
        crop_clip_button.add_value_listener(self._crop_clip)
        # browser start button (CC channel 1, CC 25)
        self.browser_start_button = ButtonElement(1, MIDI_CC_TYPE, 1, 25)
        self.browser_start_button.add_value_listener(self._start_browser)
        # browser pagination button (MIDI note channel 15, note 82)
        self.browser_navigate_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 82)
        self.browser_navigate_button.add_value_listener(self._browser_navigate)
        # browser select item button (MIDI note channel 15, note 81)
        self.browser_open_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 81)
        self.browser_open_button.add_value_listener(self._browser_open_item)
        # browser load item button (MIDI note channel 15, note 80) - always loads, never opens children
        self.browser_load_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 80)
        self.browser_load_button.add_value_listener(self._browser_load_item)
        # browser go back button (MIDI note channel 15, note 79) - go one level back, remembers page
        self.browser_back_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 79)
        self.browser_back_button.add_value_listener(self._browser_go_back)
        self.re_enable_automation_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 78)
        self.re_enable_automation_button.add_value_listener(self._re_enable_automation)
        self.remove_automation_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 77)
        self.remove_automation_button.add_value_listener(self._arm_remove_automation_from_next_encoder)
        self.re_enable_parameter_automation_button = ButtonElement(1, MIDI_NOTE_TYPE, 15, 76)
        self.re_enable_parameter_automation_button.add_value_listener(self._arm_re_enable_automation_from_next_encoder)
        # direct bank selection (CC channel 11, CC 64) - value = 64 + offset
        bank_select_button = ButtonElement(1, MIDI_CC_TYPE, 11, 64)
        bank_select_button.add_value_listener(self._bank_select)


    def send_note_on(self, note_number, channel, velocity):
        channel_byte = channel & 0x7F
        note_byte = note_number & 0x7F
        velocity_byte = velocity & 0x7F
        midi_note_on_message = (0x90 | channel_byte, note_byte, velocity_byte)
        self._send_midi(midi_note_on_message)

    def send_note_off(self, note_number, channel, velocity):
        channel_byte = channel & 0x7F
        note_byte = note_number & 0x7F
        velocity_byte = velocity & 0x7F
        midi_note_off_message = (0x80 | channel_byte, note_byte, velocity_byte)
        self._send_midi(midi_note_off_message)

    def send_cc(self, cc_number, channel, value):
        channel_byte = channel & 0x7F
        cc_byte = cc_number & 0x7F
        value_byte = int(round(value)) & 0x7F
        midi_cc_message = (0xB0 | channel_byte, cc_byte, value_byte)
        self._send_midi(midi_cc_message)

    def _parameter_value_to_cc(self, device_param):
        if not hasattr(device_param, 'value') or not hasattr(device_param, 'min') or not hasattr(device_param, 'max'):
            return 0
        
        value = device_param.value
        min_val = device_param.min
        max_val = device_param.max
        
        if max_val == min_val:
            return 0
        
        normalized = (value - min_val) / (max_val - min_val)
        cc_value = int(round(normalized * 127))
        return max(0, min(127, cc_value))

    def _create_disabled_param_listener(self, device_param, control_index):
        def listener():
            self._send_parameter_feedback(control_index, device_param, force_display=True)
        return listener

    def _create_parameter_value_listener(self, device_param, control_index):
        def listener():
            self._send_parameter_feedback(control_index, device_param, throttle_display=True)
            if (
                    self._drumcell_dynamic_parameter(device_param) or
                    self._grain_delay_dynamic_parameter(device_param)):
                self._schedule_active_bank_parameter_refresh()
        return listener

    def _create_parameter_name_listener(self, device_param, control_index):
        def listener():
            if not self._is_current_parameter_for_control(control_index, device_param):
                return
            self._schedule_active_bank_parameter_refresh()
        return listener

    def _create_parameter_source_listener(self):
        def listener():
            self._schedule_active_bank_parameter_refresh()
        return listener

    def _create_bank_parameter_source_listener(self):
        def listener():
            self._schedule_active_bank_parameter_refresh()
        return listener

    def _schedule_active_bank_parameter_refresh(self):
        if not liveobj_valid(self._device):
            return
        if self._active_bank_parameter_refresh_pending:
            return
        self._active_bank_parameter_refresh_pending = True
        self.schedule_message(1, self._refresh_active_bank_parameters)

    def _refresh_active_bank_parameters(self):
        self._parameter_name_update_timer = None
        self._active_bank_parameter_refresh_pending = False
        if not liveobj_valid(self._device):
            return

        try:
            self._device.invalidate_parameter_bank_cache()
            if hasattr(self._device, 'update'):
                self._device.update()
            self._connect_device_controls()
            try:
                self.request_rebuild_midi_map()
            except Exception:
                pass
            self._force_send_current_bank_metadata()
        except Exception as e:
            self._debug_log("Error refreshing active bank after parameter metadata change: {}".format(str(e)))

    def _remove_parameter_value_listeners(self):
        for (param, control_index), listener in list(getattr(self, '_parameter_value_listeners', {}).items()):
            if liveobj_valid(param) and hasattr(param, 'remove_value_listener'):
                try:
                    if param.value_has_listener(listener):
                        param.remove_value_listener(listener)
                except Exception:
                    pass
        self._parameter_value_listeners.clear()
        self._last_sent_parameter_displays.clear()
        self._last_sent_parameter_normalized_values.clear()
        self._last_sent_parameter_cc_values.clear()
        self._last_parameter_display_feedback_times.clear()

    def _remove_parameter_name_listeners(self):
        if self._parameter_name_update_timer:
            self._parameter_name_update_timer.cancel()
            self._parameter_name_update_timer = None

        for (param, control_index), listener in list(getattr(self, '_parameter_name_listeners', {}).items()):
            if liveobj_valid(param) and hasattr(param, 'remove_name_listener'):
                try:
                    if not hasattr(param, 'name_has_listener') or param.name_has_listener(listener):
                        param.remove_name_listener(listener)
                except Exception:
                    pass
        self._parameter_name_listeners.clear()

    def _remove_parameter_source_listener(self):
        device = getattr(self, '_parameter_source_device', None)
        listener = getattr(self, '_parameter_source_listener', None)
        if device and listener and liveobj_valid(device) and hasattr(device, 'remove_parameters_listener'):
            try:
                if not hasattr(device, 'parameters_has_listener') or device.parameters_has_listener(listener):
                    device.remove_parameters_listener(listener)
            except Exception:
                pass
        self._parameter_source_device = None
        self._parameter_source_listener = None

        bank_device = getattr(self, '_bank_parameter_source_device', None)
        bank_listener = getattr(self, '_bank_parameter_source_listener', None)
        if bank_device and bank_listener and liveobj_valid(bank_device) and hasattr(bank_device, 'remove_bank_parameters_changed_listener'):
            try:
                if not hasattr(bank_device, 'bank_parameters_changed_has_listener') or bank_device.bank_parameters_changed_has_listener(bank_listener):
                    bank_device.remove_bank_parameters_changed_listener(bank_listener)
            except Exception:
                pass
        self._bank_parameter_source_device = None
        self._bank_parameter_source_listener = None

    def _set_parameter_source_listener(self, selected_device):
        if selected_device == getattr(self, '_parameter_source_device', None):
            return

        self._remove_parameter_source_listener()
        if not selected_device or not liveobj_valid(selected_device):
            return

        if hasattr(selected_device, 'add_parameters_listener'):
            listener = self._create_parameter_source_listener()
            self._parameter_source_device = selected_device
            self._parameter_source_listener = listener
            try:
                if not hasattr(selected_device, 'parameters_has_listener') or not selected_device.parameters_has_listener(listener):
                    selected_device.add_parameters_listener(listener)
            except Exception:
                self._parameter_source_device = None
                self._parameter_source_listener = None

        if hasattr(selected_device, 'add_bank_parameters_changed_listener'):
            bank_listener = self._create_bank_parameter_source_listener()
            self._bank_parameter_source_device = selected_device
            self._bank_parameter_source_listener = bank_listener
            try:
                if not hasattr(selected_device, 'bank_parameters_changed_has_listener') or not selected_device.bank_parameters_changed_has_listener(bank_listener):
                    selected_device.add_bank_parameters_changed_listener(bank_listener)
            except Exception:
                self._bank_parameter_source_device = None
                self._bank_parameter_source_listener = None

    def _refresh_parameter_value_listeners_current_bank(self, send_current_values=False):
        self._remove_parameter_value_listeners()
        if not hasattr(self, '_device') or not liveobj_valid(self._device):
            return
        if not hasattr(self._device, '_parameter_controls'):
            return

        selected_device = self._selected_device()
        for control_index, control in enumerate(self._device._parameter_controls):
            mapped_param = self._current_connected_parameter_for_control(control_index, selected_device)
            if mapped_param and liveobj_valid(mapped_param) and hasattr(mapped_param, 'add_value_listener'):
                listener = self._create_parameter_value_listener(mapped_param, control_index)
                self._parameter_value_listeners[(mapped_param, control_index)] = listener
                try:
                    if not mapped_param.value_has_listener(listener):
                        mapped_param.add_value_listener(listener)
                except Exception:
                    pass
                self._last_sent_parameter_cc_values[control_index] = self._parameter_value_to_cc(mapped_param)
                self._last_sent_parameter_displays[control_index] = self._parameter_display_value(mapped_param)
                self._last_sent_parameter_normalized_values[control_index] = round(self._parameter_normalized_value(mapped_param), 9)
                if send_current_values:
                    self._send_parameter_feedback(control_index, mapped_param, force_display=True)

    def _refresh_parameter_name_listeners_current_bank(self):
        self._remove_parameter_name_listeners()
        if not hasattr(self, '_device') or not liveobj_valid(self._device):
            return
        if not hasattr(self._device, '_parameter_controls'):
            return

        selected_device = self._selected_device()
        for control_index, control in enumerate(self._device._parameter_controls):
            mapped_param = self._current_connected_parameter_for_control(control_index, selected_device)
            if mapped_param and liveobj_valid(mapped_param) and hasattr(mapped_param, 'add_name_listener'):
                listener = self._create_parameter_name_listener(mapped_param, control_index)
                self._parameter_name_listeners[(mapped_param, control_index)] = listener
                try:
                    if not hasattr(mapped_param, 'name_has_listener') or not mapped_param.name_has_listener(listener):
                        mapped_param.add_name_listener(listener)
                except Exception:
                    pass

    def _create_automation_state_listener(self, device_param):
        def listener():
            self._refresh_parameter_metadata_on_automation_change()
        return listener

    def _refresh_automation_state_listeners_current_bank(self):
        self._remove_automation_state_listeners()
        if not hasattr(self, '_device') or not liveobj_valid(self._device):
            return
        if self._simpler_main_active():
            for control_index in range(8):
                spec = self._simpler_virtual_spec(control_index)
                device_param = spec.get('parameter') if spec and spec.get('kind') == 'parameter' else None
                if device_param and liveobj_valid(device_param) and device_param not in self._automation_state_listeners:
                    listener = self._create_automation_state_listener(device_param)
                    try:
                        add_listener = getattr(device_param, 'add_automation_state_listener', None)
                        has_listener = getattr(device_param, 'automation_state_has_listener', None)
                        if add_listener and (not has_listener or not has_listener(listener)):
                            add_listener(listener)
                            self._automation_state_listeners[device_param] = listener
                    except Exception:
                        pass
            return
        selected_device = self._selected_device()
        for control_index, control in enumerate(self._device._parameter_controls):
            device_param = self._current_connected_parameter_for_control(control_index, selected_device)
            if device_param and liveobj_valid(device_param):
                listener = self._create_automation_state_listener(device_param)
                if device_param not in self._automation_state_listeners:
                    try:
                        add_listener = getattr(device_param, 'add_automation_state_listener', None)
                        has_listener = getattr(device_param, 'automation_state_has_listener', None)
                        if add_listener and (not has_listener or not has_listener(listener)):
                            add_listener(listener)
                            self._automation_state_listeners[device_param] = listener
                    except Exception:
                        pass

    def _get_automation_signature(self):
        if not hasattr(self, '_device') or not liveobj_valid(self._device):
            return None
        signature = []
        if self._simpler_main_active():
            for control_index in range(8):
                spec = self._simpler_virtual_spec(control_index)
                parameter = spec.get('parameter') if spec and spec.get('kind') == 'parameter' else None
                signature.append(parameter.automation_state if parameter and hasattr(parameter, 'automation_state') else None)
            return tuple(signature)
        selected_device = self._selected_device()
        for control_index, control in enumerate(self._device._parameter_controls):
            mapped_param = self._current_connected_parameter_for_control(control_index, selected_device)
            if mapped_param and hasattr(mapped_param, 'automation_state'):
                signature.append(mapped_param.automation_state)
            else:
                signature.append(None)
        return tuple(signature)

    def _refresh_parameter_metadata_on_automation_change(self):
        if not liveobj_valid(self._device):
            return
        
        selected_track = self.song().view.selected_track
        if self._track_device_is_selected():
            self._send_track_device_parameter_metadata(selected_track)
            self._last_automation_signature = self._get_automation_signature()
            self._send_re_enable_automation_enabled(force=True)
            return

        selected_device = selected_track.view.selected_device
        
        if not selected_device or not hasattr(selected_device, 'parameters'):
            return

        current_signature = self._get_automation_signature()
        if current_signature is not None and current_signature == self._last_automation_signature:
            return
        
        # Update signature immediately so the same change doesn't re-trigger
        # while the timer is pending
        self._last_automation_signature = current_signature
        
        with self._automation_timer_lock:
            if self._automation_metadata_update_timer:
                self._automation_metadata_update_timer.cancel()
        
        self._automation_metadata_device_id = id(selected_device)
        self._automation_metadata_retry_count = 0
        self._automation_metadata_retry_start = time.time()
        seq_at_schedule = self._metadata_send_seq_by_device.get(id(selected_device), 0)
        new_timer = self._schedule_main_thread(
            0.05,
            self._send_refreshed_parameter_metadata,
            args=(selected_device, seq_at_schedule)
        )
        with self._automation_timer_lock:
            self._automation_metadata_update_timer = new_timer

    def _send_refreshed_parameter_metadata(self, selected_device, seq_at_schedule=0):
        with self._automation_timer_lock:
            self._automation_metadata_update_timer = None
        if not selected_device or not liveobj_valid(selected_device):
            return
        if self._metadata_send_seq_by_device.get(id(selected_device), 0) != seq_at_schedule:
            return
        current_selected = self.song().view.selected_track.view.selected_device
        if current_selected != selected_device or id(selected_device) != self._automation_metadata_device_id:
            return
        current_metadata = self._build_parameter_metadata(selected_device)
        if current_metadata:
            if self._metadata_is_all_unmapped(current_metadata) and hasattr(selected_device, 'parameters') and selected_device.parameters:
                elapsed = 0.0
                if self._automation_metadata_retry_start is not None:
                    elapsed = time.time() - self._automation_metadata_retry_start
                cached_metadata = self._get_cached_metadata(selected_device)
                if cached_metadata != current_metadata:
                    self._send_unmapped_parameter_metadata_for_device(selected_device, current_metadata)
                    seq_at_schedule = self._metadata_send_seq_by_device.get(id(selected_device), seq_at_schedule)
                if self._automation_metadata_retry_count < 3 and elapsed < 0.3:
                    self._automation_metadata_retry_count += 1
                    new_timer = self._schedule_main_thread(
                        0.05,
                        self._send_refreshed_parameter_metadata,
                        args=(selected_device, seq_at_schedule)
                    )
                    with self._automation_timer_lock:
                        self._automation_metadata_update_timer = new_timer
                return

            cached_metadata = self._get_cached_metadata(selected_device)
            metadata_changed = cached_metadata != current_metadata
            if metadata_changed:
                self._send_sys_ex_message(current_metadata, 0x7D)
                self._schedule_parameter_metadata_resend(selected_device, current_metadata, seq_at_schedule)
                self._set_cached_metadata(selected_device, current_metadata)
                self._mark_metadata_sent(selected_device)
                self._last_automation_signature = self._get_automation_signature()
                self._refresh_parameter_value_listeners_current_bank(send_current_values=True)
                self._refresh_parameter_name_listeners_current_bank()
                self._refresh_automation_state_listeners_current_bank()
            
            if metadata_changed and hasattr(selected_device, 'parameters') and selected_device.parameters:
                for control_index in range(8):
                    mapped_param = self._current_connected_parameter_for_control(control_index, selected_device)
                    if mapped_param:
                        self._send_parameter_feedback(control_index, mapped_param, force_display=True)
            
            if not metadata_changed:
                elapsed = 0.0
                if self._automation_metadata_retry_start is not None:
                    elapsed = time.time() - self._automation_metadata_retry_start
                if self._automation_metadata_retry_count < 3 and elapsed < 0.3:
                    self._automation_metadata_retry_count += 1
                    new_timer = self._schedule_main_thread(
                        0.05,
                        self._send_refreshed_parameter_metadata,
                        args=(selected_device, seq_at_schedule)
                    )
                    with self._automation_timer_lock:
                        self._automation_metadata_update_timer = new_timer
                else:
                    self._automation_metadata_retry_count = 0
                    self._automation_metadata_retry_start = None
                    self._last_automation_signature = self._get_automation_signature()
            else:
                self._automation_metadata_retry_count = 0
                self._automation_metadata_retry_start = None

    def _schedule_parameter_metadata_resend(self, selected_device, metadata, seq_at_schedule):
        self._schedule_main_thread(
            0.1,
            self._resend_parameter_metadata_if_current,
            args=(selected_device, metadata, seq_at_schedule)
        )

    def _resend_parameter_metadata_if_current(self, selected_device, metadata, seq_at_schedule):
        try:
            if not selected_device or not liveobj_valid(selected_device):
                return
            if self._metadata_send_seq_by_device.get(id(selected_device), 0) != seq_at_schedule:
                return
            current_selected = self.song().view.selected_track.view.selected_device
            if current_selected == selected_device:
                self._send_sys_ex_message(metadata, 0x7D)
        except Exception:
            pass

    def _remove_disabled_parameter_listeners(self):
        for (param, control_index), listener in self._disabled_parameter_listeners.items():
            if liveobj_valid(param) and hasattr(param, 'remove_value_listener'):
                if param.value_has_listener(listener):
                    param.remove_value_listener(listener)
        self._disabled_parameter_listeners.clear()
        self._disabled_parameters.clear()
        self._current_disabled_controls.clear()

    def _remove_automation_state_listeners(self):
        for param, listener in self._automation_state_listeners.items():
            if liveobj_valid(param) and hasattr(param, 'remove_automation_state_listener'):
                if hasattr(param, 'automation_state_has_listener') and param.automation_state_has_listener(listener):
                    param.remove_automation_state_listener(listener)
        self._automation_state_listeners.clear()
        self._automation_metadata_device_id = None
        self._automation_metadata_retry_count = 0
        self._automation_metadata_retry_start = None
        self._last_automation_signature = None
        
        if self._automation_metadata_update_timer:
            self._automation_metadata_update_timer.cancel()
            self._automation_metadata_update_timer = None

    def _readd_disabled_parameter_listeners(self):
        if not hasattr(self, '_device') or not liveobj_valid(self._device):
            return
        
        selected_device = self._selected_device()
        
        if hasattr(selected_device, 'parameters') and selected_device.parameters:
            for control_index, control in enumerate(self._device._parameter_controls):
                device_param = self._current_connected_parameter_for_control(control_index, selected_device)

                if device_param and not self._parameter_is_control_available(device_param):
                    if (device_param, control_index) not in self._disabled_parameter_listeners:
                        listener = self._create_disabled_param_listener(device_param, control_index)
                        if not device_param.value_has_listener(listener):
                            device_param.add_value_listener(listener)

                        self._disabled_parameter_listeners[(device_param, control_index)] = listener
                        self._disabled_parameters.append(device_param)
                        self._current_disabled_controls.append(control_index)

                        self._send_parameter_feedback(control_index, device_param, force_display=True)

    def _connection_established(self, value):
        if value:            
            # self.log_message("Connection App to Ableton (still) works!")
            # send midi note on channel 3, note number 1 to confirm handshake
            midi_event_bytes = (0x90 | 0x03, 0x01, secret_version_number)
            self._send_midi(midi_event_bytes)
            was_initialized = self.was_initialized
            
            # initializing everything else if this is not just the handshake
            if self.was_initialized is False:
                self.was_initialized = True
                self.old_clips_array = []
                self._follow_action_track_signature = self._track_signature(self.song().tracks)
                self._on_tracks_changed()
                song = self.song()
                self._initialize_buttons()
                self._update_mixer_and_tracks()
                self._set_selected_track_implicit_arm()
                selected_track = song.view.selected_track
                self._send_selected_track_index(selected_track)
                self._on_selected_track_changed.subject = song.view
                # updating scale
                self._on_scale_changed()
                # track = self.song().view.selected_track
                # track.view.add_selected_device_listener(self._on_selected_device_changed)
                # self.song().view.add_selected_scene_listener(self._on_selected_scene_changed)
                self._ensure_song_listeners(song)
                # updating tempo and metronome
                self._update_tempo()
                self._update_metronome()
                # rest
                self._setup_device_control()
                self._register_clip_listeners()
                self._send_current_project_state()
                self._start_periodic_execution()
            
            # hack to get new tracks if we have a new song.
            did_send_new_song = self._check_for_new_song()
            if was_initialized and not did_send_new_song:
                self._send_current_project_state()

    def _transport_toggle_value(self, value):
        if value:
            try:
                if self._song_is_playing():
                    self.song().stop_playing()
                else:
                    self.song().start_playing()
                self._send_transport_state(force=True)
            except Exception:
                pass

    def _send_project(self, value):
        if value:
            self._send_current_project_state()

    def _start_periodic_execution(self):
        self.periodic_timer = 1
        if self._periodic_timer_ref is None or not self._periodic_timer_ref.is_alive():
            self._periodic_execution()

    def update_display(self):
        ControlSurface.update_display(self)
        if not self.was_initialized or not self._clip_position_feedback_enabled:
            return

        now = time.monotonic()
        if now - self._last_clip_position_feedback_time < self.VISUAL_FEEDBACK_INTERVAL:
            return

        self._last_clip_position_feedback_time = now
        self._send_visual_feedback_frame()

    def _set_clip_position_feedback(self, values):
        enabled = bool(values and values[0])
        track_count = len(self.song().tracks)
        track_indexes = tuple(dict.fromkeys(
            int(index) for index in values[1:]
            if 0 <= int(index) < track_count
        )) if enabled else ()

        changed = (
            enabled != self._clip_position_feedback_enabled or
            track_indexes != self._clip_position_feedback_track_indexes
        )
        self._clip_position_feedback_enabled = enabled
        self._clip_position_feedback_track_indexes = track_indexes

        if changed or enabled:
            self._last_clip_position_feedback_time = 0.0
            self._last_visual_feedback_payload = None
        if not enabled and self.was_initialized:
            self._send_sys_ex_message("", 0x47)

    def _normalized_session_clip_position(self, clip):
        try:
            position = float(clip.playing_position)
            decoupled_info = self._decoupled_automation_info(clip)
            if decoupled_info:
                loop_length = max(0.0001, float(decoupled_info["note_length"]))
                loop_position = self._positive_mod(
                    position - float(decoupled_info["note_start"]),
                    loop_length
                )
                return max(0.0, min(1.0, loop_position / loop_length))

            if bool(clip.looping):
                start = float(clip.loop_start)
                end = float(clip.loop_end)
            else:
                start = float(clip.start_marker)
                end = float(clip.end_marker)
            length = end - start
            if length <= 0.0:
                return 0.0
            return max(0.0, min(1.0, (position - start) / length))
        except Exception:
            return 0.0

    def _normalized_session_clip_velocity(self, clip):
        try:
            decoupled_info = self._decoupled_automation_info(clip)
            if decoupled_info:
                length = max(0.0001, float(decoupled_info["note_length"]))
            elif bool(clip.looping):
                start = float(clip.loop_start)
                end = float(clip.loop_end)
                length = end - start
            else:
                start = float(clip.start_marker)
                end = float(clip.end_marker)
                length = end - start
            if length <= 0.0:
                return 0.0

            # Live reports MIDI and warped-audio positions in beats, while
            # unwarped audio positions use seconds.
            is_unwarped_audio = bool(clip.is_audio_clip) and not bool(clip.warping)
            units_per_second = 1.0 if is_unwarped_audio else float(self.song().tempo) / 60.0
            return max(0.0, units_per_second / length)
        except Exception:
            return 0.0

    def _visible_clip_position_bytes(self):
        records = []
        tracks = self.song().tracks

        for track_index in self._clip_position_feedback_track_indexes:
            try:
                track = tracks[track_index]
                scene_index = int(track.playing_slot_index)
                if scene_index < 0 or scene_index >= len(track.clip_slots):
                    continue
                clip_slot = track.clip_slots[scene_index]
                if not clip_slot.has_clip:
                    continue
                progress = self._normalized_session_clip_position(clip_slot.clip)
                raw_progress = int(round(progress * 16383.0))
                velocity = self._normalized_session_clip_velocity(clip_slot.clip)
                raw_velocity = max(0, min(2097151, int(round(velocity * 10000.0))))
                records.extend((
                    track_index,
                    0x01 if bool(clip_slot.clip.looping) else 0x00,
                    scene_index & 0x7F,
                    (scene_index >> 7) & 0x7F,
                    raw_progress & 0x7F,
                    (raw_progress >> 7) & 0x7F,
                    raw_velocity & 0x7F,
                    (raw_velocity >> 7) & 0x7F,
                    (raw_velocity >> 14) & 0x7F,
                ))
            except Exception:
                continue

        return records

    def _send_binary_sys_ex_message(self, values, manufacturer_id):
        values = tuple(int(value) for value in values)
        if any(value < 0 or value > 127 for value in values):
            return
        self._send_midi((0xF0, manufacturer_id, 0x01) + values + (0xF7,))

    def _send_visual_feedback_frame(self):
        clip_bytes = self._visible_clip_position_bytes() if self._clip_position_feedback_enabled else []
        clip_count = min(127, len(clip_bytes) // 9)
        flags = 0x01 if self._song_is_playing() else 0x00
        payload = tuple(
            [0x03, flags, clip_count] +
            clip_bytes[:clip_count * 9] +
            [0x00]  # meter count: meters stay on their native event-driven CC path
        )
        if payload == self._last_visual_feedback_payload:
            return
        self._last_visual_feedback_payload = payload
        self._send_binary_sys_ex_message(payload, 0x49)
    
    def _periodic_execution(self):
        self._periodic_check()
        if self.periodic_timer == 1:
            self._periodic_timer_ref = self._schedule_main_thread(
                0.3, self._periodic_execution
            )

    def _periodic_check(self):
        if self.was_initialized:
            self._check_for_new_song()
        else:
            self._check_for_follow_action_song_change()
        self._sync_follow_actions_to_track_topology()
        if self._has_follow_action_runtime_work():
            self._reconcile_follow_action_rules()
            self._sync_follow_action_runtime_listeners()
        self._sync_follow_actions_to_transport()
        self._evaluate_follow_actions()
        self._evaluate_mutator_regeneration()
        if not self.was_initialized:
            return
        self._send_track_simpler_slice_state()
        self._send_group_fold_states_if_changed()
        # update clip slots
        # we only need to update clip slots periodically when we are in clip slots view
        # meaning not in the device view
        now = time.monotonic()
        if self.device_status is False and now - self._last_clip_slot_integrity_check >= 1.0:
            self._last_clip_slot_integrity_check = now
            self._update_clip_slots()

    def _has_follow_action_runtime_work(self):
        return bool(
            self._follow_action_rules
            or self._active_follow_actions
            or self._handled_follow_action_launches
            or self._follow_action_missing_clip_counts
            or self._follow_action_scene_triggered_listeners
            or self._follow_action_clip_slot_runtime_listeners
        )

    def _ensure_song_listener(self, song, listener_name, listener):
        try:
            has_listener = getattr(song, "{}_has_listener".format(listener_name), None)
            add_listener = getattr(song, "add_{}_listener".format(listener_name), None)
            if add_listener and (not has_listener or not has_listener(listener)):
                add_listener(listener)
        except Exception:
            pass

    def _ensure_song_listeners(self, song):
        self._ensure_song_listener(song, "tracks", self._on_tracks_changed)
        self._ensure_song_listener(song, "scale_name", self._on_scale_changed)
        self._ensure_song_listener(song, "root_note", self._on_scale_changed)
        self._ensure_song_listener(song, "tempo", self._update_tempo)
        self._ensure_song_listener(song, "swing_amount", self._update_swing_amount)
        self._ensure_song_listener(song, "metronome", self._update_metronome)
        self._ensure_song_listener(song, "session_record", self._on_session_record_changed)
        try:
            if (not hasattr(song, "is_playing_has_listener")
                    or not song.is_playing_has_listener(self._on_song_is_playing_changed)):
                song.add_is_playing_listener(self._on_song_is_playing_changed)
        except Exception:
            pass
        self._ensure_song_listener(song, "re_enable_automation_enabled", self._on_re_enable_automation_enabled_changed)

    def _remove_song_listener(self, song, listener_name, listener):
        try:
            has_listener = getattr(song, "{}_has_listener".format(listener_name), None)
            remove_listener = getattr(song, "remove_{}_listener".format(listener_name), None)
            if remove_listener and (not has_listener or has_listener(listener)):
                remove_listener(listener)
        except Exception:
            pass

    def _ensure_follow_action_song_listeners(self, song):
        if self._follow_action_song_listener_subject is not None and self._follow_action_song_listener_subject != song:
            self._remove_follow_action_song_listeners()
        self._follow_action_song_listener_subject = song
        self._ensure_song_listener(song, "tracks", self._on_follow_action_topology_changed)
        self._ensure_song_listener(song, "scenes", self._on_follow_action_topology_changed)

    def _remove_follow_action_song_listeners(self):
        song = self._follow_action_song_listener_subject
        if song is None:
            return
        self._remove_song_listener(song, "tracks", self._on_follow_action_topology_changed)
        self._remove_song_listener(song, "scenes", self._on_follow_action_topology_changed)
        self._follow_action_song_listener_subject = None

    def _on_follow_action_topology_changed(self):
        self._mutator_clip_presence_dirty = True
        self._sync_follow_actions_to_track_topology()
        self._sync_follow_action_name_listeners()
        self._load_follow_actions_from_names()
        self._sync_follow_action_runtime_listeners()

    def _on_follow_action_name_changed(self):
        self._mutator_clip_presence_dirty = True
        self._load_follow_actions_from_names()
        self._sync_follow_action_runtime_listeners()
        self._evaluate_follow_actions()

    def _on_follow_action_timing_changed(self):
        self._evaluate_follow_actions()

    def _send_selected_track_state(self):
        try:
            selected_track = self.song().view.selected_track
            self._send_selected_track_index(selected_track)
            track_has_midi_input = 1 if selected_track and selected_track.has_midi_input else 0
            self._send_sys_ex_message(str(track_has_midi_input), 0x0B)
        except Exception:
            pass

    def _send_selected_device_state(self):
        try:
            selected_track = self.song().view.selected_track
            selected_device = selected_track.view.selected_device if selected_track else None
            if self._track_device_is_selected():
                self._last_automation_signature = None
                self._on_device_changed()
                return
            if hasattr(self, "_device") and hasattr(self._device, "set_device"):
                self._device.set_device(selected_device)
            if selected_device:
                self._clear_cached_metadata(selected_device)
            self._last_automation_signature = None
            self._on_device_changed()
        except Exception:
            pass

    def _send_current_project_state(self):
        self.old_clips_array = []
        self._send_transport_state(force=True)
        self._send_session_record_state(force=True)
        self._update_tempo()
        self._update_metronome()
        self._send_re_enable_automation_enabled()
        self._update_mixer_and_tracks()
        self._send_selected_track_state()
        # Send repeat feedback after the selected-track message so Tap cannot
        # clear the newly restored state while processing the track change.
        self._restore_note_repeat_for_selected_track(force_feedback=True)
        self._send_mpe_state()
        self._send_selected_device_state()
        self._load_follow_actions_from_names(force_send=True)
        self._update_clip_slots()
        self._check_clip_playing_status(force=True)

    def _send_mpe_state(self):
        # Tap uses MPE lower-zone member channels 2-15. Channel 1 remains the
        # manager channel and channel 16 remains reserved for Tap's control
        # surface buttons, preventing MPE notes from triggering commands.
        self._send_sys_ex_message(
            "1|{}|{}".format(
                self.MPE_MEMBER_CHANNEL_COUNT,
                self.MPE_PITCH_BEND_RANGE
            ),
            0x4E
        )

    def _re_enable_automation_value(self):
        try:
            song = self.song()
            if hasattr(song, "re_enable_automation_enabled"):
                return bool(song.re_enable_automation_enabled)
        except Exception:
            pass
        return False

    def _send_re_enable_automation_enabled(self, force=False):
        enabled = self._re_enable_automation_value()
        if not force and enabled == self._re_enable_automation_enabled_state:
            return
        self._re_enable_automation_enabled_state = enabled
        self._send_sys_ex_message("1" if enabled else "0", 0x29)
        if getattr(self, 'mixer_status', False):
            self._schedule_mixer_automation_status_resends()

    def _on_re_enable_automation_enabled_changed(self):
        self._send_re_enable_automation_enabled()

    def _check_for_new_song(self):
        if not self.was_initialized:
            return False
        current_song = self.song()
        if current_song == self.song_instance:
            return False

        try:
            if self._note_repeat is not None:
                self._note_repeat.enabled = False
        except Exception:
            pass
        self._note_repeat_last_record_quantization = None
        self._last_note_repeat_feedback = None
        self._remove_all_notes_playing_listeners()
        self.song_instance = current_song
        self._track_list_signature = None
        self._last_group_fold_states = None
        self._last_group_hidden_states = None
        self._follow_action_track_signature = self._track_signature(current_song.tracks)
        self._follow_action_rules = {}
        self._active_follow_actions = {}
        self._handled_follow_action_launches = set()
        self._follow_action_missing_clip_counts = {}
        self._last_follow_action_state = None
        self._has_mutator_clips = False
        self._mutator_clip_presence_dirty = True
        self._decoupled_automation_recording_active = False
        self._decoupled_automation_recording_snapshots = {}
        self._decoupled_automation_recording_generation += 1
        self._remove_follow_action_runtime_listeners()
        self._remove_follow_action_name_listeners()
        self._ensure_follow_action_song_listeners(current_song)
        self._ensure_song_listeners(current_song)
        self._on_selected_track_changed.subject = current_song.view
        self._update_tempo()
        self._on_scale_changed()
        self._register_clip_listeners()
        self._send_current_project_state()
        return True

    def _check_for_follow_action_song_change(self):
        current_song = self.song()
        if current_song == self.song_instance:
            return False

        self.song_instance = current_song
        self._follow_action_track_signature = self._track_signature(current_song.tracks)
        self._follow_action_rules = {}
        self._active_follow_actions = {}
        self._handled_follow_action_launches = set()
        self._follow_action_missing_clip_counts = {}
        self._last_follow_action_state = None
        self._has_mutator_clips = False
        self._mutator_clip_presence_dirty = True
        self._remove_follow_action_runtime_listeners()
        self._remove_follow_action_name_listeners()
        self._ensure_follow_action_song_listeners(current_song)
        self._sync_follow_action_name_listeners()
        self._load_follow_actions_from_names(force_send=True)
        self._sync_follow_action_runtime_listeners()
        return True

    def _follow_action_key(self, target_kind, track_index, scene_index):
        if target_kind == "clip":
            return ("clip", int(track_index), int(scene_index))
        return ("scene", int(scene_index))

    def _live_object_identity(self, live_object):
        try:
            live_ptr = live_object._live_ptr
            if callable(live_ptr):
                return int(live_ptr())
            return int(live_ptr)
        except Exception:
            return id(live_object)

    def _track_signature(self, tracks):
        return tuple(self._live_object_identity(track) for track in tracks)

    def _find_clip_follow_action_rule(self, track_index, scene_index):
        try:
            clip_slot = self.song().tracks[track_index].clip_slots[scene_index]
            if not clip_slot.has_clip:
                return None, None
            key = self._follow_action_key("clip", track_index, scene_index)
            return key, self._follow_action_rules.get(key)
        except Exception:
            return None, None

    def _copy_clip_follow_action_rule(self, from_track, from_clip, to_track, to_clip, remove_source=False):
        source_key, source_rule = self._find_clip_follow_action_rule(from_track, from_clip)
        if not source_rule:
            return

        try:
            dest_slot = self.song().tracks[to_track].clip_slots[to_clip]
            if not dest_slot.has_clip:
                return
        except Exception:
            return

        if remove_source and source_key in self._follow_action_rules:
            del self._follow_action_rules[source_key]
            self._remove_follow_action_rule_from_name("clip", from_track, from_clip)
            self._handled_follow_action_launches.discard(source_key)
            self._follow_action_missing_clip_counts.pop(source_key, None)

        new_rule = dict(source_rule)
        new_rule["track_index"] = to_track
        new_rule["scene_index"] = to_clip

        dest_key = self._follow_action_key("clip", to_track, to_clip)
        self._follow_action_rules[dest_key] = new_rule
        self._save_follow_action_rule_to_name(new_rule)

    def _remove_clip_follow_action_rule(self, track_index, scene_index):
        key, _ = self._find_clip_follow_action_rule(track_index, scene_index)
        if key and key in self._follow_action_rules:
            del self._follow_action_rules[key]
        self._remove_follow_action_rule_from_name("clip", track_index, scene_index)
        if key in self._active_follow_actions:
            del self._active_follow_actions[key]
        self._handled_follow_action_launches.discard(key)
        self._follow_action_missing_clip_counts.pop(key, None)

    def _shift_follow_actions_after_scene_insert(self, insert_index):
        shifted_rules = {}
        for key, rule in self._follow_action_rules.items():
            target_kind = rule.get("target_kind")
            scene_index = int(rule.get("scene_index", 0))
            if scene_index >= insert_index:
                rule = dict(rule)
                rule["scene_index"] = scene_index + 1
                if target_kind == "clip":
                    key = self._follow_action_key("clip", rule.get("track_index"), rule["scene_index"])
                else:
                    key = self._follow_action_key("scene", None, rule["scene_index"])
            shifted_rules[key] = rule
        self._follow_action_rules = shifted_rules
        self._follow_action_missing_clip_counts = {}

        shifted_active = {}
        for active_key, active in self._active_follow_actions.items():
            if active.get("scene_index") >= insert_index:
                active = dict(active)
                active["scene_index"] += 1
                if active.get("target_kind") == "clip":
                    active_key = self._follow_action_key("clip", active.get("track_index"), active.get("scene_index"))
                else:
                    active_key = self._follow_action_key("scene", None, active.get("scene_index"))
            shifted_active[active_key] = active
        self._active_follow_actions = shifted_active

    def _shift_follow_actions_after_scene_delete(self, deleted_index):
        shifted_rules = {}
        for key, rule in self._follow_action_rules.items():
            scene_index = int(rule.get("scene_index", 0))
            if scene_index == deleted_index:
                continue
            if scene_index > deleted_index:
                rule = dict(rule)
                rule["scene_index"] = scene_index - 1
                if rule.get("target_kind") == "clip":
                    key = self._follow_action_key("clip", rule.get("track_index"), rule["scene_index"])
                else:
                    key = self._follow_action_key("scene", None, rule["scene_index"])
            shifted_rules[key] = rule
        self._follow_action_rules = shifted_rules
        self._follow_action_missing_clip_counts = {}

        shifted_active = {}
        for active_key, active in self._active_follow_actions.items():
            active_scene = active.get("scene_index")
            if active_scene == deleted_index:
                continue
            elif active_scene > deleted_index:
                active = dict(active)
                active["scene_index"] = active_scene - 1
                if active.get("target_kind") == "clip":
                    active_key = self._follow_action_key("clip", active.get("track_index"), active.get("scene_index"))
                else:
                    active_key = self._follow_action_key("scene", None, active.get("scene_index"))
            shifted_active[active_key] = active
        self._active_follow_actions = shifted_active

    def _duplicate_follow_actions_for_scene(self, source_scene_index, dest_scene_index):
        scene_key = self._follow_action_key("scene", None, source_scene_index)
        scene_rule = self._follow_action_rules.get(scene_key)
        if scene_rule:
            new_rule = dict(scene_rule)
            new_rule["scene_index"] = dest_scene_index
            self._follow_action_rules[self._follow_action_key("scene", None, dest_scene_index)] = new_rule
            self._save_follow_action_rule_to_name(new_rule)

        try:
            for track_index, track in enumerate(self.song().tracks):
                self._copy_clip_follow_action_rule(track_index, source_scene_index, track_index, dest_scene_index)
        except Exception:
            pass

    def _reset_follow_action_state(self):
        self._follow_action_rules = {}
        self._active_follow_actions = {}
        self._handled_follow_action_launches = set()
        self._follow_action_missing_clip_counts = {}
        self._last_follow_action_state = None
        self._send_follow_action_state(force=True)

    def _shift_follow_actions_after_track_insert(self, insert_index):
        shifted_rules = {}
        for key, rule in self._follow_action_rules.items():
            if rule.get("target_kind") == "clip":
                track_index = int(rule.get("track_index", 0))
                if track_index >= insert_index:
                    rule = dict(rule)
                    rule["track_index"] = track_index + 1
                key = self._follow_action_key("clip", rule.get("track_index"), rule.get("scene_index"))
            shifted_rules[key] = rule
        self._follow_action_rules = shifted_rules

        shifted_active = {}
        for active_key, active in self._active_follow_actions.items():
            if active.get("target_kind") == "clip":
                track_index = int(active.get("track_index", 0))
                if track_index >= insert_index:
                    active = dict(active)
                    active["track_index"] = track_index + 1
                active_key = self._follow_action_key("clip", active.get("track_index"), active.get("scene_index"))
            shifted_active[active_key] = active
        self._active_follow_actions = shifted_active

        shifted_handled = set()
        for key in self._handled_follow_action_launches:
            if key[0] == "clip":
                _, track_index, scene_index = key
                if track_index >= insert_index:
                    track_index += 1
                shifted_handled.add(self._follow_action_key("clip", track_index, scene_index))
            else:
                shifted_handled.add(key)
        self._handled_follow_action_launches = shifted_handled
        self._follow_action_missing_clip_counts = {}

    def _shift_follow_actions_after_track_delete(self, deleted_index):
        shifted_rules = {}
        for key, rule in self._follow_action_rules.items():
            if rule.get("target_kind") == "clip":
                track_index = int(rule.get("track_index", 0))
                if track_index == deleted_index:
                    continue
                if track_index > deleted_index:
                    rule = dict(rule)
                    rule["track_index"] = track_index - 1
                key = self._follow_action_key("clip", rule.get("track_index"), rule.get("scene_index"))
            shifted_rules[key] = rule
        self._follow_action_rules = shifted_rules

        shifted_active = {}
        for active_key, active in self._active_follow_actions.items():
            if active.get("target_kind") == "clip":
                track_index = int(active.get("track_index", 0))
                if track_index == deleted_index:
                    continue
                if track_index > deleted_index:
                    active = dict(active)
                    active["track_index"] = track_index - 1
                active_key = self._follow_action_key("clip", active.get("track_index"), active.get("scene_index"))
            shifted_active[active_key] = active
        self._active_follow_actions = shifted_active

        shifted_handled = set()
        for key in self._handled_follow_action_launches:
            if key[0] == "clip":
                _, track_index, scene_index = key
                if track_index == deleted_index:
                    continue
                if track_index > deleted_index:
                    track_index -= 1
                shifted_handled.add(self._follow_action_key("clip", track_index, scene_index))
            else:
                shifted_handled.add(key)
        self._handled_follow_action_launches = shifted_handled
        self._follow_action_missing_clip_counts = {}

    def _remap_follow_actions_to_track_signature(self, previous_signature, current_signature):
        current_index_by_track = dict((track_id, index) for index, track_id in enumerate(current_signature))

        remapped_rules = {}
        for key, rule in self._follow_action_rules.items():
            if rule.get("target_kind") == "clip":
                old_track_index = int(rule.get("track_index", 0))
                if old_track_index >= len(previous_signature):
                    continue
                track_id = previous_signature[old_track_index]
                if track_id not in current_index_by_track:
                    continue
                rule = dict(rule)
                rule["track_index"] = current_index_by_track[track_id]
                key = self._follow_action_key("clip", rule.get("track_index"), rule.get("scene_index"))
            remapped_rules[key] = rule
        self._follow_action_rules = remapped_rules

        remapped_active = {}
        for active_key, active in self._active_follow_actions.items():
            if active.get("target_kind") == "clip":
                old_track_index = int(active.get("track_index", 0))
                if old_track_index >= len(previous_signature):
                    continue
                track_id = previous_signature[old_track_index]
                if track_id not in current_index_by_track:
                    continue
                active = dict(active)
                active["track_index"] = current_index_by_track[track_id]
                active_key = self._follow_action_key("clip", active.get("track_index"), active.get("scene_index"))
            remapped_active[active_key] = active
        self._active_follow_actions = remapped_active

        remapped_handled = set()
        for key in self._handled_follow_action_launches:
            if key[0] == "clip":
                _, old_track_index, scene_index = key
                if old_track_index >= len(previous_signature):
                    continue
                track_id = previous_signature[old_track_index]
                if track_id not in current_index_by_track:
                    continue
                remapped_handled.add(self._follow_action_key("clip", current_index_by_track[track_id], scene_index))
            else:
                remapped_handled.add(key)
        self._handled_follow_action_launches = remapped_handled
        self._follow_action_missing_clip_counts = {}

    def _sync_follow_actions_to_track_topology(self):
        current_signature = self._track_signature(self.song().tracks)
        previous_signature = self._follow_action_track_signature
        self._follow_action_track_signature = current_signature

        if previous_signature is None or previous_signature == current_signature:
            return

        if not set(previous_signature).intersection(set(current_signature)):
            self._follow_action_rules = {}
            self._active_follow_actions = {}
            self._handled_follow_action_launches = set()
            self._follow_action_missing_clip_counts = {}
            self._last_follow_action_state = None
            self._load_follow_actions_from_names(force_send=True)
            return

        self._remap_follow_actions_to_track_signature(previous_signature, current_signature)
        self._send_follow_action_state(force=True)

    def _get_global_launch_quantization_beats(self):
        try:
            quantization = self.song().clip_trigger_quantization
        except Exception:
            return 0.0

        quantization_beats = [
            ("q_no_q", 0.0),
            ("q_8_bars", 32.0),
            ("q_4_bars", 16.0),
            ("q_2_bars", 8.0),
            ("q_bar", 4.0),
            ("q_half", 2.0),
            ("q_half_triplet", 4.0 / 3.0),
            ("q_quarter", 1.0),
            ("q_quarter_triplet", 2.0 / 3.0),
            ("q_eight", 0.5),
            ("q_eight_triplet", 1.0 / 3.0),
            ("q_sixteenth", 0.25),
            ("q_sixtenth", 0.25),
            ("q_sixteenth_triplet", 1.0 / 6.0),
            ("q_sixtenth_triplet", 1.0 / 6.0),
            ("q_thirtytwoth", 0.125),
        ]

        for name, beats in quantization_beats:
            try:
                if quantization == getattr(Live.Song.Quantization, name):
                    return beats
            except Exception:
                pass
        return 0.0

    def _clip_slot_length_beats(self, clip_slot):
        try:
            if clip_slot and clip_slot.has_clip:
                clip = clip_slot.clip
                folded_info = self._decoupled_automation_info(clip)
                if folded_info:
                    return max(0.0001, float(folded_info.get("note_length", 0.0001)))
                return max(0.0, float(clip.loop_end) - float(clip.loop_start))
        except Exception:
            pass
        return 0.0

    def _clip_slot_is_triggered(self, clip_slot):
        try:
            return bool(clip_slot and clip_slot.is_triggered)
        except Exception:
            return False

    def _scene_length_beats(self, scene_index):
        longest = 0.0
        try:
            for track in self.song().tracks:
                if scene_index < len(track.clip_slots):
                    longest = max(longest, self._clip_slot_length_beats(track.clip_slots[scene_index]))
        except Exception:
            pass
        return longest

    def _scene_is_playing(self, scene_index):
        try:
            for track in self.song().tracks:
                if scene_index < len(track.clip_slots) and track.clip_slots[scene_index].is_playing:
                    return True
        except Exception:
            pass
        return False

    def _scene_is_triggered(self, scene_index):
        try:
            for track in self.song().tracks:
                if scene_index < len(track.clip_slots) and self._clip_slot_is_triggered(track.clip_slots[scene_index]):
                    return True
        except Exception:
            pass
        return False

    def _scene_object_is_triggered(self, scene):
        try:
            return bool(scene and scene.is_triggered)
        except Exception:
            return False

    def _scene_is_launched(self, scene_index):
        has_clip = False
        try:
            for track in self.song().tracks:
                if scene_index >= len(track.clip_slots):
                    continue
                clip_slot = track.clip_slots[scene_index]
                if not clip_slot.has_clip:
                    continue
                has_clip = True
                if not clip_slot.is_playing and not self._clip_slot_is_triggered(clip_slot):
                    return False
        except Exception:
            return False
        return has_clip

    def _scene_has_clip(self, scene_index):
        try:
            for track in self.song().tracks:
                if scene_index < len(track.clip_slots) and track.clip_slots[scene_index].has_clip:
                    return True
        except Exception:
            pass
        return False

    def _song_is_playing(self):
        try:
            return bool(self.song().is_playing)
        except Exception:
            return False

    def _send_transport_state(self, force=False):
        is_playing = self._song_is_playing()
        value = 127 if is_playing else 0
        if not force and self._last_sent_transport_state == value:
            return
        self._last_sent_transport_state = value
        self.send_cc(118, 0, value)

    def _session_record_value(self):
        try:
            return bool(self.song().session_record)
        except Exception:
            return False

    def _send_session_record_state(self, force=False):
        value = 127 if self._session_record_value() else 0
        if not force and self._last_sent_session_record_state == value:
            return
        self._last_sent_session_record_state = value
        self.send_cc(119, 0, value)

    def _begin_decoupled_automation_recording_tracking(self, clip):
        self._decoupled_automation_recording_generation += 1
        snapshots = self._capture_decoupled_automation_recording_snapshots((clip,))
        self._decoupled_automation_recording_active = bool(snapshots)
        self._decoupled_automation_recording_snapshots = snapshots

    def _finish_decoupled_automation_recording_tracking(self):
        if self._decoupled_automation_recording_active:
            snapshots = self._decoupled_automation_recording_snapshots
            generation = self._decoupled_automation_recording_generation
            self._decoupled_automation_recording_active = False
            self._decoupled_automation_recording_snapshots = {}
            self.schedule_message(
                2,
                lambda: self._reconcile_recorded_decoupled_automation_if_current(
                    snapshots,
                    generation
                )
            )

    def _reconcile_recorded_decoupled_automation_if_current(self, snapshots, generation):
        if generation != self._decoupled_automation_recording_generation:
            return
        self._reconcile_recorded_decoupled_automation(snapshots)

    def _on_session_record_changed(self):
        self._send_session_record_state()

    def _clear_follow_action_launch_state(self):
        changed = bool(self._active_follow_actions or self._handled_follow_action_launches)
        self._active_follow_actions = {}
        self._handled_follow_action_launches = set()
        if changed:
            self._send_follow_action_state()

    def _sync_follow_actions_to_transport(self):
        song_is_playing = self._song_is_playing()
        if song_is_playing != self._last_song_is_playing:
            self._last_song_is_playing = song_is_playing
            if not song_is_playing:
                self._clear_follow_action_launch_state()
                return
            self._clear_finished_follow_action_launches()
            self._activate_follow_actions_for_playing_clips()
            return

    def _on_song_is_playing_changed(self):
        self._send_transport_state()
        self._sync_follow_actions_to_transport()

    def _normalize_follow_action(self, action_name):
        action = str(action_name or "").strip().lower().replace(" ", "_").replace("-", "_")
        aliases = {
            "playagain": "play_again",
            "play_again": "play_again",
            "noaction": "play_again",
            "no_action": "play_again",
            "none": "play_again",
        }
        return aliases.get(action, action)

    def _follow_action_payload_bytes(self, message):
        if len(message) > 3 and message[2] == 1:
            return message[3:-1]
        return message[2:-1]

    def _strip_follow_action_name_marker(self, name):
        return self.FOLLOW_ACTION_NAME_MARKER_RE.sub("", str(name or "")).rstrip()

    def _strip_decoupled_automation_name_marker(self, name):
        return self.DECOUPLED_AUTOMATION_ANY_NAME_MARKER_RE.sub("", str(name or "")).rstrip()

    def _strip_mutator_name_marker(self, name):
        return self.MUTATOR_ANY_NAME_MARKER_RE.sub("", str(name or "")).rstrip()

    def _strip_flin_name_marker(self, name):
        return self.FLIN_ANY_NAME_MARKER_RE.sub("", str(name or "")).rstrip()

    def _flin_info_from_name(self, name):
        """Decode only the supported marker version. Unknown versions stay ordinary clips."""
        try:
            matches = self.FLIN_NAME_MARKER_RE.findall(str(name or ""))
            if not matches:
                return None
            fields = {}
            for item in matches[-1].split("|"):
                if "=" in item:
                    key, value = item.split("=", 1)
                    fields[key] = value
            required = ("k", "q", "b", "r", "h", "m", "o", "p", "s", "l", "c")
            if any(key not in fields for key in required):
                return None
            info = {
                "kind": max(0, min(1, int(fields["k"]))),
                "quantization": max(0, min(3, int(fields["q"]))),
                "base_quarters": max(1, min(64, int(fields["b"]))),
                "rate_mode": max(0, min(5, int(fields["r"]))),
                "bottom_rate": max(0, min(3, int(fields.get("n", 1)))),
                "row_interval": max(0, min(5, int(fields.get("i", 4)))),
                "horizon_bars": int(fields["h"]),
                "mapping_mode": max(0, min(3, int(fields["m"]))),
                "global_offset": max(-64, min(63, int(fields["o"]))),
                "view_page": max(-64, min(63, int(fields.get("v", 0)))),
                "base_pitch": max(0, min(127, int(fields["p"]))),
                "seed": max(1, min(2000000, int(fields["s"]))),
                "default_velocity": max(1, min(127, int(fields.get("f", 100)))),
                "limited": int(fields["l"]) == 1,
                "columns": [],
            }
            if info["horizon_bars"] not in (4, 8, 16, 32, 64, 96):
                return None
            for record in filter(None, fields["c"].split(",")):
                parts = record.split(":")
                if len(parts) not in (10, 11):
                    return None
                page = int(parts[0]) if len(parts) == 11 else 0
                offset = 1 if len(parts) == 11 else 0
                info["columns"].append({
                    "page": max(-64, min(63, page)),
                    "id": max(0, min(15, int(parts[offset]))),
                    "active": int(parts[offset + 1]) == 1,
                    "rate_row": max(0, min(15, int(parts[offset + 2]))),
                    "duration_steps": max(1, min(16, int(parts[offset + 3]))),
                    "phase_ticks": max(0, int(parts[offset + 4])),
                    "scale_degree": max(-63, min(63, int(parts[offset + 5]))),
                    "octave_offset": max(-8, min(8, int(parts[offset + 6]))),
                    "pad_offset": max(-63, min(63, int(parts[offset + 7]))),
                    "velocity": max(1, min(127, int(parts[offset + 8]))),
                    "probability": max(0, min(100, int(parts[offset + 9]))),
                })
            keys = [(column["page"], column["id"]) for column in info["columns"]]
            if len(keys) != len(set(keys)):
                return None
            info["columns"].sort(key=lambda column: (column["page"], column["id"]))
            return info
        except Exception:
            return None

    def _flin_info(self, clip):
        if clip is None or not hasattr(clip, "name"):
            return None
        return self._flin_info_from_name(clip.name)

    def _flin_marker(self, info):
        default_velocity = max(1, min(127, int(info.get("default_velocity", 100))))
        columns = ",".join(":".join(str(value) for value in (
            column.get("page", 0),
            column.get("id", 0),
            1 if column.get("active", False) else 0,
            column.get("rate_row", 0),
            column.get("duration_steps", 1),
            column.get("phase_ticks", 0),
            column.get("scale_degree", 0),
            column.get("octave_offset", 0),
            column.get("pad_offset", 0),
            column.get("velocity", 100),
            column.get("probability", 100),
        )) for column in info.get("columns", []) if (
            column.get("active", False)
            or int(column.get("velocity", default_velocity)) != default_velocity
            or int(column.get("probability", 100)) != 100
        ))
        return "[TapFlin:v1|k={}|q={}|b={}|r={}|n={}|i={}|h={}|m={}|o={}|v={}|p={}|s={}|f={}|l={}|c={}]".format(
            info.get("kind", 0), info.get("quantization", 1), info.get("base_quarters", 16),
            info.get("rate_mode", 0), info.get("bottom_rate", 1), info.get("row_interval", 4),
            info.get("horizon_bars", 64), info.get("mapping_mode", 0),
            info.get("global_offset", 0), info.get("view_page", 0), info.get("base_pitch", 60), info.get("seed", 1),
            info.get("default_velocity", 100),
            1 if info.get("limited", False) else 0, columns,
        )

    def _save_flin_info_to_name(self, clip, info):
        try:
            clean_name = self._strip_flin_name_marker(clip.name)
            marker = self._flin_marker(info)
            new_name = "{} {}".format(clean_name, marker).strip() if clean_name else marker
            if clip.name != new_name:
                clip.name = new_name
        except Exception:
            pass

    def _remove_flin_info_from_name(self, clip):
        try:
            clean_name = self._strip_flin_name_marker(clip.name)
            if clip.name != clean_name:
                clip.name = clean_name
        except Exception:
            pass

    def _stable_decoupled_hash(self, value):
        result = 2166136261
        for char in str(value or ""):
            result ^= ord(char)
            result = (result * 16777619) & 0xFFFFFFFF
        return result

    def _decoupled_automation_parameter_key(self, device_param):
        try:
            if device_param is None or not liveobj_valid(device_param):
                return None

            parts = []
            parent = getattr(device_param, "canonical_parent", None)
            while parent is not None and len(parts) < 4:
                name = getattr(parent, "name", None)
                if name:
                    parts.append(str(name))
                next_parent = getattr(parent, "canonical_parent", None)
                if next_parent is parent:
                    break
                parent = next_parent

            parts = list(reversed(parts))
            parts.append(str(getattr(device_param, "name", "parameter")))
            raw_key = "/".join(parts)
            clean = re.sub(r"[^A-Za-z0-9]+", "_", raw_key).strip("_")
            if not clean:
                clean = "parameter"
            return "{}_{}".format(clean[:36], format(self._stable_decoupled_hash(raw_key), "08x"))
        except Exception:
            return None

    def _decode_decoupled_automation_lengths(self, payload):
        lengths = {}
        entries = [entry for entry in str(payload or "").split(",") if entry]
        for entry in entries:
            fields = entry.split(":")
            if len(fields) != 2:
                continue
            try:
                key = fields[0]
                if not key:
                    continue
                lengths[key] = max(0.0001, float(fields[1]))
            except Exception:
                pass
        return lengths

    def _encode_decoupled_automation_lengths(self, lengths):
        entries = []
        for key in sorted((lengths or {}).keys()):
            try:
                length = max(0.0001, float(lengths[key]))
                entries.append("{}:{:.6f}".format(key, length))
            except Exception:
                pass
        return ",".join(entries)

    def _decode_decoupled_automation_payload(self, payload):
        fields = str(payload or "").split("|")
        if len(fields) != 3:
            return None

        try:
            note_start = max(0.0, float(fields[0]))
            note_length = max(0.0001, float(fields[1]))
            automation_lengths = self._decode_decoupled_automation_lengths(fields[2])
        except Exception:
            return None

        if not automation_lengths:
            return None

        physical_length = self._decoupled_physical_length(note_length, automation_lengths.values())
        return {
            "note_start": note_start,
            "note_length": note_length,
            "note_end": note_start + note_length,
            "automation_lengths": automation_lengths,
            "physical_length": physical_length,
            "physical_end": note_start + physical_length,
        }

    def _decoupled_automation_info_from_name(self, name):
        matches = self.DECOUPLED_AUTOMATION_NAME_MARKER_RE.findall(str(name or ""))
        if not matches:
            return None
        return self._decode_decoupled_automation_payload(matches[-1])

    def _decoupled_automation_info(self, clip, device_param=None):
        try:
            if clip is None or not hasattr(clip, "name"):
                return None
            info = self._decoupled_automation_info_from_name(clip.name)
            if not info:
                return None
            info = dict(info)
            max_physical_length = self._decoupled_automation_max_physical_length(clip, info["note_length"])
            info["physical_length"] = self._decoupled_physical_length(info["note_length"], info["automation_lengths"].values(), max_physical_length)
            info["physical_end"] = info["note_start"] + info["physical_length"]
            parameter_key = self._decoupled_automation_parameter_key(device_param)
            if parameter_key:
                info["parameter_key"] = parameter_key
                info["has_parameter_length"] = parameter_key in info["automation_lengths"]
                info["automation_length"] = info["automation_lengths"].get(parameter_key, info["note_length"])
            else:
                info["parameter_key"] = None
                info["has_parameter_length"] = False
                info["automation_length"] = info["note_length"]
            return info
        except Exception:
            return None

    def _all_decoupled_automation_clips(self):
        clips = []
        try:
            for track in self.song().tracks:
                for clip_slot in track.clip_slots:
                    if clip_slot is None or not clip_slot.has_clip:
                        continue
                    clip = clip_slot.clip
                    if self._decoupled_automation_info(clip):
                        clips.append(clip)
        except Exception:
            pass
        return tuple(clips)

    def _decoupled_automation_cycle_samples(self, envelope, device_param, info):
        if envelope is None or device_param is None or not liveobj_valid(device_param) or not info:
            return tuple()

        automation_length = max(0.0001, float(info.get("automation_length", info["note_length"])))
        physical_length = max(automation_length, float(info.get("physical_length", automation_length)))
        cycle_count = max(1, int(math.floor((physical_length + 0.000001) / automation_length)))
        samples_per_cycle = max(3, int(self.AUTOMATION_ENVELOPE_MAX_SAMPLES / cycle_count))
        cycles = []

        for cycle_index in range(cycle_count):
            cycle_start = info["note_start"] + (float(cycle_index) * automation_length)
            if cycle_start + automation_length > info["physical_end"] + 0.000001:
                break

            values = []
            for sample_index in range(samples_per_cycle):
                # Keep the sample inside this loop so the next loop's first
                # value cannot make an otherwise flat loop look recorded.
                time_value = cycle_start + (
                    automation_length * float(sample_index) / float(samples_per_cycle)
                )
                try:
                    raw_value = envelope.value_at_time(time_value)
                    if device_param.max != device_param.min:
                        normalized = (raw_value - device_param.min) / (device_param.max - device_param.min)
                    else:
                        normalized = self._parameter_normalized_value(device_param)
                except Exception:
                    normalized = self._parameter_normalized_value(device_param)
                values.append(max(0.0, min(1.0, normalized)))
            cycles.append(tuple(values))

        return tuple(cycles)

    def _capture_decoupled_automation_recording_snapshots(self, clips=None):
        snapshots = {}
        target_clips = tuple(clips) if clips is not None else self._all_decoupled_automation_clips()
        for clip in target_clips:
            try:
                info = self._decoupled_automation_info(clip)
                if not info:
                    continue

                parameters = {}
                for device_param in self._clip_automation_parameters(clip, info):
                    parameter_key = self._decoupled_automation_parameter_key(device_param)
                    if not parameter_key:
                        continue

                    envelope = None
                    if hasattr(clip, "automation_envelope"):
                        try:
                            envelope = clip.automation_envelope(device_param)
                        except Exception:
                            envelope = None
                    if envelope is None:
                        continue

                    parameter_info = self._decoupled_info_for_parameter_key(info, parameter_key)
                    parameters[parameter_key] = {
                        "automation_length": parameter_info["automation_length"],
                        "cycles": self._decoupled_automation_cycle_samples(
                            envelope,
                            device_param,
                            parameter_info
                        ),
                    }

                clip_identity = self._live_object_identity(clip)
                snapshots[clip_identity] = {
                    "clip": clip,
                    "parameters": parameters,
                }
            except Exception as e:
                self.log_message("TapAuto snapshot error: {}".format(str(e)))

        return snapshots

    def _decoupled_automation_cycle_changed(self, current_values, previous_values):
        if previous_values is None or len(current_values) != len(previous_values):
            return True
        return any(
            abs(float(current) - float(previous)) > self.AUTOMATION_ENVELOPE_LINEAR_EPSILON
            for current, previous in zip(current_values, previous_values)
        )

    def _reconcile_recorded_decoupled_automation(self, snapshots):
        recorded_parameter_found = False
        for snapshot in tuple((snapshots or {}).values()):
            clip = snapshot.get("clip")
            try:
                if clip is None or not liveobj_valid(clip):
                    continue
                info = self._decoupled_automation_info(clip)
                if not info:
                    continue

                previous_parameters = snapshot.get("parameters", {})
                automation_lengths = dict(info.get("automation_lengths", {}))
                full_clip_length = max(
                    0.0001,
                    float(getattr(clip, "loop_end", info["physical_end"])) - info["note_start"]
                )
                marker_changed = False

                for device_param in self._clip_automation_parameters(clip, info):
                    parameter_key = self._decoupled_automation_parameter_key(device_param)
                    if not parameter_key:
                        continue

                    envelope = None
                    if hasattr(clip, "automation_envelope"):
                        try:
                            envelope = clip.automation_envelope(device_param)
                        except Exception:
                            envelope = None
                    if envelope is None:
                        continue

                    parameter_info = self._decoupled_info_for_parameter_key(info, parameter_key)
                    current_cycles = self._decoupled_automation_cycle_samples(
                        envelope,
                        device_param,
                        parameter_info
                    )
                    if not current_cycles:
                        continue

                    previous_parameter = previous_parameters.get(parameter_key)
                    previous_cycles = (
                        previous_parameter.get("cycles", ())
                        if previous_parameter is not None
                        and abs(
                            float(previous_parameter.get("automation_length", 0.0))
                            - float(parameter_info["automation_length"])
                        ) <= 0.000001
                        else ()
                    )
                    parameter_was_recorded = any(
                        self._decoupled_automation_cycle_changed(
                            current_values,
                            previous_cycles[cycle_index] if cycle_index < len(previous_cycles) else None
                        )
                        for cycle_index, current_values in enumerate(current_cycles)
                    )
                    if not parameter_was_recorded:
                        continue

                    recorded_parameter_found = True
                    self._clear_authored_automation_steps_for_parameter(clip, device_param)
                    if abs(automation_lengths.get(parameter_key, 0.0) - full_clip_length) > 0.000001:
                        automation_lengths[parameter_key] = full_clip_length
                        marker_changed = True
                    self.log_message(
                        "Marked recorded automation for '{}' with full clip length {:.6f}".format(
                            getattr(device_param, "name", parameter_key),
                            full_clip_length
                        )
                    )

                if marker_changed:
                    updated_info = dict(info)
                    updated_info["automation_lengths"] = automation_lengths
                    self._save_decoupled_automation_info_to_name(clip, updated_info)
            except Exception as e:
                self.log_message("TapAuto reconciliation error: {}".format(str(e)))

        if recorded_parameter_found:
            self._refresh_parameter_metadata_on_automation_change()
            self.send_selected_clip_metadata()

    def _decoupled_automation_marker(self, info):
        return "[TapAuto:v2|{:.6f}|{:.6f}|{}]".format(
            info.get("note_start", 0.0),
            info.get("note_length", 0.0),
            self._encode_decoupled_automation_lengths(info.get("automation_lengths", {})),
        )

    def _save_decoupled_automation_info_to_name(self, clip, info):
        if clip is None or not hasattr(clip, "name"):
            return

        try:
            clean_name = self._strip_decoupled_automation_name_marker(clip.name)
            marker = self._decoupled_automation_marker(info)
            new_name = "{} {}".format(clean_name, marker).strip() if clean_name else marker
            if clip.name != new_name:
                clip.name = new_name
        except Exception:
            pass

    def _remove_decoupled_automation_info_from_name(self, clip):
        if clip is None or not hasattr(clip, "name"):
            return

        try:
            clean_name = self._strip_decoupled_automation_name_marker(clip.name)
            if clip.name != clean_name:
                clip.name = clean_name
        except Exception:
            pass

    def _mutator_info_from_name(self, name, resolve_scale_root=True):
        try:
            matches = self.MUTATOR_NAME_MARKER_RE.findall(str(name or ""))
            if not matches:
                return None
            payload = matches[-1]
            fields = {}
            for item in payload.split("|"):
                if "=" not in item:
                    continue
                key, value = item.split("=", 1)
                fields[key] = value
            sections = []
            for section in fields.get("sec", "").split(","):
                if not section:
                    continue
                parts = section.split(":")
                if len(parts) >= 3:
                    sections.append({
                        "role": int(parts[0]),
                        "start": float(parts[1]),
                        "length": float(parts[2]),
                    })
            algorithm = fields.get("alg", "")
            if fields.get("ai", "").isdigit():
                algorithm = self._mutator_algorithm_from_code(int(fields.get("ai", "0")))

            scale_index = self._mutator_scale_index_from_name(fields.get("sc", ""))
            if fields.get("si", "").isdigit():
                scale_index = max(0, min(len(self.MUTATOR_SCALE_NAMES) - 1, int(fields.get("si", "2"))))
            if scale_index is None:
                scale_index = 2
            depth = 0.0
            try:
                if "dep" in fields:
                    depth = float(fields.get("dep", "0.0"))
                elif "dp" in fields:
                    depth = float(fields.get("dp", "0")) / 100.0
            except Exception:
                depth = 0.0

            preset = int(fields.get("pr", "9"))
            settings_preset = int(fields.get("sp", fields.get("pr", "9")))
            pending_settings_update = int(fields.get("pd", "0")) == 1

            companion_mode = self._mutator_companion_mode_from_code(int(fields.get("cm", "0"))) if fields.get("cm", "").isdigit() else "melody"
            target_pitches = self._mutator_target_pitches_from_value(fields.get("tg", ""))
            operation_depths = self._mutator_operation_depths_from_value(
                fields.get("od", ""),
                self._mutator_default_operation_depths()
            )
            operation_order = self._mutator_operation_order_from_value(fields.get("oo", ""))
            mutator_slots = self._mutator_slots_from_value(fields.get("ms", ""))
            mutator_slot_count = self._mutator_slot_count_from_value(fields.get("mc", ""), mutator_slots)

            info = {
                "original_loop_length": max(0.0001, float(fields.get("ol", "0.0001"))),
                "structure_length": max(0.0001, float(fields.get("sl", fields.get("ol", "0.0001")))),
                "preset": preset,
                "settings_preset": settings_preset,
                "mutations_per_pass": max(1, min(3, int(fields.get("mp", "1")))),
                "seed": int(fields.get("seed", fields.get("sd", "1"))),
                "algorithm": algorithm or "mutator",
                "algorithm_code": self._mutator_algorithm_code(algorithm or "mutator"),
                "depth": max(0.0, min(1.0, depth)),
                "regenerate_mode": int(fields.get("rg", "0")),
                "source_mode": int(fields.get("src", "2")),
                "root": max(0, min(11, int(fields.get("rt", "0")))),
                "scale_index": scale_index,
                "companion_mode": companion_mode,
                "companion_mode_code": self._mutator_companion_mode_code(companion_mode),
                "target_pitches": target_pitches,
                "operation_order": operation_order,
                "mutator_slots": mutator_slots,
                "mutator_slot_count": mutator_slot_count,
                "pending_settings_update": pending_settings_update,
                "sections": sections,
            }
            info.update(operation_depths)
            if resolve_scale_root:
                live_scale_index, live_root = self._current_mutator_scale_root(
                    info.get("scale_index", 2),
                    info.get("root", 0)
                )
                info["scale_index"] = live_scale_index
                info["root"] = live_root
            return info
        except Exception:
            return None

    def _mutator_info(self, clip):
        if clip is None or not hasattr(clip, "name"):
            return None
        info = self._mutator_info_from_name(clip.name)
        if not info:
            return None
        if not info.get("sections"):
            original_loop_length = max(0.0001, float(info.get("original_loop_length", 0.0001)))
            source_start = float(getattr(clip, "loop_start", 0.0))
            roles = self._mutator_pattern_roles(info.get("preset", 9))
            info["sections"] = [
                {"role": role, "start": source_start + (index * original_loop_length), "length": original_loop_length}
                for index, role in enumerate(roles)
            ]
            info["structure_length"] = max(
                original_loop_length,
                float(info.get("structure_length", 0.0)) or (original_loop_length * len(roles))
            )
        return info

    def _mutator_source_note_range(self, clip):
        info = self._mutator_info(clip)
        if not info:
            return None
        decoupled_info = self._decoupled_automation_info(clip)
        source_start = decoupled_info["note_start"] if decoupled_info else float(getattr(clip, "loop_start", 0.0))
        original_loop_length = max(
            0.0001,
            float(info.get("original_loop_length", float(getattr(clip, "loop_end", source_start)) - source_start))
        )
        return source_start, source_start + original_loop_length

    def _mutator_allows_source_note_time(self, clip, start_time):
        source_range = self._mutator_source_note_range(clip)
        if not source_range:
            return True
        source_start, source_end = source_range
        return float(start_time) >= source_start - 0.000001 and float(start_time) < source_end - 0.000001

    def _mutator_algorithm_code(self, algorithm):
        try:
            return self.MUTATOR_ALGORITHMS.index(str(algorithm or "mutator"))
        except Exception:
            return 0

    def _mutator_algorithm_from_code(self, code):
        try:
            index = max(0, min(len(self.MUTATOR_ALGORITHMS) - 1, int(code)))
            return self.MUTATOR_ALGORITHMS[index]
        except Exception:
            return "mutator"

    def _mutator_companion_mode_code(self, mode):
        return 1 if str(mode or "melody") == "rhythm" else 0

    def _mutator_companion_mode_from_code(self, code):
        return "rhythm" if int(code) == 1 else "melody"

    def _mutator_scale_index_from_name(self, scale_name):
        try:
            return self.MUTATOR_SCALE_NAMES.index(str(scale_name))
        except Exception:
            return None

    def _current_mutator_scale_root(self, fallback_scale_index=2, fallback_root=0):
        scale_index = fallback_scale_index
        root = fallback_root
        try:
            song = self.song()
            live_scale_index = self._mutator_scale_index_from_name(getattr(song, "scale_name", ""))
            if live_scale_index is not None:
                scale_index = live_scale_index
            root = max(0, min(11, int(getattr(song, "root_note", fallback_root))))
        except Exception:
            pass
        return scale_index, root

    def _current_mutator_scale_root_signature(self):
        return self._current_mutator_scale_root(2, 0)

    def _mutator_operation_is_scale_sensitive(self, operation):
        try:
            return int(operation) in (
                6,
                self._mutator_add_shift_operation_index(),
                self._mutator_invert_operation_index(),
                self._mutator_pitch_add_operation_index(),
                self._mutator_phrase_shift_operation_index(),
            )
        except Exception:
            return False

    def _mutator_info_is_scale_sensitive(self, info):
        if not info or info.get("companion_mode", "melody") == "rhythm":
            return False
        if self._mutator_algorithm_kind(info.get("algorithm", "mutator")) is not None:
            return True
        if self._mutator_depth_value(info, "pitch_shift_depth", 0.0) > 0.0:
            return True
        for slot in self._mutator_visible_slots(info):
            if (
                slot
                and self._mutator_operation_is_scale_sensitive(slot.get("operation", 0))
                and self._mutator_depth_value(slot, "probability_depth", 0.0) > 0.0
            ):
                return True
        return False

    def _mutator_clip_slots(self):
        try:
            for track_index, track in enumerate(self.song().tracks):
                if track is None or not hasattr(track, "clip_slots"):
                    continue
                for scene_index, clip_slot in enumerate(track.clip_slots):
                    if clip_slot is not None and clip_slot.has_clip:
                        yield track_index, scene_index, clip_slot
        except Exception:
            return

    def _sync_mutator_scale_root_to_companion_clips(self):
        self._mutator_scale_root_sync_scheduled = False
        try:
            scale_index, root = self._current_mutator_scale_root_signature()
            signature = (scale_index, root)
            previous_signature = self._last_mutator_scale_root_signature
            self._last_mutator_scale_root_signature = signature
            if previous_signature is None or previous_signature == signature:
                return

            for _, _, clip_slot in self._mutator_clip_slots():
                clip = clip_slot.clip
                raw_info = self._mutator_info_from_name(clip.name, resolve_scale_root=False)
                if not raw_info:
                    continue
                info = dict(raw_info)
                scale_root_changed = (
                    int(info.get("scale_index", 2)) != scale_index
                    or int(info.get("root", 0)) != root
                )
                info["scale_index"] = scale_index
                info["root"] = root
                if scale_root_changed:
                    self._save_mutator_info_to_name(clip, info)
                if not self._mutator_info_is_scale_sensitive(info):
                    continue

                key = self._live_object_identity(clip)
                settings = self._mutator_settings_from_info(
                    info,
                    seed=random.randint(1, 2000000000)
                )
                if self._mutator_generation_is_busy(key):
                    self._queue_mutator_generation(key, clip, settings, previous_info=info, send_updates=True)
                elif not self._schedule_mutator_generation(key, clip, settings, previous_info=info, send_updates=True):
                    self._generate_mutator_clip(clip, settings, previous_info=info, send_updates=True)
        except Exception as e:
            self._debug_log("Error syncing mutator scale/root: {}".format(str(e)))

    def _schedule_mutator_scale_root_sync(self):
        if self._mutator_scale_root_sync_scheduled:
            return
        self._mutator_scale_root_sync_scheduled = True
        try:
            self.schedule_message(1, self._sync_mutator_scale_root_to_companion_clips)
        except Exception:
            self._sync_mutator_scale_root_to_companion_clips()

    def _mutator_depth_value(self, settings, key, fallback=0.0):
        try:
            return max(0.0, min(1.0, float(settings.get(key, fallback))))
        except Exception:
            return max(0.0, min(1.0, float(fallback)))

    def _mutator_operation_depth_keys(self):
        return (
            "fill_depth",
            "simplification_depth",
            "octave_shift_depth",
            "rhythmic_shift_depth",
            "note_addition_depth",
            "note_removal_depth",
            "pitch_shift_depth",
            "velocity_change_depth",
            "gate_change_depth",
            "shift_depth",
        )

    def _mutator_add_shift_operation_index(self):
        return len(self._mutator_operation_depth_keys())

    def _mutator_loop_shift_operation_index(self):
        return 11

    def _mutator_reverse_operation_index(self):
        return 12

    def _mutator_invert_operation_index(self):
        return 13

    def _mutator_pitch_add_operation_index(self):
        return 14

    def _mutator_duplicate_operation_index(self):
        return 15

    def _mutator_phrase_shift_operation_index(self):
        return 16

    def _mutator_preserver_operation_index(self):
        return 17

    def _mutator_max_operation_index(self):
        return self._mutator_preserver_operation_index()

    def _mutator_default_operation_depths(self):
        return dict((key, 0.0) for key in self._mutator_operation_depth_keys())

    def _mutator_operation_depths_from_fields(self, fields, start_index, fallback):
        result = dict(fallback or {})
        keys = self._mutator_operation_depth_keys()
        for offset, key in enumerate(keys):
            try:
                index = int(start_index) + offset
                if index < len(fields):
                    result[key] = max(0.0, min(1.0, float(fields[index]) / 100.0))
            except Exception:
                pass
        return result

    def _mutator_operation_depths_from_value(self, value, fallback):
        result = dict(fallback or {})
        parts = str(value or "").split(",")
        for offset, key in enumerate(self._mutator_operation_depth_keys()):
            try:
                if offset < len(parts) and parts[offset] != "":
                    result[key] = max(0.0, min(1.0, float(parts[offset]) / 100.0))
            except Exception:
                pass
        return result

    def _mutator_operation_depths_marker_value(self, info):
        return ",".join(
            str(max(0, min(100, int(round(self._mutator_depth_value(info, key, 0.0) * 100.0)))))
            for key in self._mutator_operation_depth_keys()
        )

    def _mutator_operation_order_from_value(self, value, fallback=None):
        keys = self._mutator_operation_depth_keys()
        result = []
        parts = str(value or "").split(",")
        for part in parts:
            try:
                if part == "":
                    continue
                index = int(part)
                if 0 <= index < len(keys) and index not in result:
                    result.append(index)
            except Exception:
                pass
        if result:
            return result
        return list(fallback or ())

    def _mutator_active_operation_order(self, settings):
        keys = self._mutator_operation_depth_keys()
        default_order = (0, 1, 3, 9, 4, 8, 2, 6, 5, 7)
        stored_order = settings.get("operation_order", [])
        if isinstance(stored_order, (list, tuple)):
            stored_order = ",".join(str(index) for index in stored_order)
        raw_order = self._mutator_operation_order_from_value(
            stored_order,
            default_order
        )
        result = []
        for index in list(raw_order) + list(default_order):
            if 0 <= int(index) < len(keys) and int(index) not in result:
                key = keys[int(index)]
                if self._mutator_depth_value(settings, key, 0.0) > 0.0:
                    result.append(int(index))
        return result

    def _mutator_operation_order_marker_value(self, info):
        return ",".join(str(slot.get("operation", 0)) for slot in self._mutator_active_slots(info))

    def _mutator_slots_from_value(self, value):
        result = []
        max_operation_index = self._mutator_max_operation_index()
        for part in str(value or "").split(";"):
            if len(result) >= 10:
                break
            if not part or part == "x":
                result.append(None)
                continue
            fields = part.split(",")
            try:
                operation = int(fields[0])
                if operation < 0 or operation > max_operation_index:
                    result.append(None)
                    continue
                activation = max(0.0, min(1.0, float(fields[1]) / 100.0 if len(fields) > 1 else 1.0))
                probability = max(0.0, min(1.0, float(fields[2]) / 100.0 if len(fields) > 2 else 0.0))
                strength = max(0.0, min(1.0, float(fields[3]) / 100.0 if len(fields) > 3 else 0.5))
                result.append(dict(
                    operation=operation,
                    activation_probability=activation,
                    probability_depth=probability,
                    range_depth=strength,
                ))
            except Exception:
                result.append(None)
        while len(result) < 10:
            result.append(None)
        return result[:10]

    def _mutator_slots_marker_value(self, info):
        parts = []
        for slot in self._mutator_visible_slots(info):
            if not slot:
                parts.append("x")
                continue
            operation = max(0, min(self._mutator_max_operation_index(), int(slot.get("operation", 0))))
            parts.append("{},{},{},{}".format(
                operation,
                max(0, min(100, int(round(self._mutator_depth_value(slot, "activation_probability", 1.0) * 100.0)))),
                max(0, min(100, int(round(self._mutator_depth_value(slot, "probability_depth", 0.0) * 100.0)))),
                max(0, min(100, int(round(self._mutator_depth_value(slot, "range_depth", 0.5) * 100.0)))),
            ))
        return ";".join(parts)

    def _mutator_operation_uses_range_depth(self, operation):
        return int(operation) in (3, 6, 7, 8, 9, self._mutator_pitch_add_operation_index(), self._mutator_phrase_shift_operation_index())

    def _mutator_normalized_slots(self, settings):
        slots = settings.get("mutator_slots", [])
        result = []
        max_operation_index = self._mutator_max_operation_index()
        if isinstance(slots, (list, tuple)):
            for slot in slots[:10]:
                if not slot:
                    result.append(None)
                    continue
                try:
                    operation = int(slot.get("operation", 0))
                    if operation < 0 or operation > max_operation_index:
                        result.append(None)
                        continue
                    result.append(dict(
                        operation=operation,
                        activation_probability=self._mutator_depth_value(slot, "activation_probability", 1.0),
                        probability_depth=self._mutator_depth_value(slot, "probability_depth", 0.0),
                        range_depth=self._mutator_depth_value(slot, "range_depth", 0.5),
                    ))
                except Exception:
                    result.append(None)
        while len(result) < 10:
            result.append(None)
        return result[:10]

    def _mutator_slot_count_from_value(self, value, slots=None):
        try:
            if str(value or "") != "":
                return max(4, min(10, int(value)))
        except Exception:
            pass
        last_used = 0
        for index, slot in enumerate(tuple(slots or ())[:10]):
            if slot:
                last_used = index + 1
        return max(4, min(10, last_used))

    def _mutator_visible_slots(self, settings):
        slots = self._mutator_normalized_slots(settings)
        slot_count = self._mutator_slot_count_from_value(settings.get("mutator_slot_count", ""), slots)
        return slots[:slot_count]

    def _mutator_resolve_slot_activation(self, settings):
        resolved = dict(settings or {})
        rnd = random.Random(int(resolved.get("seed", 1)) ^ 0x5A175EED)
        active_slots = []
        for slot in self._mutator_visible_slots(resolved):
            if not slot:
                continue
            activation = self._mutator_depth_value(slot, "activation_probability", 1.0)
            if activation <= 0.0:
                continue
            if activation < 1.0 and rnd.random() > activation:
                continue
            active_slots.append(slot)
        resolved["_active_mutator_slots"] = active_slots
        return resolved

    def _mutator_active_slots(self, settings):
        active = []
        add_shift_index = self._mutator_add_shift_operation_index()
        source_slots = settings.get("_active_mutator_slots", self._mutator_visible_slots(settings))
        for slot in source_slots:
            if not slot:
                continue
            probability = self._mutator_depth_value(slot, "probability_depth", 0.0)
            if probability <= 0.0:
                continue
            operation = int(slot.get("operation", 0))
            if operation == add_shift_index:
                active.append(dict(operation=operation, probability_depth=probability, range_depth=probability))
            else:
                active.append(slot)
        return active

    def _mutator_role_operation_depth(self, role, operation_depth):
        amount = max(0.0, min(1.0, float(operation_depth)))
        if amount <= 0.0:
            return 0.0
        role_factors = {
            0: 0.0,
            1: 0.35,
            2: 0.58,
            3: 0.82,
            4: 0.70,
            5: 1.0,
            6: 1.0,
            7: 1.0,
            8: 0.0,
            9: 1.0,
            10: 1.0,
            11: 1.0,
            12: 0.65,
            13: 0.50,
            14: 1.0,
            15: 1.0,
            16: 1.0,
        }
        return min(1.0, role_factors.get(role, 1.0) * amount)

    def _mutator_target_pitches_from_value(self, value):
        pitches = []
        try:
            for part in str(value or "").split(","):
                if part == "":
                    continue
                pitch = max(0, min(127, int(part)))
                if pitch not in pitches:
                    pitches.append(pitch)
        except Exception:
            return []
        return pitches[:16]

    def _mutator_marker(self, info):
        target_pitches = ",".join(str(max(0, min(127, int(pitch)))) for pitch in info.get("target_pitches", [])[:16])
        return "[TapComp:v1|ol={:.4f}|pr={}|sp={}|mp={}|pd={}|sl={:.4f}|ai={}|dp={}|rg={}|src={}|si={}|rt={}|cm={}|tg={}|od={}|oo={}|ms={}|mc={}]".format(
            info.get("original_loop_length", 0.0001),
            info.get("preset", 9),
            info.get("settings_preset", info.get("preset", 9)),
            int(info.get("mutations_per_pass", 1)) & 0x7F,
            1 if info.get("pending_settings_update", False) else 0,
            info.get("structure_length", info.get("original_loop_length", 0.0001)),
            int(info.get("algorithm_code", self._mutator_algorithm_code(info.get("algorithm", "mutator")))) & 0x7F,
            max(0, min(100, int(round(float(info.get("depth", 0.0)) * 100.0)))),
            int(info.get("regenerate_mode", 0)) & 0x7F,
            int(info.get("source_mode", 2)) & 0x7F,
            int(info.get("scale_index", 2)) & 0x7F,
            int(info.get("root", 0)) & 0x7F,
            int(info.get("companion_mode_code", self._mutator_companion_mode_code(info.get("companion_mode", "melody")))) & 0x7F,
            target_pitches,
            self._mutator_operation_depths_marker_value(info),
            self._mutator_operation_order_marker_value(info),
            self._mutator_slots_marker_value(info),
            self._mutator_slot_count_from_value(info.get("mutator_slot_count", ""), self._mutator_normalized_slots(info)),
        )

    def _save_mutator_info_to_name(self, clip, info):
        if clip is None or not hasattr(clip, "name"):
            return
        try:
            clean_name = self._strip_mutator_name_marker(clip.name)
            marker = self._mutator_marker(info)
            new_name = "{} {}".format(clean_name, marker).strip() if clean_name else marker
            if clip.name != new_name:
                clip.name = new_name
            self._has_mutator_clips = True
            self._mutator_clip_presence_dirty = False
        except Exception:
            pass

    def _remove_mutator_info_from_name(self, clip):
        if clip is None or not hasattr(clip, "name"):
            return
        try:
            clean_name = self._strip_mutator_name_marker(clip.name)
            if clip.name != clean_name:
                clip.name = clean_name
            self._mutator_clip_presence_dirty = True
        except Exception:
            pass

    def _decoupled_automation_max_physical_length(self, clip=None, note_length=0.0001):
        try:
            numerator = int(getattr(clip, "signature_numerator", 4)) if clip is not None else 4
        except Exception:
            numerator = 4
        return max(float(note_length or 0.0001), float(max(1, numerator) * self.DECOUPLED_AUTOMATION_MAX_PHYSICAL_BARS))

    def _smallest_shared_loop_length(self, note_length, automation_length, max_length=None):
        try:
            note_ms = max(1, int(round(float(note_length) * 1000.0)))
            automation_ms = max(1, int(round(float(automation_length) * 1000.0)))
            shared_ms = (note_ms * automation_ms) // math.gcd(note_ms, automation_ms)
            if max_length is not None:
                max_ms = max(1, int(round(float(max_length) * 1000.0)))
                shared_ms = min(shared_ms, max_ms)
            return float(shared_ms) / 1000.0
        except Exception:
            fallback = max(float(note_length or 0.0), float(automation_length or 0.0), 0.0001)
            return min(fallback, max_length) if max_length is not None else fallback

    def _decoupled_physical_length(self, note_length, automation_lengths, max_length=None):
        lengths = [max(0.0001, float(note_length or 0.0001))]
        for length in automation_lengths or ():
            try:
                lengths.append(max(0.0001, float(length)))
            except Exception:
                pass

        if max_length is None:
            max_length = self._decoupled_automation_max_physical_length(None, note_length)

        try:
            shared_ms = max(1, int(round(lengths[0] * 1000.0)))
            max_ms = max(1, int(round(float(max_length) * 1000.0)))
            for length in lengths[1:]:
                length_ms = max(1, int(round(length * 1000.0)))
                shared_ms = (shared_ms * length_ms) // math.gcd(shared_ms, length_ms)
                if shared_ms >= max_ms:
                    return float(max_ms) / 1000.0
            return min(float(shared_ms) / 1000.0, float(max_length))
        except Exception:
            return min(max(lengths), float(max_length))

    def _positive_mod(self, value, length):
        if length <= 0.000001:
            return 0.0
        return value - (math.floor(value / length) * length)

    def _folded_note_time(self, time_value, info):
        return info["note_start"] + self._positive_mod(float(time_value) - info["note_start"], info["note_length"])

    def _note_matches_folded_time(self, note, folded_time, info, pitch=None, epsilon=0.0005):
        try:
            if pitch is not None and int(note.pitch) != int(pitch):
                return False
            return abs(self._folded_note_time(note.start_time, info) - folded_time) <= epsilon
        except Exception:
            return False

    def _repeat_count_for_decoupled_info(self, info):
        return max(1, int(round(info["physical_length"] / info["note_length"])))

    def _duration_inside_note_loop(self, start_time, duration, info):
        base_offset = self._positive_mod(float(start_time) - info["note_start"], info["note_length"])
        remaining = max(0.0001, info["note_length"] - base_offset)
        return max(0.0001, min(float(duration), remaining))

    def _make_repeated_note_specs_from_values(self, pitch, start_time, duration, velocity, mute, probability, info):
        specs = []
        base_offset = self._positive_mod(float(start_time) - info["note_start"], info["note_length"])
        clipped_duration = self._duration_inside_note_loop(start_time, duration, info)
        for repeat_index in range(self._repeat_count_for_decoupled_info(info)):
            start_time = info["note_start"] + (float(repeat_index) * info["note_length"]) + base_offset
            if start_time < info["physical_end"] - 0.000001:
                specs.append(MidiNoteSpecification(
                    pitch=int(pitch),
                    start_time=start_time,
                    duration=clipped_duration,
                    velocity=int(velocity),
                    mute=bool(mute),
                    probability=float(probability)
                ))
        return specs

    def _make_repeated_note_specs(self, base_note, info):
        return self._make_repeated_note_specs_from_values(
            getattr(base_note, "pitch", 0),
            getattr(base_note, "start_time", info["note_start"]),
            getattr(base_note, "duration", 0.0001),
            getattr(base_note, "velocity", 100),
            getattr(base_note, "mute", False),
            getattr(base_note, "probability", 1.0),
            info
        )

    def _rewrite_decoupled_note_copies(self, clip, info):
        try:
            base_notes = clip.get_notes_extended(0, 128, info["note_start"], info["note_length"])
            if hasattr(clip, "remove_notes_extended"):
                remove_start = float(info.get("remove_start", info["note_start"]))
                current_end = max(
                    info["physical_end"],
                    float(getattr(clip, "loop_end", info["physical_end"])),
                    float(getattr(clip, "end_marker", info["physical_end"])),
                    float(getattr(clip, "length", info["physical_length"])),
                )
                clip.remove_notes_extended(0, 128, remove_start, max(info["physical_length"], current_end - remove_start))
            specs = []
            for note in base_notes:
                specs.extend(self._make_repeated_note_specs(note, info))
            if specs:
                clip.add_new_notes(specs)
        except Exception as e:
            self._debug_log("Error rewriting decoupled note copies: {}".format(str(e)))

    def _double_decoupled_note_copies(self, clip, previous_info, doubled_info):
        try:
            previous_start = previous_info["note_start"]
            previous_length = previous_info["note_length"]
            base_notes = clip.get_notes_extended(0, 128, previous_start, previous_length)
            specs = []
            for note in base_notes:
                for half_offset in (0.0, previous_length):
                    specs.extend(self._make_repeated_note_specs_from_values(
                        getattr(note, "pitch", 0),
                        getattr(note, "start_time", previous_start) + half_offset,
                        getattr(note, "duration", 0.0001),
                        getattr(note, "velocity", 100),
                        getattr(note, "mute", False),
                        getattr(note, "probability", 1.0),
                        doubled_info
                    ))

            if hasattr(clip, "remove_notes_extended"):
                remove_start = float(doubled_info.get("remove_start", previous_start))
                current_end = max(
                    previous_info["physical_end"],
                    doubled_info["physical_end"],
                    float(getattr(clip, "loop_end", doubled_info["physical_end"])),
                    float(getattr(clip, "end_marker", doubled_info["physical_end"])),
                    float(getattr(clip, "length", doubled_info["physical_length"])),
                )
                clip.remove_notes_extended(0, 128, remove_start, max(doubled_info["physical_length"], current_end - remove_start))
            if specs:
                clip.add_new_notes(specs)
        except Exception as e:
            self._debug_log("Error doubling decoupled note copies: {}".format(str(e)))

    def _expanded_decoupled_automation_steps(self, info, logical_steps, sample_duration):
        if not info or not logical_steps:
            return tuple(logical_steps or ())

        expanded_steps = []
        loop_start_value = logical_steps[0][2]
        repeat_count = max(1, int(round(info["physical_length"] / info["automation_length"])))
        for repeat_index in range(repeat_count):
            cycle_start = info["note_start"] + (float(repeat_index) * info["automation_length"])
            for step in logical_steps:
                time_value, duration, normalized, curve, step_id, step_order = self._automation_step_tuple(step)
                if time_value >= info["note_start"] + info["automation_length"] - 0.000001:
                    relative_time = info["automation_length"]
                else:
                    relative_time = self._positive_mod(time_value - info["note_start"], info["automation_length"])
                if repeat_index > 0 and relative_time <= 0.000001:
                    continue
                expanded_time = cycle_start + relative_time
                if expanded_time <= info["physical_end"] + 0.000001:
                    expanded_steps.append((expanded_time, duration, normalized, curve, step_id, step_order))
            cycle_end = cycle_start + info["automation_length"]
            if cycle_end <= info["physical_end"] + 0.000001:
                expanded_steps.append((
                    min(cycle_end, info["physical_end"]),
                    sample_duration,
                    loop_start_value,
                    0.0,
                    0,
                    self.AUTOMATION_FOLDED_ENDPOINT_ORDER
                ))
        return self._automation_sorted_steps(expanded_steps)

    def _neutralize_decoupled_automation_points(self, envelope, device_param, info, previous_logical_steps, normalized_value, sample_duration):
        if envelope is None or device_param is None or not info:
            return

        raw_value = self._parameter_target_value_from_normalized(device_param, normalized_value)
        minimum_duration = 0.0001
        start_time = info["note_start"]
        try:
            envelope.insert_step(start_time, max(minimum_duration, info["physical_end"] - start_time), raw_value)
        except Exception:
            pass

        previous_physical_steps = self._expanded_decoupled_automation_steps(info, previous_logical_steps or (), sample_duration)
        seen_times = set()
        for step in previous_physical_steps:
            time_value = max(0.0, min(info["physical_end"], step[0]))
            time_key = int(round(time_value * 1000000.0))
            if time_key in seen_times:
                continue
            seen_times.add(time_key)
            try:
                envelope.insert_step(time_value, max(minimum_duration, sample_duration), raw_value)
            except Exception:
                pass

    def _automation_steps_from_envelope_samples(self, envelope, device_param, start, length, sample_duration):
        if envelope is None or device_param is None or not liveobj_valid(device_param):
            return tuple()

        samples = []
        count = max(2, min(self.AUTOMATION_ENVELOPE_MAX_SAMPLES, int(math.ceil(float(length) / sample_duration)) + 1))
        if count > 1:
            sample_duration = max(0.0001, float(length) / float(count - 1))
        for index in range(count):
            time_value = start + (float(index) * sample_duration)
            try:
                raw_value = envelope.value_at_time(time_value)
                if device_param.max != device_param.min:
                    normalized = (raw_value - device_param.min) / (device_param.max - device_param.min)
                else:
                    normalized = self._parameter_normalized_value(device_param)
            except Exception:
                normalized = self._parameter_normalized_value(device_param)
            samples.append((time_value, max(0.0, min(1.0, normalized))))

        return self._automation_sorted_steps(
            (time_value, sample_duration, normalized, 0.0, 0, 0)
            for time_value, normalized in self._compress_automation_samples(samples)
        )

    def _sampled_decoupled_automation_write_steps(self, info, logical_steps, sample_duration):
        expanded_steps = list(self._expanded_decoupled_automation_steps(info, logical_steps, sample_duration))
        if not expanded_steps:
            return tuple()

        clip_end = info["physical_end"]
        boundary_start = info["note_start"]
        guard_duration = 0.0001
        all_steps = []

        def append_target_step(time_value, duration, normalized, force=False):
            if time_value < -0.000001 or time_value > clip_end + 0.000001:
                return

            time_value = max(0.0, min(clip_end, time_value))
            normalized = max(0.0, min(1.0, normalized))
            if all_steps and not force:
                previous_time, _, previous_value, _ = all_steps[-1]
                if abs(previous_time - time_value) <= 0.000001 and abs(previous_value - normalized) <= self.AUTOMATION_ENVELOPE_LINEAR_EPSILON:
                    return

            all_steps.append((time_value, max(guard_duration, duration), normalized, bool(force)))

        if len(expanded_steps) == 1:
            step = expanded_steps[0]
            append_target_step(step[0], step[1], step[2])
        else:
            for index in range(len(expanded_steps) - 1):
                start_step = expanded_steps[index]
                next_step = expanded_steps[index + 1]
                append_target_step(start_step[0], start_step[1], start_step[2])

                time_value = start_step[0] + sample_duration
                while time_value < next_step[0] - 0.000001:
                    append_target_step(
                        time_value,
                        sample_duration,
                        self._automation_value_from_steps(time_value, expanded_steps)
                    )
                    time_value += sample_duration

            last_step = expanded_steps[-1]
            append_target_step(last_step[0], last_step[1], last_step[2])

        first_step = expanded_steps[0]
        if first_step[0] > boundary_start + guard_duration:
            append_target_step(boundary_start, max(guard_duration, first_step[0] - boundary_start), first_step[2], force=True)

        last_step = expanded_steps[-1]
        if clip_end > last_step[0] + guard_duration:
            append_target_step(clip_end - guard_duration, guard_duration, last_step[2], force=True)

        all_steps.sort(key=lambda item: item[0])
        coalesced_steps = []
        for step in all_steps:
            if not coalesced_steps:
                coalesced_steps.append(step)
                continue

            previous_time, _, previous_value, previous_force = coalesced_steps[-1]
            time_value, _, normalized, force = step
            if abs(previous_time - time_value) <= 0.000001 and abs(previous_value - normalized) <= self.AUTOMATION_ENVELOPE_LINEAR_EPSILON:
                if force and not previous_force:
                    coalesced_steps[-1] = step
                continue
            if not force and not previous_force and abs(previous_time - time_value) > 0.000001 and abs(previous_value - normalized) <= self.AUTOMATION_ENVELOPE_LINEAR_EPSILON:
                continue

            coalesced_steps.append(step)

        return tuple(coalesced_steps)

    def _decoupled_info_for_parameter_key(self, info, parameter_key):
        parameter_info = dict(info)
        parameter_info["parameter_key"] = parameter_key
        parameter_info["has_parameter_length"] = parameter_key in info.get("automation_lengths", {})
        parameter_info["automation_length"] = info.get("automation_lengths", {}).get(parameter_key, info["note_length"])
        return parameter_info

    def _rewrite_decoupled_automation_for_parameter(self, clip, device_param, control_index, info, sample_duration):
        if clip is None or device_param is None or not liveobj_valid(device_param) or not info:
            return

        parameter_key = self._decoupled_automation_parameter_key(device_param)
        if not parameter_key:
            return

        parameter_info = self._decoupled_info_for_parameter_key(info, parameter_key)
        envelope = None
        if hasattr(clip, "automation_envelope"):
            try:
                envelope = clip.automation_envelope(device_param)
            except Exception:
                envelope = None

        authored_steps = self._authored_automation_steps(clip, device_param, control_index)
        if authored_steps is not None:
            logical_steps = self._normalize_decoupled_logical_automation_steps(parameter_info, authored_steps)
        elif envelope is not None:
            logical_steps = self._automation_steps_from_envelope_samples(
                envelope,
                device_param,
                parameter_info["note_start"],
                parameter_info["automation_length"],
                sample_duration
            )
        else:
            return

        if not logical_steps:
            return

        if envelope is None and hasattr(clip, "create_automation_envelope"):
            try:
                envelope = clip.create_automation_envelope(device_param)
            except Exception:
                envelope = None
        if envelope is None:
            return

        write_steps = self._sampled_decoupled_automation_write_steps(parameter_info, logical_steps, sample_duration)
        if not write_steps:
            return

        self._neutralize_decoupled_automation_points(
            envelope,
            device_param,
            parameter_info,
            authored_steps or logical_steps,
            write_steps[0][2],
            sample_duration
        )

        self._write_automation_steps_to_envelope(envelope, device_param, parameter_info, write_steps)
        self._store_authored_automation_steps(clip, device_param, control_index, logical_steps)

    def _write_automation_steps_to_envelope(self, envelope, device_param, info, write_steps):
        if envelope is None or device_param is None or not info or not write_steps:
            return

        minimum_duration = 0.0001
        previous_insert_time = None
        for index, step in enumerate(write_steps):
            time_value, duration, normalized, _ = step
            raw_value = self._parameter_target_value_from_normalized(device_param, normalized)
            if previous_insert_time is not None and time_value <= previous_insert_time:
                time_value = previous_insert_time + minimum_duration

            next_time = write_steps[index + 1][0] if index + 1 < len(write_steps) and write_steps[index + 1][0] > time_value else None
            if next_time is not None:
                duration = max(minimum_duration, next_time - time_value)
            else:
                duration = max(minimum_duration, info["physical_end"] - time_value) if info["physical_end"] > time_value else max(minimum_duration, duration)

            try:
                envelope.insert_step(time_value, duration, raw_value)
                previous_insert_time = time_value
            except Exception:
                pass

    def _track_for_clip(self, clip):
        if clip is None:
            return None

        try:
            selected_track = self.song().view.selected_track
            if selected_track is not None:
                for clip_slot in selected_track.clip_slots:
                    if clip_slot is not None and clip_slot.has_clip and clip_slot.clip == clip:
                        return selected_track
        except Exception:
            pass

        try:
            for track in self.song().tracks:
                for clip_slot in track.clip_slots:
                    if clip_slot is not None and clip_slot.has_clip and clip_slot.clip == clip:
                        return track
        except Exception:
            pass
        return None

    def _all_track_automation_parameter_candidates(self, track):
        if track is None:
            return tuple()

        parameters = []
        seen_parameter_ids = set()
        seen_device_ids = set()

        def add_parameter(parameter):
            if not self._parameter_is_automatable(parameter):
                return
            try:
                identity = self._live_object_identity(parameter)
            except Exception:
                identity = id(parameter)
            if identity in seen_parameter_ids:
                return
            seen_parameter_ids.add(identity)
            parameters.append(parameter)

        def add_devices(devices):
            for device in tuple(devices or ()):
                if not device or not liveobj_valid(device):
                    continue
                try:
                    device_identity = self._live_object_identity(device)
                except Exception:
                    device_identity = id(device)
                if device_identity in seen_device_ids:
                    continue
                seen_device_ids.add(device_identity)

                for parameter in tuple(getattr(device, "parameters", ()) or ()):
                    add_parameter(parameter)

                for chain in tuple(getattr(device, "chains", ()) or ()):
                    if chain and liveobj_valid(chain):
                        add_devices(getattr(chain, "devices", ()))

        try:
            mixer_device = track.mixer_device
            add_parameter(getattr(mixer_device, "volume", None))
            add_parameter(getattr(mixer_device, "panning", None))
            for send in tuple(getattr(mixer_device, "sends", ()) or ()):
                add_parameter(send)
        except Exception:
            pass

        add_devices(getattr(track, "devices", ()))

        # Keep mapped/decorated parameters that are not exposed through the
        # raw device tree (for example some custom Simpler/Wavetable banks).
        for control_index in range(8):
            try:
                add_parameter(self._current_connected_parameter_for_control(control_index))
            except Exception:
                pass

        return tuple(parameters)

    def _clip_automation_parameters(self, clip, info=None):
        track = self._track_for_clip(clip)
        parameters = []
        custom_length_keys = set((info or {}).get("automation_lengths", {}).keys())

        for parameter in self._all_track_automation_parameter_candidates(track):
            has_envelope = False
            if hasattr(clip, "automation_envelope"):
                try:
                    has_envelope = clip.automation_envelope(parameter) is not None
                except Exception:
                    has_envelope = False

            parameter_key = self._decoupled_automation_parameter_key(parameter)
            has_authored_steps = self._authored_automation_steps(clip, parameter, 0) is not None
            if has_envelope or has_authored_steps or parameter_key in custom_length_keys:
                parameters.append(parameter)

        return tuple(parameters)

    def _rewrite_all_decoupled_automation_envelopes(self, clip, info):
        if clip is None or not info:
            return

        sample_duration = 1.0 / 128.0
        for control_index, device_param in enumerate(self._clip_automation_parameters(clip, info)):
            try:
                self._rewrite_decoupled_automation_for_parameter(clip, device_param, control_index, info, sample_duration)
            except Exception as e:
                self._debug_log(
                    "Error rewriting decoupled automation for parameter '{}': {}".format(
                        getattr(device_param, "name", control_index),
                        str(e)
                    )
                )

    def _automation_steps_from_step_source(self, steps, start, length, sample_duration):
        steps = self._automation_sorted_steps(steps or ())
        if not steps:
            return tuple()

        start = max(0.0, float(start))
        length = max(0.0001, float(length))
        count = max(2, min(self.AUTOMATION_ENVELOPE_MAX_SAMPLES, int(math.ceil(length / sample_duration)) + 1))
        if count > 1:
            sample_duration = max(0.0001, length / float(count - 1))

        samples = []
        for index in range(count):
            time_value = start + (float(index) * sample_duration)
            samples.append((time_value, self._automation_value_from_steps(time_value, steps)))

        return self._automation_sorted_steps(
            (time_value, sample_duration, normalized, 0.0, 0, 0)
            for time_value, normalized in self._compress_automation_samples(samples)
        )

    def _couple_decoupled_automation_for_parameter(self, clip, device_param, control_index, info, target_length, sample_duration):
        if clip is None or device_param is None or not liveobj_valid(device_param) or not info:
            return

        parameter_key = self._decoupled_automation_parameter_key(device_param)
        if not parameter_key:
            return

        source_info = self._decoupled_info_for_parameter_key(info, parameter_key)
        target_length = max(0.0001, float(target_length))
        cleanup_length = max(float(info.get("physical_length", target_length)), target_length)
        source_info["physical_length"] = cleanup_length
        source_info["physical_end"] = source_info["note_start"] + cleanup_length

        envelope = None
        if hasattr(clip, "automation_envelope"):
            try:
                envelope = clip.automation_envelope(device_param)
            except Exception:
                envelope = None

        authored_steps = self._authored_automation_steps(clip, device_param, control_index)
        if authored_steps is not None:
            logical_steps = self._normalize_decoupled_logical_automation_steps(source_info, authored_steps)
        elif envelope is not None:
            logical_steps = self._automation_steps_from_envelope_samples(
                envelope,
                device_param,
                source_info["note_start"],
                source_info["automation_length"],
                sample_duration
            )
        else:
            return

        if not logical_steps:
            return

        expanded_steps = self._expanded_decoupled_automation_steps(source_info, logical_steps, sample_duration)
        coupled_steps = self._automation_steps_from_step_source(
            expanded_steps,
            source_info["note_start"],
            target_length,
            sample_duration
        )
        if not coupled_steps:
            return

        if envelope is None and hasattr(clip, "create_automation_envelope"):
            try:
                envelope = clip.create_automation_envelope(device_param)
            except Exception:
                envelope = None
        if envelope is None:
            return

        coupled_info = {
            "note_start": source_info["note_start"],
            "note_length": target_length,
            "note_end": source_info["note_start"] + target_length,
            "automation_lengths": {},
            "automation_length": target_length,
            "physical_length": target_length,
            "physical_end": source_info["note_start"] + target_length,
        }
        write_steps = self._sampled_decoupled_automation_write_steps(coupled_info, coupled_steps, sample_duration)
        if not write_steps:
            return

        self._neutralize_decoupled_automation_points(
            envelope,
            device_param,
            source_info,
            logical_steps,
            write_steps[0][2],
            sample_duration
        )
        self._write_automation_steps_to_envelope(envelope, device_param, coupled_info, write_steps)
        self._store_authored_automation_steps(clip, device_param, control_index, coupled_steps)

    def _couple_decoupled_automation_to_loop_length(self, clip, target_length):
        info = self._decoupled_automation_info(clip)
        if not info:
            return False

        sample_duration = 1.0 / 128.0
        for control_index, device_param in enumerate(self._clip_automation_parameters(clip, info)):
            try:
                self._couple_decoupled_automation_for_parameter(clip, device_param, control_index, info, target_length, sample_duration)
            except Exception as e:
                self._debug_log(
                    "Error coupling decoupled automation for parameter '{}': {}".format(
                        getattr(device_param, "name", control_index),
                        str(e)
                    )
                )

        self._remove_decoupled_automation_info_from_name(clip)
        return True

    def _duplicate_loop_automation_to_loop_length(self, clip, source_start, source_length, target_length):
        if clip is None:
            return False

        source_start = max(0.0, float(source_start))
        source_length = max(0.0001, float(source_length))
        target_length = max(source_length, float(target_length))
        sample_duration = 1.0 / 128.0
        duplicated_any = False

        for control_index, device_param in enumerate(self._clip_automation_parameters(clip)):
            try:
                if self._duplicate_loop_automation_for_parameter(
                    clip,
                    device_param,
                    control_index,
                    source_start,
                    source_length,
                    target_length,
                    sample_duration
                ):
                    duplicated_any = True
            except Exception as e:
                self._debug_log(
                    "Error duplicating loop automation for parameter '{}': {}".format(
                        getattr(device_param, "name", control_index),
                        str(e)
                    )
                )

        return duplicated_any

    def _double_decoupled_loop_automation(self, clip, previous_info, doubled_info):
        if clip is None:
            return False

        source_start = previous_info["note_start"]
        previous_note_length = previous_info["note_length"]
        doubled_note_length = doubled_info["note_length"]
        previous_lengths = previous_info.get("automation_lengths", {})
        doubled_lengths = doubled_info.get("automation_lengths", {})
        sample_duration = 1.0 / 128.0
        duplicated_any = False

        for control_index, device_param in enumerate(self._clip_automation_parameters(clip, previous_info)):
            try:
                parameter_key = self._decoupled_automation_parameter_key(device_param)
                source_length = previous_lengths.get(parameter_key, previous_note_length)
                target_length = doubled_lengths.get(parameter_key, doubled_note_length)
                if self._duplicate_loop_automation_for_parameter(
                    clip,
                    device_param,
                    control_index,
                    source_start,
                    source_length,
                    target_length,
                    sample_duration
                ):
                    duplicated_any = True
            except Exception as e:
                self._debug_log(
                    "Error doubling decoupled loop automation for parameter '{}': {}".format(
                        getattr(device_param, "name", control_index),
                        str(e)
                    )
                )

        self._rewrite_all_decoupled_automation_envelopes(clip, doubled_info)
        return duplicated_any

    def _double_decoupled_loop(self, clip, previous_info):
        note_start = previous_info["note_start"]
        previous_note_length = previous_info["note_length"]
        doubled_note_length = previous_note_length * 2.0
        max_physical_length = self._decoupled_automation_max_physical_length(clip, doubled_note_length)
        doubled_lengths = {}
        for parameter_key, previous_length in previous_info.get("automation_lengths", {}).items():
            try:
                doubled_length = min(max_physical_length, max(0.0001, float(previous_length)) * 2.0)
                if abs(doubled_length - doubled_note_length) > 0.000001:
                    doubled_lengths[parameter_key] = doubled_length
            except Exception:
                pass

        physical_length = self._decoupled_physical_length(
            doubled_note_length,
            doubled_lengths.values(),
            max_physical_length
        )
        doubled_info = {
            "note_start": note_start,
            "note_length": doubled_note_length,
            "note_end": note_start + doubled_note_length,
            "automation_lengths": doubled_lengths,
            "automation_length": doubled_note_length,
            "physical_length": physical_length,
            "physical_end": note_start + physical_length,
            "remove_start": note_start,
        }

        clip.loop_start = note_start
        clip.start_marker = min(float(getattr(clip, "start_marker", note_start)), note_start)
        clip.loop_end = doubled_info["physical_end"]
        clip.end_marker = doubled_info["physical_end"]
        self._double_decoupled_note_copies(clip, previous_info, doubled_info)
        self._double_decoupled_loop_automation(clip, previous_info, doubled_info)

        if doubled_lengths:
            self._save_decoupled_automation_info_to_name(clip, doubled_info)
        else:
            self._remove_decoupled_automation_info_from_name(clip)
        return doubled_info

    def _duplicate_loop_automation_for_parameter(self, clip, device_param, control_index, source_start, source_length, target_length, sample_duration):
        if clip is None or device_param is None or not liveobj_valid(device_param):
            return False

        envelope = None
        if hasattr(clip, "automation_envelope"):
            try:
                envelope = clip.automation_envelope(device_param)
            except Exception:
                envelope = None

        authored_steps = self._authored_automation_steps(clip, device_param, control_index)
        if authored_steps is not None:
            logical_steps = self._automation_steps_from_step_source(
                authored_steps,
                source_start,
                source_length,
                sample_duration
            )
        elif envelope is not None:
            logical_steps = self._automation_steps_from_envelope_samples(
                envelope,
                device_param,
                source_start,
                source_length,
                sample_duration
            )
        else:
            return False

        if not logical_steps:
            return False

        expanded_source_length = source_length * max(1, int(math.ceil(target_length / source_length)))
        loop_info = {
            "note_start": source_start,
            "note_length": source_length,
            "note_end": source_start + source_length,
            "automation_lengths": {},
            "automation_length": source_length,
            "physical_length": expanded_source_length,
            "physical_end": source_start + expanded_source_length,
        }
        logical_steps = self._normalize_decoupled_logical_automation_steps(loop_info, logical_steps)
        if not logical_steps:
            return False

        expanded_steps = self._expanded_decoupled_automation_steps(loop_info, logical_steps, sample_duration)
        duplicated_steps = self._automation_steps_from_step_source(
            expanded_steps,
            source_start,
            target_length,
            sample_duration
        )
        if not duplicated_steps:
            return False

        coupled_info = {
            "note_start": source_start,
            "note_length": target_length,
            "note_end": source_start + target_length,
            "automation_lengths": {},
            "automation_length": target_length,
            "physical_length": target_length,
            "physical_end": source_start + target_length,
        }
        write_steps = self._sampled_decoupled_automation_write_steps(coupled_info, duplicated_steps, sample_duration)
        if not write_steps:
            return False

        if envelope is None and hasattr(clip, "create_automation_envelope"):
            try:
                envelope = clip.create_automation_envelope(device_param)
            except Exception:
                envelope = None
        if envelope is None:
            return False

        automation_should_re_enable = self._parameter_automation_is_enabled(device_param) or envelope is not None
        self._neutralize_decoupled_automation_points(
            envelope,
            device_param,
            coupled_info,
            duplicated_steps,
            write_steps[0][2],
            sample_duration
        )
        self._write_automation_steps_to_envelope(envelope, device_param, coupled_info, write_steps)
        self._store_authored_automation_steps(clip, device_param, control_index, duplicated_steps)
        self._re_enable_after_automation_write(device_param, automation_should_re_enable)
        return True

    def _merge_decoupled_automation_span(self, previous_steps, edited_steps, page_start, page_end):
        edited_steps = tuple(edited_steps or ())
        if previous_steps is None:
            return self._automation_sorted_steps(edited_steps)

        epsilon = 0.000001
        outside_steps = [
            step for step in previous_steps
            if step[0] < page_start - epsilon or step[0] > page_end + epsilon
        ]
        return self._automation_sorted_steps(outside_steps + list(edited_steps))

    def _normalize_decoupled_logical_automation_steps(self, info, steps):
        if not info:
            return tuple(steps or ())

        loop_start = info["note_start"]
        loop_end = info["note_start"] + info["automation_length"]
        epsilon = 0.000001
        normalized_steps = []
        for index, step in enumerate(tuple(steps or ())):
            time_value, duration, normalized, curve, step_id, step_order = self._automation_step_tuple(step, index)
            if time_value < loop_start - epsilon or time_value > loop_end + epsilon:
                continue
            folded_time = loop_end if time_value >= loop_end - epsilon else max(loop_start, time_value)
            normalized_steps.append((folded_time, duration, normalized, curve, step_id, step_order))

        return self._automation_sorted_steps(normalized_steps)

    def _follow_action_name_payload(self, rule):
        action_a, action_b = rule.get("actions", ({}, {}))
        return "|".join([
            str(max(1, int(rule.get("play_count", 1)))),
            str(max(0, min(100, int(rule.get("chance_a", 100))))),
            self._normalize_follow_action(action_a.get("type", "")),
            "" if action_a.get("jump_index") is None else str(int(action_a.get("jump_index"))),
            self._normalize_follow_action(action_b.get("type", "")),
            "" if action_b.get("jump_index") is None else str(int(action_b.get("jump_index"))),
        ])

    def _follow_action_marker_for_rule(self, rule):
        return "[TapFA:v1|{}]".format(self._follow_action_name_payload(rule))

    def _decode_follow_action_name_payload(self, payload, target_kind, track_index, scene_index):
        fields = str(payload or "").split("|")
        if len(fields) != 6:
            return None

        try:
            play_count = max(1, int(fields[0]))
            chance_a = max(0, min(100, int(fields[1])))
            action_a = self._normalize_follow_action(fields[2])
            jump_a = int(fields[3]) if fields[3] != "" else None
            action_b = self._normalize_follow_action(fields[4])
            jump_b = int(fields[5]) if fields[5] != "" else None
        except Exception:
            return None

        return {
            "target_kind": target_kind,
            "track_index": track_index,
            "scene_index": scene_index,
            "play_count": play_count,
            "chance_a": chance_a,
            "actions": (
                {"type": action_a, "jump_index": jump_a},
                {"type": action_b, "jump_index": jump_b},
            ),
        }

    def _follow_action_rule_from_name(self, name, target_kind, track_index, scene_index):
        matches = self.FOLLOW_ACTION_NAME_MARKER_RE.findall(str(name or ""))
        if not matches:
            return None
        return self._decode_follow_action_name_payload(matches[-1], target_kind, track_index, scene_index)

    def _follow_action_name_target(self, target_kind, track_index, scene_index):
        try:
            if target_kind == "clip":
                clip_slot = self.song().tracks[track_index].clip_slots[scene_index]
                if clip_slot.has_clip:
                    return clip_slot.clip
                return None
            if target_kind == "scene":
                return self.song().scenes[scene_index]
        except Exception:
            return None
        return None

    def _save_follow_action_rule_to_name(self, rule):
        target = self._follow_action_name_target(
            rule.get("target_kind"),
            rule.get("track_index"),
            rule.get("scene_index")
        )
        if target is None or not hasattr(target, "name"):
            return

        try:
            clean_name = self._strip_follow_action_name_marker(target.name)
            marker = self._follow_action_marker_for_rule(rule)
            new_name = "{} {}".format(clean_name, marker).strip() if clean_name else marker
            if target.name != new_name:
                target.name = new_name
        except Exception:
            pass

    def _remove_follow_action_rule_from_name(self, target_kind, track_index, scene_index):
        target = self._follow_action_name_target(target_kind, track_index, scene_index)
        if target is None or not hasattr(target, "name"):
            return

        try:
            clean_name = self._strip_follow_action_name_marker(target.name)
            if target.name != clean_name:
                target.name = clean_name
        except Exception:
            pass

    def _load_follow_actions_from_names(self, force_send=False):
        loaded_rules = {}

        try:
            for scene_index, scene in enumerate(self.song().scenes):
                rule = self._follow_action_rule_from_name(scene.name, "scene", None, scene_index)
                if rule:
                    loaded_rules[self._follow_action_key("scene", None, scene_index)] = rule

            for track_index, track in enumerate(self.song().tracks):
                for scene_index, clip_slot in enumerate(track.clip_slots):
                    if not clip_slot.has_clip:
                        continue
                    rule = self._follow_action_rule_from_name(clip_slot.clip.name, "clip", track_index, scene_index)
                    if rule:
                        loaded_rules[self._follow_action_key("clip", track_index, scene_index)] = rule
        except Exception:
            return

        if force_send or loaded_rules != self._follow_action_rules:
            self._follow_action_rules = loaded_rules
            self._active_follow_actions = {}
            self._handled_follow_action_launches = set()
            self._follow_action_missing_clip_counts = {}
            self._last_follow_action_state = None
            self._send_follow_action_state(force=True)

    def _decode_follow_action_rule(self, message):
        try:
            raw_payload = bytes(self._follow_action_payload_bytes(message)).decode("ascii")
        except Exception:
            return None

        fields = self._split_escaped_sysex_fields(raw_payload, "|")
        if len(fields) < 9:
            return None

        try:
            target_kind = self._unescape_sysex_string(fields[0])
            track_index = int(fields[1]) if fields[1] != "" else None
            scene_index = int(fields[2])
            play_count = max(1, int(fields[3]))
            chance_a = max(0, min(100, int(fields[4])))
            action_a = self._normalize_follow_action(fields[5])
            jump_a = int(fields[6]) if fields[6] != "" else None
            action_b = self._normalize_follow_action(fields[7])
            jump_b = int(fields[8]) if fields[8] != "" else None
        except Exception as error:
            return None

        if target_kind not in ("clip", "scene"):
            return None

        return {
            "target_kind": target_kind,
            "track_index": track_index,
            "scene_index": scene_index,
            "play_count": play_count,
            "chance_a": chance_a,
            "actions": (
                {"type": action_a, "jump_index": jump_a},
                {"type": action_b, "jump_index": jump_b},
            ),
        }

    def _set_follow_action_rule(self, message):
        rule = self._decode_follow_action_rule(message)
        if not rule:
            return
        key = self._follow_action_key(rule["target_kind"], rule.get("track_index"), rule["scene_index"])
        self._follow_action_rules[key] = rule
        self._save_follow_action_rule_to_name(rule)
        self._sync_follow_action_name_listeners()
        self._send_follow_action_state()

    def _delete_follow_action_rule(self, message):
        try:
            raw_payload = bytes(self._follow_action_payload_bytes(message)).decode("ascii")
            fields = self._split_escaped_sysex_fields(raw_payload, "|")
            target_kind = self._unescape_sysex_string(fields[0])
            track_index = int(fields[1]) if fields[1] != "" else None
            scene_index = int(fields[2])
            key = self._follow_action_key(target_kind, track_index, scene_index)
            if key in self._follow_action_rules:
                del self._follow_action_rules[key]
            self._remove_follow_action_rule_from_name(target_kind, track_index, scene_index)
            if key in self._active_follow_actions:
                del self._active_follow_actions[key]
            self._handled_follow_action_launches.discard(key)
            self._follow_action_missing_clip_counts.pop(key, None)
            self._sync_follow_action_name_listeners()
        except Exception:
            pass
        self._send_follow_action_state()

    def _activate_follow_action_for_clip(self, track_index, scene_index, clip_slot):
        if not clip_slot or not clip_slot.has_clip:
            return
        key = self._follow_action_key("clip", track_index, scene_index)
        if key in self._handled_follow_action_launches:
            return
        rule = self._follow_action_rules.get(key)
        if not rule:
            return

        self._active_follow_actions[key] = {
            "key": key,
            "rule": rule,
            "target_kind": "clip",
            "track_index": track_index,
            "scene_index": scene_index,
            "clip_slot": clip_slot,
            "started_at": None,
            "waiting_for_launch": (not clip_slot.is_playing) or self._clip_slot_is_triggered(clip_slot),
            "executed": False,
        }
        self._send_follow_action_state()

    def _activate_follow_action_for_scene(self, scene_index):
        key = self._follow_action_key("scene", None, scene_index)
        if key in self._handled_follow_action_launches:
            return
        rule = self._follow_action_rules.get(key)
        if not rule:
            self._send_follow_action_state()
            return

        self._active_follow_actions[key] = {
            "key": key,
            "rule": rule,
            "target_kind": "scene",
            "track_index": None,
            "scene_index": scene_index,
            "started_at": None,
            "waiting_for_launch": True,
            "executed": False,
        }
        self._send_follow_action_state()

    def _evaluate_follow_actions(self):
        self._clear_finished_follow_action_launches()
        if not self._active_follow_actions:
            return

        try:
            song_time = float(self.song().current_song_time)
        except Exception:
            return

        changed = False
        active_items = sorted(
            list(self._active_follow_actions.items()),
            key=lambda item: 1 if item[1].get("target_kind") == "scene" else 0
        )

        for key, active in active_items:
            if key not in self._active_follow_actions or active.get("executed"):
                continue

            target_kind = active.get("target_kind")
            scene_index = active.get("scene_index")
            clip_slot = active.get("clip_slot")

            if target_kind == "clip":
                if not clip_slot or not clip_slot.has_clip:
                    del self._active_follow_actions[key]
                    changed = True
                    continue
                if not clip_slot.is_playing:
                    if self._clip_slot_is_triggered(clip_slot):
                        continue
                    del self._active_follow_actions[key]
                    changed = True
                    continue
                if active.get("waiting_for_launch"):
                    if self._clip_slot_is_triggered(clip_slot):
                        continue
                    active["waiting_for_launch"] = False
                    active["started_at"] = song_time
                    changed = True
                    continue
                base_length = self._clip_slot_length_beats(clip_slot)
            else:
                if not self._scene_is_playing(scene_index):
                    if active.get("waiting_for_launch") and self._scene_is_triggered(scene_index):
                        continue
                    del self._active_follow_actions[key]
                    changed = True
                    continue
                if active.get("waiting_for_launch"):
                    if self._scene_is_triggered(scene_index):
                        continue
                    active["waiting_for_launch"] = False
                    active["started_at"] = song_time
                    changed = True
                    continue
                base_length = self._scene_length_beats(scene_index)

            if base_length <= 0.0:
                continue

            if active.get("started_at") is None:
                active["started_at"] = song_time

            rule = active.get("rule", {})
            total_beats = base_length * max(1, int(rule.get("play_count", 1)))
            launch_quantization_beats = self._get_global_launch_quantization_beats()
            trigger_after = max(0.0, total_beats - launch_quantization_beats)

            if song_time - active["started_at"] >= trigger_after:
                active["executed"] = True
                del self._active_follow_actions[key]
                launched_key = self._execute_follow_action(active)
                if launched_key != key:
                    self._handled_follow_action_launches.add(key)
                changed = True

        if changed:
            self._send_follow_action_state()

    def _choose_follow_action(self, rule):
        chance_a = max(0, min(100, int(rule.get("chance_a", 100))))
        return rule.get("actions", ({}, {}))[0 if random.randint(1, 100) <= chance_a else 1]

    def _execute_follow_action(self, active):
        rule = active.get("rule", {})
        action = self._choose_follow_action(rule)
        action_type = action.get("type")
        if action_type in (None, "", "none"):
            return None

        if active.get("target_kind") == "scene":
            return self._execute_scene_follow_action(active.get("scene_index"), action)
        else:
            return self._execute_clip_follow_action(active.get("track_index"), active.get("scene_index"), action)

    def _valid_scene_indexes(self):
        return [index for index, _ in enumerate(self.song().scenes) if self._scene_has_clip(index)]

    def _valid_clip_indexes(self, track_index):
        try:
            return [index for index, clip_slot in enumerate(self.song().tracks[track_index].clip_slots) if clip_slot.has_clip]
        except Exception:
            return []

    def _pick_index_for_action(self, indexes, current_index, action):
        action_type = action.get("type")
        if not indexes:
            return None
        if action_type == "first":
            return indexes[0]
        if action_type == "last":
            return indexes[-1]
        if action_type == "previous":
            previous = [index for index in indexes if index < current_index]
            return previous[-1] if previous else indexes[-1]
        if action_type == "next":
            next_indexes = [index for index in indexes if index > current_index]
            return next_indexes[0] if next_indexes else indexes[0]
        if action_type == "any":
            return random.choice(indexes)
        if action_type == "other":
            other_indexes = [index for index in indexes if index != current_index]
            return random.choice(other_indexes or indexes)
        if action_type == "jump":
            jump_index = action.get("jump_index")
            return jump_index if jump_index in indexes else None
        if action_type == "play_again":
            return current_index
        return None

    def _execute_scene_follow_action(self, scene_index, action):
        action_type = action.get("type")
        if action_type == "stop":
            self.song().stop_all_clips()
            return
        if action_type == "jump":
            target_index = action.get("jump_index")
        else:
            target_index = self._pick_index_for_action(self._valid_scene_indexes(), scene_index, action)
        if target_index is not None and target_index < len(self.song().scenes):
            self.song().scenes[target_index].fire()
            target_key = self._follow_action_key("scene", None, target_index)
            self._handled_follow_action_launches.discard(target_key)
            self._activate_follow_action_for_scene(target_index)
            return target_key
        return None

    def _execute_clip_follow_action(self, track_index, scene_index, action):
        try:
            track = self.song().tracks[track_index]
            clip_slot = track.clip_slots[scene_index]
        except Exception:
            return

        action_type = action.get("type")
        if action_type == "stop":
            clip_slot.stop()
            return None

        if action_type == "jump":
            target_index = action.get("jump_index")
        else:
            target_index = self._pick_index_for_action(self._valid_clip_indexes(track_index), scene_index, action)
        if target_index is not None and 0 <= target_index < len(track.clip_slots):
            target_slot = track.clip_slots[target_index]
            target_slot.fire()
            target_key = self._follow_action_key("clip", track_index, target_index)
            self._handled_follow_action_launches.discard(target_key)
            self._activate_follow_action_for_clip(track_index, target_index, target_slot)
            return target_key
        return None

    def _encode_follow_action_rule(self, rule):
        action_a, action_b = rule.get("actions", ({}, {}))
        return "|".join([
            "rule",
            rule.get("target_kind", ""),
            "" if rule.get("track_index") is None else str(rule.get("track_index")),
            str(rule.get("scene_index", 0)),
            str(rule.get("play_count", 1)),
            str(rule.get("chance_a", 100)),
            action_a.get("type", ""),
            "" if action_a.get("jump_index") is None else str(action_a.get("jump_index")),
            action_b.get("type", ""),
            "" if action_b.get("jump_index") is None else str(action_b.get("jump_index")),
        ])

    def _send_follow_action_state(self, force=False):
        rules = [self._encode_follow_action_rule(rule) for rule in self._follow_action_rules.values()]
        for active in self._active_follow_actions.values():
            rule = active.get("rule", {})
            rules.append("|".join([
                "active",
                active.get("target_kind", ""),
                "" if active.get("track_index") is None else str(active.get("track_index")),
                str(active.get("scene_index", 0)),
                "1",
            ]))
        payload = ";".join(rules)
        if force or payload != self._last_follow_action_state:
            self._last_follow_action_state = payload
            if not self.was_initialized:
                return
            self._send_sys_ex_message(payload, 0x18)

    def _reconcile_follow_action_rules(self, force=False, remove_missing_clips=True):
        changed = False
        reconciled_rules = {}
        seen_keys = set()

        for key, rule in self._follow_action_rules.items():
            target_kind = rule.get("target_kind")
            scene_index = rule.get("scene_index")

            if target_kind == "clip":
                track_index = rule.get("track_index")
                try:
                    clip_slot = self.song().tracks[track_index].clip_slots[scene_index]
                    if not clip_slot.has_clip:
                        if remove_missing_clips:
                            missing_count = self._follow_action_missing_clip_counts.get(key, 0) + 1
                            self._follow_action_missing_clip_counts[key] = missing_count
                            if missing_count >= 4:
                                changed = True
                                self._follow_action_missing_clip_counts.pop(key, None)
                                continue
                        else:
                            self._follow_action_missing_clip_counts.pop(key, None)
                    else:
                        self._follow_action_missing_clip_counts.pop(key, None)
                except Exception:
                    changed = True
                    self._follow_action_missing_clip_counts.pop(key, None)
                    continue

                key = self._follow_action_key("clip", track_index, scene_index)
                seen_keys.add(key)
                reconciled_rules[key] = rule

            elif target_kind == "scene":
                try:
                    if scene_index is None or scene_index >= len(self.song().scenes):
                        changed = True
                        continue
                except Exception:
                    changed = True
                    continue

                key = self._follow_action_key("scene", None, scene_index)
                seen_keys.add(key)
                reconciled_rules[key] = rule

        for missing_key in list(self._follow_action_missing_clip_counts.keys()):
            if missing_key not in seen_keys:
                self._follow_action_missing_clip_counts.pop(missing_key, None)

        if force or changed:
            self._follow_action_rules = reconciled_rules
            self._active_follow_actions = {
                key: active for key, active in self._active_follow_actions.items()
                if key in self._follow_action_rules
            }
            self._handled_follow_action_launches = {
                key for key in self._handled_follow_action_launches
                if key in self._follow_action_rules
            }
            self._send_follow_action_state()

    def _redo_button_value(self, value):
        if value != 0:
            song = self.song()
            if song.can_redo:
                song.redo()
                # self._periodic_check()

    def _undo_button_value(self, value):
        if value != 0:
            song = self.song()
            if song.can_undo:
                song.undo()
                # self._periodic_check()

    def _sesh_record_value(self, value):
        if value != 0:
            song = self.song()
            record = bool(song.session_record)
            if not record:
                clip_slot = song.view.highlighted_clip_slot
                clip = clip_slot.clip if clip_slot is not None and clip_slot.has_clip else None
                if self._decoupled_automation_info(clip):
                    self._begin_decoupled_automation_recording_tracking(clip)
                else:
                    # Ordinary clip recording must not create or alter TapAuto
                    # metadata.
                    self._decoupled_automation_recording_generation += 1
                    self._decoupled_automation_recording_active = False
                    self._decoupled_automation_recording_snapshots = {}
                song.session_record = True
            else:
                song.session_record = False
                self._finish_decoupled_automation_recording_tracking()
            self._send_session_record_state(force=True)
            self._set_up_notes_playing("clip")

    def _capture_button_value(self, value):
        if value != 0:
            self.song().capture_midi()
            self._set_up_notes_playing("clip")

    def _quantize_grid_value(self, value):
        global quantize_grid_value
        quantize_grid_value = value

    def _quantize_strength_value(self, value):
        global quantize_strength_value
        quantize_strength_value = value / 100.0

    def _swing_amount_value(self, value):
        global swing_amount_value
        swing_amount_value = value / 100.0
        try:
            self.song().swing_amount = swing_amount_value
        except Exception:
            pass
        self._send_note_repeat_state(force=True)

    def _quantize_button_value(self, value):
        if value != 0:
            clip = self.song().view.detail_clip
            if clip:
                # need to set the swing amount first (0.00-1.00)
                self.song().swing_amount = swing_amount_value
                # grid (int 1 == 1/4, 2 == 1/8, 5 == 1/16, 8 = 1/32), strength (0.50 == 50%)
                clip.quantize(quantize_grid_value, quantize_strength_value)

    def _duplicate_button_value(self, value):
        if value != 0:
            self._duplicate_clip()

    def _duplicate_scene_button_value(self, value):
        if value != 0:
            song = self.song()
            selected_scene = song.view.selected_scene
            all_scenes = song.scenes
            current_index = list(all_scenes).index(selected_scene)
            song.duplicate_scene(current_index)
            destination_index = current_index + 1
            self._shift_follow_actions_after_scene_insert(destination_index)
            self._duplicate_follow_actions_for_scene(current_index, destination_index)
            self._send_follow_action_state()

    def _add_empty_clip(self, value):
        """
        Adds an empty clip at the currently highlighted track and scene.
        The clip length matches the time signature numerator (one full bar).
        """
        if value != 0:
            song = self.song()
            selected_track = song.view.selected_track
    
            if selected_track is None:
                return
            
            selected_scene = song.view.selected_scene
            all_scenes = song.scenes
            scene_index = list(all_scenes).index(selected_scene)
        
            clip_slot = selected_track.clip_slots[scene_index]
            
            if clip_slot.has_clip:
                return  # Avoid overwriting an existing clip
            
            clip_length = song.signature_numerator  # Use the time signature numerator for one full bar
            clip_slot.create_clip(clip_length)
            
            # lil trick to get the clip metadata to fire
            if self.seq_status:
                if self.device_status:
                    self.start_step_seq()
    
    def _create_new_empty_clip(self, value):
        """
        Creates an empty clip at the next empty the slot in the currently highlighted track.
        The clip length matches the time signature numerator (one full bar).
        """
        if value != 0:
            song = self.song()
            selected_track = song.view.selected_track
    
            if selected_track is None:
                return
            
            selected_scene = song.view.selected_scene
            all_scenes = song.scenes
            scene_index = list(all_scenes).index(selected_scene)
            destination_scene_index = len(all_scenes)
    
            # check if there is a free clip slot after the current clip
            for index, clip_slot in enumerate(selected_track.clip_slots):
                if index <= scene_index:
                    continue
                if clip_slot.has_clip:
                    continue
                destination_scene_index = index
                break
    
            if destination_scene_index == len(all_scenes):
                # create a new scene if there is no free slot after the current slot
                song.create_scene(-1)
        
            # adding empty clip at next empty scene
            clip_slot = selected_track.clip_slots[destination_scene_index]
            clip_length = song.signature_numerator  # Use the time signature numerator for one full bar
            clip_slot.create_clip(clip_length)
            
            # selecting the empty scene
            song.view.selected_scene = song.scenes[destination_scene_index]
    
    def _select_playing_clip(self, value):
        if value != 0:
            song = self.song()
            selected_track = song.view.selected_track
    
            if selected_track is None:
                return
            
            for index, clip_slot in enumerate(selected_track.clip_slots):
                if clip_slot.is_playing:
                    song.view.selected_scene = song.scenes[index]
                    break
    
    def _crop_clip(self, value):
        if value != 0:
            song = self.song()
            clip_slot = song.view.highlighted_clip_slot
            
            if clip_slot and clip_slot.has_clip:
                clip = clip_slot.clip
                clip.crop()
    
    def _duplicate_clip(self):
        song = self.song()
        selected_track = song.view.selected_track

        if selected_track is None:
            return

        selected_scene = song.view.selected_scene
        all_scenes = song.scenes
        scene_index = list(all_scenes).index(selected_scene)
        track_index = list(song.tracks).index(selected_track)
        destination_scene_index = len(all_scenes)

        source_clip_slot = selected_track.clip_slots[scene_index]
        if source_clip_slot is None or not source_clip_slot.has_clip:
            return

        # Keep the launch decision tied to the slot being duplicated. Live's
        # highlighted slot can temporarily lag behind selected scene changes.
        was_playing = bool(source_clip_slot.is_playing)

        # check if there is a free clip slot after the current clip
        for index, clip_slot in enumerate(selected_track.clip_slots):
            if index <= scene_index:
                continue
            if clip_slot.has_clip:
                continue
            destination_scene_index = index
            break

        if destination_scene_index == len(all_scenes):
            # create a new scene if there is no free slot after the current slot
            song.create_scene(-1)

        self._copy_paste_clip(track_index, scene_index, track_index, destination_scene_index)
        destination_clip_slot = selected_track.clip_slots[destination_scene_index]

        # select newly created clip
        song.view.selected_scene = song.scenes[destination_scene_index]
        song.view.highlighted_clip_slot = destination_clip_slot
        # fire the new clip if the old clip was playing
        if was_playing:
            destination_clip_slot.fire(force_legato=True)
        
        # set up everything new
        self._on_selected_track_changed()

    @subject_slot('selected_track')
    def _on_selected_track_changed(self):
        if self.was_initialized:
            selected_track = self.song().view.selected_track
            track_control_selected = self._track_device_is_selected(selected_track)
            self._track_device_selected = track_control_selected
            track_has_midi_input = 0
            if selected_track and selected_track.has_midi_input:
                self._set_selected_track_implicit_arm()
                track_has_midi_input = 1
            self._set_up_notes_playing(selected_track)
            self._set_other_tracks_implicit_arm()
            # send new index of selected track
            self._send_selected_track_index(selected_track)
            self._restore_note_repeat_for_selected_track(force_feedback=True)
            self._on_selected_scene_changed()
            # send sys ex of track midi input status.
            self._send_sys_ex_message(str(track_has_midi_input), 0x0B)
            # TODO: this part doesn't seem to work? how can I make this work with master and return?
            device_to_select = selected_track.view.selected_device
            if device_to_select is None and len(selected_track.devices) > 0:
                device_to_select = selected_track.devices[0]
            if track_control_selected:
                self._last_automation_signature = None
                self._on_device_changed()
            elif device_to_select is not None:
                self._track_change_in_progress = True
                self.song().view.select_device(device_to_select)
                self._track_change_in_progress = False
                self._device_component.set_device(device_to_select)
                self._last_automation_signature = None
                self._on_device_changed()
            else:
                self._device_component.set_device(device_to_select)
                self._last_automation_signature = None
                self._on_device_changed()
            self._check_clip_playing_status(force=True)
            if self.seq_status:
                if self.device_status:
                    self.start_step_seq()

    def _set_up_notes_playing(self, selected_track):
        if selected_track == "clip":
            selected_track = self.song().view.selected_track
        else:
            self._previous_selected_track = selected_track

        desired_clips = {}
        if selected_track is not None and liveobj_valid(selected_track) and selected_track.has_midi_input:
            desired_clips = {
                clip_index: clip_slot.clip
                for clip_index, clip_slot in enumerate(selected_track.clip_slots)
                if clip_slot is not None and clip_slot.has_clip
            }

        # Reconcile exact clip objects, not only scene indexes. A duplicated,
        # deleted, or replaced clip can occupy the same slot index while the old
        # Live object still owns our listener.
        for clip_index, (old_clip, listener) in list(self._playing_position_listener_clips.items()):
            desired_clip = desired_clips.get(clip_index)
            if desired_clip is not None and not liveobj_changed(old_clip, desired_clip):
                continue
            try:
                if liveobj_valid(old_clip) and old_clip.playing_position_has_listener(listener):
                    old_clip.remove_playing_position_listener(listener)
            except Exception:
                pass
            self._remove_playing_note_cache_listener(old_clip)
            self._playing_position_listener_clips.pop(clip_index, None)
            if clip_index < len(self.playing_position_listeners):
                self.playing_position_listeners[clip_index] = None

        for clip_index, clip in desired_clips.items():
            existing = self._playing_position_listener_clips.get(clip_index)
            if existing is None:
                listener = lambda index=clip_index: self._clip_pos_changed(index)
                try:
                    if not clip.playing_position_has_listener(listener):
                        clip.add_playing_position_listener(listener)
                    self._playing_position_listener_clips[clip_index] = (clip, listener)
                    if clip_index >= len(self.playing_position_listeners):
                        self.playing_position_listeners.extend(
                            [None] * (clip_index + 1 - len(self.playing_position_listeners))
                        )
                    self.playing_position_listeners[clip_index] = listener
                except Exception as e:
                    self._debug_log("Exception adding clip position listener: {}".format(str(e)))

    def _playing_note_snapshot(self, clip):
        clip_start = min(clip.start_time, clip.start_marker, clip.loop_start) - self.clip_length_trick
        time_span = (
            max(clip.loop_end, clip.end_marker, clip.length) + self.clip_length_trick
        ) - clip_start
        raw_notes = clip.get_notes_extended(0, 128, clip_start, time_span)
        return tuple(
            (midi_note.pitch, midi_note.start_time, midi_note.start_time + midi_note.duration)
            for midi_note in raw_notes
        )

    def _refresh_playing_note_cache(self, clip):
        try:
            if not liveobj_valid(clip) or not getattr(clip, "is_midi_clip", False):
                self._playing_note_cache.pop(clip, None)
                self._playing_note_cache_dirty.discard(clip)
                return False
            self._playing_note_cache[clip] = self._playing_note_snapshot(clip)
            self._playing_note_cache_dirty.discard(clip)
            return True
        except Exception as e:
            self._playing_note_cache.pop(clip, None)
            self._playing_note_cache_dirty.add(clip)
            self._debug_log("Exception refreshing playing-note cache: {}".format(str(e)))
            return False

    def _ensure_playing_note_cache_listener(self, clip):
        listener = self._playing_note_cache_listeners.get(clip)
        if listener is None:
            def listener(clip=clip):
                # A note edit can produce several notifications in one Live
                # operation. Marking dirty coalesces them into one snapshot on
                # the next play-position callback.
                self._playing_note_cache_dirty.add(clip)

            try:
                if not clip.notes_has_listener(listener):
                    clip.add_notes_listener(listener)
                self._playing_note_cache_listeners[clip] = listener
            except Exception as e:
                # Keep correctness if this Live object cannot expose a notes
                # listener: _clip_pos_changed will refresh on every callback.
                self._playing_note_cache_listeners.pop(clip, None)
                self._debug_log("Exception adding playing-note listener: {}".format(str(e)))

        # Always take the initial snapshot after attempting registration.
        self._refresh_playing_note_cache(clip)
        return clip in self._playing_note_cache_listeners

    def _remove_playing_note_cache_listener(self, clip):
        listener = self._playing_note_cache_listeners.pop(clip, None)
        if listener is not None:
            try:
                if liveobj_valid(clip) and clip.notes_has_listener(listener):
                    clip.remove_notes_listener(listener)
            except Exception:
                pass
        self._playing_note_cache.pop(clip, None)
        self._playing_note_cache_dirty.discard(clip)

    def _remove_all_notes_playing_listeners(self):
        for clip_index, (clip, listener) in list(self._playing_position_listener_clips.items()):
            try:
                if liveobj_valid(clip) and clip.playing_position_has_listener(listener):
                    clip.remove_playing_position_listener(listener)
            except Exception:
                pass
            self._remove_playing_note_cache_listener(clip)
            if clip_index < len(self.playing_position_listeners):
                self.playing_position_listeners[clip_index] = None
        self._playing_position_listener_clips.clear()

        # Normally emptied above; this also covers a note listener whose
        # position-listener registration failed part-way through.
        for clip in list(self._playing_note_cache_listeners.keys()):
            self._remove_playing_note_cache_listener(clip)

    def _check_clip_playing_status(self, force=False):
        try:
            song = self.song()
            selected_track = song.view.selected_track
            highlighted_clip_slot_playing = getattr(song.view.highlighted_clip_slot, 'is_playing', False)
            
            if highlighted_clip_slot_playing:
                # Ensure status is 0 if the highlighted clip is playing
                new_status = 0
            else:
                # Check if any other clip is playing
                another_clip_playing = any(clip_slot.is_playing for clip_slot in selected_track.clip_slots if clip_slot.has_clip)
                new_status = 1 if another_clip_playing else 2
        except Exception:
            return
        
        # Update status only if it has changed
        if force or self.seq_clip_playing_status != new_status:
            self.seq_clip_playing_status = new_status
            self.send_cc(self.CLIP_PLAYING_STATUS_CC, self.CLIP_PLAYING_STATUS_CHANNEL, new_status)

    def _clip_pos_changed(self, clip_index):
        # Only check and send things if we are in device view
        if self.device_status:
            song = self.song()
            selected_track = song.view.selected_track

            if clip_index < len(selected_track.clip_slots):
                clip_slot = selected_track.clip_slots[clip_index]

                if clip_slot is not None and clip_slot.has_clip:
                    clip_playing = clip_slot.clip
                    
                    loop_start = clip_playing.loop_start

                    # Sequencer views need only compact playhead feedback. Avoid
                    # enumerating large Flin clips for every position callback.
                    if self.seq_status:
                        try:
                            clip_position = clip_playing.playing_position
                            self._check_clip_playing_status()
                            if song.view.highlighted_clip_slot.is_playing:
                                self.send_out_playing_pos(clip_position, self._flin_beats_per_bar(clip_playing))
                                self.last_sent_out_playing_pos = clip_position
                            elif self.last_sent_out_playing_pos != 0.0:
                                self.last_sent_out_playing_pos = 0.0
                                self.send_out_playing_pos(0.0, 1.0, force=True, hidden=True)
                        except Exception as e:
                            self._debug_log("Exception sending sequencer position: {}".format(str(e)))
                        return
                    
                    try:
                        listener_active = clip_playing in self._playing_note_cache_listeners
                        if not listener_active:
                            listener_active = self._ensure_playing_note_cache_listener(clip_playing)
                        if listener_active and (
                            clip_playing in self._playing_note_cache_dirty
                            or clip_playing not in self._playing_note_cache
                        ):
                            self._refresh_playing_note_cache(clip_playing)
                        current_clip_notes = self._playing_note_cache.get(clip_playing, ())
                        self.current_clip_notes = current_clip_notes

                        # check which notes are playing at position
                        # if we detect changes send them out to app
                        clip_position = clip_playing.playing_position
                        
                        # clip status no mater the seq_status
                        self._check_clip_playing_status()
                        
                        if self.seq_status:
                            if song.view.highlighted_clip_slot.is_playing:
                                self.send_out_playing_pos(clip_position, clip_playing.signature_numerator)
                                self.last_sent_out_playing_pos = clip_position
                            else:
                                # reseting the playing position
                                if self.last_sent_out_playing_pos != 0.0:
                                    self.last_sent_out_playing_pos = 0.0
                                    self.send_out_playing_pos(self.last_sent_out_playing_pos, 1.0, force=True, hidden=True)
                                
                        else:
                            # making sure we have the right starting position, when jumping back to the start of clip or loop
                            if self.last_playing_position > clip_position:
                                if clip_position >= loop_start:
                                    self.last_playing_position = loop_start
                                else:
                                    self.last_playing_position = clip_playing.start_marker
    
                            # check if currently playing notes are still playing in this playing position
                            for (note_index, is_playing) in enumerate(self.currently_playing_notes):
                                if is_playing:
                                    # Initialize a flag to indicate if a playing note was found
                                    found_playing_note = False
    
                                    # Find the notes that stopped playing in since the last update
                                    for note in current_clip_notes:
                                        pitch, note_start_time, end_time = note
    
                                        if note_start_time <= self.last_playing_position and clip_position < end_time and pitch == note_index:
                                            # Note is still playing
                                            found_playing_note = True
                                            break
    
                                    # If no playing note was found, update the state
                                    if not found_playing_note:
                                        self.currently_playing_notes[note_index] = False
                                        # send note off for note_index note.
                                        # self.log_message("Note off: {}".format(note_index))
                                        self.send_note_off(note_index, 0, 100)
    
                            # check current clip notes array which notes are on for that playing position
                            for note in current_clip_notes:
                                pitch, note_start_time, end_time = note
                                if self.last_playing_position <= note_start_time <= clip_position:
                                    # note starts playing
                                    self.currently_playing_notes[pitch] = True
                                    # send midi note on
                                    # self.log_message("Note on: {}".format(pitch))
                                    self.send_note_on(pitch, 0, 100)
                            # update last playing position
                            self.last_playing_position = clip_position
                    except Exception as e:
                        self._debug_log(f"Exception for clip position changed: {str(e)}")
                        import traceback
                        self._debug_log(traceback.format_exc())
                        pass
                # else:
                    # self.log_message("No valid clip in the slot.")

    def _send_selected_track_index(self, selected_track):
        track_list = self.song().tracks
        track_index = self._find_track_index(selected_track, track_list)
        self._send_sys_ex_message(track_index, 0x03)
        if track_index == "not found":
            return_tracks_list = self.song().return_tracks
            return_track_index = self._find_track_index(selected_track, return_tracks_list)
            if return_track_index == "not found":
                return_track_index = str(len(return_tracks_list))
            self._send_sys_ex_message(return_track_index, 0x08)
        else:
            self._send_sys_ex_message("none selected", 0x08)

    def _find_track_index(self, track, track_list):
        for index, t in enumerate(track_list):
            if track == t:
                return str(index)
        return "not found" # Track not found

    def _select_device_by_index(self, value):
        selected_track = self.song().view.selected_track
        was_track_control = self._track_device_is_selected(selected_track)
        if value == 0:
            self._set_track_device_selected(True, selected_track)
            self._connect_track_device_parameter_controls(selected_track)
            try:
                self.request_rebuild_midi_map()
            except Exception:
                pass
            self._on_device_changed()
            return

        self._set_track_device_selected(False, selected_track)
        if was_track_control:
            self._connect_device_controls()
            try:
                self.request_rebuild_midi_map()
            except Exception:
                pass
        all_devices = self._get_all_nested_devices(selected_track.devices)[0]
        live_index = self._app_device_index_to_live_index(value)
        if live_index < 0 or live_index >= len(all_devices):
            return
        device_to_select = all_devices[live_index]
        was_selected_device = device_to_select == selected_track.view.selected_device
        self.song().view.select_device(device_to_select)
        if was_selected_device:
            if hasattr(self, "_device") and hasattr(self._device, "set_device"):
                self._device.set_device(device_to_select)
            self._last_automation_signature = None
            self._on_device_changed()

    def _select_track_by_index(self, track_index):
        # self.log_message("Getting track: {}".format(track_index))
        song = self.song()
        if track_index >= 0 and track_index < len(song.tracks):
            song.view.selected_track = song.tracks[track_index]
        else:
            self._debug_log("Invalid track index: {}".format(track_index))

    def _select_return_track_by_index(self, track_index):
        song = self.song()
        if track_index < len(song.return_tracks):
            return_track = song.return_tracks[track_index] 
            song.view.selected_track = return_track
        else:
            master_track = song.master_track 
            song.view.selected_track = master_track

    def _set_selected_track_implicit_arm(self):
        selected_track = self.song().view.selected_track
        if selected_track and selected_track.has_midi_input:
            try:
                selected_track.implicit_arm = True
            except Exception:
                pass
        # else:
        #     try:
        #         self.song().tracks[0].implicit_arm = True
        #     except Exception:
        #         pass

    def _set_other_tracks_implicit_arm(self):
        for track in self.song().tracks:
            if track != self.song().view.selected_track:
                try:
                    track.implicit_arm = False
                except Exception:
                    pass

    def _on_tracks_changed(self):
        self._mutator_clip_presence_dirty = True
        if self._metadata_recheck_timer:
            self._metadata_recheck_timer.cancel()
            self._metadata_recheck_timer = None
        self._metadata_cache.clear()
        self._metadata_send_seq_by_device.clear()
        self._sync_follow_actions_to_track_topology()
        self._update_mixer_and_tracks()
        self._register_clip_listeners()
        self._update_clip_slots()

    def _make_color_string(self, color):
        red = (color >> 16) & 255
        green = (color >> 8) & 255
        blue = color & 255
        color_string = "({},{},{})".format(red, green, blue)
        return color_string

    def _on_color_name_changed(self):
        self._update_mixer_and_tracks()
        self._on_selected_track_changed()
    
    def _create_level_change_handler(self, index, side):
        """
        A factory that returns a handler function for a specific index.
        This guarantees the index is correctly captured.
        """
        def handler():
            self._on_output_level_changed(index, side)
        return handler

    def _track_has_output_meter(self, track):
        try:
            return bool(track and liveobj_valid(track) and track.has_audio_output)
        except Exception:
            return False

    def _remove_output_meter_listener_pair(self, track, left_listener, right_listener):
        # Live's proxy advertises the output-meter listener methods even for a
        # track whose routing has changed to MIDI output.  Calling any of those
        # methods then raises RuntimeError, so capability must be checked first
        # and every proxy call kept inside the same guard.
        if not self._track_has_output_meter(track):
            return
        try:
            if (left_listener and
                    track.output_meter_left_has_listener(left_listener)):
                track.remove_output_meter_left_listener(left_listener)
        except (AttributeError, RuntimeError):
            pass
        try:
            if (right_listener and
                    track.output_meter_right_has_listener(right_listener)):
                track.remove_output_meter_right_listener(right_listener)
        except (AttributeError, RuntimeError):
            pass

    def _sync_visible_meter_listeners(self, meter_targets):
        desired_tracks = set(meter_targets.values())
        listener_maps = (
            self._track_level_listeners,
            self._return_level_listeners,
            self._master_level_listeners,
        )

        for listener_map in listener_maps:
            for track, (left_listener, right_listener) in list(listener_map.items()):
                if track not in desired_tracks or not self._track_has_output_meter(track):
                    self._remove_output_meter_listener_pair(track, left_listener, right_listener)
                    listener_map.pop(track, None)

        return_tracks = self.song().return_tracks
        master_track = self.song().master_track
        for index, track in meter_targets.items():
            if not self._track_has_output_meter(track):
                continue
            if track == master_track:
                listener_map = self._master_level_listeners
            elif track in return_tracks:
                listener_map = self._return_level_listeners
            else:
                listener_map = self._track_level_listeners
            if track in listener_map:
                continue

            left_handler = self._create_level_change_handler(index, "left")
            right_handler = self._create_level_change_handler(index, "right")
            try:
                track.add_output_meter_left_listener(left_handler)
                track.add_output_meter_right_listener(right_handler)
                listener_map[track] = (left_handler, right_handler)
                self._on_output_level_changed(index, "left", force=True)
                self._on_output_level_changed(index, "right", force=True)
            except RuntimeError:
                self._remove_output_meter_listener_pair(track, left_handler, right_handler)

        visible_indexes = set(meter_targets.keys())
        self._last_meter_values = {
            key: value for key, value in self._last_meter_values.items()
            if key[0] in visible_indexes
        }

    def _foldable_group_track_for_track(self, track):
        try:
            if track and liveobj_valid(track) and getattr(track, 'is_foldable', False):
                return track
        except Exception:
            pass

        try:
            if track and liveobj_valid(track) and getattr(track, 'is_grouped', False):
                group_track = getattr(track, 'group_track', None)
                if group_track and liveobj_valid(group_track) and getattr(group_track, 'is_foldable', False):
                    return group_track
        except Exception:
            pass

        return None

    def _group_fold_state_codes(self, tracks):
        fold_states = []
        for track in tracks:
            group_track = self._foldable_group_track_for_track(track)
            if group_track is None:
                fold_states.append("-")
                continue

            try:
                fold_states.append("1" if bool(group_track.fold_state) else "0")
            except Exception:
                fold_states.append("-")

        return tuple(fold_states)

    def _send_group_fold_states_if_changed(self, tracks=None, force=False):
        if tracks is None:
            tracks = list(self.song().tracks)

        fold_states = self._group_fold_state_codes(tracks)
        if force or fold_states != self._last_group_fold_states:
            self._last_group_fold_states = fold_states
            self._send_sys_ex_message(",".join(fold_states), 0x2B)

        hidden_states = self._group_hidden_state_codes(tracks)
        if force or hidden_states != self._last_group_hidden_states:
            self._last_group_hidden_states = hidden_states
            self._send_sys_ex_message(",".join(hidden_states), 0x2D)

    def _group_hidden_state_codes(self, tracks):
        hidden_states = []
        for track in tracks:
            hidden = False
            try:
                if track and liveobj_valid(track) and getattr(track, 'is_grouped', False):
                    group_track = getattr(track, 'group_track', None)
                    hidden = bool(group_track and liveobj_valid(group_track) and group_track.fold_state)
            except Exception:
                hidden = False

            hidden_states.append("1" if hidden else "0")

        return tuple(hidden_states)
    
    # Updating names and number of tracks
    def _format_track_name_for_display(self, name):
        name = str(name)
        dash_index = name.find("-")
        if dash_index <= 0:
            return name

        prefix = name[:dash_index]
        if not (prefix.isdigit() or (dash_index == 1 and prefix.isalpha())):
            return name

        return "{} {}".format(prefix, name[dash_index + 1:].lstrip())

    def _update_mixer_and_tracks(self):
        tracks = list(self.song().tracks)
        return_tracks = list(self.song().return_tracks)
        master_track = self.song().master_track

        track_signature = (
            tuple(
                (
                    id(track),
                    str(track.name),
                    int(track.color),
                    bool(track.is_grouped),
                    bool(track.has_audio_input),
                    bool(track.has_audio_output),
                    any(clip_slot.is_group_slot for clip_slot in track.clip_slots),
                )
                for track in tracks
            ),
            tuple((id(track), str(track.name), int(track.color)) for track in return_tracks),
            int(master_track.color),
        )
        tracks_changed = track_signature != self._track_list_signature
        
        if tracks_changed:
            # 1. Remove all old listeners to prevent leaks
            for track, (left_listener, right_listener) in self._track_level_listeners.items():
                self._remove_output_meter_listener_pair(track, left_listener, right_listener)
            self._track_level_listeners.clear()

            for track, (left_listener, right_listener) in self._return_level_listeners.items():
                self._remove_output_meter_listener_pair(track, left_listener, right_listener)
            self._return_level_listeners.clear()
            
            if self._master_level_listeners:
                left_listener, right_listener = self._master_level_listeners.get(master_track, (None, None))
                self._remove_output_meter_listener_pair(master_track, left_listener, right_listener)
                self._master_level_listeners.clear()
            self._last_meter_values.clear()
            self._track_list_signature = track_signature

            # 2. Build track names, types, colors and send via SysEx
            track_names = []
            track_is_audio = []
            track_colors = []
            
            for index, track in enumerate(tracks):
                name = self._format_track_name_for_display(track.name)
                track_names.append(name)
                if any(clip_slot.is_group_slot for clip_slot in track.clip_slots):
                    track_is_audio.append("2")
                elif track.is_grouped:
                    if track.has_audio_input:
                        track_is_audio.append("4")
                    else:
                        track_is_audio.append("3")
                elif track.has_audio_input:
                    track_is_audio.append("1")
                else:
                    track_is_audio.append("0")
                color_string = self._make_color_string(track.color)
                track_colors.append(color_string)

            self._send_sys_ex_message(",".join(self._escape_sysex_string(name) for name in track_names), 0x02)
            self._send_sys_ex_message(",".join(track_is_audio), 0x0C)
            self._send_sys_ex_message("-".join(track_colors), 0x04)

            return_track_names = []
            return_track_colors = []
            for index, return_track in enumerate(return_tracks):
                name = self._format_track_name_for_display(return_track.name)
                return_track_names.append(name)
                return_track_colors.append(self._make_color_string(return_track.color))

            color_string = self._make_color_string(master_track.color)
            return_track_colors.append(color_string)
            self._send_sys_ex_message(",".join(self._escape_sysex_string(name) for name in return_track_names), 0x06)
            self._send_sys_ex_message("-".join(return_track_colors), 0x07)

        self._send_group_fold_states_if_changed(tracks)
        
        for track in tracks:
            if not track.color_has_listener(self._on_color_name_changed):
                track.add_color_listener(self._on_color_name_changed)
            if not track.name_has_listener(self._on_color_name_changed):
                track.add_name_listener(self._on_color_name_changed)

        self._set_up_mixer_controls()

    def _create_mixer_automation_control(self, control_type, midi_channel, cc, channel_type, track_index, parameter_name, send_index=None):
        if control_type == "slider":
            control = SliderElement(MIDI_CC_TYPE, midi_channel, cc)
        else:
            control = EncoderElement(MIDI_CC_TYPE, midi_channel, cc, Live.MidiMap.MapMode.absolute)

        control.add_value_listener(
            lambda value, channel_type=channel_type, track_index=track_index, parameter_name=parameter_name, send_index=send_index:
                self._on_mixer_automation_control_value(value, channel_type, track_index, parameter_name, send_index)
        )
        parameter = self._mixer_parameter(channel_type, track_index, parameter_name, send_index)
        if parameter and liveobj_valid(parameter):
            control.connect_to(parameter)
        self._mixer_automation_controls.append(control)
        self._register_mixer_automation_status(midi_channel, cc, channel_type, track_index, parameter_name, send_index)
        return control

    def _create_mixer_toggle_control(self, midi_channel, cc, channel_type, track_index, property_name):
        control = ButtonElement(1, MIDI_CC_TYPE, midi_channel, cc)
        control.add_value_listener(
            lambda value, channel_type=channel_type, track_index=track_index, property_name=property_name:
                self._on_mixer_toggle_control_value(value, channel_type, track_index, property_name)
        )
        self._mixer_automation_controls.append(control)
        return control

    def _on_mixer_toggle_control_value(self, value, channel_type, track_index, property_name):
        if value == 0:
            return

        track = self._mixer_track(channel_type, track_index)
        if track is None:
            return

        try:
            setattr(track, property_name, not bool(getattr(track, property_name)))
        except Exception:
            pass

    def _release_mixer_controls(self):
        for control in list(getattr(self, '_mixer_automation_controls', [])):
            try:
                control.release_parameter()
            except Exception:
                pass
        self._mixer_automation_controls = []

    def _disconnect_mixer_component_controls(self):
        try:
            for index in range(127):
                strip = mixer.channel_strip(index)
                strip.set_volume_control(None)
                strip.set_send_controls(None)
                strip.set_pan_control(None)
                strip.set_mute_button(None)
                strip.set_solo_button(None)
        except Exception:
            pass

        try:
            mixer.master_strip().set_volume_control(None)
            mixer.set_prehear_volume_control(None)
            mixer.master_strip().set_pan_control(None)
        except Exception:
            pass

        try:
            for index in range(12):
                strip = mixer.return_strip(index)
                strip.set_volume_control(None)
                strip.set_mute_button(None)
                strip.set_solo_button(None)
                strip.set_send_controls(None)
                strip.set_pan_control(None)
        except Exception:
            pass

    def _register_mixer_automation_status(self, midi_channel, cc, channel_type, track_index, parameter_name, send_index=None):
        self._mixer_automation_status_specs.append((midi_channel, cc, channel_type, track_index, parameter_name, send_index))
        parameter = self._mixer_parameter(channel_type, track_index, parameter_name, send_index)
        if parameter and liveobj_valid(parameter) and hasattr(parameter, 'add_automation_state_listener'):
            listener = self._create_mixer_automation_state_listener()
            self._mixer_automation_state_listeners.append((parameter, listener))
            if not hasattr(parameter, 'automation_state_has_listener') or not parameter.automation_state_has_listener(listener):
                parameter.add_automation_state_listener(listener)

    def _create_mixer_automation_state_listener(self):
        def listener():
            self._schedule_mixer_automation_status_resends()
        return listener

    def _remove_mixer_automation_state_listeners(self):
        for parameter, listener in self._mixer_automation_state_listeners:
            try:
                if liveobj_valid(parameter) and hasattr(parameter, 'remove_automation_state_listener'):
                    if not hasattr(parameter, 'automation_state_has_listener') or parameter.automation_state_has_listener(listener):
                        parameter.remove_automation_state_listener(listener)
            except Exception:
                pass
        self._mixer_automation_state_listeners = []

    def _cancel_mixer_automation_status_resends(self):
        for timer in list(getattr(self, '_mixer_automation_status_timers', [])):
            try:
                timer.cancel()
            except Exception:
                pass
        self._mixer_automation_status_timers = []

    def _schedule_mixer_automation_status_resends(self, send_now=True):
        self._cancel_mixer_automation_status_resends()
        if send_now:
            self._send_mixer_automation_statuses()
        if not getattr(self, 'mixer_status', False):
            return
        for delay in (0.05, 0.15, 0.35):
            timer = self._schedule_main_thread(delay, self._send_mixer_automation_statuses)
            self._mixer_automation_status_timers.append(timer)

    def _mixer_automation_state_for_parameter(self, parameter):
        try:
            if parameter and liveobj_valid(parameter) and hasattr(parameter, 'automation_state'):
                return int(parameter.automation_state)
        except Exception:
            pass
        return 0

    def _send_mixer_automation_statuses(self):
        if not self.mixer_status:
            self._send_sys_ex_message("", 0x2A)
            return

        entries = []
        for midi_channel, cc, channel_type, track_index, parameter_name, send_index in self._mixer_automation_status_specs:
            parameter = self._mixer_parameter(channel_type, track_index, parameter_name, send_index)
            state = self._mixer_automation_state_for_parameter(parameter)
            entries.append("{}:{}:{}".format(midi_channel, cc, state))
        self._send_sys_ex_message(",".join(entries), 0x2A)

    def _mixer_track(self, channel_type, track_index):
        try:
            song = self.song()
            if channel_type == "track":
                return song.tracks[track_index]
            elif channel_type == "return":
                return song.return_tracks[track_index]
            return song.master_track
        except Exception:
            return None

    def _mixer_parameter(self, channel_type, track_index, parameter_name, send_index=None):
        try:
            track = self._mixer_track(channel_type, track_index)
            if track is None:
                return None
            mixer_device = track.mixer_device
            if parameter_name == "send":
                sends = mixer_device.sends
                if send_index is not None and send_index < len(sends):
                    return sends[send_index]
                return None
            return getattr(mixer_device, parameter_name, None)
        except Exception:
            return None

    def _on_mixer_automation_control_value(self, value, channel_type, track_index, parameter_name, send_index=None):
        self._schedule_mixer_automation_status_resends(send_now=False)
        if not self._pending_parameter_automation_action():
            return

        parameter = self._mixer_parameter(channel_type, track_index, parameter_name, send_index)
        track = self._mixer_track(channel_type, track_index)
        self._consume_remove_automation_request(parameter, track)
        
    def _set_up_mixer_controls(self):
        song = self.song()
        tracks = song.tracks
        return_tracks = song.return_tracks
        hidden_track_states = self._group_hidden_state_codes(tracks)
        visible_track_indexes = set(
            index for index, hidden in enumerate(hidden_track_states)
            if hidden != "1"
        )
        self._remove_mixer_automation_state_listeners()
        self._release_mixer_controls()
        self._disconnect_mixer_component_controls()
        self._mixer_automation_status_specs = []
        first_visible_channel = self.visible_channels[0]
        last_visible_channel = self.visible_channels[1]
        master_track_index = len(tracks) + len(return_tracks)
        master_track_visible = first_visible_channel <= master_track_index <= last_visible_channel
        meter_targets = {}
        if self.mixer_status:
            for index, track in enumerate(tracks):
                if index in visible_track_indexes and index >= first_visible_channel and index <= last_visible_channel:
                    meter_targets[index] = track
            for index, return_track in enumerate(return_tracks):
                combined_index = len(tracks) + index
                if combined_index >= first_visible_channel and combined_index <= last_visible_channel:
                    meter_targets[combined_index] = return_track
            if master_track_visible:
                meter_targets[127] = song.master_track
        self._mixer_meter_targets = meter_targets
        self._sync_visible_meter_listeners(meter_targets)
        
        # Channels
        for index, track in enumerate(tracks):

            if index in meter_targets:
                self._create_mixer_automation_control("slider", 2, index, "track", index, "volume")
                self._create_mixer_automation_control("encoder", 3, index, "track", index, "send", 0)
                self._create_mixer_automation_control("encoder", 4, index, "track", index, "send", 1)
                self._create_mixer_automation_control("encoder", 5, index, "track", index, "panning")
                self._create_mixer_toggle_control(6, index, "track", index, "mute")
                self._create_mixer_toggle_control(7, index, "track", index, "solo")

            # Other strip controls can be configured similarly
            # strip.set_arm_button(...)
            # strip.set_shift_button(...)

        # Master / channel 7 cc 127
        if 127 in meter_targets:
            self._create_mixer_automation_control("slider", 0, 127, "master", 0, "volume")
            self._create_mixer_automation_control("encoder", 0, 126, "master", 0, "cue_volume")
            self._create_mixer_automation_control("encoder", 0, 125, "master", 0, "panning")

        # Return Tracks
        for index, returnTrack in enumerate(return_tracks):
            combined_index = len(tracks) + index
            if combined_index in meter_targets:
                self._create_mixer_automation_control("slider", 8, index, "return", index, "volume")
                self._create_mixer_toggle_control(8, index + 12, "return", index, "mute")
                self._create_mixer_toggle_control(8, index + 24, "return", index, "solo")
                self._create_mixer_automation_control("encoder", 8, index + 36, "return", index, "send", 0)
                self._create_mixer_automation_control("encoder", 8, index + 48, "return", index, "send", 1)
                self._create_mixer_automation_control("encoder", 8, index + 60, "return", index, "panning")

        self._schedule_mixer_automation_status_resends()
        
    def _on_output_level_changed(self, index, side, force=False):
        if not self.mixer_status or index < 0 or index > 127:
            return

        track = self._mixer_meter_targets.get(index)
        if not self._track_has_output_meter(track):
            return

        try:
            raw_value = track.output_meter_left if side == "left" else track.output_meter_right
            value = max(0, min(100, int(round(float(raw_value) * 100.0))))
        except Exception:
            return

        cache_key = (index, side)
        if not force and self._last_meter_values.get(cache_key) == value:
            return
        self._last_meter_values[cache_key] = value

        channel = 9 if side == "left" else 10
        self._send_midi((0xB0 | channel, index, value))

    def _get_track_index(self, track):
        if not track:
            return None
        try:
            return list(self.song().tracks).index(track)
        except ValueError:
            return None

    def _make_clip_has_clip_listener(self, track):
        def listener():
            self._on_clip_has_clip_changed(track)
        return listener

    def _make_clip_triggered_listener(self, track):
        def listener():
            self._on_clip_playing_status_changed(track)
        return listener

    def _make_clip_playing_listener(self, track):
        def listener():
            self._on_clip_playing_status_changed(track)
        return listener

    def _make_clip_color_listener(self, track):
        def listener():
            self._on_clip_has_clip_changed(track)
        return listener

    def _add_clip_color_listener(self, clip, listener):
        try:
            if not liveobj_valid(clip) or not hasattr(clip, 'add_color_listener'):
                return False
            if not hasattr(clip, 'color_has_listener') or not clip.color_has_listener(listener):
                clip.add_color_listener(listener)
            return True
        except Exception as e:
            self._debug_log("Error adding clip color listener: {}".format(str(e)))
            return False

    def _sync_clip_color_listeners_for_track(self, track):
        for clip_slot in track.clip_slots:
            if clip_slot is None:
                continue
            if clip_slot.has_clip:
                current_clip = clip_slot.clip
                previous_clip = self._clip_slot_color_map.get(clip_slot)
                if previous_clip is not None and previous_clip != current_clip:
                    old_listener = self._clip_color_listeners.pop(previous_clip, None)
                    if old_listener and liveobj_valid(previous_clip) and previous_clip.color_has_listener(old_listener):
                        previous_clip.remove_color_listener(old_listener)
                if current_clip not in self._clip_color_listeners:
                    listener = self._make_clip_color_listener(track)
                    if self._add_clip_color_listener(current_clip, listener):
                        self._clip_color_listeners[current_clip] = listener
                self._clip_slot_color_map[clip_slot] = current_clip
            else:
                previous_clip = self._clip_slot_color_map.pop(clip_slot, None)
                if previous_clip is not None:
                    old_listener = self._clip_color_listeners.pop(previous_clip, None)
                    if old_listener and liveobj_valid(previous_clip) and previous_clip.color_has_listener(old_listener):
                        previous_clip.remove_color_listener(old_listener)

    # clipSlots
    def _remove_clip_slot_listener(self, clip_slot, listener_kind, listener):
        try:
            if not liveobj_valid(clip_slot):
                return
            has_listener = getattr(
                clip_slot, "{}_has_listener".format(listener_kind), None
            )
            remove_listener = getattr(
                clip_slot, "remove_{}_listener".format(listener_kind), None
            )
            if remove_listener and (not has_listener or has_listener(listener)):
                remove_listener(listener)
        except Exception:
            pass

    def _add_clip_slot_listener(self, clip_slot, listener_kind, listener):
        try:
            if not liveobj_valid(clip_slot):
                return False
            has_listener = getattr(
                clip_slot, "{}_has_listener".format(listener_kind), None
            )
            add_listener = getattr(
                clip_slot, "add_{}_listener".format(listener_kind), None
            )
            if not add_listener:
                return False
            if not has_listener or not has_listener(listener):
                add_listener(listener)
            return True
        except Exception as e:
            self._debug_log(
                "Error adding {} clip-slot listener: {}".format(listener_kind, str(e))
            )
            return False

    def _remove_clip_color_listener(self, clip, listener):
        try:
            if liveobj_valid(clip) and hasattr(clip, 'remove_color_listener'):
                if not hasattr(clip, 'color_has_listener') or clip.color_has_listener(listener):
                    clip.remove_color_listener(listener)
        except Exception:
            pass

    def _register_clip_listeners(self):
        current_track_ids = set()
        expected_listener_keys = set()
        expected_clip_slots = set()
        expected_clips = set()
        for track in self.song().tracks:
            track_id = id(track)
            current_track_ids.add(track_id)

            for clip_slot in track.clip_slots:
                if clip_slot is None:
                    continue
                expected_clip_slots.add(clip_slot)

                listener_key = (clip_slot, 'has_clip')
                expected_listener_keys.add(listener_key)
                if listener_key not in self._clip_slot_listeners:
                    listener = self._make_clip_has_clip_listener(track)
                    if self._add_clip_slot_listener(clip_slot, 'has_clip', listener):
                        self._clip_slot_listeners[listener_key] = listener

                listener_key = (clip_slot, 'is_triggered')
                expected_listener_keys.add(listener_key)
                if listener_key not in self._clip_slot_listeners:
                    listener = self._make_clip_triggered_listener(track)
                    if self._add_clip_slot_listener(clip_slot, 'is_triggered', listener):
                        self._clip_slot_listeners[listener_key] = listener

                listener_key = (clip_slot, 'is_playing')
                expected_listener_keys.add(listener_key)
                if listener_key not in self._clip_slot_listeners:
                    listener = self._make_clip_playing_listener(track)
                    if self._add_clip_slot_listener(clip_slot, 'is_playing', listener):
                        self._clip_slot_listeners[listener_key] = listener

            self._sync_clip_color_listeners_for_track(track)
            for clip_slot in track.clip_slots:
                if clip_slot is not None and clip_slot.has_clip:
                    expected_clips.add(clip_slot.clip)

        # Listener dictionaries retain Live objects, so remove entries for
        # deleted tracks/scenes rather than merely forgetting their IDs.
        for listener_key in list(self._clip_slot_listeners.keys()):
            if listener_key not in expected_listener_keys:
                clip_slot, listener_kind = listener_key
                listener = self._clip_slot_listeners.pop(listener_key, None)
                if listener is not None:
                    self._remove_clip_slot_listener(clip_slot, listener_kind, listener)

        for clip_slot in list(self._clip_slot_color_map.keys()):
            if clip_slot not in expected_clip_slots:
                self._clip_slot_color_map.pop(clip_slot, None)

        for clip in list(self._clip_color_listeners.keys()):
            if clip not in expected_clips:
                listener = self._clip_color_listeners.pop(clip, None)
                if listener is not None:
                    self._remove_clip_color_listener(clip, listener)

        self._registered_track_ids = current_track_ids

    def _unregister_clip_and_audio_listeners(self):
        for (clip_slot, listener_kind), listener in list(self._clip_slot_listeners.items()):
            self._remove_clip_slot_listener(clip_slot, listener_kind, listener)

        for clip, listener in list(self._clip_color_listeners.items()):
            self._remove_clip_color_listener(clip, listener)

        for track, (left_listener, right_listener) in list(self._track_level_listeners.items()):
            self._remove_output_meter_listener_pair(track, left_listener, right_listener)

        for return_track, (left_listener, right_listener) in list(self._return_level_listeners.items()):
            self._remove_output_meter_listener_pair(return_track, left_listener, right_listener)
        
        self._track_level_listeners.clear()
        self._return_level_listeners.clear()
        self._clip_listener_track_slots.clear()
        self._clip_slot_listeners.clear()
        self._clip_color_listeners.clear()
        self._clip_slot_color_map.clear()
        self._registered_track_ids.clear()

    # def _on_playing_position_changed(self):
    #     # self.log_message("trying to log the playing position")
    #     self._update_clip_slots()

    def find_different_indexes(self, arrays1, arrays2):
        different_indexes = []

        for index, (array1, array2) in enumerate(zip_longest(arrays1, arrays2)):
            if array1 != array2:
                different_indexes.append(index)

        return different_indexes

    def _on_clip_playing_status_changed(self, track=None):
        # self.log_message("clip playing status changed")
        self._refresh_parameter_metadata_on_automation_change()
        if track:
            track_index = self._get_track_index(track)
            if track_index is not None:
                self._update_clip_slots(track_index)
                self._activate_follow_actions_for_playing_clips(track_index)
                self._evaluate_mutator_regeneration(track_index)
                return
        self._update_clip_slots()
        self._activate_follow_actions_for_playing_clips()
        self._evaluate_mutator_regeneration()

    def _activate_follow_actions_for_playing_clips(self, only_track_index=None):
        self._clear_finished_follow_action_launches()
        try:
            for track_index, track in enumerate(self.song().tracks):
                if only_track_index is not None and track_index != only_track_index:
                    continue
                for scene_index, clip_slot in enumerate(track.clip_slots):
                    if not clip_slot.has_clip or not clip_slot.is_playing:
                        continue
                    key = self._follow_action_key("clip", track_index, scene_index)
                    if key in self._active_follow_actions:
                        continue
                    if key in self._follow_action_rules:
                        self._activate_follow_action_for_clip(track_index, scene_index, clip_slot)
        except Exception:
            pass

    def _make_follow_action_scene_triggered_listener(self, scene_index):
        def listener():
            try:
                key = self._follow_action_key("scene", None, scene_index)
                if key not in self._follow_action_rules:
                    return
                scene = self.song().scenes[scene_index]
                if self._scene_object_is_triggered(scene) or self._scene_is_launched(scene_index):
                    self._activate_follow_action_for_scene(scene_index)
            except Exception:
                pass
        return listener

    def _make_follow_action_clip_slot_listener(self, track_index, scene_index, clip_slot):
        def listener():
            try:
                key = self._follow_action_key("clip", track_index, scene_index)
                if key not in self._follow_action_rules:
                    return
                if clip_slot.has_clip and (clip_slot.is_playing or self._clip_slot_is_triggered(clip_slot)):
                    self._activate_follow_action_for_clip(track_index, scene_index, clip_slot)
            except Exception:
                pass
        return listener

    def _make_follow_action_name_listener(self):
        def listener():
            self._on_follow_action_name_changed()
        return listener

    def _make_follow_action_clip_timing_listener(self):
        def listener():
            self._on_follow_action_timing_changed()
        return listener

    def _make_follow_action_clip_has_clip_listener(self):
        def listener():
            self._sync_follow_action_name_listeners()
            self._load_follow_actions_from_names()
            self._sync_follow_action_runtime_listeners()
        return listener

    def _remove_named_object_listener(self, listener_map, key):
        listener_info = listener_map.pop(key, None)
        if not listener_info:
            return
        named_object, listener = listener_info
        try:
            remove_listener = getattr(named_object, "remove_name_listener", None)
            has_listener = getattr(named_object, "name_has_listener", None)
            if remove_listener and (not has_listener or has_listener(listener)):
                remove_listener(listener)
        except Exception:
            pass

    def _remove_follow_action_clip_timing_listeners(self, key):
        listener_info = self._follow_action_clip_timing_listeners.pop(key, None)
        if not listener_info:
            return
        clip, listeners = listener_info
        for property_name, listener in listeners.items():
            try:
                remove_listener = getattr(clip, "remove_{}_listener".format(property_name), None)
                has_listener = getattr(clip, "{}_has_listener".format(property_name), None)
                if remove_listener and (not has_listener or has_listener(listener)):
                    remove_listener(listener)
            except Exception:
                pass

    def _ensure_follow_action_clip_timing_listeners(self, key, clip):
        existing = self._follow_action_clip_timing_listeners.get(key)
        if existing and existing[0] is clip:
            return

        self._remove_follow_action_clip_timing_listeners(key)
        listeners = {}
        for property_name in ("loop_start", "loop_end", "end_marker"):
            try:
                add_listener = getattr(clip, "add_{}_listener".format(property_name), None)
                has_listener = getattr(clip, "{}_has_listener".format(property_name), None)
                if not add_listener:
                    continue
                listener = self._make_follow_action_clip_timing_listener()
                if not has_listener or not has_listener(listener):
                    add_listener(listener)
                listeners[property_name] = listener
            except Exception:
                pass

        if listeners:
            self._follow_action_clip_timing_listeners[key] = (clip, listeners)

    def _clip_affects_follow_action_timing(self, track_index, scene_index):
        return (
            self._follow_action_key("clip", track_index, scene_index) in self._follow_action_rules
            or self._follow_action_key("scene", None, scene_index) in self._follow_action_rules
        )

    def _remove_follow_action_clip_has_clip_listener(self, key):
        listener_info = self._follow_action_clip_has_clip_listeners.pop(key, None)
        if not listener_info:
            return
        clip_slot, listener = listener_info
        try:
            remove_listener = getattr(clip_slot, "remove_has_clip_listener", None)
            has_listener = getattr(clip_slot, "has_clip_has_listener", None)
            if remove_listener and (not has_listener or has_listener(listener)):
                remove_listener(listener)
        except Exception:
            pass

    def _sync_follow_action_name_listeners(self):
        expected_scene_keys = set()
        expected_clip_keys = set()
        expected_clip_slot_keys = set()
        expected_clip_timing_keys = set()

        try:
            scenes = self.song().scenes
            for scene in scenes:
                key = self._live_object_identity(scene)
                expected_scene_keys.add(key)
                existing = self._follow_action_scene_name_listeners.get(key)
                if existing and existing[0] is scene:
                    continue
                self._remove_named_object_listener(self._follow_action_scene_name_listeners, key)
                try:
                    listener = self._make_follow_action_name_listener()
                    add_listener = getattr(scene, "add_name_listener", None)
                    has_listener = getattr(scene, "name_has_listener", None)
                    if add_listener and (not has_listener or not has_listener(listener)):
                        add_listener(listener)
                    self._follow_action_scene_name_listeners[key] = (scene, listener)
                except Exception:
                    pass

            for track_index, track in enumerate(self.song().tracks):
                for scene_index, clip_slot in enumerate(track.clip_slots):
                    slot_key = self._live_object_identity(clip_slot)
                    expected_clip_slot_keys.add(slot_key)
                    existing_slot = self._follow_action_clip_has_clip_listeners.get(slot_key)
                    if not existing_slot or existing_slot[0] is not clip_slot:
                        self._remove_follow_action_clip_has_clip_listener(slot_key)
                        try:
                            listener = self._make_follow_action_clip_has_clip_listener()
                            add_listener = getattr(clip_slot, "add_has_clip_listener", None)
                            has_listener = getattr(clip_slot, "has_clip_has_listener", None)
                            if add_listener and (not has_listener or not has_listener(listener)):
                                add_listener(listener)
                            self._follow_action_clip_has_clip_listeners[slot_key] = (clip_slot, listener)
                        except Exception:
                            pass

                    if not clip_slot.has_clip:
                        continue
                    clip = clip_slot.clip
                    clip_key = self._live_object_identity(clip)
                    expected_clip_keys.add(clip_key)
                    existing_clip = self._follow_action_clip_name_listeners.get(clip_key)
                    needs_timing_listener = self._clip_affects_follow_action_timing(track_index, scene_index)
                    if needs_timing_listener:
                        expected_clip_timing_keys.add(clip_key)
                    else:
                        self._remove_follow_action_clip_timing_listeners(clip_key)
                    if existing_clip and existing_clip[0] is clip:
                        if needs_timing_listener:
                            self._ensure_follow_action_clip_timing_listeners(clip_key, clip)
                        continue
                    self._remove_named_object_listener(self._follow_action_clip_name_listeners, clip_key)
                    try:
                        listener = self._make_follow_action_name_listener()
                        add_listener = getattr(clip, "add_name_listener", None)
                        has_listener = getattr(clip, "name_has_listener", None)
                        if add_listener and (not has_listener or not has_listener(listener)):
                            add_listener(listener)
                        self._follow_action_clip_name_listeners[clip_key] = (clip, listener)
                    except Exception:
                        pass
                    if needs_timing_listener:
                        self._ensure_follow_action_clip_timing_listeners(clip_key, clip)
        except Exception:
            pass

        for key in list(self._follow_action_scene_name_listeners.keys()):
            if key not in expected_scene_keys:
                self._remove_named_object_listener(self._follow_action_scene_name_listeners, key)
        for key in list(self._follow_action_clip_name_listeners.keys()):
            if key not in expected_clip_keys:
                self._remove_named_object_listener(self._follow_action_clip_name_listeners, key)
        for key in list(self._follow_action_clip_has_clip_listeners.keys()):
            if key not in expected_clip_slot_keys:
                self._remove_follow_action_clip_has_clip_listener(key)
        for key in list(self._follow_action_clip_timing_listeners.keys()):
            if key not in expected_clip_timing_keys:
                self._remove_follow_action_clip_timing_listeners(key)

    def _remove_follow_action_name_listeners(self):
        for key in list(self._follow_action_scene_name_listeners.keys()):
            self._remove_named_object_listener(self._follow_action_scene_name_listeners, key)
        for key in list(self._follow_action_clip_name_listeners.keys()):
            self._remove_named_object_listener(self._follow_action_clip_name_listeners, key)
        for key in list(self._follow_action_clip_has_clip_listeners.keys()):
            self._remove_follow_action_clip_has_clip_listener(key)
        for key in list(self._follow_action_clip_timing_listeners.keys()):
            self._remove_follow_action_clip_timing_listeners(key)

    def _remove_follow_action_scene_listener(self, key):
        listener_info = self._follow_action_scene_triggered_listeners.pop(key, None)
        if not listener_info:
            return
        scene, listener = listener_info
        try:
            remove_listener = getattr(scene, "remove_is_triggered_listener", None)
            has_listener = getattr(scene, "is_triggered_has_listener", None)
            if remove_listener and (not has_listener or has_listener(listener)):
                remove_listener(listener)
        except Exception:
            pass

    def _remove_follow_action_clip_slot_listeners(self, key):
        listener_info = self._follow_action_clip_slot_runtime_listeners.pop(key, None)
        if not listener_info:
            return
        clip_slot, triggered_listener, playing_listener = listener_info
        try:
            remove_listener = getattr(clip_slot, "remove_is_triggered_listener", None)
            has_listener = getattr(clip_slot, "is_triggered_has_listener", None)
            if remove_listener and (not has_listener or has_listener(triggered_listener)):
                remove_listener(triggered_listener)
        except Exception:
            pass
        try:
            remove_listener = getattr(clip_slot, "remove_is_playing_listener", None)
            has_listener = getattr(clip_slot, "is_playing_has_listener", None)
            if remove_listener and (not has_listener or has_listener(playing_listener)):
                remove_listener(playing_listener)
        except Exception:
            pass

    def _sync_follow_action_runtime_listeners(self):
        expected_scene_keys = set()
        expected_clip_keys = set()

        for key, rule in self._follow_action_rules.items():
            target_kind = rule.get("target_kind")
            scene_index = rule.get("scene_index")

            if target_kind == "scene":
                expected_scene_keys.add(key)
                try:
                    scene = self.song().scenes[scene_index]
                except Exception:
                    continue
                existing = self._follow_action_scene_triggered_listeners.get(key)
                if existing and existing[0] is scene:
                    continue
                self._remove_follow_action_scene_listener(key)
                try:
                    listener = self._make_follow_action_scene_triggered_listener(scene_index)
                    scene.add_is_triggered_listener(listener)
                    self._follow_action_scene_triggered_listeners[key] = (scene, listener)
                except Exception:
                    pass

            elif target_kind == "clip":
                track_index = rule.get("track_index")
                expected_clip_keys.add(key)
                try:
                    clip_slot = self.song().tracks[track_index].clip_slots[scene_index]
                except Exception:
                    continue
                existing = self._follow_action_clip_slot_runtime_listeners.get(key)
                if existing and existing[0] is clip_slot:
                    continue
                self._remove_follow_action_clip_slot_listeners(key)
                try:
                    triggered_listener = self._make_follow_action_clip_slot_listener(track_index, scene_index, clip_slot)
                    playing_listener = self._make_follow_action_clip_slot_listener(track_index, scene_index, clip_slot)
                    clip_slot.add_is_triggered_listener(triggered_listener)
                    clip_slot.add_is_playing_listener(playing_listener)
                    self._follow_action_clip_slot_runtime_listeners[key] = (clip_slot, triggered_listener, playing_listener)
                except Exception:
                    pass

        for key in list(self._follow_action_scene_triggered_listeners.keys()):
            if key not in expected_scene_keys:
                self._remove_follow_action_scene_listener(key)
        for key in list(self._follow_action_clip_slot_runtime_listeners.keys()):
            if key not in expected_clip_keys:
                self._remove_follow_action_clip_slot_listeners(key)

    def _remove_follow_action_runtime_listeners(self):
        for key in list(self._follow_action_scene_triggered_listeners.keys()):
            self._remove_follow_action_scene_listener(key)
        for key in list(self._follow_action_clip_slot_runtime_listeners.keys()):
            self._remove_follow_action_clip_slot_listeners(key)

    def _clear_finished_follow_action_launches(self):
        for key in list(self._handled_follow_action_launches):
            try:
                if key[0] == "clip":
                    _, track_index, scene_index = key
                    clip_slot = self.song().tracks[track_index].clip_slots[scene_index]
                    if not clip_slot.has_clip or not clip_slot.is_playing:
                        self._handled_follow_action_launches.discard(key)
                elif key[0] == "scene":
                    _, scene_index = key
                    if not self._scene_is_playing(scene_index):
                        self._handled_follow_action_launches.discard(key)
            except Exception:
                self._handled_follow_action_launches.discard(key)

    def _on_clip_has_clip_changed(self, track=None):
        # self.log_message("has clip status changed")
        self._mutator_clip_presence_dirty = True
        self._refresh_parameter_metadata_on_automation_change()
        if track:
            track_index = self._get_track_index(track)
            if track_index is not None:
                self._update_clip_slots(track_index)
                self._sync_clip_color_listeners_for_track(track)
                self._set_up_notes_playing("clip")
                return
        self._update_clip_slots()
        self._set_up_notes_playing("clip")

    def _update_clip_slots(self, only_track_index=None):
        try:
            track_clips = []
            tracks = self.song().tracks
            if only_track_index is not None and len(self.old_clips_array) != len(tracks):
                only_track_index = None
            for track_index, track in enumerate(tracks):
                if only_track_index is not None and track_index != only_track_index:
                    track_clips.append(self.old_clips_array[track_index] if track_index < len(self.old_clips_array) else "")
                    continue
                try:
                    is_armed = track.arm
                    has_audio = track.has_audio_input
                except Exception:
                    is_armed = False
                    has_audio = False
                # track clip slots
                clip_slots = []
                try:
                    for clip_slot in track.clip_slots:
                        clip_value = "0"
                        try:
                            if clip_slot.is_triggered:
                                clip_value = "4"
                            elif clip_slot.is_recording:
                                clip_value = "3"
                            elif clip_slot.is_playing:
                                clip_value = "2"
                            elif clip_slot.has_clip:
                                clip_value = "1"
                            elif is_armed and has_audio:
                                clip_value = "5"
                        except Exception:
                            clip_value = "0"

                        color_string_value = "0"
                        
                        # this could also just be made to if value == "1", but does not hurt this way
                        if clip_value != "0" and clip_slot.has_clip:
                            # extra test if has clip because group channels don't have a clip but might be triggered etc
                            try:
                                if clip_slot.clip.color is not None:
                                    color_string_value = self._make_color_string(clip_slot.clip.color)
                            except Exception:
                                color_string_value = "0"
                        #     playing_position = clip_slot.clip.playing_position
                        #     length = clip_slot.clip.length
                        #     self.log_message("playing: {} triggering {}".format(is_playing_value, is_triggered_value))
                        # else:
                        #     playing_position = 0.0
                        #     length = 0.0

                        clip_string = "{}:{}".format(clip_value, color_string_value)
                        clip_slots.append(clip_string)
                except Exception as e:
                    pass
                clip_slots_string = "-".join(clip_slots)
                track_clips.append(clip_slots_string)

            # compare old track clips with new
            clips_difference = self.find_different_indexes(track_clips, self.old_clips_array)
            
            # safe new values
            self.old_clips_array = track_clips

            # send different tracks out
            # TODO: now this still does send out each track. not sure why. also it should only send out the clip that is changed and not the whole track I would say.
            if clips_difference != []:
                for track_index in clips_difference:
                    if int(track_index) < len(track_clips):
                        string_prefix = str(track_index) + "%"
                        track_string = string_prefix + str(track_clips[track_index])
                        self._send_sys_ex_message(track_string, 0x05)
                    else:
                        delete_clips = "DEL" + str(track_index)
                        self._send_sys_ex_message(delete_clips, 0x05)
        except Exception as e:
            # need to stop threading or we get a fatal error.
            # self.periodic_timer = 0
            pass

    def _on_scale_changed(self):
        song = self.song()
        scale = song.scale_name
        root = song.root_note
        scale_string = "{};{}".format(self._escape_sysex_string(scale), root)
        self._send_sys_ex_message(scale_string, 0x0A)
        self._schedule_mutator_scale_root_sync()
        rebuilt_flin = self._rebuild_visible_melodic_flin()
        if not rebuilt_flin:
            try:
                self.send_selected_clip_metadata()
            except Exception:
                pass

    def _flin_quantum_beats(self, info):
        return (0.125, 0.25, 0.5, 1.0)[max(0, min(3, int(info.get("quantization", 1))))]

    def _flin_beats_per_bar(self, clip):
        numerator = max(1, int(getattr(clip, "signature_numerator", 4)))
        denominator = max(1, int(getattr(clip, "signature_denominator", 4)))
        return float(numerator) * 4.0 / float(denominator)

    def _flin_period_ticks(self, info, clip, row):
        quantum = self._flin_quantum_beats(info)
        base_bars = float(info.get("base_quarters", 16)) / 4.0
        base_ticks = max(1, int(round(base_bars * self._flin_beats_per_bar(clip) / quantum)))
        row = max(0, min(15, int(row)))
        mode = max(0, min(5, int(info.get("rate_mode", 0))))
        primes = (1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47)
        if mode == 1:
            raw = float(base_ticks) / float(row + 1)
        elif mode == 2:
            raw = float(base_ticks) / float(2 ** row)
        elif mode == 3:
            raw = float(base_ticks) * ((1.0 / float(base_ticks)) ** (float(row) / 15.0))
        elif mode == 4:
            raw = float(base_ticks) / float(primes[row])
        elif mode == 5:
            bottom_beats = (0.125, 0.25, 0.5, 1.0)[max(0, min(3, int(info.get("bottom_rate", 1))))]
            row_step = (2.0, 4.0 / 3.0, 1.0, 0.5, 0.25, 0.125)[max(0, min(5, int(info.get("row_interval", 4))))]
            raw = (bottom_beats + float(15 - row) * row_step) / quantum
        else:
            raw = float(base_ticks) * float(16 - row) / 16.0
        return max(1, int(math.floor(raw + 0.5)))

    def _flin_loop_ticks(self, info, clip):
        quantum = self._flin_quantum_beats(info)
        beats_per_bar = self._flin_beats_per_bar(clip)
        base_ticks = max(1, int(round((float(info.get("base_quarters", 16)) / 4.0) * beats_per_bar / quantum)))
        horizon_ticks = max(1, int(round(float(info.get("horizon_bars", 64)) * beats_per_bar / quantum)))
        common = base_ticks
        for column in info.get("columns", []):
            if not column.get("active", False):
                continue
            period = self._flin_period_ticks(info, clip, column.get("rate_row", 0))
            common = (common * period) // math.gcd(common, period)
            if common > horizon_ticks:
                info["limited"] = True
                return horizon_ticks
        info["limited"] = common > horizon_ticks
        return min(horizon_ticks, max(base_ticks, common))

    def _flin_column_offset(self, info, page, column_id):
        density = max(1, min(4, int(info.get("mapping_mode", 0)) + 1))
        absolute_column = int(page) * 16 + int(column_id)
        return int(math.floor(float(absolute_column) / float(density)))

    def _flin_column_for_page(self, info, page, column_id):
        for column in info.get("columns", []):
            if int(column.get("page", 0)) == int(page) and int(column.get("id", -1)) == int(column_id):
                return column
        return None

    def _flin_column_is_persistent(self, info, column):
        default_velocity = max(1, min(127, int(info.get("default_velocity", 100))))
        return (
            bool(column.get("active", False))
            or int(column.get("velocity", default_velocity)) != default_velocity
            or int(column.get("probability", 100)) != 100
        )

    def _flin_remap_density(self, info, new_mode):
        old_density = max(1, min(4, int(info.get("mapping_mode", 0)) + 1))
        new_density = max(1, min(4, int(new_mode) + 1))
        if old_density == new_density:
            return

        remapped = {}
        for source in info.get("columns", []):
            absolute = int(source.get("page", 0)) * 16 + int(source.get("id", 0))
            pitch_slot = int(math.floor(float(absolute) / float(old_density)))
            lane = absolute - pitch_slot * old_density
            # Reducing density deliberately removes the duplicate lanes that
            # no longer exist; lane zero keeps the pitch and rhythm.
            if lane >= new_density:
                continue
            target_absolute = pitch_slot * new_density + lane
            target_page = int(math.floor(float(target_absolute) / 16.0))
            target_id = target_absolute - target_page * 16
            target = dict(source)
            target["page"] = target_page
            target["id"] = target_id
            key = (target_page, target_id)
            previous = remapped.get(key)
            if previous is None or (target.get("active", False) and not previous.get("active", False)):
                remapped[key] = target

        old_view = int(info.get("view_page", 0))
        first_pitch_slot = int(math.floor(float(old_view * 16) / float(old_density)))
        first_new_column = first_pitch_slot * new_density
        info["view_page"] = max(-64, min(63, int(math.floor(float(first_new_column) / 16.0))))
        info["mapping_mode"] = new_density - 1
        info["columns"] = sorted(remapped.values(), key=lambda value: (value["page"], value["id"]))

    def _flin_visible_columns(self, info):
        page = max(-64, min(63, int(info.get("view_page", 0))))
        result = []
        for column_id in range(16):
            stored = self._flin_column_for_page(info, page, column_id)
            mapped = self._flin_column_offset(info, page, column_id)
            if stored is None:
                stored = {
                    "page": page, "id": column_id, "active": False,
                    "rate_row": 0, "duration_steps": 1, "phase_ticks": 0,
                    "octave_offset": 0,
                    "velocity": max(1, min(127, int(info.get("default_velocity", 100)))),
                    "probability": 100,
                }
            column = dict(stored)
            column["id"] = column_id
            column["page"] = page
            column["scale_degree"] = mapped
            column["pad_offset"] = mapped
            result.append(column)
        return result

    def _flin_raw_pitch(self, info, column):
        page = int(column.get("page", info.get("view_page", 0)))
        mapped = self._flin_column_offset(info, page, int(column.get("id", 0)))
        if int(info.get("kind", 0)) == 1:
            return int(info.get("base_pitch", 36)) + int(info.get("global_offset", 0)) * 16 + mapped
        song = self.song()
        root = max(0, min(11, int(getattr(song, "root_note", 0))))
        intervals = self._mutator_scale_intervals(str(getattr(song, "scale_name", "Minor")))
        octave, normalized_degree = divmod(mapped, max(1, len(intervals)))
        root_at_octave = (int(info.get("base_pitch", 60)) // 12) * 12 + root
        return root_at_octave + (int(info.get("global_offset", 0)) + octave) * 12 + intervals[normalized_degree]

    def _flin_pitch_bounds(self, info):
        active = [column for column in info.get("columns", []) if column.get("active", False)]
        source = active if active else self._flin_visible_columns(info)
        pitches = [self._flin_raw_pitch(info, column) for column in source]
        if not pitches:
            return (0, 127)
        return (max(0, min(127, min(pitches))), max(0, min(127, max(pitches))))

    def _flin_pitch(self, info, column):
        return max(0, min(127, self._flin_raw_pitch(info, column)))

    def _flin_rebuild_clip(self, clip, info, send_updates=True):
        if clip is None or not getattr(clip, "is_midi_clip", False):
            return False
        quantum = self._flin_quantum_beats(info)
        loop_ticks = self._flin_loop_ticks(info, clip)
        loop_start = float(getattr(clip, "loop_start", 0.0))
        loop_length = max(quantum, float(loop_ticks) * quantum)
        specs = []
        for column in info.get("columns", []):
            if not column.get("active", False):
                continue
            period = self._flin_period_ticks(info, clip, column.get("rate_row", 0))
            phase = int(column.get("phase_ticks", 0)) % max(1, period)
            duration_sixteenths = max(1, min(16, int(column.get("duration_steps", 1))))
            repeat_distance_ticks = max(1, min(period, loop_ticks))
            duration_beats = float(repeat_distance_ticks) * quantum * float(duration_sixteenths) / 16.0
            tick = phase
            while tick < loop_ticks:
                specs.append(MidiNoteSpecification(
                    pitch=self._flin_pitch(info, column),
                    start_time=loop_start + float(tick) * quantum,
                    duration=max(0.0001, duration_beats),
                    velocity=max(1, min(127, int(column.get("velocity", 100)))),
                    mute=False,
                    probability=max(0.0, min(1.0, float(column.get("probability", 100)) / 100.0)),
                ))
                tick += period

        remove_start = min(
            loop_start,
            float(getattr(clip, "start_time", loop_start)),
            float(getattr(clip, "start_marker", loop_start)),
        ) - self.clip_length_trick
        old_end = max(
            loop_start + loop_length,
            float(getattr(clip, "loop_end", loop_start)),
            float(getattr(clip, "end_marker", loop_start)),
            float(getattr(clip, "length", loop_length)),
        )
        self._begin_selected_clip_update_batch()
        undo_step_started = self._begin_undo_step()
        try:
            if hasattr(clip, "remove_notes_extended"):
                clip.remove_notes_extended(0, 128, remove_start, max(0.0001, old_end - remove_start))
            for start in range(0, len(specs), 512):
                clip.add_new_notes(tuple(specs[start:start + 512]))
            clip.start_marker = min(float(getattr(clip, "start_marker", loop_start)), loop_start)
            clip.loop_end = loop_start + loop_length
            clip.end_marker = loop_start + loop_length
            clip.looping = True
            self._save_flin_info_to_name(clip, info)

            decoupled = self._decoupled_automation_info(clip)
            if decoupled:
                decoupled["note_start"] = loop_start
                decoupled["note_length"] = loop_length
                decoupled["note_end"] = loop_start + loop_length
                self._save_decoupled_automation_info_to_name(clip, decoupled)
        finally:
            self._end_undo_step(undo_step_started)
            self._end_selected_clip_update_batch()
        if send_updates:
            self.send_selected_clip_metadata()
            self.send_selected_clip_notes()
        return True

    def _flin_settings_from_payload(self, parts):
        try:
            if len(parts) < 16:
                return None
            info = {
                "kind": max(0, min(1, int(parts[2]))),
                "quantization": max(0, min(3, int(parts[3]))),
                "base_quarters": max(1, min(64, int(parts[4]))),
                "rate_mode": max(0, min(5, int(parts[5]))),
                "bottom_rate": max(0, min(3, int(parts[6]))),
                "row_interval": max(0, min(5, int(parts[7]))),
                "horizon_bars": int(parts[8]),
                "mapping_mode": max(0, min(3, int(parts[9]))),
                "global_offset": max(-64, min(63, int(parts[10]))),
                "view_page": max(-64, min(63, int(parts[11]))),
                "base_pitch": max(0, min(127, int(parts[12]))),
                "seed": max(1, min(2000000, int(parts[13]))),
                "default_velocity": max(1, min(127, int(parts[14]))),
                "limited": False,
                "columns": [],
            }
            if info["horizon_bars"] not in (4, 8, 16, 32, 64, 96):
                return None
            for record in parts[15].split(","):
                values = [int(value) for value in record.split(":")]
                if len(values) != 10:
                    return None
                info["columns"].append({
                    "page": info["view_page"],
                    "id": max(0, min(15, values[0])), "active": values[1] == 1,
                    "rate_row": max(0, min(15, values[2])), "duration_steps": max(1, min(16, values[3])),
                    "phase_ticks": max(0, values[4]), "scale_degree": max(-63, min(63, values[5])),
                    "octave_offset": max(-8, min(8, values[6])), "pad_offset": max(-63, min(63, values[7])),
                    "velocity": max(1, min(127, values[8])), "probability": max(0, min(100, values[9])),
                })
            if len(info["columns"]) != 16:
                return None
            info["columns"].sort(key=lambda column: column["id"])
            return info
        except Exception:
            return None

    def _handle_flin_command(self, message):
        try:
            payload = bytes(message[2:-1]).decode("ascii")
            parts = payload.split("|")
            if len(parts) < 2 or parts[0] != "v1":
                return
            slot = self.song().view.highlighted_clip_slot
            if slot is None or not slot.has_clip or not getattr(slot.clip, "is_midi_clip", False):
                return
            clip = slot.clip
            action = parts[1]
            if action in ("activate", "settings"):
                incoming = self._flin_settings_from_payload(parts)
                if not incoming or (action == "activate" and self._mutator_info(clip)):
                    return
                if action == "activate":
                    info = incoming
                    info["columns"] = [
                        column for column in incoming["columns"]
                        if self._flin_column_is_persistent(incoming, column)
                    ]
                else:
                    info = self._flin_info(clip)
                    if not info:
                        return
                    for key in (
                        "kind", "quantization", "base_quarters", "rate_mode", "bottom_rate", "row_interval", "horizon_bars",
                        "mapping_mode", "global_offset", "view_page", "base_pitch", "seed",
                        "default_velocity",
                    ):
                        info[key] = incoming[key]
                    page = incoming["view_page"]
                    info["columns"] = [
                        column for column in info.get("columns", [])
                        if int(column.get("page", 0)) != page
                    ] + [
                        column for column in incoming["columns"]
                        if self._flin_column_is_persistent(incoming, column)
                    ]
                if any(
                    not 0 <= self._flin_raw_pitch(info, column) <= 127
                    for column in info.get("columns", []) if column.get("active", False)
                ):
                    self.send_selected_clip_metadata()
                    return
                self._flin_rebuild_clip(clip, info)
                return
            info = self._flin_info(clip)
            if not info:
                return
            if action == "gesture" and len(parts) >= 8:
                was_playing = bool(getattr(slot, "is_playing", False))
                page = max(-64, min(63, int(parts[2])))
                column_index = max(0, min(15, int(parts[3])))
                row = max(0, min(15, int(parts[4])))
                duration = max(1, min(16, int(parts[5])))
                velocity = max(1, min(127, int(parts[6])))
                probability = max(0, min(100, int(parts[7])))
                period = self._flin_period_ticks(info, clip, row)
                quantum = self._flin_quantum_beats(info)
                if was_playing:
                    position = float(getattr(clip, "playing_position", clip.loop_start))
                    relative_tick = int(math.ceil(((position - float(clip.loop_start)) / quantum) - 0.000001))
                    phase_tick = (relative_tick + period) % period
                else:
                    # A stopped gesture authors the note at the clip start and
                    # launches the clip. Live playback, not an audition note,
                    # produces the sound.
                    phase_tick = 0
                column = self._flin_column_for_page(info, page, column_index)
                if column is None:
                    column = {"page": page, "id": column_index}
                    info["columns"].append(column)
                column.update(
                    active=True, rate_row=row, duration_steps=duration, phase_ticks=phase_tick,
                    velocity=velocity, probability=probability, octave_offset=0,
                )
                self._flin_rebuild_clip(clip, info)
                if not was_playing:
                    slot.fire()
            elif action == "remove" and len(parts) >= 4:
                page = max(-64, min(63, int(parts[2])))
                column_index = max(0, min(15, int(parts[3])))
                column = self._flin_column_for_page(info, page, column_index)
                if column is not None:
                    column["active"] = False
                self._flin_rebuild_clip(clip, info)
            elif action == "column" and len(parts) >= 6:
                page = max(-64, min(63, int(parts[2])))
                column_index = max(0, min(15, int(parts[3])))
                velocity = max(1, min(127, int(parts[4])))
                probability = max(0, min(100, int(parts[5])))
                duration = max(1, min(16, int(parts[6]))) if len(parts) >= 7 else None
                column = self._flin_column_for_page(info, page, column_index)
                if column is None:
                    column = {
                        "page": page, "id": column_index, "active": False,
                        "rate_row": 0, "duration_steps": 1, "phase_ticks": 0,
                        "octave_offset": 0,
                    }
                    info["columns"].append(column)
                column["velocity"] = velocity
                column["probability"] = probability
                if duration is not None:
                    column["duration_steps"] = duration
                if column.get("active", False):
                    self._flin_rebuild_clip(clip, info)
                else:
                    self._save_flin_info_to_name(clip, info)
                    self.send_selected_clip_metadata()
            elif action == "transpose" and len(parts) >= 3:
                amount = max(-64, min(63, int(parts[2])))
                candidate = dict(info)
                candidate["global_offset"] = max(
                    -64,
                    min(63, int(info.get("global_offset", 0)) + amount)
                )
                if all(
                    0 <= self._flin_raw_pitch(candidate, column) <= 127
                    for column in candidate.get("columns", []) if column.get("active", False)
                ):
                    info["global_offset"] = candidate["global_offset"]
                    self._flin_rebuild_clip(clip, info)
                else:
                    self.send_selected_clip_metadata()
            elif action == "density" and len(parts) >= 3:
                target_mode = max(0, min(3, int(parts[2])))
                self._flin_remap_density(info, target_mode)
                if any(
                    not 0 <= self._flin_raw_pitch(info, column) <= 127
                    for column in info.get("columns", []) if column.get("active", False)
                ):
                    self.send_selected_clip_metadata()
                    return
                self._flin_rebuild_clip(clip, info)
            elif action == "view" and len(parts) >= 3:
                target = max(-64, min(63, int(parts[2])))
                candidate = dict(info)
                candidate["view_page"] = target
                if all(0 <= self._flin_raw_pitch(candidate, column) <= 127 for column in self._flin_visible_columns(candidate)):
                    info["view_page"] = target
                    self._save_flin_info_to_name(clip, info)
                    self.send_selected_clip_metadata()
            elif action == "velocity" and len(parts) >= 3:
                delta = max(-127, min(127, int(parts[2])))
                info["default_velocity"] = max(1, min(127, int(info.get("default_velocity", 100)) + delta))
                for column in info.get("columns", []):
                    column["velocity"] = max(1, min(127, int(column.get("velocity", 100)) + delta))
                self._flin_rebuild_clip(clip, info)
            elif action == "reset" and len(parts) >= 4:
                target = str(parts[2])
                value = int(parts[3])
                if target == "velocity":
                    value = max(1, min(127, value))
                    info["default_velocity"] = value
                    for column in info.get("columns", []):
                        column["velocity"] = value
                elif target == "probability":
                    value = max(0, min(100, value))
                    for column in info.get("columns", []):
                        column["probability"] = value
                else:
                    return
                self._flin_rebuild_clip(clip, info)
            elif action == "clear":
                for column in info.get("columns", []):
                    column["active"] = False
                self._flin_rebuild_clip(clip, info)
            elif action == "exit":
                self._remove_flin_info_from_name(clip)
                self.send_selected_clip_metadata()
                self.send_selected_clip_notes()
        except Exception as e:
            self._debug_log("Error handling Flin command: {}".format(str(e)))

    def _rebuild_visible_melodic_flin(self):
        try:
            slot = self.song().view.highlighted_clip_slot
            if slot is not None and slot.has_clip:
                info = self._flin_info(slot.clip)
                if info and int(info.get("kind", 0)) == 0:
                    return self._flin_rebuild_clip(slot.clip, info)
        except Exception as e:
            self._debug_log("Error following scale for Flin: {}".format(str(e)))
        return False

    def handle_sysex(self, message):
        """
        Handles incoming SysEx messages, including multi-part (chunked) ones.
        Chunks start with '$' (more coming) or '_' (final chunk).
        Only for message ids that can be chunked by the app.
        """
        # Ensure we have a buffer for assembling chunks
        if not hasattr(self, "_sysex_buffer"):
            self._sysex_buffer = []
    
        # Basic validity check
        if len(message) < 3:
            self._sysex_buffer = []
            return
        
        manufacturer_id = message[1]
        prefix = message[2]
    
        # Check if this message is chunked. Existing Tap app -> script chunks
        # always use the prefix directly after the manufacturer id.
        if manufacturer_id in self.CHUNKED_INCOMING_SYSEX_IDS:
            if prefix == 36:
                # Intermediate chunk
                self._sysex_buffer.extend(message[3:-1])  # skip F0, manuf, prefix, F7
                return
        
            elif prefix == 95:
                # Final chunk — assemble full message
                self._sysex_buffer.extend(message[3:-1])
                full_message = [0xF0, manufacturer_id] + self._sysex_buffer + [0xF7]
                self._sysex_buffer = []  # reset buffer
        
                # Now call the original handler
                self._handle_full_sysex(full_message)
                return
            
            else:
                self._sysex_buffer = []
                self._handle_full_sysex(message)
                return
        
        else:
            if self._sysex_buffer != []:
                # Cancel chunking, something went wrong
                self._sysex_buffer = []
                return
                
            else:
                # Non-chunked message → handle directly
                self._handle_full_sysex(message)

    def _handle_full_sysex(self, message):
        # Selected audio-clip editing, sample loading and conversion commands.
        if len(message) >= 3 and message[1] == 0x52:
            self._handle_audio_clip_command(message)
            return

        # Select the expression encoder shown in Track Controls.
        if len(message) >= 3 and message[1] == 0x4F:
            self._handle_track_expression_control_command(message)
            return

        # Native Live note repeat always targets the selected MIDI track.
        if len(message) >= 3 and message[1] == 0x4B:
            self._handle_note_repeat_command(message)
            return

        # Clip/Mixer views explicitly provide the raw track indexes currently
        # visible in the app. Keep position work completely dormant elsewhere.
        if len(message) >= 3 and message[1] == 0x47:
            self._set_clip_position_feedback(self.extract_values_from_sysex_message(message))
            return
        # Push-style Simpler option row.
        if len(message) >= 4 and message[1] == 0x43:
            values = self.extract_values_from_sysex_message(message)
            if values:
                self._trigger_simpler_action(values[0])
            return
        # Simpler's two-axis Zoom control sends zoom and waveform center as
        # two 14-bit normalized values.
        if len(message) >= 7 and message[1] == 0x46:
            self._set_simpler_viewport(self.extract_values_from_sysex_message(message))
            return
        # The app may connect after the one-time sample-change waveform send.
        if len(message) >= 4 and message[1] == 0x45:
            self._debug_log('Simpler waveform requested by app')
            self._request_simpler_waveform()
            return
        # Browser name search and content-tag filtering are performed here in the
        # Remote Script so the app only ever receives the current 12-item page.
        if len(message) >= 3 and message[1] == 0x3C:
            self._browser_search(message)
            return
        # Preview the item at the supplied one-based row index, or stop at zero.
        if len(message) >= 3 and message[1] == 0x3D:
            values = self.extract_values_from_sysex_message(message)
            self._browser_preview(values[0] if values else 0)
            return
        # Flin owns the MIDI notes of a marked clip while the mode is active.
        if len(message) >= 3 and message[1] == 0x3E:
            self._handle_flin_command(message)
            return
        # start stop clip
        if len(message) >= 2 and message[1] == 9:
            values = self.extract_values_from_sysex_message(message)
            if len(values) == 3:
                self._fire_clip(values[0], values[1], values[2])
        # delete clip
        if len(message) >= 2 and message[1] == 10:
            values = self.extract_values_from_sysex_message(message)
            if len(values) == 2:
                self._delete_clip(values[0], values[1])
        # copy paste clip
        if len(message) >= 2 and message[1] == 11:
            values = self.extract_values_from_sysex_message(message)
            if len(values) == 4:
                self._copy_paste_clip(values[0], values[1], values[2], values[3])
        # scale and rootnote
        if len(message) >= 2 and message[1] == 12:
            values = self.decode_sys_ex_scale_root(message)
            if len(values) == 2:
                self._set_scale_root_note(values[0], values[1])
        # duplicate loop
        if len(message) >= 2 and message[1] == 13:
            values = self.extract_values_from_sysex_message(message)
            if len(values) == 2:
                self._duplicate_loop(values[0], values[1])
        # request selected track local controls (ModWheel/Pressure)
        if len(message) >= 2 and message[1] == 59:
            self._send_track_local_control_state()
        
        # add MULTIPLE notes
        if len(message) >= 2 and message[1] == 14:
            index = 2
            new_notes = []
            new_note_values = []

            # Decode all notes in the message
            while index + 10 <= (len(message) - 1):
                # Decode the pitch of the note
                note_pitch = message[index]
                index += 1

                # Decode the start-time magnitude (3 bytes, 7-bit packed)
                if index + 3 > len(message):
                    break
                start_time_magnitude = self._from_3_7bit_magnitude(message, index)
                index += 3

                # Decode the duration magnitude (3 bytes, 7-bit packed)
                if index + 3 > len(message):
                    break
                duration_magnitude = self._from_3_7bit_magnitude(message, index)
                index += 3

                # Decode velocity
                if index >= len(message):
                    break
                velocity = message[index]
                index += 1

                # Probability and note/sign flags are separate SysEx7-safe bytes.
                probability = message[index] / 127.0
                index += 1
                note_flags = message[index]
                index += 1
                start_time = self._value_from_magnitude(
                    start_time_magnitude,
                    note_flags,
                    1
                )
                duration = self._value_from_magnitude(
                    duration_magnitude,
                    note_flags,
                    2
                )
                mute = bool(note_flags & self.NOTE_FLAG_MUTE)

                # Create a MidiNoteSpecification object
                note_spec = MidiNoteSpecification(
                    pitch=note_pitch,
                    start_time=start_time / 1000.0,
                    duration=duration / 1000.0,
                    velocity=velocity,
                    mute=mute,
                    probability=probability
                )

                new_notes.append(note_spec)
                new_note_values.append((
                    note_pitch,
                    start_time / 1000.0,
                    duration / 1000.0,
                    velocity,
                    mute,
                    probability
                ))

            # Add all decoded notes to the current clip
            song = self.song()
            clip_slot = song.view.highlighted_clip_slot
            if clip_slot is not None and clip_slot.has_clip and len(new_notes) > 0:
                clip = clip_slot.clip
                filtered_notes = []
                filtered_note_values = []
                for note_spec, note_values in zip(new_notes, new_note_values):
                    if self._mutator_allows_source_note_time(clip, note_values[1]):
                        filtered_notes.append(note_spec)
                        filtered_note_values.append(note_values)
                new_notes = filtered_notes
                new_note_values = filtered_note_values
                if not new_notes:
                    return
                decoupled_info = self._decoupled_automation_info(clip)
                if decoupled_info:
                    repeated_notes = []
                    for pitch, start_time, duration, velocity, mute, probability in new_note_values:
                        repeated_notes.extend(self._make_repeated_note_specs_from_values(
                            pitch,
                            start_time,
                            duration,
                            velocity,
                            mute,
                            probability,
                            decoupled_info
                        ))
                    if repeated_notes:
                        clip.add_new_notes(repeated_notes)
                else:
                    clip.add_new_notes(new_notes)
        
        # remove note (also multiple)
        if len(message) >= 2 and message[1] == 15:
            note_ids = []
            index = 2
            while index + 5 <= (len(message) - 1):
                note_id = self._from_5_7bit_bytes(message, index)
                note_ids.append(note_id)
                index += 5
        
            # Get the selected clip
            song = self.song()
            clip_slot = song.view.highlighted_clip_slot
            if clip_slot is not None and clip_slot.has_clip:
                clip = clip_slot.clip
                decoupled_info = self._decoupled_automation_info(clip)
                if decoupled_info:
                    notes = clip.get_notes_extended(0, 128, decoupled_info["note_start"], decoupled_info["physical_length"])
                    note_ids = [
                        note_id for note_id in note_ids
                        if any(note.note_id == note_id and self._mutator_allows_source_note_time(clip, note.start_time) for note in notes)
                    ]
                    if not note_ids:
                        return
                    remove_ids = set(note_ids)
                    targets = []
                    for note in notes:
                        if note.note_id in remove_ids:
                            targets.append((int(note.pitch), self._folded_note_time(note.start_time, decoupled_info)))
                    matching_ids = []
                    for note in notes:
                        for pitch, folded_time in targets:
                            if self._note_matches_folded_time(note, folded_time, decoupled_info, pitch=pitch):
                                matching_ids.append(note.note_id)
                                break
                    if matching_ids:
                        clip.remove_notes_by_id(tuple(matching_ids))
                else:
                    clip_start = min(clip.start_time, clip.start_marker, clip.loop_start) - self.clip_length_trick
                    clip_length = (max(clip.loop_end, clip.end_marker, clip.length) + self.clip_length_trick) - clip_start
                    notes = clip.get_notes_extended(0, 128, clip_start, clip_length)
                    note_ids = [
                        note_id for note_id in note_ids
                        if any(note.note_id == note_id and self._mutator_allows_source_note_time(clip, note.start_time) for note in notes)
                    ]
                    if not note_ids:
                        return
                    # Remove the note by ID
                    clip.remove_notes_by_id(note_ids)
        
        # modify MULTIPLE notes
        if len(message) >= 3 and message[1] == 16:
            index = 2
        
            # Get the selected clip
            song = self.song()
            clip_slot = song.view.highlighted_clip_slot
            if clip_slot is not None and clip_slot.has_clip:
                clip = clip_slot.clip
                decoupled_info = self._decoupled_automation_info(clip)
                
                # Fetch existing notes from the clip
                clip_start = min(clip.start_time, clip.start_marker, clip.loop_start) - self.clip_length_trick
                clip_length = (max(clip.loop_end, clip.end_marker, clip.length) + self.clip_length_trick) - clip_start
                notes = clip.get_notes_extended(0, 128, clip_start, clip_length)
                did_modify_notes = False
        
                # Modify the matching notes
                while index < (len(message) - 1):
                    # One record is 15 data bytes. Never decode across the
                    # terminating F7 byte when a packet is truncated.
                    if index + 15 > len(message) - 1:
                        break
                    note_id = self._from_5_7bit_bytes(message, index)
                    index += 5
                    pitch = message[index]
                    index += 1
        
                    start_time_magnitude = self._from_3_7bit_magnitude(message, index)
                    index += 3
        
                    duration_magnitude = self._from_3_7bit_magnitude(message, index)
                    index += 3
        
                    velocity = message[index]
                    index += 1
        
                    probability = message[index] / 127.0
                    index += 1
                    note_flags = message[index]
                    index += 1
                    start_time = self._value_from_magnitude(
                        start_time_magnitude,
                        note_flags,
                        1
                    ) / 1000.0
                    duration = self._value_from_magnitude(
                        duration_magnitude,
                        note_flags,
                        2
                    ) / 1000.0
                    mute = bool(note_flags & self.NOTE_FLAG_MUTE)

                    if decoupled_info:
                        target_note = None
                        for note in notes:
                            if note.note_id == note_id:
                                target_note = note
                                break
                        if target_note is None:
                            continue
                        if not self._mutator_allows_source_note_time(clip, target_note.start_time):
                            continue
                        if not self._mutator_allows_source_note_time(clip, start_time):
                            continue

                        old_pitch = int(target_note.pitch)
                        old_folded_time = self._folded_note_time(target_note.start_time, decoupled_info)
                        new_offset = self._positive_mod(start_time - decoupled_info["note_start"], decoupled_info["note_length"])
                        clipped_duration = self._duration_inside_note_loop(start_time, duration, decoupled_info)
                        for note in notes:
                            if self._note_matches_folded_time(note, old_folded_time, decoupled_info, pitch=old_pitch):
                                repeat_index = int(math.floor(max(0.0, note.start_time - decoupled_info["note_start"]) / decoupled_info["note_length"]))
                                note.pitch = pitch
                                note.start_time = decoupled_info["note_start"] + (float(repeat_index) * decoupled_info["note_length"]) + new_offset
                                note.duration = clipped_duration
                                note.velocity = velocity
                                note.mute = mute
                                note.probability = probability
                                did_modify_notes = True
                    else:
                        for note in notes:
                            if note.note_id == note_id:
                                if not self._mutator_allows_source_note_time(clip, note.start_time):
                                    break
                                if not self._mutator_allows_source_note_time(clip, start_time):
                                    break
                                note.pitch = pitch
                                note.start_time = start_time
                                note.duration = duration
                                note.velocity = velocity
                                note.mute = mute
                                note.probability = probability
                                did_modify_notes = True
                                break
        
                # Apply the modified notes back to the clip
                if did_modify_notes:
                    clip.apply_note_modifications(notes)
        
        # markers
        if len(message) >= 7 and message[1] == 17:
            # Decode the note ID and data
            marker_flags = message[2]
            marker_id = marker_flags & self.MARKER_ID_MASK
            
            # Decode the marker magnitude and apply its flag-carried sign.
            index = 3
            marker_time_magnitude = self._from_3_7bit_magnitude(message, index)
            marker_time_raw = (
                -marker_time_magnitude
                if marker_flags & self.MARKER_FLAG_NEGATIVE_TIME
                else marker_time_magnitude
            )
            marker_time = marker_time_raw / 1000.0
            
            # Get the selected clip
            song = self.song()
            clip_slot = song.view.highlighted_clip_slot
            if clip_slot is not None and clip_slot.has_clip:
                clip = clip_slot.clip
                if marker_id == 0:
                    clip.start_marker = marker_time
                elif marker_id == 1:
                    clip.end_marker = marker_time
                elif marker_id == 2:
                    decoupled_info = self._decoupled_automation_info(clip)
                    if decoupled_info:
                        note_end = decoupled_info["note_start"] + decoupled_info["note_length"]
                        note_length = max(0.0001, note_end - marker_time)
                        self._apply_decoupled_note_loop(clip, marker_time, note_length, send_updates=True)
                    else:
                        clip.loop_start = marker_time
                else:
                    decoupled_info = self._decoupled_automation_info(clip)
                    if decoupled_info:
                        note_length = max(0.0001, marker_time - decoupled_info["note_start"])
                        self._apply_decoupled_note_loop(clip, decoupled_info["note_start"], note_length, send_updates=True)
                    else:
                        clip.loop_end = marker_time
        
        # visible channel and mixer status true
        if len(message) >= 5 and message[1] == 18:
            start = message[2]
            end = message[3]
            self.visible_channels = (start, end)
            self.mixer_status = True
            self._last_clip_position_feedback_time = 0.0
            self._last_visual_feedback_payload = None
            self._set_up_mixer_controls()
            
        # combine clips
        if len(message) >= 2 and message[1] == 19:
            values = self.extract_values_from_sysex_message(message)
            if len(values) == 4:
                self._append_and_remove_clip(values[0], values[1], values[2], values[3])
        
        # toggle arm for audio tracks
        if len(message) >= 4 and message[1] == 20:
            track_index = message[2]
            tracks = self.song().tracks
            if 0 <= track_index < len(tracks):
                track = tracks[track_index]
                if getattr(track, 'can_be_armed', True):
                    track.arm = not track.arm
        
        # select next clip
        if len(message) >= 4 and message[1] == 21:
            upValue = message[2]
            track = self.song().view.selected_track
            current_clip_slot = self.song().view.highlighted_clip_slot
            clip_slots = list(getattr(track, 'clip_slots', ()))
            if current_clip_slot not in clip_slots:
                return
            current_index = clip_slots.index(current_clip_slot)
            
            if upValue == 0:  # Move down to next clip
                # Search for next clip slot with a clip
                for i in range(current_index + 1, len(clip_slots)):
                    if clip_slots[i].has_clip:
                        self.song().view.highlighted_clip_slot = clip_slots[i]
                        break
                        
            elif upValue == 1:  # Move up to previous clip
                # Search for previous clip slot with a clip (in reverse)
                for i in range(current_index - 1, -1, -1):
                    if clip_slots[i].has_clip:
                        self.song().view.highlighted_clip_slot = clip_slots[i]
                        break
        if len(message) >= 2 and message[1] == 22:
            tempo_bytes = message[2:-1]
            try:
                tempo_string = bytes(tempo_bytes).decode('ascii')
                new_tempo = float(tempo_string)
                self.song().tempo = new_tempo
                # Optional: print for debugging
                # self.canonical_parent.log_message("Tempo set to " + tempo_string)
            except Exception as e:
                # Optional: log error
                # self.canonical_parent.log_message("Tempo decode error: " + str(e))
                pass
        if len(message) >= 3 and message[1] == 23:
            try:
                self.song().metronome = bool(message[2])
            except Exception:
                pass
        if len(message) >= 2 and message[1] == 43:
            self._handle_tap_tempo()
        if len(message) >= 2 and message[1] == 35:
            self._set_follow_action_rule(message)
        if len(message) >= 2 and message[1] == 36:
            self._delete_follow_action_rule(message)
        if len(message) >= 2 and message[1] == 37:
            self._send_follow_action_state(force=True)
        if len(message) >= 2 and message[1] == 38:
            values = self.extract_values_from_sysex_message(message)
            if len(values) == 1:
                self._stop_track_clips(values[0])
        if len(message) >= 2 and message[1] == 39:
            self._set_device_control_high_resolution(message)
        if len(message) >= 3 and message[1] == 44:
            self._toggle_group_fold(message[2])
        if len(message) >= 3 and message[1] == 45:
            self._add_random_effect_after_device(message[2])
        if len(message) >= 3 and message[1] == 46:
            self._set_browser_insert_after_device(message[2])
        if len(message) >= 4 and message[1] == 47:
            self._move_device_after_index(message[2], message[3])
        if len(message) >= 4 and message[1] == 48:
            self._handle_rack_snapshot_command(message)
        if len(message) >= 2 and message[1] == 49:
            self._send_automation_envelope(message)
        if len(message) >= 2 and message[1] == 50:
            self._set_automation_envelope(message)
        if len(message) >= 2 and message[1] == 51:
            self._set_decoupled_automation_length(message)
        if len(message) >= 2 and message[1] == 52:
            self._unfold_decoupled_automation_clip()
        if len(message) >= 2 and message[1] == 53:
            self._clear_automation_envelope(message)
        if len(message) >= 2 and message[1] == 54:
            self._clear_all_automation_envelopes(message)
        if len(message) >= 2 and message[1] == 55:
            self._set_mutator_clip(message)
        if len(message) >= 2 and message[1] == 56:
            action = message[2] if len(message) >= 3 else 0
            if action == 1:
                self._unfold_mutator_clip()
            else:
                self._end_mutator_clip()
        if len(message) >= 2 and message[1] == 57:
            self._update_mutator_clip_settings(message)
        if len(message) >= 2 and message[1] == 58:
            self._replace_rhythm_generator_lane(message)
    def _replace_rhythm_generator_lane(self, message):
        try:
            payload = bytes(message[2:-1]).decode('ascii', errors='ignore')
            fields = payload.split("|")
            if len(fields) < 3:
                return

            pitch = max(0, min(127, int(fields[0])))
            replace_start = max(0.0, int(fields[1]) / 1000.0)
            replace_end = max(replace_start, int(fields[2]) / 1000.0)
            replace_length = max(0.0001, replace_end - replace_start)
            note_payload = fields[3] if len(fields) > 3 else ""

            clip_slot = self.song().view.highlighted_clip_slot
            if clip_slot is None or not clip_slot.has_clip:
                return
            clip = clip_slot.clip
            if not getattr(clip, "is_midi_clip", False):
                return

            if hasattr(clip, "remove_notes_extended"):
                clip.remove_notes_extended(pitch, 1, replace_start, replace_length)

            specs = []
            for item in note_payload.split(";"):
                if not item:
                    continue
                parts = item.split(",")
                if len(parts) < 3:
                    continue
                start_time = max(0.0, int(parts[0]) / 1000.0)
                duration = max(0.0001, int(parts[1]) / 1000.0)
                velocity = max(1, min(127, int(parts[2])))
                specs.append(MidiNoteSpecification(
                    pitch=pitch,
                    start_time=start_time,
                    duration=duration,
                    velocity=velocity,
                    mute=False,
                    probability=1.0
                ))

            if specs:
                clip.add_new_notes(tuple(specs))
            self.send_selected_clip_metadata()
            self.send_selected_clip_notes()
        except Exception as e:
            self._debug_log("Error replacing rhythm generator lane: {}".format(str(e)))

    def _mutator_settings_from_message(self, message):
        payload = bytes(message[2:-1]).decode('ascii', errors='ignore')
        fields = self._split_escaped_sysex_fields(payload, "|")
        def int_field(index, fallback):
            try:
                return int(fields[index])
            except Exception:
                return fallback
        def float_field(index, fallback):
            try:
                return float(fields[index])
            except Exception:
                return fallback
        seed_index = 11
        algorithm_index = 12
        companion_mode_index = 13
        target_pitches_index = 14
        operation_depths_index = 15
        operation_order_index = operation_depths_index + len(self._mutator_operation_depth_keys())
        mutator_slots_index = operation_order_index + 1
        mutator_slot_count_index = mutator_slots_index + 1
        companion_mode = "rhythm" if int_field(companion_mode_index, 0) == 1 else "melody"
        target_pitches = self._mutator_target_pitches_from_value(fields[target_pitches_index] if len(fields) > target_pitches_index else "")
        operation_depths = self._mutator_operation_depths_from_fields(
            fields,
            operation_depths_index,
            self._mutator_default_operation_depths()
        )
        operation_order = self._mutator_operation_order_from_value(
            fields[operation_order_index] if len(fields) > operation_order_index else ""
        )
        mutator_slots = self._mutator_slots_from_value(
            fields[mutator_slots_index] if len(fields) > mutator_slots_index else ""
        )
        mutator_slot_count = self._mutator_slot_count_from_value(
            fields[mutator_slot_count_index] if len(fields) > mutator_slot_count_index else "",
            mutator_slots
        )
        message_scale = self._unescape_sysex_string(fields[9]) if len(fields) > 9 else "Minor"
        message_scale_index = self._mutator_scale_index_from_name(message_scale)
        if message_scale_index is None:
            message_scale_index = 2
        live_scale_index, live_root = self._current_mutator_scale_root(
            message_scale_index,
            max(0, min(11, int_field(10, 0)))
        )
        return {
            "preset": int_field(0, 9),
            "mutations_per_pass": max(1, min(3, int_field(1, 1))),
            "return_after_passes": max(1, min(4, int_field(2, 2))),
            "return_mode": int_field(3, 0),
            "original_loops": max(0, int_field(4, 4)),
            "loops_per_pass": max(1, int_field(5, 1)),
            "regenerate_mode": int_field(6, 0),
            "source_mode": int_field(7, 2),
            "depth": max(0.0, min(1.0, float_field(8, 0.0))),
            "scale": self._mutator_scale_name_from_index(live_scale_index),
            "root": live_root,
            "seed": int_field(seed_index, random.randint(1, 2000000000)),
            "algorithm": self._unescape_sysex_string(fields[algorithm_index]) if len(fields) > algorithm_index else "mutator",
            "companion_mode": companion_mode,
            "target_pitches": target_pitches,
            "fill_depth": operation_depths.get("fill_depth", 0.0),
            "simplification_depth": operation_depths.get("simplification_depth", 0.0),
            "octave_shift_depth": operation_depths.get("octave_shift_depth", 0.0),
            "rhythmic_shift_depth": operation_depths.get("rhythmic_shift_depth", 0.0),
            "note_addition_depth": operation_depths.get("note_addition_depth", 0.0),
            "note_removal_depth": operation_depths.get("note_removal_depth", 0.0),
            "pitch_shift_depth": operation_depths.get("pitch_shift_depth", 0.0),
            "velocity_change_depth": operation_depths.get("velocity_change_depth", 0.0),
            "gate_change_depth": operation_depths.get("gate_change_depth", 0.0),
            "shift_depth": operation_depths.get("shift_depth", 0.0),
            "operation_order": operation_order,
            "mutator_slots": mutator_slots,
            "mutator_slot_count": mutator_slot_count,
            "settings_payload": payload.replace("|", "~")[:80],
        }

    def _mutator_info_from_settings(self, settings, previous_info, clip, commit_structure=False):
        settings_scale_index = self._mutator_scale_index_from_name(settings.get("scale", "Minor"))
        if settings_scale_index is None:
            settings_scale_index = previous_info.get("scale_index", 2)
        scale_index, root = self._current_mutator_scale_root(
            settings_scale_index,
            settings.get("root", previous_info.get("root", 0))
        )
        preset = settings.get("preset", previous_info.get("preset", 9))
        mutator_slots = self._mutator_visible_slots(settings)
        mutator_slot_count = self._mutator_slot_count_from_value(settings.get("mutator_slot_count", ""), self._mutator_normalized_slots(settings))
        info = {
            "original_loop_length": previous_info.get("original_loop_length", 0.0001),
            "structure_length": previous_info.get("structure_length", previous_info.get("original_loop_length", 0.0001)),
            "preset": preset if commit_structure else previous_info.get("preset", preset),
            "settings_preset": preset,
            "seed": settings.get("seed", previous_info.get("seed", 1)) if commit_structure else previous_info.get("seed", settings.get("seed", 1)),
            "algorithm": settings.get("algorithm", previous_info.get("algorithm", "mutator")),
            "algorithm_code": self._mutator_algorithm_code(settings.get("algorithm", previous_info.get("algorithm", "mutator"))),
            "mutations_per_pass": settings.get("mutations_per_pass", previous_info.get("mutations_per_pass", 1)),
            "depth": settings.get("depth", previous_info.get("depth", 0.0)),
            "regenerate_mode": settings.get("regenerate_mode", previous_info.get("regenerate_mode", 0)),
            "source_mode": settings.get("source_mode", previous_info.get("source_mode", 2)),
            "root": root,
            "scale_index": scale_index,
            "companion_mode": settings.get("companion_mode", previous_info.get("companion_mode", "melody")),
            "companion_mode_code": self._mutator_companion_mode_code(settings.get("companion_mode", previous_info.get("companion_mode", "melody"))),
            "target_pitches": settings.get("target_pitches", previous_info.get("target_pitches", [])),
            "operation_order": [int(slot.get("operation", 0)) for slot in self._mutator_active_slots(settings)],
            "mutator_slots": mutator_slots,
            "mutator_slot_count": mutator_slot_count,
            "sections": previous_info.get("sections", []),
        }
        for key in self._mutator_operation_depth_keys():
            info[key] = self._mutator_depth_value(settings, key, previous_info.get(key, 0.0))
        if commit_structure:
            info["pending_settings_update"] = False
        else:
            info["pending_settings_update"] = (
                bool(previous_info.get("pending_settings_update", False)) or
                self._mutator_generation_settings_changed(info, previous_info)
            )
        return info

    def _mutator_generation_settings_changed(self, info, previous_info):
        comparisons = (
            ("settings_preset", int(info.get("settings_preset", info.get("preset", 9))), int(previous_info.get("settings_preset", previous_info.get("preset", 9)))),
            ("algorithm_code", int(info.get("algorithm_code", 0)), int(previous_info.get("algorithm_code", self._mutator_algorithm_code(previous_info.get("algorithm", "mutator"))))),
            ("mutations_per_pass", int(info.get("mutations_per_pass", 1)), int(previous_info.get("mutations_per_pass", 1))),
            ("source_mode", int(info.get("source_mode", 2)), int(previous_info.get("source_mode", 2))),
            ("root", int(info.get("root", 0)), int(previous_info.get("root", 0))),
            ("scale_index", int(info.get("scale_index", 2)), int(previous_info.get("scale_index", 2))),
            ("companion_mode_code", int(info.get("companion_mode_code", 0)), int(previous_info.get("companion_mode_code", self._mutator_companion_mode_code(previous_info.get("companion_mode", "melody"))))),
        )
        for _, current, previous in comparisons:
            if current != previous:
                return True
        if tuple(info.get("target_pitches", [])) != tuple(previous_info.get("target_pitches", [])):
            return True
        if tuple(info.get("operation_order", [])) != tuple(previous_info.get("operation_order", [])):
            return True
        if tuple(str(slot) for slot in self._mutator_visible_slots(info)) != tuple(str(slot) for slot in self._mutator_visible_slots(previous_info)):
            return True
        if int(info.get("mutator_slot_count", 4)) != int(previous_info.get("mutator_slot_count", 4)):
            return True
        for key in self._mutator_operation_depth_keys():
            try:
                if abs(self._mutator_depth_value(info, key, 0.0) - self._mutator_depth_value(previous_info, key, 0.0)) > 0.005:
                    return True
            except Exception:
                pass
        try:
            return abs(float(info.get("depth", 0.0)) - float(previous_info.get("depth", 0.0))) > 0.005
        except Exception:
            return False

    def _mutator_pattern_roles(self, preset):
        patterns = {
            0: [0, 0, 0, 0, 5, 5, 5, 5],
            1: [0, 0, 0, 0, 4, 4, 5, 5],
            2: [0, 5, 6, 9, 6, 12, 5, 0],
            3: [0, 0, 1, 1, 5, 7, 1, 8],
            4: [0, 0, 1, 1, 5, 7, 6, 6, 1, 8],
            5: [0, 0, 0, 1, 1, 5, 7, 6, 6, 5, 7, 6, 6, 1, 8],
            6: [0, 5, 6, 9],
            7: [0, 0, 5, 5, 6, 6, 9, 9],
            8: [0, 0, 0, 0, 5, 6, 9, 10],
            9: [0, 5],
            10: [0, 0, 5, 5],
            11: [0, 0, 5, 8],
            12: [0, 5, 8, 5, 6, 5],
            13: [0, 1, 2, 5, 6, 8],
            14: [0, 1, 2, 7, 5, 13, 14, 6, 15, 8],
            15: [0, 0, 5, 6, 9, 10],
            16: [0, 0, 5, 5, 16, 16],
            17: [0, 0, 5, 16],
            18: [0, 0, 5, 5, 0, 0, 16, 16],
        }
        return patterns.get(int(preset), patterns[9])

    def _mutator_preset_is_chain(self, preset):
        return int(preset) in (2, 6, 7, 8, 15)

    def _mutator_role_depth(self, role, global_depth):
        ranges = {
            0: (0.0, 0.10),
            1: (0.08, 0.22),
            2: (0.10, 0.26),
            3: (0.50, 0.68),
            4: (0.25, 0.60),
            5: (0.35, 0.70),
            6: (0.20, 0.55),
            7: (0.45, 0.75),
            8: (0.0, 0.0),
            9: (0.30, 0.60),
            10: (0.35, 0.65),
            11: (0.40, 0.70),
            12: (0.38, 0.68),
            13: (0.42, 0.72),
            14: (0.20, 0.50),
            15: (0.45, 0.78),
            16: (0.35, 0.70),
        }
        low, high = ranges.get(role, (0.15, 0.45))
        return low + ((high - low) * max(0.0, min(1.0, global_depth)))

    def _mutator_algorithm_kind(self, algorithm):
        if algorithm in ("verse_weaver", "motif_ladder"):
            return "expand"
        if algorithm in ("sparse_echo",):
            return "variations"
        if algorithm in ("chorus_lift", "middle_eight", "tension_break"):
            return "section"
        if algorithm in ("skylight_hook", "glass_steps", "nocturne_line"):
            return "melody"
        if algorithm in ("modal_drift", "circle_resolve"):
            return "chords"
        return None

    def _mutator_scale_notes(self, settings):
        intervals = self._mutator_scale_intervals(settings.get("scale", "Minor"))
        root = int(settings.get("root", 0)) % 12
        notes = [pitch for pitch in range(128) if ((pitch - root) % 12) in intervals]
        return notes if notes else list(range(128))

    def _mutator_scale_index(self, pitch, scale_notes):
        return min(range(len(scale_notes)), key=lambda index: abs(scale_notes[index] - int(round(pitch))))

    def _mutator_transpose_scale_steps(self, pitch, steps, settings):
        if settings.get("scale", "Minor") == "Chromatic":
            return max(0, min(127, int(round(pitch + steps))))
        scale_notes = self._mutator_scale_notes(settings)
        index = self._mutator_scale_index(pitch, scale_notes)
        return scale_notes[max(0, min(len(scale_notes) - 1, index + int(steps)))]

    def _mutator_scale_step_span_for_octave_fraction(self, pitch, amount, settings):
        amount = max(0.0, min(1.0, float(amount)))
        if amount <= 0.0:
            return 0
        if settings.get("scale", "Minor") == "Chromatic":
            return max(1, int(math.ceil(amount * 12.0)))

        scale_notes = self._mutator_scale_notes(settings)
        index = self._mutator_scale_index(pitch, scale_notes)
        source_pitch = scale_notes[index]
        semitone_span = max(1, int(math.ceil(amount * 12.0)))
        upper = index
        while upper + 1 < len(scale_notes) and scale_notes[upper + 1] - source_pitch <= semitone_span:
            upper += 1
        lower = index
        while lower - 1 >= 0 and source_pitch - scale_notes[lower - 1] <= semitone_span:
            lower -= 1
        return max(1, upper - index, index - lower)

    def _mutator_degree_pitch(self, degree, octave, settings):
        intervals = self._mutator_scale_intervals(settings.get("scale", "Minor"))
        degree = int(degree)
        octave_shift = degree // len(intervals)
        degree_index = degree % len(intervals)
        pitch = 12 * (octave + 1 + octave_shift) + (int(settings.get("root", 0)) % 12) + intervals[degree_index]
        return self._mutator_quantize_pitch(pitch, settings)

    def _mutator_algorithm_source_steps(self, kind, algorithm, bar, total_bars, cycle):
        expand_patterns = {
            "verse_weaver": [0, 0, 1, 1, -1, -1, 2, 0],
            "motif_ladder": [0, 1, 2, 3, 2, 1, 0, -1],
        }
        variation_patterns = {
            "sparse_echo": [0, -2, 0, 2],
        }
        section_patterns = {
            "chorus_lift": [2, 2, 3, 3, 4, 4, 2, 0],
            "middle_eight": [-2, 1, -1, 2, -3, 2, 1, -1],
            "tension_break": [4, 4, 3, 4, 5, 4, 3, 4],
        }
        if kind == "expand":
            pattern = expand_patterns.get(algorithm, expand_patterns["verse_weaver"])
        elif kind == "variations":
            pattern = variation_patterns.get(algorithm, variation_patterns["sparse_echo"])
        else:
            pattern = section_patterns.get(algorithm, section_patterns["chorus_lift"])
        return pattern[(bar + cycle) % len(pattern)]

    def _mutator_algorithm_prune_values(self, values, loop_length):
        cleaned = []
        for value in values:
            start = max(0.0, float(value.get("start", 0.0)))
            if start >= loop_length:
                continue
            duration = max(0.03125, min(float(value.get("duration", 0.03125)), loop_length - start))
            cleaned.append(dict(
                value,
                pitch=max(0, min(127, int(round(value.get("pitch", 60))))),
                start=start,
                duration=duration,
                velocity=max(1, min(127, int(round(value.get("velocity", 96))))),
                mute=bool(value.get("mute", False)),
                probability=max(0.0, min(1.0, float(value.get("probability", 1.0)))),
            ))
        cleaned.sort(key=lambda item: (item["start"], item["pitch"], item["duration"]))
        return cleaned

    def _mutator_make_algorithm_section_values(self, source_values, role, source_start, loop_length, settings, rnd):
        algorithm = settings.get("algorithm", "mutator")
        kind = self._mutator_algorithm_kind(algorithm)
        if not kind:
            return None

        try:
            bar_beats = float(max(1, int(self.song().signature_numerator)))
        except Exception:
            bar_beats = 4.0
        bar_beats = min(max(1.0, bar_beats), max(1.0, float(loop_length)))
        total_bars = max(1, int(math.ceil(float(loop_length) / bar_beats)))

        source = []
        for value in tuple(source_values or ()):
            relative_start = max(0.0, min(loop_length - 0.0001, float(value.get("start", 0.0)) - float(source_start)))
            source.append(dict(value, start=relative_start, duration=min(float(value.get("duration", 0.03125)), loop_length - relative_start)))
        if not source:
            return None

        chord_starts = {}
        for value in source:
            key = round(value["start"], 3)
            chord_starts[key] = chord_starts.get(key, 0) + 1
        result = []
        variation = max(0.0, min(1.0, float(settings.get("depth", 0.0))))

        def random_step_variation(spread=2, chance=None, upward_bias=0):
            if chance is None:
                chance = 0.18 + (variation * 0.42)
            if rnd.random() >= chance:
                return 0
            choices = []
            for amount in range(1, max(1, int(spread)) + 1):
                choices.extend([-amount, amount])
                if upward_bias > 0:
                    choices.extend([amount] * int(upward_bias))
            return rnd.choice(choices or [0])

        melody_offsets = {
            "skylight_hook": [0, 1, 2, 3, 2, 1, 0, -1],
            "glass_steps": [0, 1, 1, 2, -1, 2, 1, 0],
            "nocturne_line": [0, -1, -2, -1, 0, 1, -1, 0],
        }
        chord_progressions = {
            "modal_drift": [0, -1, 2, 1, 3, 1, 2, 4],
            "circle_resolve": [-2, 1, -1, 0, 2, -1, 1, 4],
        }
        role_weight = {
            1: 1, 2: 2, 3: 3, 4: 2, 5: 3, 6: 2, 7: 2, 9: 3, 10: 4, 11: 5, 12: 4
        }.get(role, 1)

        for index, value in enumerate(source):
            is_chord_note = chord_starts.get(round(value["start"], 3), 0) > 1
            start = value["start"]
            bar = int(start / bar_beats)
            new_value = dict(value)

            if kind == "melody":
                offsets = melody_offsets.get(algorithm, melody_offsets["skylight_hook"])
                steps = offsets[(index + role) % len(offsets)] + random_step_variation(spread=2, upward_bias=1 if algorithm in ("skylight_hook", "glass_steps") else 0)
                if algorithm == "glass_steps":
                    steps += 1 if role_weight >= 3 and index % 3 == 1 else 0
                    if role_weight >= 4 and rnd.random() < 0.35 + (variation * 0.35):
                        steps += 1
                elif algorithm == "nocturne_line":
                    steps = max(-3, min(2, steps))
                elif algorithm == "skylight_hook" and role_weight >= 3 and rnd.random() < 0.25 + (variation * 0.35):
                    steps += 1
                new_value["pitch"] = self._mutator_transpose_scale_steps(value["pitch"], steps, settings)
                new_value["duration"] = value["duration"]
                velocity_lift = (4 if algorithm == "glass_steps" else 2) + rnd.randint(0, int(2 + (variation * 6)))
                new_value["velocity"] = max(1, min(127, int(round(value["velocity"] + velocity_lift))))

            elif kind == "chords":
                progression = chord_progressions.get(algorithm, chord_progressions["modal_drift"])
                steps = progression[(bar + role) % len(progression)] + random_step_variation(spread=2, chance=0.22 + (variation * 0.45))
                if role in (10, 11) or (role_weight >= 4 and bar >= total_bars - 1):
                    steps += 3
                root_pitch = self._mutator_transpose_scale_steps(value["pitch"], steps, settings)
                chord_velocity = max(1, min(127, int(round(value["velocity"] + 2 + rnd.randint(0, int(2 + variation * 6))))))
                if is_chord_note:
                    result.append(dict(value, pitch=root_pitch, start=start, duration=value["duration"], velocity=chord_velocity))
                    continue
                root_value = dict(value, pitch=root_pitch, start=start, duration=value["duration"], velocity=chord_velocity)
                third = dict(root_value, pitch=self._mutator_transpose_scale_steps(root_pitch, 2, settings), velocity=max(1, min(127, root_value["velocity"] - 8)))
                fifth_steps = 5 if role in (10, 11) else 4
                fifth = dict(root_value, pitch=self._mutator_transpose_scale_steps(root_pitch, fifth_steps, settings), velocity=max(1, min(127, root_value["velocity"] - 12)))
                result.extend([root_value, third, fifth])
                if algorithm == "circle_resolve" and role_weight >= 3 and (bar + role) % 2 == 0:
                    result.append(dict(root_value, pitch=self._mutator_transpose_scale_steps(root_pitch, 6, settings), velocity=max(1, min(127, root_value["velocity"] - 16))))
                continue

            else:
                steps = self._mutator_algorithm_source_steps(kind, algorithm, bar, total_bars, role)
                if algorithm == "motif_ladder":
                    steps += random_step_variation(spread=2, chance=0.20 + (variation * 0.45), upward_bias=1)
                elif algorithm in ("middle_eight", "tension_break"):
                    steps += random_step_variation(spread=2, chance=0.25 + (variation * 0.45), upward_bias=1 if algorithm == "tension_break" else 0)
                elif algorithm == "sparse_echo":
                    steps += random_step_variation(spread=1, chance=0.12 + (variation * 0.25))
                new_value["pitch"] = self._mutator_transpose_scale_steps(new_value["pitch"], steps, settings)

            if kind == "section" and algorithm == "middle_eight" and bar % 2 == 1:
                start += rnd.choice([0.0, 0.125, 0.25]) if variation > 0.25 else 0.125
            if kind == "section" and algorithm == "middle_eight":
                new_value["duration"] = value["duration"] * (1.35 if is_chord_note else 1.15)
            elif kind == "section" and algorithm == "tension_break":
                new_value["duration"] = max(0.0625, value["duration"] * rnd.choice([0.75, 0.9, 1.0]))
            lift = 0
            if kind == "section" and algorithm == "chorus_lift":
                lift = 8 + role_weight
            elif kind == "section" and algorithm == "tension_break":
                lift = 4 + rnd.randint(0, int(4 + variation * 8))
            elif kind == "variations" and algorithm == "sparse_echo":
                lift = rnd.randint(8, int(14 + variation * 10))
            elif kind == "expand":
                lift = 4 + min(4, role_weight) + rnd.randint(0, int(2 + variation * 5))
            new_value["start"] = start
            new_value["velocity"] = max(1, min(127, int(round(value["velocity"] + lift))))
            result.append(new_value)

            if not is_chord_note and algorithm == "sparse_echo" and rnd.random() < 0.46:
                echo_velocity = new_value["velocity"] if rnd.random() < 0.35 else max(1, int(round(new_value["velocity"] * rnd.uniform(0.78, 0.98))))
                result.append(dict(new_value, start=start + min(0.5, max(0.125, value["duration"])), duration=max(0.0625, value["duration"] * 0.55), pitch=self._mutator_transpose_scale_steps(new_value["pitch"], 5 + random_step_variation(spread=1, chance=0.25 + variation * 0.25), settings), velocity=echo_velocity, probability=min(new_value.get("probability", 1.0), rnd.uniform(0.82, 1.0))))
            elif kind == "section" and algorithm == "chorus_lift" and not is_chord_note and rnd.random() < 0.18:
                result.append(dict(new_value, pitch=min(127, new_value["pitch"] + 12), velocity=max(1, new_value["velocity"] - 20)))

        return self._mutator_algorithm_prune_values(result, loop_length)

    def _mutator_scale_intervals(self, scale_name):
        table = {
            "Chromatic": list(range(12)),
            "Major": [0, 2, 4, 5, 7, 9, 11],
            "Minor": [0, 2, 3, 5, 7, 8, 10],
            "Dorian": [0, 2, 3, 5, 7, 9, 10],
            "Mixolydian": [0, 2, 4, 5, 7, 9, 10],
            "Lydian": [0, 2, 4, 6, 7, 9, 11],
            "Phrygian": [0, 1, 3, 5, 7, 8, 10],
            "Locrian": [0, 1, 3, 5, 6, 8, 10],
            "Whole Tone": [0, 2, 4, 6, 8, 10],
            "Half-whole Dim.": [0, 1, 3, 4, 6, 7, 9, 10],
            "Whole-half Dim.": [0, 2, 3, 5, 6, 8, 9, 11],
            "Minor Pentatonic": [0, 3, 5, 7, 10],
            "Major Pentatonic": [0, 2, 4, 7, 9],
            "Minor Blues": [0, 3, 5, 6, 7, 10],
            "Harmonic Minor": [0, 2, 3, 5, 7, 8, 11],
            "Harmonic Major": [0, 2, 4, 5, 7, 8, 11],
            "Dorian #4": [0, 2, 3, 6, 7, 9, 10],
            "Phrygian Dominant": [0, 1, 4, 5, 7, 8, 10],
            "Melodic Minor": [0, 2, 3, 5, 7, 9, 11],
            "Lydian Augmented": [0, 2, 4, 6, 8, 9, 11],
            "Lydian Dominant": [0, 2, 4, 6, 7, 9, 10],
            "Super Locrian": [0, 1, 3, 4, 6, 8, 10],
            "8-Tone Spanish": [0, 1, 3, 4, 5, 6, 8, 10],
            "Bhairav": [0, 1, 4, 5, 7, 8, 11],
            "Hungarian Minor": [0, 2, 3, 6, 7, 8, 11],
            "Hirajoshi": [0, 2, 3, 7, 8],
            "In-Sen": [0, 1, 5, 7, 10],
            "Iwato": [0, 1, 5, 6, 10],
            "Kumoi": [0, 2, 3, 7, 9],
            "Pelog Selisir": [0, 1, 3, 7, 8],
            "Pelog Tembung": [0, 1, 5, 7, 8],
            "Messiaen 3": [0, 2, 3, 4, 6, 7, 8, 10, 11],
            "Messiaen 4": [0, 1, 2, 5, 6, 7, 8, 11],
            "Messiaen 5": [0, 1, 5, 6, 7, 11],
            "Messiaen 6": [0, 2, 4, 5, 6, 8, 10],
            "Messiaen 7": [0, 1, 2, 3, 5, 6, 7, 8, 9, 11],
        }
        return table.get(scale_name, table["Minor"])

    def _mutator_quantize_pitch(self, pitch, settings):
        intervals = self._mutator_scale_intervals(settings.get("scale", "Minor"))
        root = int(settings.get("root", 0))
        best = int(pitch)
        best_distance = 128
        for candidate in range(max(0, int(pitch) - 12), min(127, int(pitch) + 12) + 1):
            rel = (candidate - root) % 12
            if rel in intervals:
                distance = abs(candidate - int(pitch))
                if distance < best_distance:
                    best = candidate
                    best_distance = distance
        return max(0, min(127, best))

    def _mutator_note_values(self, note):
        return {
            "pitch": int(note.pitch),
            "start": float(note.start_time),
            "duration": max(0.0001, float(note.duration)),
            "velocity": int(note.velocity),
            "mute": bool(note.mute),
            "probability": float(getattr(note, "probability", 1.0)),
        }

    def _mutator_specs_from_values(self, values):
        return MidiNoteSpecification(
            pitch=max(0, min(127, int(values["pitch"]))),
            start_time=max(0.0, float(values["start"])),
            duration=max(0.0001, float(values["duration"])),
            velocity=max(1, min(127, int(values["velocity"]))),
            mute=bool(values.get("mute", False)),
            probability=max(0.0, min(1.0, float(values.get("probability", 1.0))))
        )

    def _mutator_place_section_values(self, values, section_start, loop_length):
        specs = []
        for value in tuple(values or ()):
            relative_start = max(0.0, min(float(loop_length) - 0.0001, float(value.get("start", 0.0))))
            duration = max(0.0001, min(float(value.get("duration", 0.0001)), float(loop_length) - relative_start))
            specs.append(self._mutator_specs_from_values(dict(
                value,
                start=float(section_start) + relative_start,
                duration=duration
            )))
        return specs

    def _mutator_relative_section_values(self, source_values, source_start, loop_length):
        result = []
        for value in tuple(source_values or ()):
            relative_start = max(0.0, min(float(loop_length) - 0.0001, float(value.get("start", 0.0)) - float(source_start)))
            result.append(dict(
                value,
                start=relative_start,
                duration=min(float(value.get("duration", 0.0001)), float(loop_length) - relative_start)
            ))
        return result

    def _mutator_rhythm_target_pitches(self, settings, source_values):
        targets = [int(pitch) for pitch in settings.get("target_pitches", []) if 0 <= int(pitch) <= 127]
        return targets[:16]

    def _mutator_split_rhythm_source_values(self, settings, source_values, source_start, loop_length):
        target_pitches = set(self._mutator_rhythm_target_pitches(settings, source_values))
        selected_values = []
        passthrough_values = []
        for value in tuple(source_values or ()):
            pitch = int(value.get("pitch", 0))
            if pitch in target_pitches:
                selected_values.append(value)
            else:
                passthrough_values.append(value)
        passthrough_section_values = self._mutator_relative_section_values(
            passthrough_values,
            source_start,
            loop_length
        )
        return selected_values, passthrough_section_values

    def _mutator_rhythm_occupied_steps(self, values, loop_length=None, grid=0.125):
        occupied = set()
        step_count = max(1, int(round(float(loop_length) / float(grid)))) if loop_length else None
        for value in tuple(values or ()):
            try:
                pitch = int(value.get("pitch", 0))
                step = int(round(float(value.get("start", 0.0)) / float(grid)))
                if step_count:
                    step = step % step_count
                occupied.add((pitch, step))
            except Exception:
                pass
        return occupied

    def _mutator_rhythm_free_start(self, pitch, start, loop_length, occupied, grid=0.125):
        steps = max(1, int(round(float(loop_length) / float(grid))))
        step = int(round(float(start) / float(grid))) % steps
        for offset in range(steps):
            candidate_step = (step + offset) % steps
            key = (int(pitch), candidate_step)
            if key not in occupied:
                occupied.add(key)
                return min(float(loop_length) - 0.0001, candidate_step * float(grid))
        return None

    def _mutator_velocity_delta(self, rnd, depth, role, rhythm=False):
        amount = max(0.0, min(1.0, float(depth)))
        if amount <= 0.0:
            return 0
        spread = max(1, int(round(amount * (48 if rhythm else 34))))
        return rnd.randint(-spread, spread)

    def _mutator_rhythm_gate_duration(self, duration, remaining, depth, rnd):
        amount = max(0.0, min(1.0, float(depth)))
        current = max(0.0001, float(duration))
        limit = max(0.0001, float(remaining))
        if current <= 0.125:
            short_targets = [0.03125, 0.0625, 0.09375, 0.125, 0.1875, 0.25, 0.3125, 0.375, 0.5]
            target_limit = min(limit, max(current * (1.0 + amount * 3.0), 0.0625 + amount * 0.3125))
            candidates = [
                value
                for value in short_targets
                if value <= target_limit + 0.000001 and abs(value - current) >= 0.015625
            ]
            if not candidates:
                candidates = [max(0.03125, min(target_limit, current * (0.5 if current > 0.03125 else 2.0)))]
            return max(0.03125, min(limit, rnd.choice(candidates)))
        multiplier_choices = [0.35, 0.5, 0.75, 1.25, 1.5, 2.0]
        if amount >= 0.75:
            multiplier_choices += [0.25, 2.5]
        return max(0.03125, min(limit, current * rnd.choice(multiplier_choices)))

    def _mutator_gate_duration(self, duration, remaining, strength, rnd):
        amount = max(0.0, min(1.0, float(strength)))
        current = max(0.0001, float(duration))
        limit = max(0.0001, float(remaining))
        if amount <= 0.0:
            return min(limit, current)
        if rnd.random() < 0.5:
            if amount <= 0.5:
                span = 0.125 + amount * 0.75
                multiplier = rnd.uniform(max(0.1, 1.0 - span), 1.0)
            else:
                low = 0.5 - ((amount - 0.5) / 0.5) * 0.4
                multiplier = rnd.uniform(max(0.1, low), 1.0)
        else:
            if amount <= 0.5:
                span = 0.125 + amount * 0.75
                multiplier = rnd.uniform(1.0, 1.0 + span)
            elif rnd.random() < 0.78:
                multiplier = rnd.uniform(1.75, 2.5 + amount * 0.75)
            else:
                high = 1.5 + ((amount - 0.5) / 0.5) * 8.5
                multiplier = rnd.uniform(1.0, high)
        return max(0.03125, min(limit, current * multiplier))

    def _mutator_operation_count(self, count, depth, rnd=None):
        amount = max(0.0, min(1.0, float(depth)))
        if count <= 0 or amount <= 0.0:
            return 0
        if amount >= 1.0:
            return int(count)
        if rnd is None:
            return max(0, min(int(count), int(round(float(count) * amount))))
        return sum(1 for _ in range(int(count)) if rnd.random() < amount)

    def _mutator_operation_indexes(self, count, depth, rnd):
        amount = max(0.0, min(1.0, float(depth)))
        if count <= 0 or amount <= 0.0:
            return []
        if amount >= 1.0:
            return list(range(int(count)))
        return [index for index in range(int(count)) if rnd.random() < amount]

    def _mutator_deterministic_count(self, count, amount, minimum_when_positive=True):
        amount = max(0.0, min(1.0, float(amount)))
        count = max(0, int(count))
        if count <= 0 or amount <= 0.0:
            return 0
        result = max(0, min(count, int(round(float(count) * amount))))
        if minimum_when_positive:
            result = max(1, result)
        return result

    def _mutator_deterministic_indexes(self, count, amount, rnd, minimum_when_positive=True):
        target_count = self._mutator_deterministic_count(count, amount, minimum_when_positive=minimum_when_positive)
        if target_count <= 0:
            return []
        indexes = list(range(int(count)))
        rnd.shuffle(indexes)
        return sorted(indexes[:target_count])

    def _mutator_has_sub_sixteenth_notes(self, values):
        for value in tuple(values or ()):
            try:
                start = float(value.get("start", 0.0))
                if abs((start / 0.125) - round(start / 0.125)) <= 0.00001 and abs((start / 0.25) - round(start / 0.25)) > 0.00001:
                    return True
            except Exception:
                pass
        return False

    def _mutator_timing_grid(self, values):
        return 0.125 if self._mutator_has_sub_sixteenth_notes(values) else 0.25

    def _mutator_addition_grid(self, values):
        has_sixteenth = False
        for value in tuple(values or ()):
            try:
                start = float(value.get("start", 0.0))
                if abs((start / 0.125) - round(start / 0.125)) <= 0.00001 and abs((start / 0.25) - round(start / 0.25)) > 0.00001:
                    return 0.125
                if abs((start / 0.25) - round(start / 0.25)) <= 0.00001 and abs((start / 0.5) - round(start / 0.5)) > 0.00001:
                    has_sixteenth = True
            except Exception:
                pass
        return 0.25 if has_sixteenth else 0.5

    def _mutator_quantized_time(self, start, loop_length, grid):
        grid = max(0.0001, float(grid))
        loop_length = max(0.0001, float(loop_length))
        return max(0.0, min(loop_length - 0.0001, round(float(start) / grid) * grid))

    def _mutator_pack_grid(self, values):
        pack = [dict(value) for value in tuple(values or ())]
        if not pack:
            return 0.25
        starts = []
        for value in pack:
            starts.append(max(0.0, float(value.get("start", 0.0))))
        for grid in (1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125):
            tolerance = min(0.026, grid * 0.22)
            if all(abs(start - (round(start / grid) * grid)) <= tolerance for start in starts):
                return grid
        if len(starts) > 2:
            required_matches = len(starts) - 1
            for grid in (1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125):
                tolerance = min(0.026, grid * 0.22)
                matches = sum(1 for start in starts if abs(start - (round(start / grid) * grid)) <= tolerance)
                if matches >= required_matches:
                    return grid
        return 0.03125

    def _mutator_note_start_grid(self, start):
        start = max(0.0, float(start))
        for grid in (1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125):
            tolerance = min(0.026, grid * 0.22)
            if abs(start - (round(start / grid) * grid)) <= tolerance:
                return grid
        return 0.125

    def _mutator_notes_overlap(self, left, right):
        if int(left.get("pitch", 60)) != int(right.get("pitch", 60)):
            return False
        left_start = float(left.get("start", 0.0))
        right_start = float(right.get("start", 0.0))
        left_end = left_start + max(0.0001, float(left.get("duration", 0.0001)))
        right_end = right_start + max(0.0001, float(right.get("duration", 0.0001)))
        return left_start < right_end - 0.000001 and right_start < left_end - 0.000001

    def _mutator_sample_note_traits(self, pool, rnd, fallback=None, minimum_duration=0.03125, maximum_duration=None):
        pool = [dict(value) for value in tuple(pool or ()) if value]
        fallback = dict(fallback or (pool[0] if pool else {}))
        durations = [max(minimum_duration, float(value.get("duration", fallback.get("duration", 0.125)))) for value in pool]
        velocities = [max(1, min(127, int(value.get("velocity", fallback.get("velocity", 96))))) for value in pool]
        mutes = [bool(value.get("mute", fallback.get("mute", False))) for value in pool]
        probabilities = [max(0.0, min(1.0, float(value.get("probability", fallback.get("probability", 1.0))))) for value in pool]
        duration = rnd.choice(durations) if durations else max(minimum_duration, float(fallback.get("duration", 0.125)))
        if maximum_duration is not None:
            duration = min(duration, max(minimum_duration, float(maximum_duration)))
        return {
            "duration": max(minimum_duration, duration),
            "velocity": rnd.choice(velocities) if velocities else max(1, min(127, int(fallback.get("velocity", 96)))),
            "mute": rnd.choice(mutes) if mutes else bool(fallback.get("mute", False)),
            "probability": rnd.choice(probabilities) if probabilities else max(0.0, min(1.0, float(fallback.get("probability", 1.0)))),
        }

    def _mutator_phrase_start_candidates(self, source_values, result_values, base, pitch, loop_length, rnd, grid, prefer_global_open=False):
        loop_length = max(0.0001, float(loop_length))
        grid = max(0.03125, float(grid))
        step_count = max(1, int(round(loop_length / grid)))
        pitch = int(pitch)

        def quantized(start):
            return max(0.0, min(loop_length - 0.0001, round(float(start) / grid) * grid))

        def start_key(start):
            return int(round(quantized(start) * 960.0))

        occupied_starts = set()
        occupied_pitch_starts = set()
        for value in tuple(result_values or ()):
            try:
                value_pitch = int(value.get("pitch", 60))
                key = start_key(float(value.get("start", 0.0)))
                occupied_starts.add(key)
                occupied_pitch_starts.add((value_pitch, key))
            except Exception:
                pass

        source = [
            dict(value)
            for value in tuple(source_values or ())
            if 0.0 <= float(value.get("start", 0.0)) < loop_length
        ]
        if not source:
            source = [dict(base)]
        source.sort(key=lambda item: (float(item.get("start", 0.0)), int(item.get("pitch", 60))))
        same_pitch = [value for value in source if int(value.get("pitch", 60)) == pitch] or source
        base_start = quantized(float(base.get("start", 0.0)))

        def unique_starts(values):
            seen = set()
            starts = []
            for value in values:
                start = quantized(float(value.get("start", 0.0)))
                key = start_key(start)
                if key in seen:
                    continue
                seen.add(key)
                starts.append(start)
            return sorted(starts)

        starts = unique_starts(source)
        pitch_starts = unique_starts(same_pitch)

        def intervals_from(starts_to_scan):
            counts = {}
            if len(starts_to_scan) < 2:
                return []
            ordered = sorted(starts_to_scan)
            pairs = list(zip(ordered[:-1], ordered[1:]))
            pairs.append((ordered[-1], ordered[0] + loop_length))
            for left, right in pairs:
                interval = quantized(right - left)
                if interval < grid - 0.000001 or interval > 2.0 + 0.000001:
                    continue
                key = int(round(interval / grid))
                counts[key] = counts.get(key, 0) + 1
            ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
            return [key * grid for key, _ in ranked[:5]]

        intervals = intervals_from(pitch_starts) + intervals_from(starts)
        if not intervals:
            intervals = [grid, grid * 2.0, grid * 3.0, grid * 4.0]

        phrase_last = max(starts) if starts else base_start
        phrase_first = min(starts) if starts else base_start
        pitch_last = max(pitch_starts) if pitch_starts else phrase_last
        pitch_first = min(pitch_starts) if pitch_starts else phrase_first
        offsets = sorted(set(quantized(start % 1.0) for start in pitch_starts), key=lambda offset: abs(offset - (base_start % 1.0)))
        if not offsets:
            offsets = [base_start % 1.0]

        candidates = []

        def add_candidate(start, mode_score, local_score=0.0):
            start = quantized(start % loop_length)
            key = start_key(start)
            score = float(mode_score) + float(local_score)
            if (pitch, key) in occupied_pitch_starts:
                score += 1000.0
            if key in occupied_starts:
                score += 7.5 if prefer_global_open else 1.35
            else:
                score -= 0.55 if prefer_global_open else 0.25
            score += rnd.random() * 0.025
            candidates.append((score, start))

        for order, interval in enumerate(intervals[:4]):
            add_candidate(base_start + interval, 0.0, order * 0.08)
            add_candidate(pitch_last + interval, 0.12, order * 0.08)
            add_candidate(phrase_last + interval, 0.35, order * 0.08)
            add_candidate(base_start - interval, 1.3, order * 0.08)

        for order, interval in enumerate(intervals[:4]):
            pickup = loop_length - interval
            if pitch_first <= interval + grid:
                pickup = max(0.0, loop_length - max(grid, interval - pitch_first))
            add_candidate(pickup, 0.55, order * 0.12)
            add_candidate(loop_length - max(grid, interval * 0.5), 0.75, order * 0.12)

        beat = math.floor(base_start)
        answer_offsets = (0.5, 0.75, 1.0, 1.5, -0.5)
        for order, offset in enumerate(answer_offsets):
            add_candidate(base_start + offset, 0.9, order * 0.06)
            add_candidate(beat + offset, 1.05, order * 0.06)

        for cell_delta in (1, 2, 3, 4, -1, -2, 6, -4, 8, -6):
            cell_start = quantized(base_start + (cell_delta * grid))
            for order, offset in enumerate(offsets[:4]):
                add_candidate(math.floor(cell_start) + offset, 1.6, abs(cell_delta) * 0.02 + order * 0.06)

        for step in range(step_count):
            start = step * grid
            key = start_key(start)
            if key not in occupied_starts:
                distance = min((step - int(round(base_start / grid))) % step_count, (int(round(base_start / grid)) - step) % step_count)
                add_candidate(start, 2.15, distance * 0.015)

        seen = set()
        ordered = []
        for _, start in sorted(candidates, key=lambda item: item[0]):
            key = start_key(start)
            if key in seen:
                continue
            seen.add(key)
            ordered.append(start)
        return ordered

    def _mutator_apply_break_role(self, values, loop_length, rhythm=False):
        values = [dict(value) for value in tuple(values or ())]
        if not values:
            return []
        values.sort(key=lambda item: (float(item.get("start", 0.0)), int(item.get("pitch", 0))))
        keep_stride = 3 if rhythm else 2
        kept = [value for index, value in enumerate(values) if index % keep_stride == 0] or values[:1]
        result = []
        for value in kept:
            start = max(0.0, min(float(loop_length) - 0.0001, float(value.get("start", 0.0))))
            duration = min(float(loop_length) - start, max(float(value.get("duration", 0.125)) * 1.35, 0.125))
            result.append(dict(
                value,
                start=start,
                duration=max(0.03125, duration),
                velocity=max(1, min(127, int(value.get("velocity", 96)) - (18 if rhythm else 14))),
            ))
        return result

    def _mutator_simplify_values(self, values, depth, rnd):
        values = [dict(value) for value in tuple(values or ())]
        remove_count = min(max(0, len(values) - 1), self._mutator_operation_count(len(values), depth, rnd))
        if remove_count <= 0:
            return values
        ranked = sorted(
            range(len(values)),
            key=lambda index: (
                int(values[index].get("velocity", 96)),
                float(values[index].get("duration", 0.125)),
                -abs(float(values[index].get("start", 0.0)) - round(float(values[index].get("start", 0.0)))),
            )
        )
        remove_indexes = set(ranked[:remove_count])
        return [value for index, value in enumerate(values) if index not in remove_indexes]

    def _mutator_shift_starts_by_depth(self, values, probability, strength, loop_length, rnd, rhythm=False):
        values = [dict(value) for value in tuple(values or ())]
        indexes = self._mutator_operation_indexes(len(values), probability, rnd)
        if not indexes:
            return values
        grid = self._mutator_timing_grid(values)
        max_steps = max(1, min(4 if rhythm else 3, int(math.ceil(max(0.0, min(1.0, strength)) * (4 if rhythm else 3)))))
        choices = [step * grid for step in range(-max_steps, max_steps + 1) if step != 0]
        for index in indexes:
            start = float(values[index].get("start", 0.0)) + rnd.choice(choices)
            values[index]["start"] = self._mutator_quantized_time(start, loop_length, grid)
        return values

    def _mutator_shift_pitch_groups_by_depth(self, values, probability, strength, loop_length, rnd, rhythm=False, target_pitches=None):
        values = [dict(value) for value in tuple(values or ())]
        amount = max(0.0, min(1.0, float(probability)))
        shift_range = max(0.0, min(1.0, float(strength)))
        loop_length = max(0.0001, float(loop_length))
        if amount <= 0.0 or shift_range <= 0.0 or not values:
            return values

        pitches = sorted(set(int(value.get("pitch", 60)) for value in values if 0 <= int(value.get("pitch", 60)) <= 127))
        if rhythm:
            selected = set(int(pitch) for pitch in tuple(target_pitches or ()) if 0 <= int(pitch) <= 127)
            if not selected:
                return values
            pitches = [pitch for pitch in pitches if pitch in selected]
        if not pitches:
            return values

        grid = self._mutator_timing_grid(values)
        max_steps = max(1, min(8, int(math.ceil((loop_length / grid) * shift_range))))
        offsets_by_pitch = {}
        for pitch in pitches:
            pitch_rnd = random.Random(rnd.randint(0, 2147483647))
            if pitch_rnd.random() > amount:
                continue
            step_choices = [step for step in range(-max_steps, max_steps + 1) if step != 0]
            if step_choices:
                offsets_by_pitch[pitch] = pitch_rnd.choice(step_choices) * grid
        if not offsets_by_pitch:
            return values

        for value in values:
            pitch = int(value.get("pitch", 60))
            if pitch not in offsets_by_pitch:
                continue
            start = (float(value.get("start", 0.0)) + offsets_by_pitch[pitch]) % loop_length
            value["start"] = self._mutator_quantized_time(start, loop_length, grid)
        return values

    def _mutator_loop_shift_by_depth(self, values, probability, loop_length, rnd):
        values = [dict(value) for value in tuple(values or ())]
        amount = max(0.0, min(1.0, float(probability)))
        if amount <= 0.0 or not values:
            return values
        grid = self._mutator_timing_grid(values)
        max_steps = max(1, min(16, int(math.ceil((float(loop_length) / grid) * amount))))
        step_choices = [step for step in range(-max_steps, max_steps + 1) if step != 0]
        if not step_choices:
            return values
        offset = rnd.choice(step_choices) * grid
        loop_length = max(0.0001, float(loop_length))
        for value in values:
            value["start"] = self._mutator_quantized_time((float(value.get("start", 0.0)) + offset) % loop_length, loop_length, grid)
        return values

    def _mutator_add_values_by_depth(self, values, depth, strength, role, loop_length, settings, rnd, rhythm=False, target_pitches=None):
        values = [dict(value) for value in tuple(values or ())]
        amount = max(0.0, min(1.0, float(depth)))
        if amount <= 0.0 or not values:
            return values
        rnd = random.Random((rnd.randint(0, 2147483647) << 1) ^ rnd.randint(0, 2147483647))
        loop_length = max(0.0001, float(loop_length))
        grid = self._mutator_addition_grid(values)
        cell_size = 1.0
        cell_count = max(1, int(math.ceil(loop_length / cell_size)))
        result = list(values)
        source_pitches = sorted(set(int(value.get("pitch", 60)) for value in values if 0 <= int(value.get("pitch", 60)) <= 127))
        target_pitch_set = set(int(pitch) for pitch in tuple(target_pitches or ()) if 0 <= int(pitch) <= 127)
        allowed_pitches = set(source_pitches)
        if rhythm and target_pitch_set:
            allowed_pitches = allowed_pitches.intersection(target_pitch_set) or allowed_pitches
        motif = [
            value for value in sorted(
                values,
                key=lambda item: (
                    float(item.get("start", 0.0)),
                    int(item.get("pitch", 60)),
                    -int(item.get("velocity", 96)),
                )
            )
            if int(value.get("pitch", 60)) in allowed_pitches
        ]
        if not motif:
            return values
        minimum_duration = 0.03125 if rhythm else 0.0625
        source_durations = sorted(set(
            max(minimum_duration, min(loop_length, quantized_duration))
            for quantized_duration in (
                round(max(minimum_duration, float(value.get("duration", 0.125))) / 0.03125) * 0.03125
                for value in values
            )
            if quantized_duration > 0.0
        ))

        def quantized(value):
            return max(0.0, min(loop_length - 0.0001, round(float(value) / grid) * grid))

        def quantized_to(value, step):
            step = max(0.0001, float(step))
            return max(0.0, min(loop_length - 0.0001, round(float(value) / step) * step))

        def cell_index(start):
            return max(0, min(cell_count - 1, int(math.floor(max(0.0, float(start)) / cell_size))))

        offsets_by_pitch = {}
        cells_by_pitch = {}
        occupied_starts = set()
        for value in values:
            pitch = int(value.get("pitch", 60))
            start = quantized(float(value.get("start", 0.0)))
            occupied_starts.add(int(round(start * 960.0)))
            cell = cell_index(start)
            offset = max(0.0, min(cell_size - grid, quantized(start - (cell * cell_size))))
            offsets_by_pitch.setdefault(pitch, set()).add(offset)
            cells_by_pitch.setdefault(pitch, set()).add(cell)

        def relevant_for_overlap(value, candidate_pitch):
            return int(value.get("pitch", 60)) == int(candidate_pitch)

        def start_is_taken(candidate_start, candidate_pitch):
            for value in result:
                if relevant_for_overlap(value, candidate_pitch) and abs(float(value.get("start", 0.0)) - candidate_start) < 0.000001:
                    return True
            return False

        def global_start_is_taken(candidate_start):
            return int(round(float(candidate_start) * 960.0)) in occupied_starts

        def max_free_duration(candidate_start, candidate_pitch):
            limit = max(0.0, loop_length - candidate_start)
            for value in result:
                if not relevant_for_overlap(value, candidate_pitch):
                    continue
                other_start = float(value.get("start", 0.0))
                other_duration = max(0.0001, float(value.get("duration", 0.0001)))
                other_end = other_start + other_duration
                if other_start <= candidate_start < other_end - 0.000001:
                    return 0.0
                if other_start > candidate_start + 0.000001:
                    limit = min(limit, other_start - candidate_start)
            return max(0.0, limit)

        def ordered_cells_for(base_cell):
            base_bar = base_cell // 4
            base_beat = base_cell % 4
            preferred = []
            answer_beats = ((base_beat - 1) % 4, (base_beat + 1) % 4, (base_beat + 2) % 4, base_beat, 0, 2, 1, 3)
            for bar_delta in (1, -1, 2, -2, 3, -3):
                for beat in answer_beats:
                    preferred.append(((base_bar + bar_delta) * 4) + beat)
            for beat in answer_beats:
                preferred.append((base_bar * 4) + beat)
            preferred.extend(range(cell_count))

            seen = set()
            cells = []
            for cell in preferred:
                if 0 <= cell < cell_count and cell != base_cell and cell not in seen:
                    seen.add(cell)
                    cells.append(cell)
            return cells

        def placement_candidates(base):
            pitch = int(base.get("pitch", 60))
            start = quantized(float(base.get("start", 0.0)))
            base_cell = cell_index(start)
            base_offset = max(0.0, min(cell_size - grid, quantized(start - (base_cell * cell_size))))
            offsets = sorted(offsets_by_pitch.get(pitch, {base_offset}), key=lambda offset: (abs(offset - base_offset), offset))
            pitch_cells = cells_by_pitch.get(pitch, set())
            scored = []
            for order_index, cell in enumerate(ordered_cells_for(base_cell)):
                for offset in offsets:
                    candidate_start = quantized((cell * cell_size) + offset)
                    if candidate_start >= loop_length - 0.000001:
                        continue
                    score = float(order_index)
                    if global_start_is_taken(candidate_start):
                        score += 2.5
                    if cell in pitch_cells:
                        score -= 0.35
                    if (cell % 4) == (base_cell % 4):
                        score -= 0.25
                    scored.append((score + rnd.random() * 0.01, candidate_start))
            return [start for _, start in sorted(scored, key=lambda item: item[0])]

        def fallback_gap_candidates(base):
            pitch = int(base.get("pitch", 60))
            base_start = quantized(float(base.get("start", 0.0)))
            base_cell = cell_index(base_start)
            steps = tuple(sorted(set([grid, max(grid, 0.5), max(grid, 1.0)])))
            intervals = []
            for value in result:
                if not relevant_for_overlap(value, pitch):
                    continue
                start = max(0.0, min(loop_length, float(value.get("start", 0.0))))
                end = max(start, min(loop_length, start + max(0.0001, float(value.get("duration", 0.0001)))))
                intervals.append((start, end))
            intervals.sort()

            free_spans = []
            cursor = 0.0
            for start, end in intervals:
                if start > cursor + 0.000001:
                    free_spans.append((cursor, start))
                cursor = max(cursor, end)
            if cursor < loop_length - 0.000001:
                free_spans.append((cursor, loop_length))

            scored = []
            for span_start, span_end in free_spans:
                if span_end - span_start < 0.03125:
                    continue
                span_mid = (span_start + span_end) * 0.5
                for step_index, step in enumerate(steps):
                    start = math.ceil((span_start + 0.000001) / step) * step
                    while start < span_end - 0.000001:
                        candidate_start = quantized_to(start, step)
                        if candidate_start >= span_end - 0.000001:
                            break
                        candidate_cell = cell_index(candidate_start)
                        score = (
                            step_index * 12.0
                            + abs(candidate_cell - base_cell)
                            + abs(candidate_start - span_mid) * 0.1
                        )
                        if (candidate_cell % 4) == (base_cell % 4):
                            score -= 0.2
                        scored.append((score + rnd.random() * 0.01, candidate_start))
                        start += step
            return [start for _, start in sorted(scored, key=lambda item: item[0])]

        def choose_start_and_duration(base):
            pitch = int(base.get("pitch", 60))
            base_duration = max(minimum_duration, float(base.get("duration", 0.125)))
            candidates = []
            seen = set()
            smart_candidates = self._mutator_phrase_start_candidates(
                motif,
                result,
                base,
                pitch,
                loop_length,
                rnd,
                grid,
                prefer_global_open=False
            )
            for candidate in list(smart_candidates) + list(placement_candidates(base)) + list(fallback_gap_candidates(base)):
                key = int(round(candidate / 0.0001))
                if key in seen:
                    continue
                seen.add(key)
                candidates.append(candidate)
            viable = []
            globally_free = []
            for candidate_start in candidates:
                if start_is_taken(candidate_start, pitch):
                    continue
                free_duration = max_free_duration(candidate_start, pitch)
                if free_duration >= minimum_duration - 0.000001:
                    candidate = (candidate_start, free_duration)
                    if not global_start_is_taken(candidate_start):
                        globally_free.append(candidate)
                    viable.append(candidate)
                if len(viable) >= 16:
                    break
            preferred = globally_free or viable
            if preferred:
                if globally_free and viable and rnd.random() >= 0.92:
                    preferred = viable
                window = max(1, min(len(viable), 2 + int(round(amount * 8.0))))
                window = max(1, min(len(preferred), window))
                candidate_start, free_duration = rnd.choice(preferred[:window])
                duration_pool = [duration for duration in source_durations if duration <= free_duration + 0.000001]
                if duration_pool and rnd.random() < 0.82:
                    duration = rnd.choice(duration_pool)
                else:
                    duration = base_duration * rnd.choice([0.5, 0.75, 1.0, 1.25, 1.5, 2.0])
                return candidate_start, max(minimum_duration, min(free_duration, duration))
            return None, None

        motif_by_pitch = {}
        for value in motif:
            motif_by_pitch.setdefault(int(value.get("pitch", 60)), []).append(value)

        add_count = self._mutator_deterministic_count(len(motif), amount)
        selected_bases = list(motif)
        rnd.shuffle(selected_bases)
        selected_bases = selected_bases[:add_count]

        for base in selected_bases:
            base = dict(base)
            pitch = int(base.get("pitch", 60))
            if pitch not in allowed_pitches:
                continue
            start, duration = choose_start_and_duration(base)
            if start is None:
                continue
            traits = self._mutator_sample_note_traits(motif_by_pitch.get(pitch, motif), rnd, fallback=base, minimum_duration=minimum_duration, maximum_duration=duration)
            cell = cell_index(start)
            offset = max(0.0, min(cell_size - grid, quantized(start - (cell * cell_size))))
            offsets_by_pitch.setdefault(pitch, set()).add(offset)
            cells_by_pitch.setdefault(pitch, set()).add(cell)
            occupied_starts.add(int(round(start * 960.0)))
            result.append(dict(
                base,
                pitch=pitch,
                start=start,
                duration=traits["duration"],
                velocity=traits["velocity"],
                mute=traits["mute"],
                probability=traits["probability"],
            ))
        return result

    def _mutator_gate_remaining_for_index(self, values, index, loop_length):
        start = max(0.0, min(float(loop_length) - 0.0001, float(values[index].get("start", 0.0))))
        pitch = int(values[index].get("pitch", 0))
        remaining = float(loop_length) - start
        for other_index, value in enumerate(values):
            if other_index == index or int(value.get("pitch", 0)) != pitch:
                continue
            other_start = float(value.get("start", 0.0))
            if other_start > start + 0.000001:
                remaining = min(remaining, other_start - start)
        return max(0.03125, remaining)

    def _mutator_apply_gate_by_depth(self, values, probability, strength, loop_length, rnd):
        values = [dict(value) for value in tuple(values or ())]
        for index in self._mutator_operation_indexes(len(values), probability, rnd):
            values[index]["duration"] = self._mutator_gate_duration(
                float(values[index].get("duration", 0.125)),
                self._mutator_gate_remaining_for_index(values, index, loop_length),
                strength,
                rnd
            )
        return values

    def _mutator_apply_octave_by_depth(self, values, depth, rnd):
        values = [dict(value) for value in tuple(values or ())]
        for index in self._mutator_operation_indexes(len(values), depth, rnd):
            values[index]["pitch"] = max(0, min(127, int(values[index].get("pitch", 60)) + rnd.choice([-12, 12])))
        return values

    def _mutator_apply_pitch_by_depth(self, values, probability, strength, settings, rnd, rhythm=False, target_pitches=None):
        values = [dict(value) for value in tuple(values or ())]
        amount = max(0.0, min(1.0, float(strength)))
        if rhythm:
            targets = sorted(set(int(pitch) for pitch in tuple(target_pitches or ()) if 0 <= int(pitch) <= 127))
            for index in self._mutator_deterministic_indexes(len(values), probability, rnd):
                pitch = int(values[index].get("pitch", 60))
                choices = [target for target in targets if target != pitch]
                if not choices:
                    continue
                choices.sort(key=lambda target: abs(target - pitch))
                window = max(1, min(len(choices), int(math.ceil(1 + amount * min(5, len(choices))))))
                values[index]["pitch"] = rnd.choice(choices[:window])
            return values
        for index in self._mutator_deterministic_indexes(len(values), probability, rnd):
            pitch = int(values[index].get("pitch", 60))
            max_steps = self._mutator_scale_step_span_for_octave_fraction(pitch, amount, settings)
            step_choices = [step for step in range(-max_steps, max_steps + 1) if step != 0]
            if step_choices:
                values[index]["pitch"] = self._mutator_transpose_scale_steps(pitch, rnd.choice(step_choices), settings)
        return values

    def _mutator_apply_pitch_add_by_depth(self, values, probability, strength, loop_length, settings, rnd, rhythm=False, target_pitches=None):
        values = [dict(value) for value in tuple(values or ())]
        if not values:
            return values
        add_count = self._mutator_deterministic_count(len(values), probability)
        if add_count <= 0:
            return values

        amount = max(0.0, min(1.0, float(strength)))
        selected = list(values)
        rnd.shuffle(selected)
        selected = selected[:add_count]
        result = list(values)
        loop_length = max(0.0001, float(loop_length))
        grid = self._mutator_timing_grid(values)
        occupied = set(
            (
                int(value.get("pitch", 60)),
                int(round(float(value.get("start", 0.0)) * 960.0))
            )
            for value in result
        )
        occupied_starts = set(int(round(float(value.get("start", 0.0)) * 960.0)) for value in result)
        targets = sorted(set(int(pitch) for pitch in tuple(target_pitches or ()) if 0 <= int(pitch) <= 127))

        def quantized_start(value):
            return self._mutator_quantized_time(value, loop_length, grid)

        def global_start_is_taken(start):
            return int(round(float(start) * 960.0)) in occupied_starts

        def pitch_start_is_taken(pitch, start):
            return (int(pitch), int(round(float(start) * 960.0))) in occupied

        for base in selected:
            base_start = max(0.0, min(loop_length - 0.0001, float(base.get("start", 0.0))))
            source_pitch = int(base.get("pitch", 60))
            pitch = None
            if rhythm and targets:
                choices = [target for target in targets if target != source_pitch]
                choices.sort(key=lambda target: abs(target - source_pitch))
                window = max(1, min(len(choices), int(math.ceil(1 + amount * min(6, len(choices)))))) if choices else 0
                if window:
                    pitch = rnd.choice(choices[:window])
            else:
                max_steps = self._mutator_scale_step_span_for_octave_fraction(source_pitch, amount, settings)
                step_choices = [step for step in range(-max_steps, max_steps + 1) if step != 0]
                rnd.shuffle(step_choices)
                for step in step_choices:
                    candidate = self._mutator_transpose_scale_steps(source_pitch, step, settings)
                    if candidate != source_pitch:
                        pitch = candidate
                        break
            if pitch is None:
                continue

            start = None
            candidate_starts = self._mutator_phrase_start_candidates(
                values,
                result,
                base,
                pitch,
                loop_length,
                rnd,
                grid,
                prefer_global_open=True
            )
            for candidate_start in candidate_starts:
                if not pitch_start_is_taken(pitch, candidate_start):
                    start = candidate_start
                    if not global_start_is_taken(candidate_start):
                        break
            if start is not None and global_start_is_taken(start):
                for candidate_start in candidate_starts:
                    if not global_start_is_taken(candidate_start) and not pitch_start_is_taken(pitch, candidate_start):
                        start = candidate_start
                        break
            if start is None:
                steps = max(1, int(round(loop_length / grid)))
                base_step = int(round(quantized_start(base_start) / grid)) % steps
                for offset in (1, 2, 3, 4, -1, -2, 6, -4, 8, -6, 12, -8):
                    candidate_start = quantized_start(((base_step + offset) % steps) * grid)
                    if not global_start_is_taken(candidate_start) and not pitch_start_is_taken(pitch, candidate_start):
                        start = candidate_start
                        break
            if start is None:
                fallback_start = quantized_start(base_start)
                if not pitch_start_is_taken(pitch, fallback_start):
                    start = fallback_start
            if start is None:
                continue
            occupied.add((int(pitch), int(round(start * 960.0))))
            occupied_starts.add(int(round(start * 960.0)))
            traits = self._mutator_sample_note_traits(values, rnd, fallback=base, minimum_duration=0.03125 if rhythm else 0.0625, maximum_duration=loop_length - start)
            result.append(dict(
                base,
                pitch=max(0, min(127, int(pitch))),
                start=start,
                duration=traits["duration"],
                velocity=traits["velocity"],
                mute=traits["mute"],
                probability=traits["probability"],
            ))
        return result

    def _mutator_duplicate_by_depth(self, values, probability, loop_length, rnd):
        values = [dict(value) for value in tuple(values or ())]
        indexes = self._mutator_deterministic_indexes(len(values), probability, rnd)
        if not indexes:
            return values
        selected = [dict(values[index]) for index in indexes]
        loop_length = max(0.0001, float(loop_length))
        grid = self._mutator_pack_grid(selected)
        ticks_per_beat = 960
        loop_ticks = max(1, int(round(loop_length * ticks_per_beat)))
        grid_ticks = max(1, int(round(grid * ticks_per_beat)))

        def snap_tick(start):
            tick = int(round(float(start) * ticks_per_beat))
            return int(round(float(tick) / float(grid_ticks))) * grid_ticks

        snapped_starts = [max(0, min(loop_ticks - 1, snap_tick(value.get("start", 0.0)))) for value in selected]
        range_start_tick = (min(snapped_starts) // grid_ticks) * grid_ticks
        range_end_tick = (((max(snapped_starts) + grid_ticks) + grid_ticks - 1) // grid_ticks) * grid_ticks
        range_start_tick = max(0, min(loop_ticks - 1, range_start_tick))
        range_end_tick = max(range_start_tick + grid_ticks, min(loop_ticks, range_end_tick))
        range_length_ticks = max(grid_ticks, range_end_tick - range_start_tick)
        max_steps = max(1, min(32, int(math.ceil(float(loop_ticks) / float(range_length_ticks)))))
        copy_count = 1
        result = list(values)

        def shifted_note(value, step):
            relative_tick = snap_tick(value.get("start", 0.0)) - range_start_tick
            start_tick = (range_start_tick + relative_tick + (step * range_length_ticks)) % loop_ticks
            start = max(0.0, min(loop_length - 0.0001, float(start_tick) / float(ticks_per_beat)))
            return dict(
                value,
                start=start,
                duration=max(0.03125, min(float(value.get("duration", 0.03125)), loop_length - start))
            )

        logical_steps = [
            step
            for step in range(1, max_steps + 1)
            if (step * range_length_ticks) % loop_ticks != 0
        ]
        if len(logical_steps) < copy_count:
            logical_steps.extend(
                -step
                for step in range(1, max_steps + 1)
                if (-step * range_length_ticks) % loop_ticks != 0
            )

        used_steps = []
        for step in logical_steps:
            if step in used_steps:
                continue
            used_steps.append(step)
            for candidate in [shifted_note(value, step) for value in selected]:
                result.append(candidate)
            if len(used_steps) >= copy_count:
                break

        if used_steps:
            return result

        offsets = [1, 2, 3, 4, 6, 8, 12, 16, -1, -2, -3, -4, -6, -8, -12, -16]
        rnd.shuffle(offsets)
        offsets.sort(key=lambda step: (abs(step), 0 if step > 0 else 1))
        for repeat_index in range(copy_count):
            offset = offsets[repeat_index % len(offsets)] * grid_ticks
            for value in selected:
                start_tick = (snap_tick(value.get("start", 0.0)) + offset) % loop_ticks
                start = max(0.0, min(loop_length - 0.0001, float(start_tick) / float(ticks_per_beat)))
                result.append(dict(
                    value,
                    start=start,
                    duration=max(0.03125, min(float(value.get("duration", 0.03125)), loop_length - start))
                ))
        return result

    def _mutator_phrase_shift_by_depth(self, values, probability, strength, settings, rnd, rhythm=False, target_pitches=None):
        values = [dict(value) for value in tuple(values or ())]
        indexes = self._mutator_deterministic_indexes(len(values), probability, rnd)
        if not indexes:
            return values
        amount = max(0.0, min(1.0, float(strength)))
        if rhythm:
            targets = sorted(set(int(pitch) for pitch in tuple(target_pitches or ()) if 0 <= int(pitch) <= 127))
            if len(targets) < 2:
                return values
            selected_positions = [
                targets.index(int(values[index].get("pitch", 60)))
                for index in indexes
                if int(values[index].get("pitch", 60)) in targets
            ]
            if not selected_positions:
                return values
            min_position = min(selected_positions)
            max_position = max(selected_positions)
            max_down = min_position
            max_up = len(targets) - 1 - max_position
            max_span = max(max_down, max_up)
            if max_span <= 0:
                return values
            max_steps = max(1, min(max_span, int(math.ceil(max_span * max(0.125, amount)))))
            step_choices = [step for step in range(-max_steps, max_steps + 1) if step != 0 and -max_down <= step <= max_up]
            if not step_choices:
                return values
            offset = rnd.choice(step_choices)
            for index in indexes:
                pitch = int(values[index].get("pitch", 60))
                if pitch not in targets:
                    continue
                values[index]["pitch"] = targets[targets.index(pitch) + offset]
            return values

        selected_pitches = [int(values[index].get("pitch", 60)) for index in indexes]
        if not selected_pitches:
            return values
        max_steps = min(
            self._mutator_scale_step_span_for_octave_fraction(min(selected_pitches), amount, settings),
            self._mutator_scale_step_span_for_octave_fraction(max(selected_pitches), amount, settings)
        )
        step_choices = [step for step in range(-max_steps, max_steps + 1) if step != 0]
        if not step_choices:
            return values
        offset = rnd.choice(step_choices)
        for index in indexes:
            values[index]["pitch"] = self._mutator_transpose_scale_steps(int(values[index].get("pitch", 60)), offset, settings)
        return values

    def _mutator_preserve_original_by_depth(self, values, source_values, probability, loop_length, rnd):
        values = [dict(value) for value in tuple(values or ())]
        source = [dict(value) for value in tuple(source_values or ())]
        indexes = self._mutator_deterministic_indexes(len(source), probability, rnd)
        if not indexes:
            return values
        loop_length = max(0.0001, float(loop_length))
        preserved = []
        for index in indexes:
            note = dict(source[index])
            start = max(0.0, min(loop_length - 0.0001, float(note.get("start", 0.0))))
            note["start"] = start
            note["duration"] = max(0.03125, min(float(note.get("duration", 0.03125)), loop_length - start))
            preserved.append(note)
        result = []
        for value in values:
            if any(self._mutator_notes_overlap(value, note) for note in preserved):
                continue
            result.append(value)
        result.extend(preserved)
        return result

    def _mutator_reverse_timing_by_depth(self, values, probability, loop_length, rnd):
        values = [dict(value) for value in tuple(values or ())]
        indexes = self._mutator_deterministic_indexes(len(values), probability, rnd)
        if len(indexes) < 2:
            return values
        selected = [values[index] for index in indexes]
        range_start = min(float(value.get("start", 0.0)) for value in selected)
        range_end = max(float(value.get("start", 0.0)) + max(0.0001, float(value.get("duration", 0.0001))) for value in selected)
        range_end = min(max(range_start + 0.0001, range_end), float(loop_length))
        for index in indexes:
            duration = max(0.0001, float(values[index].get("duration", 0.0001)))
            original_end = float(values[index].get("start", 0.0)) + duration
            values[index]["start"] = max(0.0, min(float(loop_length) - 0.0001, range_start + (range_end - original_end)))
        return values

    def _mutator_invert_pitch_by_depth(self, values, probability, settings, rnd, rhythm=False, target_pitches=None):
        values = [dict(value) for value in tuple(values or ())]
        indexes = self._mutator_deterministic_indexes(len(values), probability, rnd)
        if len(indexes) < 2:
            return values
        selected_pitches = [int(values[index].get("pitch", 60)) for index in indexes]
        min_pitch = min(selected_pitches)
        max_pitch = max(selected_pitches)
        if rhythm:
            allowed = sorted(set(int(pitch) for pitch in tuple(target_pitches or selected_pitches) if 0 <= int(pitch) <= 127))
            if len(allowed) < 2:
                return values
            selected_indexes = [allowed.index(pitch) for pitch in selected_pitches if pitch in allowed]
            if len(selected_indexes) < 2:
                return values
            min_index = min(selected_indexes)
            max_index = max(selected_indexes)
            for index in indexes:
                pitch = int(values[index].get("pitch", 60))
                if pitch not in allowed:
                    continue
                mirrored_index = max_index - max(0, allowed.index(pitch) - min_index)
                if 0 <= mirrored_index < len(allowed):
                    values[index]["pitch"] = allowed[mirrored_index]
            return values
        if settings.get("scale", "Minor") == "Chromatic":
            for index in indexes:
                pitch = int(values[index].get("pitch", 60))
                values[index]["pitch"] = max(0, min(127, min_pitch + (max_pitch - pitch)))
            return values

        allowed = self._mutator_scale_notes(settings)
        try:
            min_index = self._mutator_scale_index(min_pitch, allowed)
            max_index = self._mutator_scale_index(max_pitch, allowed)
        except Exception:
            return values
        for index in indexes:
            pitch_index = self._mutator_scale_index(int(values[index].get("pitch", 60)), allowed)
            mirrored_index = max_index - max(0, pitch_index - min_index)
            if 0 <= mirrored_index < len(allowed):
                values[index]["pitch"] = allowed[mirrored_index]
        return values

    def _mutator_remove_by_depth(self, values, depth, strength, rnd):
        values = [dict(value) for value in tuple(values or ())]
        if max(0.0, min(1.0, float(depth))) <= 0.0:
            return values
        remove_indexes = set(self._mutator_deterministic_indexes(len(values), depth, rnd))
        if not remove_indexes:
            return values
        return [value for index, value in enumerate(values) if index not in remove_indexes]

    def _mutator_apply_velocity_by_depth(self, values, probability, strength, role, rnd, rhythm=False):
        values = [dict(value) for value in tuple(values or ())]
        span = max(1, int(round(max(0.0, min(1.0, float(strength))) * 127.0)))
        for index in self._mutator_operation_indexes(len(values), probability, rnd):
            velocity = int(values[index].get("velocity", 96))
            values[index]["velocity"] = max(1, min(127, velocity + rnd.randint(-span, span)))
        return values

    def _mutator_apply_role_shape(self, values, role, loop_length, settings, rnd, rhythm=False):
        result = [dict(value) for value in tuple(values or ())]
        slot_shape_depth = 0.0
        for slot in self._mutator_active_slots(settings):
            slot_shape_depth = max(slot_shape_depth, self._mutator_depth_value(slot, "probability_depth", 0.0))
        shape_depth = max(
            slot_shape_depth,
            self._mutator_depth_value(settings, "rhythmic_shift_depth"),
            self._mutator_depth_value(settings, "note_addition_depth"),
            self._mutator_depth_value(settings, "note_removal_depth"),
            self._mutator_depth_value(settings, "velocity_change_depth"),
            self._mutator_depth_value(settings, "gate_change_depth"),
            self._mutator_depth_value(settings, "shift_depth"),
            0.0 if rhythm else self._mutator_depth_value(settings, "octave_shift_depth"),
            0.0 if rhythm else self._mutator_depth_value(settings, "pitch_shift_depth"),
        )
        if shape_depth <= 0.0 and role != 15:
            return result
        if role == 6:
            for index, value in enumerate(result):
                value["start"] = round(float(value.get("start", 0.0)) / 0.5) * 0.5
                if index % 2 == 0:
                    value["velocity"] = min(127, int(value.get("velocity", 96)) + 10)
        elif role == 4:
            for value in result:
                if float(value.get("start", 0.0)) > float(loop_length) * 0.65:
                    value["pitch"] = self._mutator_quantize_pitch(int(value.get("pitch", 60)) + (2 if rnd.random() < 0.6 else -2), settings)
                    value["velocity"] = min(127, int(value.get("velocity", 96)) + 8)
        elif role == 13:
            for value in result:
                value["velocity"] = min(127, int(value.get("velocity", 96)) + 6)
        elif role == 15:
            for index, value in enumerate(result):
                value["start"] = round(float(value.get("start", 0.0)) / 0.25) * 0.25
                value["velocity"] = min(127, int(value.get("velocity", 96)) + 18)
                if index % 2 == 0:
                    value["pitch"] = max(0, min(127, int(value.get("pitch", 60)) + 12))
        return result

    def _mutator_apply_add_shift_by_depth(self, values, source_values, role, loop_length, settings, rnd, depth, rhythm=False, target_pitches=None):
        depth = max(0.0, min(1.0, float(depth)))
        result = [dict(value) for value in tuple(values or ())]
        source = [dict(value) for value in tuple(source_values or ())]
        if depth <= 0.0 or not result:
            return result

        if rhythm:
            targets = sorted(set(int(pitch) for pitch in tuple(target_pitches or ()) if 0 <= int(pitch) <= 127))
            if targets:
                for index in self._mutator_operation_indexes(len(result), depth, rnd):
                    pitch = int(result[index].get("pitch", 60))
                    choices = [target for target in targets if target != pitch]
                    if choices:
                        choices.sort(key=lambda target: abs(target - pitch))
                        window = max(1, min(len(choices), int(math.ceil(1 + depth * min(5, len(choices))))))
                        result[index]["pitch"] = rnd.choice(choices[:window])
        else:
            for value in result:
                if rnd.random() < depth:
                    max_steps = max(1, min(4, int(math.ceil(depth * 4))))
                    step_choices = list(range(-max_steps, 0)) + list(range(1, max_steps + 1))
                    value["pitch"] = self._mutator_transpose_scale_steps(
                        int(value.get("pitch", 60)),
                        rnd.choice(step_choices),
                        settings
                    )

        if role in (0, 8, 14) or not source:
            return result

        additions = int(math.ceil(depth * int(settings.get("mutations_per_pass", 1)) * (4 if role in (4, 7) else 3)))
        if depth >= 0.18 and role in (1, 2, 3, 4, 5, 6, 9, 10, 11, 12, 13, 15):
            additions = max(1, additions)
        if depth >= 0.55:
            additions = max(additions, min(len(set(value.get("pitch", 60) for value in source)) + 1, 6))
        if depth >= 0.80:
            additions = max(additions, min(len(set(value.get("pitch", 60) for value in source)) * 2, 12))
        if additions <= 0:
            return result

        allowed_pitches = set(int(value.get("pitch", 60)) for value in source)
        if rhythm and target_pitches:
            targets = set(int(pitch) for pitch in tuple(target_pitches or ()) if 0 <= int(pitch) <= 127)
            allowed_pitches = allowed_pitches.intersection(targets) or allowed_pitches
        motif = [value for value in source if int(value.get("pitch", 60)) in allowed_pitches]
        motif.sort(key=lambda item: int(item.get("velocity", 96)), reverse=True)
        grid = 0.0625 if role == 7 else self._mutator_timing_grid(source or result)
        occupied = self._mutator_rhythm_occupied_steps(result, loop_length, grid=grid)
        for add_index in range(additions):
            if not motif:
                break
            base = dict(motif[add_index % len(motif)])
            if role == 7:
                start = float(loop_length) * rnd.choice([0.75, 0.8125, 0.875, 0.9375])
                duration = min(0.25, float(loop_length) - start)
            else:
                start = (float(base.get("start", 0.0)) + rnd.choice([0.125, 0.25, 0.375, 0.5, 0.75, 1.0])) % float(loop_length)
                duration = min(float(base.get("duration", 0.125)), float(loop_length) - start)
            pitch = int(base.get("pitch", 60))
            start_candidates = self._mutator_phrase_start_candidates(
                motif,
                result,
                base,
                pitch,
                loop_length,
                rnd,
                grid,
                prefer_global_open=False
            )
            if role == 7:
                start_candidates = [
                    candidate
                    for candidate in start_candidates
                    if candidate >= max(0.0, float(loop_length) - 1.0)
                ] or start_candidates
            start_candidates.append(start)
            placed_start = None
            for candidate in start_candidates[:18]:
                placed_start = self._mutator_rhythm_free_start(pitch, candidate, loop_length, occupied, grid=grid)
                if placed_start is not None:
                    break
            start = placed_start
            if start is None:
                continue
            duration_limit = min(duration, max(0.03125, float(loop_length) - start))
            traits = self._mutator_sample_note_traits(motif, rnd, fallback=base, minimum_duration=0.03125 if rhythm else 0.0625, maximum_duration=duration_limit)
            result.append(dict(
                base,
                pitch=pitch,
                start=start,
                duration=traits["duration"],
                velocity=traits["velocity"],
                mute=traits["mute"],
                probability=traits["probability"],
            ))
        return result

    def _mutator_apply_depth_pipeline(self, values, role, loop_length, settings, rnd, rhythm=False, target_pitches=None):
        source_values = [dict(value) for value in tuple(values or ())]
        result = [dict(value) for value in source_values]
        if role == 14:
            return self._mutator_apply_break_role(result, loop_length, rhythm=rhythm)

        result = self._mutator_apply_role_shape(result, role, loop_length, settings, rnd, rhythm=rhythm)
        keys = self._mutator_operation_depth_keys()
        for slot in self._mutator_active_slots(settings):
            operation_index = int(slot.get("operation", 0))
            probability = self._mutator_role_operation_depth(role, self._mutator_depth_value(slot, "probability_depth", 0.0))
            strength = self._mutator_depth_value(slot, "range_depth", 0.5)
            if probability <= 0.0:
                continue
            if operation_index == self._mutator_add_shift_operation_index():
                result = self._mutator_apply_add_shift_by_depth(result, source_values, role, loop_length, settings, rnd, probability, rhythm=rhythm, target_pitches=target_pitches)
                continue
            if operation_index == self._mutator_loop_shift_operation_index():
                result = self._mutator_loop_shift_by_depth(result, probability, loop_length, rnd)
                continue
            if operation_index == self._mutator_reverse_operation_index():
                result = self._mutator_reverse_timing_by_depth(result, probability, loop_length, rnd)
                continue
            if operation_index == self._mutator_invert_operation_index():
                result = self._mutator_invert_pitch_by_depth(result, probability, settings, rnd, rhythm=rhythm, target_pitches=target_pitches)
                continue
            if operation_index == self._mutator_pitch_add_operation_index():
                result = self._mutator_apply_pitch_add_by_depth(result, probability, strength, loop_length, settings, rnd, rhythm=rhythm, target_pitches=target_pitches)
                continue
            if operation_index == self._mutator_duplicate_operation_index():
                result = self._mutator_duplicate_by_depth(result, probability, loop_length, rnd)
                continue
            if operation_index == self._mutator_phrase_shift_operation_index():
                result = self._mutator_phrase_shift_by_depth(result, probability, strength, settings, rnd, rhythm=rhythm, target_pitches=target_pitches)
                continue
            if operation_index == self._mutator_preserver_operation_index():
                result = self._mutator_preserve_original_by_depth(result, source_values, probability, loop_length, rnd)
                continue
            if operation_index < 0 or operation_index >= len(keys):
                continue
            key = keys[operation_index]
            if key == "fill_depth":
                self._mutator_add_fill_values(result, result, role, loop_length, settings, rnd, target_pitches=target_pitches, rhythm=rhythm, fill_depth=probability)
            elif key == "simplification_depth":
                result = self._mutator_simplify_values(result, probability, rnd)
            elif key == "rhythmic_shift_depth":
                result = self._mutator_shift_starts_by_depth(result, probability, strength, loop_length, rnd, rhythm=rhythm)
            elif key == "shift_depth":
                result = self._mutator_shift_pitch_groups_by_depth(result, probability, strength, loop_length, rnd, rhythm=rhythm, target_pitches=target_pitches)
            elif key == "note_addition_depth":
                result = self._mutator_add_values_by_depth(result, probability, strength, role, loop_length, settings, rnd, rhythm=rhythm, target_pitches=target_pitches)
            elif key == "gate_change_depth":
                result = self._mutator_apply_gate_by_depth(result, probability, strength, loop_length, rnd)
            elif key == "octave_shift_depth" and not rhythm:
                result = self._mutator_apply_octave_by_depth(result, probability, rnd)
            elif key == "pitch_shift_depth":
                result = self._mutator_apply_pitch_by_depth(result, probability, strength, settings, rnd, rhythm=rhythm, target_pitches=target_pitches)
            elif key == "note_removal_depth":
                result = self._mutator_remove_by_depth(result, probability, strength, rnd)
            elif key == "velocity_change_depth":
                result = self._mutator_apply_velocity_by_depth(result, probability, strength, role, rnd, rhythm=rhythm)
        return self._mutator_algorithm_prune_values(result, loop_length)

    def _mutator_add_fill_values(self, result, values, role, loop_length, settings, rnd, target_pitches=None, rhythm=False, fill_depth=None):
        if role not in (4, 5, 6, 7, 13, 14, 15):
            return
        pool = [dict(value) for value in tuple(values or ())]
        if target_pitches:
            targets = [int(pitch) for pitch in target_pitches if 0 <= int(pitch) <= 127]
            pool = [value for value in pool if int(value.get("pitch", 0)) in targets] or [
                dict(pitch=pitch, start=0.0, duration=0.125, velocity=96, mute=False, probability=1.0)
                for pitch in targets
            ]
        else:
            targets = sorted(set(int(value.get("pitch", 0)) for value in pool))
        if not pool or not targets:
            return

        if fill_depth is not None:
            fill_depth = max(0.0, min(1.0, float(fill_depth)))
        elif settings.get("algorithm", "mutator") == "mutator":
            fill_depth = self._mutator_role_operation_depth(role, self._mutator_depth_value(settings, "fill_depth", 0.0))
        else:
            fill_depth = max(0.0, min(1.0, float(settings.get("depth", 0.0))))
        if fill_depth <= 0.0:
            return
        hit_count = max(1, min(8, int(math.ceil(fill_depth * (8 if rhythm else 7)))))
        if hit_count <= 2:
            fill_window = min(float(loop_length), 2.0)
        elif hit_count <= 4:
            fill_window = min(float(loop_length), 1.5)
        else:
            fill_window = min(float(loop_length), 1.0)
        fill_start = max(0.0, float(loop_length) - fill_window)
        fill_patterns = {
            1: ((0.5,), (1.0,), (1.5,)),
            2: ((0.0, 1.0), (0.5, 1.5), (0.5, 1.0), (1.0, 1.5)),
            3: ((0.0, 0.75, 1.25), (0.25, 0.75, 1.25), (0.5, 1.0, 1.25)),
            4: ((0.0, 0.5, 1.0, 1.25), (0.25, 0.75, 1.0, 1.25), (0.0, 0.5, 0.75, 1.25)),
            5: ((0.25, 0.5, 0.625, 0.75, 0.875), (0.375, 0.5, 0.625, 0.75, 0.875)),
            6: ((0.25, 0.375, 0.5, 0.625, 0.75, 0.875), (0.125, 0.375, 0.5, 0.625, 0.75, 0.875)),
            7: ((0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875),),
            8: ((0.0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875),),
        }
        offsets = list(rnd.choice(fill_patterns.get(hit_count, fill_patterns[8])))
        occupied = self._mutator_rhythm_occupied_steps(result, loop_length, grid=0.0625)
        contour_targets = list(targets)
        rnd.shuffle(contour_targets)

        for fill_index, offset in enumerate(offsets):
            base = dict(rnd.choice(pool))
            if rhythm:
                pitch = rnd.choice(targets)
            elif contour_targets:
                pitch = contour_targets[fill_index % len(contour_targets)]
            else:
                pitch = int(base.get("pitch", 60))
            start = fill_start + min(fill_window - 0.0625, offset)
            start = self._mutator_rhythm_free_start(pitch, start, loop_length, occupied, grid=0.0625)
            if start is None:
                continue
            traits = self._mutator_sample_note_traits(pool, rnd, fallback=base, minimum_duration=0.03125, maximum_duration=float(loop_length) - start)
            velocity = int(traits.get("velocity", base.get("velocity", 96)))
            velocity_depth = fill_depth
            if settings.get("algorithm", "mutator") == "mutator":
                velocity_depth = self._mutator_role_operation_depth(role, self._mutator_depth_value(settings, "velocity_change_depth", 0.0))
            if velocity_depth > 0.0:
                velocity += self._mutator_velocity_delta(rnd, velocity_depth, role, rhythm=rhythm)
            result.append(dict(
                base,
                pitch=pitch,
                start=start,
                duration=max(0.03125, min(traits["duration"], 0.125 if rhythm else 0.16, float(loop_length) - start)),
                velocity=max(1, min(127, velocity)),
                mute=traits["mute"],
                probability=traits["probability"],
            ))

    def _mutator_rhythm_named_values(self, role, loop_length, settings, rnd):
        algorithm = settings.get("algorithm", "mutator")
        if algorithm not in ("backbeat_engine", "broken_garage", "four_floor_bloom"):
            return None
        targets = self._mutator_rhythm_target_pitches(settings, [])
        if not targets:
            return []

        try:
            bar_beats = float(max(1, int(self.song().signature_numerator)))
        except Exception:
            bar_beats = 4.0
        bar_beats = min(max(1.0, bar_beats), max(1.0, float(loop_length)))
        total_bars = max(1, int(math.ceil(float(loop_length) / bar_beats)))
        kick = targets[0]
        snare = targets[min(1, len(targets) - 1)]
        hat = targets[min(2, len(targets) - 1)]
        open_hat = targets[min(3, len(targets) - 1)]
        result = []
        depth = max(0.0, min(1.0, float(settings.get("depth", 0.0))))

        for bar in range(total_bars):
            offset = bar * bar_beats
            if algorithm == "four_floor_bloom":
                kick_beats = [0.0, 1.0, 2.0, 3.0]
                snare_beats = [1.0, 3.0] if len(targets) > 1 else []
                hat_beats = [0.5, 1.5, 2.5, 3.5] if len(targets) > 2 else []
            elif algorithm == "broken_garage":
                kick_beats = [0.0, 1.5, 2.75]
                snare_beats = [1.0, 3.0] if len(targets) > 1 else []
                hat_beats = [0.0, 0.75, 1.5, 2.25, 3.25] if len(targets) > 2 else []
            else:
                kick_beats = [0.0, 2.0, 2.75 if (bar + role) % 2 else 3.0]
                snare_beats = [1.0, 3.0] if len(targets) > 1 else []
                hat_beats = [i * 0.5 for i in range(int(bar_beats * 2))] if len(targets) > 2 else []

            if role in (1, 2, 4, 13) and depth > 0.2:
                kick_beats = kick_beats + ([3.5] if bar % 2 == 1 else [])
            if role in (7, 14, 15):
                kick_beats = [beat for beat in kick_beats if beat < max(0.0, bar_beats - 1.0)]
                snare_beats = [beat for beat in snare_beats if beat < max(0.0, bar_beats - 1.0)]
                hat_beats = [beat for beat in hat_beats if beat < max(0.0, bar_beats - 1.0)]

            for beat in kick_beats:
                if beat < bar_beats:
                    result.append(dict(pitch=kick, start=offset + beat, duration=0.125, velocity=104, mute=False, probability=1.0))
            for beat in snare_beats:
                if beat < bar_beats:
                    result.append(dict(pitch=snare, start=offset + beat, duration=0.125, velocity=98, mute=False, probability=1.0))
            for beat in hat_beats:
                if beat < bar_beats:
                    pitch = open_hat if len(targets) > 3 and beat % 1.0 == 0.5 and algorithm == "four_floor_bloom" else hat
                    result.append(dict(pitch=pitch, start=offset + beat, duration=0.0625, velocity=70 if pitch == hat else 86, mute=False, probability=1.0))

        self._mutator_add_fill_values(result, result, role, loop_length, settings, rnd, target_pitches=targets, rhythm=True)

        if depth > 0.0:
            for value in result:
                if rnd.random() < depth:
                    start = max(0.0, min(float(loop_length) - 0.0001, float(value.get("start", 0.0))))
                    value["duration"] = self._mutator_rhythm_gate_duration(
                        float(value.get("duration", 0.125)),
                        float(loop_length) - start,
                        depth,
                        rnd
                    )

        return self._mutator_algorithm_prune_values(result, loop_length)

    def _mutator_make_rhythm_section_values(self, source_values, role, source_start, loop_length, settings, rnd):
        if role in (0, 8):
            return self._mutator_relative_section_values(source_values, source_start, loop_length)

        named_values = self._mutator_rhythm_named_values(role, loop_length, settings, rnd)
        if named_values is not None:
            return named_values

        values = self._mutator_relative_section_values(source_values, source_start, loop_length)
        values.sort(key=lambda item: (item["start"], item["pitch"]))
        if not values:
            for pitch in self._mutator_rhythm_target_pitches(settings, source_values):
                values.append(dict(pitch=pitch, start=0.0, duration=0.125, velocity=96, mute=False, probability=1.0))

        target_pitches = self._mutator_rhythm_target_pitches(settings, source_values)
        result = self._mutator_apply_depth_pipeline(
            values,
            role,
            loop_length,
            settings,
            rnd,
            rhythm=True,
            target_pitches=target_pitches
        )

        return self._mutator_algorithm_prune_values(result, loop_length)

    def _mutator_make_section_values(self, source_values, role, source_start, loop_length, settings, rnd):
        if settings.get("companion_mode", "melody") == "rhythm":
            return self._mutator_make_rhythm_section_values(source_values, role, source_start, loop_length, settings, rnd)

        if role in (0, 8):
            return [
                dict(
                    value,
                    start=max(0.0, min(loop_length - 0.0001, value["start"] - source_start)),
                    duration=min(value["duration"], loop_length - max(0.0, min(loop_length - 0.0001, value["start"] - source_start)))
                )
                for value in source_values
            ]

        algorithm_values = self._mutator_make_algorithm_section_values(source_values, role, source_start, loop_length, settings, rnd)
        if algorithm_values is not None:
            return algorithm_values

        values = self._mutator_relative_section_values(source_values, source_start, loop_length)
        values.sort(key=lambda item: (item["start"], item["pitch"]))
        section_values = self._mutator_apply_depth_pipeline(
            values,
            role,
            loop_length,
            settings,
            rnd,
            rhythm=False
        )

        return section_values

    def _mutator_scale_name_from_index(self, scale_index):
        try:
            index = max(0, min(len(self.MUTATOR_SCALE_NAMES) - 1, int(scale_index)))
            return self.MUTATOR_SCALE_NAMES[index]
        except Exception:
            return "Minor"

    def _mutator_settings_from_info(self, info, seed=None):
        companion_mode = info.get("companion_mode", "melody")

        settings = {
            "preset": int(info.get("settings_preset", info.get("preset", 9))),
            "mutations_per_pass": max(1, min(3, int(info.get("mutations_per_pass", 1)))),
            "regenerate_mode": int(info.get("regenerate_mode", 0)),
            "source_mode": int(info.get("source_mode", 2)),
            "depth": max(0.0, min(1.0, float(info.get("depth", 0.0)))),
            "scale": self._mutator_scale_name_from_index(info.get("scale_index", 2)),
            "root": max(0, min(11, int(info.get("root", 0)))),
            "seed": int(seed if seed is not None else info.get("seed", random.randint(1, 2000000000))),
            "algorithm": info.get("algorithm", "mutator"),
            "companion_mode": companion_mode,
            "target_pitches": info.get("target_pitches", []),
            "operation_order": info.get("operation_order", []),
            "mutator_slots": self._mutator_normalized_slots(info),
            "mutator_slot_count": self._mutator_slot_count_from_value(info.get("mutator_slot_count", ""), self._mutator_normalized_slots(info)),
        }
        for key in self._mutator_operation_depth_keys():
            settings[key] = self._mutator_depth_value(info, key, 0.0)
        return settings

    def _mutator_generation_is_busy(self, key):
        with self._mutator_generation_lock:
            return key in self._mutator_generation_in_progress or key in self._mutator_generation_scheduled

    def _queue_mutator_work(self, key, work):
        if not work:
            return False
        with self._mutator_generation_lock:
            self._queued_mutator_work[key] = work
        return True

    def _queue_mutator_settings_update(self, key, clip, settings, send_updates=True):
        return self._queue_mutator_work(key, {
            "type": "settings",
            "clip": clip,
            "settings": dict(settings or {}),
            "send_updates": bool(send_updates),
        })

    def _queue_mutator_generation(self, key, clip, settings, previous_info=None, send_updates=True):
        return self._queue_mutator_work(key, {
            "type": "generate",
            "clip": clip,
            "settings": dict(settings or {}),
            "previous_info": dict(previous_info or {}) if previous_info else None,
            "send_updates": bool(send_updates),
        })

    def _pop_queued_mutator_work(self, key):
        with self._mutator_generation_lock:
            return self._queued_mutator_work.pop(key, None)

    def _flush_queued_mutator_work(self, key):
        with self._mutator_generation_lock:
            if key in self._mutator_generation_in_progress or key in self._mutator_generation_scheduled:
                return False
        work = self._pop_queued_mutator_work(key)

        if not work:
            return False

        def run_queued_work():
            work_type = work.get("type")
            clip = work.get("clip")
            settings = work.get("settings", {})
            send_updates = bool(work.get("send_updates", True))
            if work_type == "generate":
                previous_info = self._mutator_info(clip) or work.get("previous_info")
                self._generate_mutator_clip(
                    clip,
                    settings,
                    previous_info=previous_info,
                    send_updates=send_updates,
                    automatic=False
                )
            elif work_type == "settings":
                self._apply_mutator_clip_settings(clip, settings, send_updates=send_updates)

        try:
            self.schedule_message(1, run_queued_work)
            return True
        except Exception:
            try:
                run_queued_work()
                return True
            except Exception as e:
                self._debug_log("Error flushing queued mutator work: {}".format(str(e)))
                return False

    def _begin_selected_clip_update_batch(self):
        self._selected_clip_update_suppression_depth += 1

    def _end_selected_clip_update_batch(self):
        self._selected_clip_update_suppression_depth = max(0, self._selected_clip_update_suppression_depth - 1)
        if self._selected_clip_update_suppression_depth == 0:
            self._selected_clip_update_pending_metadata = False
            self._selected_clip_update_pending_notes = False

    def _selected_clip_updates_are_suppressed(self):
        return self._selected_clip_update_suppression_depth > 0

    def _begin_undo_step(self):
        try:
            song = self.song()
            begin_undo_step = getattr(song, "begin_undo_step", None)
            if begin_undo_step:
                begin_undo_step()
                return True
        except Exception:
            pass
        return False

    def _end_undo_step(self, undo_step_started):
        if not undo_step_started:
            return
        try:
            end_undo_step = getattr(self.song(), "end_undo_step", None)
            if end_undo_step:
                end_undo_step()
        except Exception:
            pass

    def _refresh_visible_mutator_clip(self, clip, send_notes=True):
        try:
            highlighted_clip_slot = self.song().view.highlighted_clip_slot
            if (
                highlighted_clip_slot is not None
                and highlighted_clip_slot.has_clip
                and self._live_object_identity(highlighted_clip_slot.clip) == self._live_object_identity(clip)
            ):
                self.send_selected_clip_metadata()
                if send_notes:
                    self.send_selected_clip_notes()
        except Exception:
            pass

    def _generate_mutator_clip(self, clip, settings, previous_info=None, send_updates=True, automatic=False):
        generation_key = self._live_object_identity(clip)
        now = time.time()
        with self._mutator_generation_lock:
            if generation_key in self._mutator_generation_in_progress:
                return False
            if automatic and now - self._last_mutator_generation_times.get(generation_key, 0.0) < self.MUTATOR_GENERATION_COOLDOWN_SECONDS:
                return False
            self._mutator_generation_in_progress.add(generation_key)
        try:
            if clip is None or not getattr(clip, "is_midi_clip", False):
                return False

            previous_info = previous_info or self._mutator_info(clip)
            companion_was_already_running = previous_info is not None
            decoupled_info = self._decoupled_automation_info(clip)
            source_start = decoupled_info["note_start"] if decoupled_info else float(getattr(clip, "loop_start", 0.0))
            original_loop_length = previous_info.get("original_loop_length") if previous_info else None
            if original_loop_length is None:
                if decoupled_info:
                    original_loop_length = decoupled_info["note_length"]
                else:
                    original_loop_length = max(0.0001, float(getattr(clip, "loop_end", source_start + 4.0)) - source_start)
            original_loop_length = max(0.0001, float(original_loop_length))
            source_end = source_start + original_loop_length
            source_notes = clip.get_notes_extended(0, 128, source_start, original_loop_length)
            source_values = [self._mutator_note_values(note) for note in source_notes if note.start_time >= source_start - 0.000001 and note.start_time < source_end - 0.000001]
            rhythm_mode = settings.get("companion_mode", "melody") == "rhythm"
            target_pitches = set(self._mutator_rhythm_target_pitches(settings, source_values)) if rhythm_mode else set()
            if not source_values and not target_pitches:
                return False
            settings = self._mutator_resolve_slot_activation(settings)
            generation_source_values = source_values
            passthrough_section_values = []
            if rhythm_mode:
                generation_source_values, passthrough_section_values = self._mutator_split_rhythm_source_values(
                    settings,
                    source_values,
                    source_start,
                    original_loop_length
                )

            def section_payload(values):
                return [dict(value) for value in tuple(values or ())] + [dict(value) for value in passthrough_section_values]

            roles = self._mutator_pattern_roles(settings.get("preset", 9))
            sections = []
            specs = []
            generated_section_cache = {}
            chain_preset = self._mutator_preset_is_chain(settings.get("preset", 9))
            original_section_values = self._mutator_make_section_values(
                generation_source_values,
                0,
                source_start,
                original_loop_length,
                settings,
                random.Random(0)
            )
            previous_chain_values = tuple(dict(value) for value in original_section_values)
            rnd = random.Random(int(settings.get("seed", 1)))
            for index, role in enumerate(roles):
                section_start = source_start + (index * original_loop_length)
                sections.append({"role": role, "start": section_start, "length": original_loop_length})
                preserve_source_section = index == 0

                if chain_preset:
                    if role == 0:
                        section_values = original_section_values
                        previous_chain_values = tuple(dict(value) for value in section_values)
                    elif role in generated_section_cache:
                        section_values = generated_section_cache[role]
                        previous_chain_values = tuple(dict(value) for value in section_values)
                    else:
                        section_values = self._mutator_make_section_values(
                            previous_chain_values,
                            role,
                            0.0,
                            original_loop_length,
                            settings,
                            rnd
                        )
                        generated_section_cache[role] = tuple(dict(value) for value in section_values)
                        previous_chain_values = tuple(dict(value) for value in section_values)
                    if not preserve_source_section:
                        specs.extend(self._mutator_place_section_values(section_payload(section_values), section_start, original_loop_length))
                    continue

                if role in (0, 8):
                    section_values = self._mutator_make_section_values(
                        generation_source_values,
                        role,
                        source_start,
                        original_loop_length,
                        settings,
                        rnd
                    )
                    if not preserve_source_section:
                        specs.extend(self._mutator_place_section_values(section_payload(section_values), section_start, original_loop_length))
                elif role in generated_section_cache:
                    specs.extend(self._mutator_place_section_values(section_payload(generated_section_cache[role]), section_start, original_loop_length))
                elif role == 2 and 1 in generated_section_cache:
                    section_values = self._mutator_make_section_values(
                        generated_section_cache[1],
                        role,
                        0.0,
                        original_loop_length,
                        settings,
                        rnd
                    )
                    generated_section_cache[role] = tuple(dict(value) for value in section_values)
                    specs.extend(self._mutator_place_section_values(section_payload(section_values), section_start, original_loop_length))
                elif role == 13 and 5 in generated_section_cache:
                    section_values = self._mutator_make_section_values(
                        generated_section_cache[5],
                        role,
                        0.0,
                        original_loop_length,
                        settings,
                        rnd
                    )
                    generated_section_cache[role] = tuple(dict(value) for value in section_values)
                    specs.extend(self._mutator_place_section_values(section_payload(section_values), section_start, original_loop_length))
                elif role == 12 and 6 in generated_section_cache:
                    section_values = self._mutator_make_section_values(
                        generated_section_cache[6],
                        role,
                        0.0,
                        original_loop_length,
                        settings,
                        rnd
                    )
                    generated_section_cache[role] = tuple(dict(value) for value in section_values)
                    specs.extend(self._mutator_place_section_values(section_payload(section_values), section_start, original_loop_length))
                elif role == 15 and 6 in generated_section_cache:
                    section_values = self._mutator_make_section_values(
                        generated_section_cache[6],
                        role,
                        0.0,
                        original_loop_length,
                        settings,
                        rnd
                    )
                    generated_section_cache[role] = tuple(dict(value) for value in section_values)
                    specs.extend(self._mutator_place_section_values(section_payload(section_values), section_start, original_loop_length))
                else:
                    generation_role = 5 if role == 16 else role
                    section_values = self._mutator_make_section_values(
                        generation_source_values,
                        generation_role,
                        source_start,
                        original_loop_length,
                        settings,
                        rnd
                    )
                    generated_section_cache[role] = tuple(dict(value) for value in section_values)
                    specs.extend(self._mutator_place_section_values(section_payload(section_values), section_start, original_loop_length))

            structure_length = original_loop_length * len(roles)
            previous_structure_length = max(0.0001, float(previous_info.get("structure_length", original_loop_length))) if previous_info else original_loop_length
            should_duplicate_automation = (
                not companion_was_already_running or
                structure_length > previous_structure_length + 0.000001
            )
            automation_source_length = previous_structure_length if companion_was_already_running else original_loop_length
            remove_start = source_end
            remove_end = max(
                source_start + structure_length,
                float(getattr(clip, "loop_end", 0.0)),
                float(getattr(clip, "end_marker", 0.0)),
                float(getattr(clip, "length", 0.0))
            )
            self._begin_selected_clip_update_batch()
            undo_step_started = self._begin_undo_step()
            try:
                if hasattr(clip, "remove_notes_extended"):
                    clip.remove_notes_extended(0, 128, remove_start, max(0.0001, remove_end - remove_start))
                if specs:
                    clip.add_new_notes(tuple(specs))

                clip.loop_start = source_start
                clip.start_marker = min(float(getattr(clip, "start_marker", source_start)), source_start)
                clip.loop_end = source_start + structure_length
                clip.end_marker = source_start + structure_length
                if should_duplicate_automation:
                    if decoupled_info:
                        self._couple_decoupled_automation_to_loop_length(clip, structure_length)
                    else:
                        self._duplicate_loop_automation_to_loop_length(
                            clip,
                            source_start,
                            automation_source_length,
                            structure_length
                        )
                info = self._mutator_info_from_settings(settings, {
                    "original_loop_length": original_loop_length,
                    "structure_length": structure_length,
                    "seed": settings.get("seed", 1),
                    "sections": sections,
                }, clip, commit_structure=True)
                self._save_mutator_info_to_name(clip, info)
            finally:
                self._end_undo_step(undo_step_started)
                self._end_selected_clip_update_batch()
            if send_updates:
                self._refresh_visible_mutator_clip(clip)
            self._last_mutator_generation_times[generation_key] = time.time()
            return True
        except Exception as e:
            self._debug_log("Error generating mutator clip: {}".format(str(e)))
            return False
        finally:
            with self._mutator_generation_lock:
                self._mutator_generation_in_progress.discard(generation_key)
            self._flush_queued_mutator_work(generation_key)

    def _schedule_mutator_generation(self, key, clip, settings, previous_info=None, send_updates=True, respect_cooldown=True, automatic=True):
        with self._mutator_generation_lock:
            if key in self._mutator_generation_scheduled or key in self._mutator_generation_in_progress:
                return False
            if respect_cooldown and time.time() - self._last_mutator_generation_times.get(key, 0.0) < self.MUTATOR_GENERATION_COOLDOWN_SECONDS:
                return False
            self._mutator_generation_scheduled.add(key)

        def generate_later():
            try:
                queued_work = self._pop_queued_mutator_work(key)
                generation_clip = clip
                generation_settings = settings
                generation_previous_info = previous_info
                generation_send_updates = send_updates
                generation_automatic = bool(automatic)
                apply_settings_if_generation_fails = None

                if queued_work:
                    work_type = queued_work.get("type")
                    if work_type == "generate":
                        generation_clip = queued_work.get("clip")
                        generation_settings = queued_work.get("settings", {})
                        generation_previous_info = self._mutator_info(generation_clip) or queued_work.get("previous_info")
                        generation_send_updates = bool(queued_work.get("send_updates", True))
                        generation_automatic = False
                    elif work_type == "settings":
                        generation_clip = queued_work.get("clip")
                        generation_settings = queued_work.get("settings", {})
                        generation_previous_info = self._mutator_info(generation_clip) or previous_info
                        generation_send_updates = bool(queued_work.get("send_updates", True))
                        generation_automatic = False
                        apply_settings_if_generation_fails = queued_work

                generation_succeeded = self._generate_mutator_clip(
                    generation_clip,
                    generation_settings,
                    previous_info=generation_previous_info,
                    send_updates=generation_send_updates,
                    automatic=generation_automatic
                )
                if apply_settings_if_generation_fails and not generation_succeeded:
                    self._apply_mutator_clip_settings(
                        apply_settings_if_generation_fails.get("clip"),
                        apply_settings_if_generation_fails.get("settings", {}),
                        send_updates=bool(apply_settings_if_generation_fails.get("send_updates", True)),
                        request_generation=False
                    )
                if not generation_succeeded:
                    self._mark_mutator_generation_unscheduled(key)
            finally:
                with self._mutator_generation_lock:
                    self._mutator_generation_scheduled.discard(key)
                self._flush_queued_mutator_work(key)

        try:
            self.schedule_message(1, generate_later)
            return True
        except Exception:
            with self._mutator_generation_lock:
                self._mutator_generation_scheduled.discard(key)
            return False

    def _mark_mutator_generation_unscheduled(self, key):
        with self._mutator_generation_lock:
            state = self._mutator_regeneration_states.get(key)
            if state:
                state["regenerated_for_current_cycle"] = False
            self._last_mutator_generation_signatures.pop(key, None)

    def _request_mutator_generation_after_settings_update(self, key, clip, info, previous_info, send_updates=True):
        try:
            if not self._song_is_playing():
                return False
            if int(info.get("regenerate_mode", 0)) == 0:
                return False
            if not self._mutator_generation_settings_changed(info, previous_info):
                return False
            self._mark_mutator_generation_unscheduled(key)
            settings = self._mutator_settings_from_info(info, seed=random.randint(1, 2000000000))
            if self._mutator_generation_is_busy(key):
                return self._queue_mutator_generation(key, clip, settings, previous_info=info, send_updates=send_updates)
            if self._schedule_mutator_generation(key, clip, settings, previous_info=info, send_updates=send_updates):
                return True
            self._mark_mutator_generation_unscheduled(key)
        except Exception as e:
            self._debug_log("Error requesting mutator generation after settings update: {}".format(str(e)))
        return False

    def _should_regenerate_mutator_clip(self, key, clip, info, raw_position):
        with self._mutator_generation_lock:
            if key in self._mutator_generation_scheduled or key in self._mutator_generation_in_progress:
                return False

            state = self._mutator_regeneration_states.setdefault(key, {
                "last_position": None,
                "completed_pass_count": 0,
                "regenerated_for_current_cycle": False,
            })
            now = time.time()

            cycle_start = float(getattr(clip, "loop_start", 0.0))
            cycle_end = cycle_start + max(0.0001, float(info.get("structure_length", 0.0001)))
            previous = state.get("last_position")
            wrapped_to_start = previous is not None and previous > raw_position + 0.25
            if wrapped_to_start:
                state["regenerated_for_current_cycle"] = False
                state["completed_pass_count"] = int(state.get("completed_pass_count", 0)) + 1

            regenerate_mode = int(info.get("regenerate_mode", 0))
            should_regenerate = False
            if regenerate_mode == 1:
                should_regenerate = wrapped_to_start
            elif regenerate_mode == 2:
                should_regenerate = raw_position >= cycle_end - 0.5 and raw_position < cycle_end + 0.25
            elif regenerate_mode == 3:
                should_regenerate = wrapped_to_start and int(state.get("completed_pass_count", 0)) % 2 == 0
            elif regenerate_mode == 4:
                should_regenerate = wrapped_to_start and int(state.get("completed_pass_count", 0)) % 4 == 0
            elif regenerate_mode == 5:
                should_regenerate = wrapped_to_start and random.random() < 0.10
            elif regenerate_mode == 6:
                should_regenerate = wrapped_to_start and random.random() < 0.25
            elif regenerate_mode == 7:
                should_regenerate = wrapped_to_start and random.random() < 0.50
            elif regenerate_mode == 8:
                should_regenerate = wrapped_to_start and random.random() < 0.75

            state["last_position"] = raw_position
            if should_regenerate and not state.get("regenerated_for_current_cycle", False):
                generation_signature = (
                    int(regenerate_mode),
                    int(state.get("completed_pass_count", 0)),
                    int(round(cycle_start * 1000.0)),
                    int(round(cycle_end * 1000.0))
                )
                if self._last_mutator_generation_signatures.get(key) == generation_signature:
                    return False
                if now - self._last_mutator_generation_request_times.get(key, 0.0) < self.MUTATOR_GENERATION_COOLDOWN_SECONDS:
                    return False
                self._last_mutator_generation_request_times[key] = now
                self._last_mutator_generation_signatures[key] = generation_signature
                state["regenerated_for_current_cycle"] = True
                return True
            return False

    def _should_regenerate_mutator_clip_on_launch(self, key, clip, info, raw_position):
        with self._mutator_generation_lock:
            state = self._mutator_regeneration_states.setdefault(key, {
                "last_position": None,
                "completed_pass_count": 0,
                "regenerated_for_current_cycle": False,
            })

            cycle_start = float(getattr(clip, "loop_start", 0.0))
            cycle_end = cycle_start + max(0.0001, float(info.get("structure_length", 0.0001)))
            play_count = int(state.get("completed_pass_count", 0)) + 1
            state["completed_pass_count"] = play_count
            state["last_position"] = raw_position
            state["regenerated_for_current_cycle"] = False

            regenerate_mode = int(info.get("regenerate_mode", 0))
            should_regenerate = False
            if regenerate_mode in (1, 2):
                should_regenerate = True
            elif regenerate_mode == 3:
                should_regenerate = play_count % 2 == 0
            elif regenerate_mode == 4:
                should_regenerate = play_count % 4 == 0
            elif regenerate_mode == 5:
                should_regenerate = random.random() < 0.10
            elif regenerate_mode == 6:
                should_regenerate = random.random() < 0.25
            elif regenerate_mode == 7:
                should_regenerate = random.random() < 0.50
            elif regenerate_mode == 8:
                should_regenerate = random.random() < 0.75

            if should_regenerate:
                generation_signature = (
                    "launch",
                    int(regenerate_mode),
                    int(play_count),
                    int(round(cycle_start * 1000.0)),
                    int(round(cycle_end * 1000.0))
                )
                if self._last_mutator_generation_signatures.get(key) == generation_signature:
                    return False
                self._last_mutator_generation_request_times[key] = time.time()
                self._last_mutator_generation_signatures[key] = generation_signature
                state["regenerated_for_current_cycle"] = True
                return True
            return False

    def _request_mutator_generation_for_launch(self, key, clip, info, raw_position):
        try:
            if not info or int(info.get("regenerate_mode", 0)) == 0:
                return False
            if not self._should_regenerate_mutator_clip_on_launch(key, clip, info, raw_position):
                return False
            settings = self._mutator_settings_from_info(info, seed=random.randint(1, 2000000000))
            if self._mutator_generation_is_busy(key):
                return self._queue_mutator_generation(key, clip, settings, previous_info=info, send_updates=True)
            if self._schedule_mutator_generation(
                key,
                clip,
                settings,
                previous_info=info,
                send_updates=True,
                respect_cooldown=False,
                automatic=False
            ):
                return True
            self._mark_mutator_generation_unscheduled(key)
        except Exception as e:
            self._debug_log("Error requesting mutator generation for launch: {}".format(str(e)))
        return False

    def _refresh_mutator_clip_presence(self):
        previous_presence = self._has_mutator_clips
        try:
            has_mutator_clips = False
            for track in self.song().tracks:
                for clip_slot in track.clip_slots:
                    if not clip_slot.has_clip:
                        continue
                    clip = clip_slot.clip
                    if self._mutator_info_from_name(clip.name, resolve_scale_root=False):
                        has_mutator_clips = True
                        break
                if has_mutator_clips:
                    break
        except Exception as e:
            # Do not cache a false negative when Live is temporarily changing
            # its topology; try again on the next evaluation.
            self._mutator_clip_presence_dirty = True
            self._debug_log("Error checking mutator clip presence: {}".format(str(e)))
            return previous_presence
        self._has_mutator_clips = has_mutator_clips
        self._mutator_clip_presence_dirty = False
        return self._has_mutator_clips

    def _evaluate_mutator_regeneration(self, only_track_index=None):
        try:
            if not self._song_is_playing():
                self._mutator_regeneration_states.clear()
                self._last_mutator_generation_signatures.clear()
                self._mutator_playing_clip_keys.clear()
                self._mutator_triggered_clip_keys.clear()
                return

            if self._mutator_clip_presence_dirty:
                self._refresh_mutator_clip_presence()
            if not self._has_mutator_clips:
                self._mutator_regeneration_states.clear()
                self._last_mutator_generation_signatures.clear()
                self._mutator_playing_clip_keys.clear()
                self._mutator_triggered_clip_keys.clear()
                return

            active_keys = set()
            known_keys = set()
            scoped_keys = set()
            for track_index, track in enumerate(self.song().tracks):
                if only_track_index is not None and track_index != only_track_index:
                    continue
                for scene_index, clip_slot in enumerate(track.clip_slots):
                    if not clip_slot.has_clip:
                        continue
                    clip = clip_slot.clip
                    is_playing = bool(clip_slot.is_playing)
                    is_triggered = self._clip_slot_is_triggered(clip_slot)

                    if not is_playing and not is_triggered:
                        if not self._mutator_playing_clip_keys and not self._mutator_triggered_clip_keys:
                            continue
                        key = self._live_object_identity(clip)
                        if key not in self._mutator_playing_clip_keys and key not in self._mutator_triggered_clip_keys:
                            continue
                    else:
                        key = self._live_object_identity(clip)

                    known_keys.add(key)
                    scoped_keys.add(key)
                    info = self._mutator_info(clip)
                    if not info or int(info.get("regenerate_mode", 0)) == 0:
                        self._mutator_playing_clip_keys.discard(key)
                        self._mutator_triggered_clip_keys.discard(key)
                        continue

                    raw_position = float(getattr(clip, "playing_position", 0.0))

                    if is_triggered:
                        self._mutator_triggered_clip_keys.add(key)

                    if is_playing:
                        active_keys.add(key)
                        was_already_playing = key in self._mutator_playing_clip_keys
                        trigger_resolved = key in self._mutator_triggered_clip_keys and not is_triggered
                        if not was_already_playing or trigger_resolved:
                            self._request_mutator_generation_for_launch(key, clip, info, raw_position)
                            self._mutator_triggered_clip_keys.discard(key)
                        self._mutator_playing_clip_keys.add(key)
                    else:
                        self._mutator_playing_clip_keys.discard(key)
                        if not is_triggered:
                            self._mutator_triggered_clip_keys.discard(key)
                        continue

                    if self._should_regenerate_mutator_clip(key, clip, info, raw_position):
                        settings = self._mutator_settings_from_info(info, seed=random.randint(1, 2000000000))
                        if not self._schedule_mutator_generation(key, clip, settings, previous_info=info, send_updates=True):
                            self._mark_mutator_generation_unscheduled(key)

            if only_track_index is None:
                self._mutator_playing_clip_keys.intersection_update(active_keys)
                self._mutator_triggered_clip_keys.intersection_update(known_keys | active_keys)
                for key in list(self._mutator_regeneration_states.keys()):
                    if key not in active_keys:
                        self._mutator_regeneration_states.pop(key, None)
                        self._last_mutator_generation_signatures.pop(key, None)
            else:
                for key in list(self._mutator_playing_clip_keys):
                    if key in scoped_keys and key not in active_keys:
                        self._mutator_playing_clip_keys.discard(key)
        except Exception as e:
            self._debug_log("Error evaluating mutator regeneration: {}".format(str(e)))

    def _set_mutator_clip(self, message):
        try:
            settings = self._mutator_settings_from_message(message)
            clip_slot = self.song().view.highlighted_clip_slot
            if clip_slot is None or not clip_slot.has_clip:
                return
            clip = clip_slot.clip
            key = self._live_object_identity(clip)
            previous_info = self._mutator_info(clip)
            if self._mutator_generation_is_busy(key):
                self._queue_mutator_generation(key, clip, settings, previous_info=previous_info, send_updates=True)
                return
            self._generate_mutator_clip(clip, settings, previous_info=previous_info, send_updates=True)
        except Exception as e:
            self._debug_log("Error setting mutator clip: {}".format(str(e)))

    def _apply_mutator_clip_settings(self, clip, settings, send_updates=True, request_generation=True):
        if clip is None or not getattr(clip, "is_midi_clip", False):
            return False

        key = self._live_object_identity(clip)
        previous_info = self._mutator_info(clip)
        if not previous_info:
            return False

        info = self._mutator_info_from_settings(settings, previous_info, clip)
        info["pending_settings_update"] = False
        self._begin_selected_clip_update_batch()
        try:
            self._save_mutator_info_to_name(clip, info)
        finally:
            self._end_selected_clip_update_batch()
        if send_updates:
            self._refresh_visible_mutator_clip(clip, send_notes=False)
        if request_generation:
            self._request_mutator_generation_after_settings_update(key, clip, info, previous_info, send_updates=send_updates)
        return True

    def _update_mutator_clip_settings(self, message):
        try:
            settings = self._mutator_settings_from_message(message)
            clip_slot = self.song().view.highlighted_clip_slot
            if clip_slot is None or not clip_slot.has_clip:
                return
            clip = clip_slot.clip
            if not getattr(clip, "is_midi_clip", False):
                return
            key = self._live_object_identity(clip)
            if self._mutator_generation_is_busy(key):
                self._queue_mutator_settings_update(key, clip, settings, send_updates=True)
                return
            self._apply_mutator_clip_settings(clip, settings, send_updates=True)
        except Exception as e:
            self._debug_log("Error updating mutator clip settings: {}".format(str(e)))

    def _end_mutator_clip(self):
        try:
            clip_slot = self.song().view.highlighted_clip_slot
            if clip_slot is None or not clip_slot.has_clip:
                return
            clip = clip_slot.clip
            info = self._mutator_info(clip)
            if not info:
                return
            source_start = float(getattr(clip, "loop_start", 0.0))
            original_loop_length = float(info.get("original_loop_length", max(0.0001, float(getattr(clip, "loop_end", source_start)) - source_start)))
            source_end = source_start + max(0.0001, original_loop_length)
            remove_end = max(
                source_end,
                source_start + float(info.get("structure_length", original_loop_length)),
                float(getattr(clip, "loop_end", 0.0)),
                float(getattr(clip, "end_marker", 0.0)),
                float(getattr(clip, "length", 0.0))
            )
            if hasattr(clip, "remove_notes_extended"):
                clip.remove_notes_extended(0, 128, source_end, max(0.0001, remove_end - source_end))
            clip.loop_start = source_start
            clip.start_marker = min(float(getattr(clip, "start_marker", source_start)), source_start)
            clip.loop_end = source_end
            clip.end_marker = clip.loop_end
            self._remove_mutator_info_from_name(clip)
            self.send_selected_clip_metadata()
            self.send_selected_clip_notes()
        except Exception as e:
            self._debug_log("Error ending mutator clip: {}".format(str(e)))

    def _unfold_mutator_clip(self):
        try:
            clip_slot = self.song().view.highlighted_clip_slot
            if clip_slot is None or not clip_slot.has_clip:
                return
            clip = clip_slot.clip
            info = self._mutator_info(clip)
            if not info:
                return
            source_start = float(getattr(clip, "loop_start", 0.0))
            structure_length = float(info.get("structure_length", max(0.0001, float(getattr(clip, "loop_end", source_start)) - source_start)))
            clip.loop_start = source_start
            clip.start_marker = min(float(getattr(clip, "start_marker", source_start)), source_start)
            clip.loop_end = source_start + max(0.0001, structure_length)
            clip.end_marker = clip.loop_end
            self._remove_mutator_info_from_name(clip)
            self.send_selected_clip_metadata()
            self.send_selected_clip_notes()
        except Exception as e:
            self._debug_log("Error unfolding mutator clip: {}".format(str(e)))

    def _handle_tap_tempo(self):
        try:
            self.song().tap_tempo()
        except Exception:
            pass

    def _apply_decoupled_note_loop(self, clip, note_start, note_length, send_updates=True):
        try:
            if clip is None:
                return

            previous_info = self._decoupled_automation_info(clip)
            if not previous_info:
                return

            note_start = max(0.0, float(note_start))
            note_length = max(0.0001, float(note_length))
            automation_lengths = {}
            for key, length in previous_info.get("automation_lengths", {}).items():
                try:
                    length = max(0.0001, float(length))
                    if abs(length - note_length) > 0.000001:
                        automation_lengths[key] = length
                except Exception:
                    pass

            if not automation_lengths:
                folded_info = {
                    "note_start": note_start,
                    "note_length": note_length,
                    "note_end": note_start + note_length,
                    "automation_lengths": {},
                    "automation_length": note_length,
                    "physical_length": note_length,
                    "physical_end": note_start + note_length,
                    "remove_start": min(previous_info["note_start"], note_start),
                }
                self._rewrite_decoupled_note_copies(clip, folded_info)
                self._rewrite_all_decoupled_automation_envelopes(clip, folded_info)
                self._remove_decoupled_automation_info_from_name(clip)
                clip.loop_start = note_start
                clip.start_marker = min(float(getattr(clip, "start_marker", note_start)), note_start)
                clip.loop_end = note_start + note_length
                clip.end_marker = note_start + note_length
                if send_updates:
                    self.send_selected_clip_metadata()
                    self.send_selected_clip_notes()
                return

            max_physical_length = self._decoupled_automation_max_physical_length(clip, note_length)
            physical_length = self._decoupled_physical_length(note_length, automation_lengths.values(), max_physical_length)
            info = {
                "note_start": note_start,
                "note_length": note_length,
                "note_end": note_start + note_length,
                "automation_lengths": automation_lengths,
                "automation_length": note_length,
                "physical_length": physical_length,
                "physical_end": note_start + physical_length,
                "remove_start": min(previous_info["note_start"], note_start),
            }

            self._rewrite_decoupled_note_copies(clip, info)
            self._rewrite_all_decoupled_automation_envelopes(clip, info)
            clip.loop_start = info["note_start"]
            clip.start_marker = min(float(getattr(clip, "start_marker", info["note_start"])), info["note_start"])
            clip.loop_end = info["physical_end"]
            clip.end_marker = info["physical_end"]
            self._save_decoupled_automation_info_to_name(clip, info)
            if send_updates:
                self.send_selected_clip_metadata()
                self.send_selected_clip_notes()
        except Exception as e:
            self._debug_log("Error applying decoupled note loop: {}".format(str(e)))

    def _set_decoupled_automation_length(self, message):
        try:
            payload = bytes(message[2:-1]).decode('ascii', errors='ignore')
            fields = self._split_escaped_sysex_fields(payload, "|")
            if not fields:
                return

            automation_length = max(0.0001, float(fields[0]))
            control_index = max(0, min(7, int(fields[1]))) if len(fields) >= 2 and fields[1] != "" else 0
            device_param = self._current_connected_parameter_for_control(control_index)
            clip_slot = self.song().view.highlighted_clip_slot
            if clip_slot is None or not clip_slot.has_clip:
                return

            self._apply_decoupled_automation_length(clip_slot.clip, device_param, automation_length, send_updates=True)
        except Exception as e:
            self._debug_log("Error setting decoupled automation length: {}".format(str(e)))

    def _apply_decoupled_automation_length(self, clip, device_param, automation_length, send_updates=True):
        try:
            parameter_key = self._decoupled_automation_parameter_key(device_param)
            if not parameter_key:
                return

            if clip is None:
                return

            automation_length = max(0.0001, float(automation_length))
            previous_info = self._decoupled_automation_info(clip)
            if previous_info:
                note_start = previous_info["note_start"]
                note_length = previous_info["note_length"]
                automation_lengths = dict(previous_info.get("automation_lengths", {}))
            else:
                note_start = float(getattr(clip, "loop_start", 0.0))
                note_end = float(getattr(clip, "loop_end", note_start + automation_length))
                note_length = max(0.0001, note_end - note_start)
                automation_lengths = {}

            max_physical_length = self._decoupled_automation_max_physical_length(clip, note_length)
            automation_length = min(automation_length, max_physical_length)
            if abs(automation_length - note_length) <= 0.000001:
                automation_lengths.pop(parameter_key, None)
            else:
                automation_lengths[parameter_key] = automation_length

            if not automation_lengths:
                folded_info = {
                    "note_start": note_start,
                    "note_length": note_length,
                    "note_end": note_start + note_length,
                    "automation_lengths": {},
                    "automation_length": note_length,
                    "physical_length": note_length,
                    "physical_end": note_start + note_length,
                }
                self._rewrite_decoupled_note_copies(clip, folded_info)
                self._rewrite_all_decoupled_automation_envelopes(clip, folded_info)
                self._remove_decoupled_automation_info_from_name(clip)
                clip.loop_start = note_start
                clip.start_marker = min(float(getattr(clip, "start_marker", note_start)), note_start)
                clip.loop_end = note_start + note_length
                clip.end_marker = note_start + note_length
                if send_updates:
                    self.send_selected_clip_metadata()
                    self.send_selected_clip_notes()
                return

            physical_length = self._decoupled_physical_length(note_length, automation_lengths.values(), max_physical_length)
            info = {
                "note_start": note_start,
                "note_length": note_length,
                "note_end": note_start + note_length,
                "automation_lengths": automation_lengths,
                "automation_length": automation_length,
                "physical_length": physical_length,
                "physical_end": note_start + physical_length,
            }

            self._rewrite_decoupled_note_copies(clip, info)
            self._rewrite_all_decoupled_automation_envelopes(clip, info)
            if info["physical_end"] > float(getattr(clip, "loop_end", 0.0)):
                clip.loop_end = info["physical_end"]
                clip.end_marker = info["physical_end"]
            clip.loop_start = info["note_start"]
            clip.start_marker = min(float(getattr(clip, "start_marker", info["note_start"])), info["note_start"])
            clip.loop_end = info["physical_end"]
            clip.end_marker = info["physical_end"]
            self._save_decoupled_automation_info_to_name(clip, info)
            if send_updates:
                self.send_selected_clip_metadata()
                self.send_selected_clip_notes()
        except Exception as e:
            self._debug_log("Error applying decoupled automation length: {}".format(str(e)))

    def _unfold_decoupled_automation_clip(self):
        try:
            clip_slot = self.song().view.highlighted_clip_slot
            if clip_slot is None or not clip_slot.has_clip:
                return

            clip = clip_slot.clip
            info = self._decoupled_automation_info(clip)
            if not info:
                return

            clip.loop_start = info["note_start"]
            clip.start_marker = min(float(getattr(clip, "start_marker", info["note_start"])), info["note_start"])
            clip.loop_end = info["physical_end"]
            clip.end_marker = info["physical_end"]
            self._remove_decoupled_automation_info_from_name(clip)
            self.send_selected_clip_metadata()
            self.send_selected_clip_notes()
        except Exception as e:
            self._debug_log("Error unfolding decoupled automation clip: {}".format(str(e)))

    def _automation_clear_response(self, control_index, current_value):
        response = "{}|{}|{:.6f}|{}|{}".format(
            control_index,
            0,
            current_value,
            "",
            ""
        )
        self._send_sys_ex_message(response, 0x31)

    def _automation_write_error_response(self, control_index, write_token=""):
        device_param = self._current_connected_parameter_for_control(control_index)
        current_value = self._parameter_normalized_value(device_param)
        clip_slot = self.song().view.highlighted_clip_slot
        clip = clip_slot.clip if clip_slot is not None and clip_slot.has_clip else None
        response_fields = self._automation_response_decoupled_fields(clip, device_param)
        response_fields.extend([str(write_token or ""), "error"])
        response = "{}|{}|{:.6f}|{}|{}|{}".format(
            control_index,
            0,
            current_value,
            "",
            "",
            "|".join(response_fields)
        )
        self._send_sys_ex_message(response, 0x31)

    def _automation_response_decoupled_fields(self, clip, device_param):
        info = self._decoupled_automation_info(clip, device_param)
        if not info:
            return ["0", "0.000000", "0.000000"]
        return [
            "1" if info.get("has_parameter_length") else "0",
            "{:.6f}".format(info.get("automation_length", info.get("note_length", 0.0))),
            "{:.6f}".format(info.get("physical_end", info.get("note_end", 0.0))),
        ]

    def _clear_automation_envelope(self, message):
        try:
            control_index = max(0, min(7, int(message[2]) if len(message) >= 4 else 0))
            device_param = self._current_connected_parameter_for_control(control_index)
            current_value = self._parameter_normalized_value(device_param)
            clip_slot = self.song().view.highlighted_clip_slot
            if clip_slot is None or not clip_slot.has_clip or not device_param or not liveobj_valid(device_param):
                self._automation_clear_response(control_index, current_value)
                return

            clip = clip_slot.clip
            envelope = None
            if hasattr(clip, 'automation_envelope'):
                try:
                    envelope = clip.automation_envelope(device_param)
                except Exception:
                    envelope = None
            if envelope is not None:
                self._clear_clip_automation_envelope(clip, envelope, device_param, current_value)
            self._clear_authored_automation_steps_for_parameter(clip, device_param)
            self._reset_decoupled_automation_length_for_parameter(
                clip,
                device_param,
                send_updates=True
            )
            self._automation_clear_response(control_index, current_value)
            self._refresh_parameter_metadata_on_automation_change()
        except Exception as e:
            self._debug_log("Error clearing automation envelope: {}".format(str(e)))

    def _clear_all_automation_envelopes(self, message):
        try:
            control_index = max(0, min(7, int(message[2]) if len(message) >= 4 else 0))
            device_param = self._current_connected_parameter_for_control(control_index)
            current_value = self._parameter_normalized_value(device_param)
            clip_slot = self.song().view.highlighted_clip_slot
            if clip_slot is None or not clip_slot.has_clip:
                self._automation_clear_response(control_index, current_value)
                return

            clip = clip_slot.clip
            decoupled_info = self._decoupled_automation_info(clip)
            for device_param in self._clip_automation_parameters(clip, decoupled_info):
                envelope = None
                if hasattr(clip, 'automation_envelope'):
                    try:
                        envelope = clip.automation_envelope(device_param)
                    except Exception:
                        envelope = None
                if envelope is None:
                    continue
                self._clear_clip_automation_envelope(clip, envelope, device_param, self._parameter_normalized_value(device_param))
            self._clear_authored_automation_steps_for_clip(clip)

            if decoupled_info:
                note_start = decoupled_info["note_start"]
                note_length = decoupled_info["note_length"]
                folded_info = {
                    "note_start": note_start,
                    "note_length": note_length,
                    "note_end": note_start + note_length,
                    "automation_lengths": {},
                    "automation_length": note_length,
                    "physical_length": note_length,
                    "physical_end": note_start + note_length,
                    "remove_start": note_start,
                }
                self._rewrite_decoupled_note_copies(clip, folded_info)
                self._remove_decoupled_automation_info_from_name(clip)
                clip.loop_start = note_start
                clip.start_marker = min(float(getattr(clip, "start_marker", note_start)), note_start)
                clip.loop_end = note_start + note_length
                clip.end_marker = note_start + note_length
                self.send_selected_clip_metadata()
                self.send_selected_clip_notes()

            self._automation_clear_response(control_index, current_value)
            self._refresh_parameter_metadata_on_automation_change()
        except Exception as e:
            self._debug_log("Error clearing all automation envelopes: {}".format(str(e)))

    def _send_automation_envelope(self, message):
        try:
            payload = bytes(message[2:-1]).decode('ascii', errors='ignore')
            fields = self._split_escaped_sysex_fields(payload, "|")
            if len(fields) < 4:
                return

            control_index = max(0, min(7, int(fields[0])))
            start = float(fields[1])
            step_duration = max(0.0001, float(fields[2]))
            count = max(1, min(self.AUTOMATION_ENVELOPE_MAX_SAMPLES, int(fields[3])))
            device_param = self._current_connected_parameter_for_control(control_index)
            current_value = self._parameter_normalized_value(device_param)

            clip_slot = self.song().view.highlighted_clip_slot
            clip = None
            envelope = None
            if clip_slot is not None and clip_slot.has_clip and device_param and liveobj_valid(device_param):
                clip = clip_slot.clip
                if hasattr(clip, 'automation_envelope'):
                    try:
                        envelope = clip.automation_envelope(device_param)
                    except Exception:
                        envelope = None

            samples = []
            has_envelope = 1 if envelope is not None else 0
            for index in range(count):
                time_value = start + (float(index) * step_duration)
                normalized = current_value
                if envelope is not None:
                    try:
                        raw_value = envelope.value_at_time(time_value)
                        if device_param.max != device_param.min:
                            normalized = (raw_value - device_param.min) / (device_param.max - device_param.min)
                    except Exception:
                        normalized = current_value
                normalized = max(0.0, min(1.0, normalized))
                samples.append((time_value, normalized))

            authored_steps = self._authored_automation_steps(clip, device_param, control_index)
            request_end = start + (float(count - 1) * step_duration)
            decoupled_info = self._decoupled_automation_info(clip, device_param)
            if authored_steps is not None and decoupled_info is not None:
                authored_steps = self._normalize_decoupled_logical_automation_steps(decoupled_info, authored_steps)
                self._store_authored_automation_steps(clip, device_param, control_index, authored_steps)
            authored_render_steps = None
            if authored_steps is not None and decoupled_info is not None:
                authored_render_steps = self._expanded_decoupled_automation_steps(
                    decoupled_info,
                    authored_steps,
                    step_duration
                )
            if authored_steps is not None and decoupled_info is None and not self._authored_automation_steps_match_samples(authored_steps, samples):
                points = self._compress_automation_samples(samples)
                replacement_steps = []
                for sample in points:
                    time_value, normalized = sample
                    if time_value >= start - 0.000001 and time_value <= request_end + 0.000001:
                        replacement_steps.append((time_value, step_duration, normalized, 0.0, 0, 0))
                authored_steps = self._automation_sorted_steps(
                    list(step for step in authored_steps if step[0] < start - 0.000001 or step[0] > request_end + 0.000001)
                    + replacement_steps
                )
                self._store_authored_automation_steps(clip, device_param, control_index, authored_steps)
            points = [] if authored_steps is not None else self._compress_automation_samples(samples)
            entries = []
            if authored_steps is not None:
                for step in authored_steps:
                    entries.append(self._automation_step_entry(step))
            else:
                for sample in points:
                    time_value, normalized = sample
                    if decoupled_info is not None and abs(time_value - request_end) <= 0.000001:
                        continue
                    entries.append("{:.6f}:{:.6f}:{:.6f}:{:.6f}".format(time_value, step_duration, normalized, 0.0))
            render_entries = []
            for sample in samples:
                time_value, normalized = sample
                if authored_render_steps:
                    normalized = self._automation_value_from_steps(time_value, authored_render_steps)
                render_entries.append("{:.6f}:{:.6f}:{:.6f}:{:.6f}".format(time_value, step_duration, normalized, 0.0))

            response = "{}|{}|{:.6f}|{}|{}|{}".format(
                control_index,
                has_envelope,
                current_value,
                ",".join(entries),
                ",".join(render_entries),
                "|".join(self._automation_response_decoupled_fields(clip, device_param))
            )
            self._send_sys_ex_message(response, 0x31)
        except Exception as e:
            self._debug_log("Error sending automation envelope: {}".format(str(e)))

    def _set_automation_envelope(self, message):
        try:
            payload = bytes(message[2:-1]).decode('ascii', errors='ignore')
            fields = self._split_escaped_sysex_fields(payload, "|")
            if len(fields) < 5:
                return

            control_index = max(0, min(7, int(fields[0])))
            page_start = float(fields[1])
            page_end = max(page_start, float(fields[2]))
            sample_duration = max(0.0001, float(fields[3]))
            step_entries = self._split_escaped_sysex_fields(fields[4], ",") if fields[4] else []
            write_token = fields[7] if len(fields) >= 8 else ""
            response_token_fields = [write_token] if write_token else []

            if len(fields) >= 7:
                try:
                    expected_step_count = int(fields[5])
                    expected_checksum = int(fields[6], 16)
                    checksum_payload = "|".join(fields[:5])
                    actual_checksum = self._automation_payload_checksum(checksum_payload)
                    if expected_step_count != len(step_entries) or expected_checksum != actual_checksum:
                        self._debug_log(
                            "Rejected corrupted automation envelope payload: expected {} / {:08X}, got {} / {:08X}".format(
                                expected_step_count,
                                expected_checksum,
                                len(step_entries),
                                actual_checksum
                            )
                        )
                        self._automation_write_error_response(control_index, write_token)
                        return
                except Exception:
                    self._debug_log("Rejected automation envelope payload with invalid checksum fields")
                    self._automation_write_error_response(control_index, write_token)
                    return

            device_param = self._current_connected_parameter_for_control(control_index)
            clip_slot = self.song().view.highlighted_clip_slot
            if (clip_slot is None or not clip_slot.has_clip
                    or not self._parameter_is_automatable(device_param)):
                self._automation_write_error_response(control_index, write_token)
                return

            automation_was_enabled = self._parameter_automation_is_enabled(device_param)
            clip = clip_slot.clip
            envelope = None
            if hasattr(clip, 'automation_envelope'):
                try:
                    envelope = clip.automation_envelope(device_param)
                except Exception:
                    envelope = None
            automation_should_re_enable = automation_was_enabled or envelope is not None
            previous_authored_steps = self._authored_automation_steps(clip, device_param, control_index)

            current_normalized = self._parameter_normalized_value(device_param)
            try:
                clip_end = max(
                    page_end,
                    float(getattr(clip, 'loop_end', 0.0)),
                    float(getattr(clip, 'end_marker', 0.0)),
                    float(getattr(clip, 'length', 0.0))
                )
            except Exception:
                clip_end = page_end

            steps = []
            for entry in step_entries:
                components = entry.split(":")
                if len(components) < 3:
                    continue
                try:
                    time_value = max(0.0, min(clip_end, float(components[0])))
                    duration = max(0.0001, float(components[1]))
                    normalized = max(0.0, min(1.0, float(components[2])))
                    curve = max(-1.0, min(1.0, float(components[3]) if len(components) >= 4 else 0.0))
                    step_id = max(0, int(components[4])) if len(components) >= 5 else 0
                    step_order = max(0, int(components[5])) if len(components) >= 6 else step_id
                    steps.append((time_value, duration, normalized, curve, step_id, step_order))
                except Exception:
                    pass

            logical_steps = self._automation_sorted_steps(steps)
            steps = list(logical_steps)

            decoupled_info = self._decoupled_automation_info(clip, device_param)
            if decoupled_info:
                logical_steps = self._merge_decoupled_automation_span(
                    previous_authored_steps,
                    logical_steps,
                    page_start,
                    page_end
                )
                logical_steps = self._normalize_decoupled_logical_automation_steps(decoupled_info, logical_steps)
                steps = list(logical_steps)
            if decoupled_info and steps:
                steps = list(self._expanded_decoupled_automation_steps(decoupled_info, steps, sample_duration))
                clip_end = decoupled_info["physical_end"]
            response_source_steps = tuple(steps)

            def edited_span_value(time_value):
                if not steps:
                    return current_normalized

                first_step = steps[0]
                if time_value <= first_step[0]:
                    return first_step[2]

                previous_step = first_step
                for next_step in steps[1:]:
                    if abs(next_step[0] - previous_step[0]) <= 0.000001:
                        if time_value >= next_step[0]:
                            previous_step = next_step
                        continue

                    if time_value <= next_step[0]:
                        progress = max(0.0, min(1.0, (time_value - previous_step[0]) / (next_step[0] - previous_step[0])))
                        return curve_segment_value(previous_step[2], next_step[2], progress, previous_step[3])

                    previous_step = next_step

                return previous_step[2]

            def curve_segment_value(start_value, end_value, progress, curve):
                progress = max(0.0, min(1.0, progress))
                curve = max(-1.0, min(1.0, curve))
                if abs(curve) <= 0.000001:
                    return max(0.0, min(1.0, start_value + ((end_value - start_value) * progress)))

                exponent = 1.0 + (abs(curve) * 14.0)
                rises = end_value >= start_value
                bows_up = curve > 0.0
                if bows_up == rises:
                    shaped_progress = 1.0 - pow(1.0 - progress, exponent)
                else:
                    shaped_progress = pow(progress, exponent)

                blended_progress = progress + ((shaped_progress - progress) * abs(curve))
                return max(0.0, min(1.0, start_value + ((end_value - start_value) * blended_progress)))

            all_steps = []

            def append_target_step(time_value, duration, normalized, force=False):
                if time_value < -0.000001 or time_value > clip_end + 0.000001:
                    return

                time_value = max(0.0, min(clip_end, time_value))
                normalized = max(0.0, min(1.0, normalized))
                if all_steps and not force:
                    previous_time, _, previous_value, _ = all_steps[-1]
                    if abs(previous_time - time_value) <= 0.000001 and abs(previous_value - normalized) <= self.AUTOMATION_ENVELOPE_LINEAR_EPSILON:
                        return

                all_steps.append((time_value, max(0.0001, duration), normalized, bool(force)))

            def append_boundary_hold_steps():
                if not steps:
                    return

                guard_duration = 0.0001
                boundary_start = decoupled_info["note_start"] if decoupled_info else 0.0
                first_step = steps[0]
                if first_step[0] > boundary_start + guard_duration:
                    append_target_step(boundary_start, max(guard_duration, first_step[0] - boundary_start), first_step[2], force=True)

                last_step = steps[-1]
                if clip_end > last_step[0] + guard_duration:
                    append_target_step(clip_end - guard_duration, guard_duration, last_step[2], force=True)

            def append_edited_span():
                if not steps:
                    return

                if len(steps) == 1:
                    step = steps[0]
                    append_target_step(step[0], step[1], step[2])
                    return

                for index in range(len(steps) - 1):
                    start_step = steps[index]
                    next_step = steps[index + 1]
                    append_target_step(start_step[0], start_step[1], start_step[2])

                    time_value = start_step[0] + sample_duration
                    while time_value < next_step[0] - 0.000001:
                        append_target_step(time_value, sample_duration, edited_span_value(time_value))
                        time_value += sample_duration

                last_step = steps[-1]
                append_target_step(last_step[0], last_step[1], last_step[2])

            append_edited_span()
            append_boundary_hold_steps()

            if not all_steps:
                if envelope is None and hasattr(clip, 'create_automation_envelope'):
                    try:
                        envelope = clip.create_automation_envelope(device_param)
                    except Exception:
                        envelope = None
                if envelope is not None:
                    try:
                        raw_value = self._parameter_target_value_from_normalized(device_param, current_normalized)
                        boundary_start = decoupled_info["note_start"] if decoupled_info else 0.0
                        envelope.insert_step(boundary_start, max(0.0001, clip_end - boundary_start), raw_value)
                    except Exception:
                        pass
                self._clear_authored_automation_steps(clip, device_param, control_index)
                response = "{}|{}|{:.6f}|{}|{}|{}".format(
                    control_index,
                    0,
                    current_normalized,
                    "",
                    "",
                    "|".join(self._automation_response_decoupled_fields(clip, device_param) + response_token_fields)
                )
                self._send_sys_ex_message(response, 0x31)
                self._refresh_parameter_metadata_on_automation_change()
                return

            if envelope is None and hasattr(clip, 'create_automation_envelope'):
                try:
                    envelope = clip.create_automation_envelope(device_param)
                    if envelope is not None:
                        automation_should_re_enable = True
                except Exception:
                    envelope = None

            if envelope is None:
                self._automation_write_error_response(control_index, write_token)
                self._refresh_parameter_metadata_on_automation_change()
                return

            all_steps.sort(key=lambda item: item[0])
            coalesced_steps = []
            for step in all_steps:
                if not coalesced_steps:
                    coalesced_steps.append(step)
                    continue

                previous_time, _, previous_value, previous_force = coalesced_steps[-1]
                time_value, _, normalized, force = step
                if abs(previous_time - time_value) <= 0.000001 and abs(previous_value - normalized) <= self.AUTOMATION_ENVELOPE_LINEAR_EPSILON:
                    if force and not previous_force:
                        coalesced_steps[-1] = step
                    continue
                if not force and not previous_force and abs(previous_time - time_value) > 0.000001 and abs(previous_value - normalized) <= self.AUTOMATION_ENVELOPE_LINEAR_EPSILON:
                    continue

                coalesced_steps.append(step)

            all_steps = coalesced_steps
            minimum_duration = 0.0001
            if decoupled_info and all_steps:
                self._neutralize_decoupled_automation_points(
                    envelope,
                    device_param,
                    decoupled_info,
                    previous_authored_steps,
                    all_steps[0][2],
                    sample_duration
                )
            elif all_steps:
                replace_start = max(0.0, min(clip_end, page_start))
                replace_end = max(replace_start + minimum_duration, min(clip_end, page_end))
                self._neutralize_automation_span(
                    envelope,
                    device_param,
                    replace_start,
                    replace_end,
                    edited_span_value(replace_start)
                )

            previous_insert_time = None
            insert_failed = False
            for index, step in enumerate(all_steps):
                time_value, duration, normalized, _ = step
                raw_value = self._parameter_target_value_from_normalized(device_param, normalized)
                if previous_insert_time is not None and time_value <= previous_insert_time:
                    time_value = previous_insert_time + minimum_duration

                next_time = all_steps[index + 1][0] if index + 1 < len(all_steps) and all_steps[index + 1][0] > time_value else None

                if next_time is not None:
                    duration = max(minimum_duration, next_time - time_value)
                else:
                    duration = max(minimum_duration, clip_end - time_value) if clip_end > time_value else max(minimum_duration, duration)

                try:
                    envelope.insert_step(time_value, duration, raw_value)
                    previous_insert_time = time_value
                except Exception:
                    insert_failed = True

            if insert_failed or previous_insert_time is None:
                self._debug_log(
                    "Automation envelope write did not insert every requested step for control {}".format(
                        control_index
                    )
                )
                self._automation_write_error_response(control_index, write_token)
                self._refresh_parameter_metadata_on_automation_change()
                return

            self._store_authored_automation_steps(clip, device_param, control_index, logical_steps)

            response_samples = []
            count = max(2, min(self.AUTOMATION_ENVELOPE_MAX_SAMPLES, int((page_end - page_start) / sample_duration) + 1))
            for index in range(count):
                time_value = page_start + (float(index) * sample_duration)
                normalized = current_normalized
                if response_source_steps:
                    normalized = self._automation_value_from_steps(time_value, response_source_steps)
                else:
                    try:
                        raw_value = envelope.value_at_time(time_value)
                        if device_param.max != device_param.min:
                            normalized = (raw_value - device_param.min) / (device_param.max - device_param.min)
                    except Exception:
                        normalized = current_normalized
                response_samples.append((time_value, max(0.0, min(1.0, normalized))))

            point_entries = []
            for step in logical_steps:
                point_entries.append(self._automation_step_entry(step))

            render_entries = []
            for sample in response_samples:
                time_value, normalized = sample
                render_entries.append("{:.6f}:{:.6f}:{:.6f}:{:.6f}".format(time_value, sample_duration, normalized, 0.0))

            response = "{}|{}|{:.6f}|{}|{}|{}".format(
                control_index,
                1,
                current_normalized,
                ",".join(point_entries),
                ",".join(render_entries),
                "|".join(self._automation_response_decoupled_fields(clip, device_param) + response_token_fields)
            )
            self._send_sys_ex_message(response, 0x31)
            self._re_enable_after_automation_write(device_param, automation_should_re_enable)
            self._refresh_parameter_metadata_on_automation_change()
        except Exception as e:
            self._debug_log("Error setting automation envelope: {}".format(str(e)))

    def _parameter_automation_is_enabled(self, device_param):
        try:
            return bool(device_param and liveobj_valid(device_param) and hasattr(device_param, 'automation_state') and int(device_param.automation_state) == 1)
        except Exception:
            return False

    def _re_enable_after_automation_write(self, device_param, should_re_enable=True):
        try:
            if not should_re_enable or not device_param or not liveobj_valid(device_param):
                return

            self._re_enable_parameter_automation(device_param)
            self.schedule_message(1, lambda: self._re_enable_written_automation_if_needed(device_param))
            self.schedule_message(3, lambda: self._re_enable_written_automation_if_needed(device_param))
            self._send_re_enable_automation_enabled(force=True)
        except Exception as e:
            self._debug_log("Error re-enabling written automation: {}".format(str(e)))

    def _re_enable_parameter_automation(self, device_param):
        if hasattr(device_param, 're_enable_automation'):
            device_param.re_enable_automation()
        if hasattr(self.song(), 're_enable_automation'):
            self.song().re_enable_automation()

    def _re_enable_written_automation_if_needed(self, device_param):
        try:
            if device_param and liveobj_valid(device_param) and not self._parameter_automation_is_enabled(device_param):
                self._re_enable_parameter_automation(device_param)
                self._send_re_enable_automation_enabled(force=True)
        except Exception as e:
            self._debug_log("Error retrying written automation re-enable: {}".format(str(e)))

    def _authored_automation_steps_match_samples(self, steps, samples):
        if not steps or not samples:
            return False

        close_threshold = 0.0125
        maximum_difference_threshold = 0.02
        required_close_ratio = 0.995
        max_difference = 0.0
        close_samples = 0
        for time_value, normalized in samples:
            difference = abs(self._automation_value_from_steps(time_value, steps) - normalized)
            max_difference = max(max_difference, difference)
            if difference <= close_threshold:
                close_samples += 1

        close_ratio = float(close_samples) / float(len(samples))
        return close_ratio >= required_close_ratio and max_difference <= maximum_difference_threshold

    def _automation_value_from_steps(self, time_value, steps):
        if not steps:
            return 0.0

        sorted_steps = self._automation_sorted_steps(steps)
        first_step = sorted_steps[0]
        if time_value <= first_step[0]:
            return max(0.0, min(1.0, first_step[2]))

        previous_step = first_step
        for next_step in sorted_steps[1:]:
            if abs(next_step[0] - previous_step[0]) <= 0.000001:
                if time_value >= next_step[0]:
                    previous_step = next_step
                continue

            if time_value <= next_step[0]:
                progress = max(0.0, min(1.0, (time_value - previous_step[0]) / (next_step[0] - previous_step[0])))
                return self._automation_curve_segment_value(previous_step[2], next_step[2], progress, previous_step[3] if len(previous_step) >= 4 else 0.0)

            previous_step = next_step

        return max(0.0, min(1.0, previous_step[2]))

    def _automation_curve_segment_value(self, start_value, end_value, progress, curve):
        progress = max(0.0, min(1.0, progress))
        curve = max(-1.0, min(1.0, curve))
        if abs(curve) <= 0.000001:
            return max(0.0, min(1.0, start_value + ((end_value - start_value) * progress)))

        exponent = 1.0 + (abs(curve) * 14.0)
        rises = end_value >= start_value
        bows_up = curve > 0.0
        if bows_up == rises:
            shaped_progress = 1.0 - pow(1.0 - progress, exponent)
        else:
            shaped_progress = pow(progress, exponent)

        blended_progress = progress + ((shaped_progress - progress) * abs(curve))
        return max(0.0, min(1.0, start_value + ((end_value - start_value) * blended_progress)))

    def _compress_automation_samples(self, samples):
        if len(samples) <= 2:
            return samples

        result = []
        segment = [samples[0]]
        for index in range(1, len(samples)):
            previous_sample = samples[index - 1]
            current_sample = samples[index]
            previous_flat = index >= 2 and abs(previous_sample[1] - samples[index - 2][1]) <= self.AUTOMATION_ENVELOPE_LINEAR_EPSILON
            next_flat = index + 1 < len(samples) and abs(current_sample[1] - samples[index + 1][1]) <= self.AUTOMATION_ENVELOPE_LINEAR_EPSILON
            is_jump = (
                abs(current_sample[1] - previous_sample[1]) >= self.AUTOMATION_ENVELOPE_JUMP_THRESHOLD
                and (previous_flat or next_flat)
            )

            if is_jump:
                self._append_automation_samples(result, self._simplify_automation_segment(segment))
                self._append_automation_sample(result, (current_sample[0], previous_sample[1]))
                self._append_automation_sample(result, current_sample)
                segment = [current_sample]
            else:
                segment.append(current_sample)

        self._append_automation_samples(result, self._simplify_automation_segment(segment))
        return result

    def _simplify_automation_segment(self, samples):
        if len(samples) <= 2:
            return samples

        first_time, first_value = samples[0]
        last_time, last_value = samples[-1]
        time_span = last_time - first_time
        if abs(time_span) <= 0.000001:
            return [samples[0], samples[-1]]

        max_deviation = 0.0
        split_index = 0
        for index in range(1, len(samples) - 1):
            time_value, normalized = samples[index]
            progress = (time_value - first_time) / time_span
            linear_value = first_value + ((last_value - first_value) * progress)
            deviation = abs(normalized - linear_value)
            if deviation > max_deviation:
                max_deviation = deviation
                split_index = index

        if max_deviation <= self.AUTOMATION_ENVELOPE_LINEAR_EPSILON:
            return [samples[0], samples[-1]]

        left = self._simplify_automation_segment(samples[:split_index + 1])
        right = self._simplify_automation_segment(samples[split_index:])
        return left[:-1] + right

    def _append_automation_samples(self, result, samples):
        for sample in samples:
            self._append_automation_sample(result, sample)

    def _append_automation_sample(self, result, sample):
        if not result:
            result.append(sample)
            return

        previous_time, previous_value = result[-1]
        current_time, current_value = sample
        if abs(previous_time - current_time) <= 0.000001 and abs(previous_value - current_value) <= self.AUTOMATION_ENVELOPE_LINEAR_EPSILON:
            return

        result.append(sample)

    def decode_sys_ex_scale_root(self, message):
        scale_name_bytes = message[2:-2]
        scale_name_bytes = bytes(message[2:-2])
        scale_name = self._unescape_sysex_string(scale_name_bytes.decode('utf-8'))
        root_note_index = message[-2]
        return scale_name, root_note_index

    def extract_values_from_sysex_message(self, message):
        # Extract the values from the SysEx message based on the message format
        # Replace this with your own logic to extract the desired values
        # For example, if your message is [0xF0, 0x09, value1, value2, ..., 0xF7]
        # you can extract values starting from index 2: values = message[2:-1]
        values = message[2:-1]
        return values

    def _fire_clip(self, fire, track_index, clip_index):
        track = self.song().tracks[track_index]
        clip_slot = track.clip_slots[clip_index]
        if fire == 1:
            if clip_slot.is_playing:
                clip_slot.stop()
                keys_to_clear = [
                    key for key, active in self._active_follow_actions.items()
                    if active.get("target_kind") == "clip"
                    and active.get("track_index") == track_index
                    and active.get("scene_index") == clip_index
                ]
                for key in keys_to_clear:
                    del self._active_follow_actions[key]
                if keys_to_clear:
                    self._send_follow_action_state()
            else:
                clip_slot.set_fire_button_state(1)
                self._activate_follow_action_for_clip(track_index, clip_index, clip_slot)
        else:
            clip_slot.set_fire_button_state(1)
            self._activate_follow_action_for_clip(track_index, clip_index, clip_slot)

    def _stop_track_clips(self, track_index):
        try:
            track = self.song().tracks[track_index]
        except Exception:
            return

        track.stop_all_clips()
        keys_to_clear = [
            key for key, active in self._active_follow_actions.items()
            if active.get("target_kind") == "clip"
            and active.get("track_index") == track_index
        ]
        for key in keys_to_clear:
            del self._active_follow_actions[key]
        if keys_to_clear:
            self._send_follow_action_state()

    def _delete_clip(self, track_index, clip_index):
        track = self.song().tracks[track_index]
        clip_slot = track.clip_slots[clip_index]
        self._remove_clip_follow_action_rule(track_index, clip_index)
        clip_slot.delete_clip()
        self._send_follow_action_state()

    def _duplicate_loop(self, track_index, clip_index):
        track = self.song().tracks[track_index]
        clip_slot = track.clip_slots[clip_index]
        if not clip_slot.has_clip:
            return

        clip = clip_slot.clip
        decoupled_info = self._decoupled_automation_info(clip)

        self._begin_selected_clip_update_batch()
        undo_step_started = self._begin_undo_step()

        try:
            if decoupled_info:
                self._double_decoupled_loop(clip, decoupled_info)
            else:
                clip.duplicate_loop()

        except Exception as e:
            self._debug_log("Error in _duplicate_loop: {}".format(str(e)))
            raise
        finally:
            self._end_undo_step(undo_step_started)
            self._end_selected_clip_update_batch()

        if decoupled_info:
            self.send_selected_clip_metadata()
            self.send_selected_clip_notes()

    def _copy_paste_clip(self, from_track, from_clip, to_track, to_clip):
        tracks = self.song().tracks

        copy_track = tracks[from_track]
        copy_clip_slot = copy_track.clip_slots[from_clip]

        paste_track = tracks[to_track]
        paste_clip_slot = paste_track.clip_slots[to_clip]

        copy_clip_slot.duplicate_clip_to(paste_clip_slot)
        self._copy_clip_follow_action_rule(from_track, from_clip, to_track, to_clip)
        self._send_follow_action_state()
        
        # set up new clip listeners
        try:
            self._register_clip_listeners()
        except Exception as e:
            # Listener bookkeeping must never abort a completed clip copy.
            self._debug_log("Error refreshing clip listeners after copy: {}".format(str(e)))

    def _append_and_remove_clip(self, from_track, from_clip, to_track, to_clip):
        """
        Appends notes from one MIDI clip to the end of another, then removes the source clip.
        
        Args:
            from_track: Index of the track containing the clip to append
            from_clip: Index of the clip slot to append from
            to_track: Index of the track containing the destination clip
            to_clip: Index of the clip slot to append to
        """
        tracks = self.song().tracks
        source_track = tracks[from_track]
        source_clip_slot = source_track.clip_slots[from_clip]
        dest_track = tracks[to_track]
        dest_clip_slot = dest_track.clip_slots[to_clip]
        
        # Check if both clips exist and are MIDI clips
        if not source_clip_slot.has_clip or not dest_clip_slot.has_clip:
            return
        
        source_clip = source_clip_slot.clip
        dest_clip = dest_clip_slot.clip
        
        if not source_clip.is_midi_clip or not dest_clip.is_midi_clip:
            return

        _, dest_follow_rule = self._find_clip_follow_action_rule(to_track, to_clip)
        
        # Get source clip looped region only
        source_loop_start = source_clip.loop_start
        source_loop_end = source_clip.loop_end
        source_looped_length = source_loop_end - source_loop_start
        source_notes = source_clip.get_notes_extended(0, 128, source_loop_start, source_looped_length)
        
        # Get destination clip loop end position
        dest_clip_loop_end = dest_clip.loop_end
        
        # Remove any notes in destination clip that are after loop_end
        # Get ALL notes in the clip (use clip length to ensure we capture everything)
        dest_clip_full_length = max(dest_clip.loop_end, dest_clip.end_marker, dest_clip.length, 110)
        dest_clip_notes = dest_clip.get_notes_extended(0, 128, 0, dest_clip_full_length)
        
        # Collect note IDs to delete (notes at or after loop_end)
        note_ids_to_delete = []
        for note in dest_clip_notes:
            if note.start_time >= dest_clip_loop_end:
                note_ids_to_delete.append(note.note_id)
        
        # Delete all notes in one call using note IDs
        if note_ids_to_delete:
            dest_clip.remove_notes_by_id(tuple(note_ids_to_delete))
        
        # Calculate offset for appending notes (append after destination's loop_end)
        time_offset = dest_clip_loop_end - source_loop_start
        
        # Offset source notes to append at the end of destination
        if source_notes:
            new_notes = []
            for note in source_notes:
                pitch = int(note.pitch)
                start_time = note.start_time + time_offset
                duration = note.duration
                velocity = int(note.velocity)
                mute = note.mute
                probability = note.probability
                
                note_spec = MidiNoteSpecification(
                    pitch=pitch,
                    start_time=start_time,
                    duration=duration,
                    velocity=velocity,
                    mute=mute,
                    probability=probability
                )
                new_notes.append(note_spec)
            
            # Add offset notes to destination clip
            dest_clip.add_new_notes(tuple(new_notes))
            
            # Update destination clip loop_end and end_marker to include new notes
            new_end = dest_clip_loop_end + source_looped_length
            dest_clip.loop_end = new_end
            dest_clip.end_marker = new_end
        
        # Remove the source clip
        if not dest_follow_rule:
            self._copy_clip_follow_action_rule(from_track, from_clip, to_track, to_clip, remove_source=True)
        else:
            self._remove_clip_follow_action_rule(from_track, from_clip)
        source_clip_slot.delete_clip()
        self._send_follow_action_state()

    def _set_scale_root_note(self, scale, root):
        song = self.song()
        song.scale_name = scale
        song.root_note = root

        if scale.lower() == 'chromatic':
            song.scale_mode = False
        else:
            song.scale_mode = True

        # Live's root/scale listeners are not guaranteed to fire in the same
        # callback turn when both values arrive from Tap. Rebuild explicitly
        # after the final pair is applied so Flin-owned notes always follow.
        self._rebuild_visible_melodic_flin()

    def _fire_scene(self, value):
        scenes = self.song().scenes
        if value < len(scenes):
            scene = scenes[value]
            scene.fire()
            self._handled_follow_action_launches.discard(self._follow_action_key("scene", None, value))
            self._activate_follow_action_for_scene(value)

    def _select_clip_scene(self, value):
        scenes = self.song().scenes
        if value < len(scenes):
            self.song().view.selected_scene = scenes[value]
        track = self.song().view.selected_track
        if value < len(track.clip_slots):
            self.song().view.highlighted_clip_slot = track.clip_slots[value]
        self._send_selected_clip_slot(value)

    def _delete_scene(self, value):
        self.song().delete_scene(value)
        self._shift_follow_actions_after_scene_delete(value)
        self._send_follow_action_state()

    def _on_selected_scene_changed(self):
        selected_scene = self.song().view.selected_scene
        scenes_list = self.song().scenes
        new_index = self._find_track_index(selected_scene, scenes_list)
        self._send_selected_clip_slot(new_index)
        self._send_audio_clip_state(force=True)
        self._check_clip_playing_status(force=True)
        if self.seq_status:
            self.start_step_seq()

    def _send_selected_clip_slot(self, clip_index):
        self._send_sys_ex_message(str(clip_index), 0x10)

    def _is_instrument_device(self, device):
        try:
            if hasattr(device, 'type') and device.type == Live.Device.DeviceType.instrument:
                return True
        except Exception:
            pass

        try:
            class_name = str(device.class_name) if hasattr(device, 'class_name') else ''
            return class_name in ('InstrumentGroupDevice', 'DrumGroupDevice')
        except Exception:
            return False

    def _valid_chains(self, rack):
        if not liveobj_valid(rack) or not hasattr(rack, 'chains'):
            return []
        return [chain for chain in rack.chains if liveobj_valid(chain) and hasattr(chain, 'devices')]

    def _find_device_location(self, container, target_device, rack_context=None):
        if not liveobj_valid(container) or not hasattr(container, 'devices'):
            return None

        for index, device in enumerate(container.devices):
            if device == target_device:
                return {
                    'container': container,
                    'index': index,
                    'rack_context': rack_context
                }

            for chain in self._valid_chains(device):
                result = self._find_device_location(chain, target_device, {
                    'rack': device,
                    'rack_container': container,
                    'rack_index': index,
                    'chain': chain
                })
                if result:
                    return result

        return None

    def _rack_device_at_navigation_index(self, device_index):
        selected_track = self.song().view.selected_track
        if not selected_track or not hasattr(selected_track, 'devices'):
            return None
        
        all_devices = self._get_all_nested_devices(selected_track.devices)[0]
        live_index = self._app_device_index_to_live_index(device_index)
        if live_index < 0 or live_index >= len(all_devices):
            return None
        
        device = all_devices[live_index]
        if not isinstance(device, Live.RackDevice.RackDevice):
            return None
        return device

    def _handle_rack_snapshot_command(self, message):
        device_index = message[2]
        action = message[3]
        device = self._rack_device_at_navigation_index(device_index)
        if not liveobj_valid(device):
            return
        if action != 4:
            self._cancel_smooth_macro_randomize()
        
        try:
            if action == 0:
                previous_variation_count = self._rack_variation_count(device)
                device.store_variation()
                self._select_newly_stored_variation(device, previous_variation_count)
                self._schedule_rack_snapshot_state_refresh()
            elif action == 1:
                device.recall_last_used_variation()
            elif action == 2:
                self._randomize_rack_macros(device)
            elif action == 3 and len(message) >= 5:
                variation_index = message[4]
                if hasattr(device, 'selected_variation_index'):
                    device.selected_variation_index = variation_index
                device.recall_selected_variation()
            elif action == 4 and len(message) >= 5:
                duration = max(1.0, float(message[4]))
                self._randomize_rack_macros_smoothly(device, duration)
                return
        except Exception as e:
            self._debug_log("Rack snapshot command failed: {}".format(str(e)))
        
        self._refresh_after_rack_snapshot_action(device)

    def _rack_variation_count(self, device):
        if not liveobj_valid(device) or not hasattr(device, 'variation_count'):
            return 0
        try:
            return int(device.variation_count)
        except Exception:
            return 0

    def _select_newly_stored_variation(self, device, previous_variation_count):
        if not liveobj_valid(device):
            return
        if not hasattr(device, 'variation_count') or not hasattr(device, 'selected_variation_index'):
            return
        
        try:
            variation_count = int(device.variation_count)
            if variation_count > previous_variation_count:
                device.selected_variation_index = variation_count - 1
        except Exception as e:
            self._debug_log("Selecting stored variation failed: {}".format(str(e)))

    def _schedule_rack_snapshot_state_refresh(self):
        self.schedule_message(1, self._send_rack_snapshot_state)
        self.schedule_message(3, self._send_rack_snapshot_state)

    def _is_macro_randomize_protected_parameter(self, parameter):
        try:
            return str(parameter.name).strip().lower() == "volume"
        except Exception:
            return False

    def _macro_parameters_for_rack(self, device, protected_only=False):
        if not liveobj_valid(device) or not hasattr(device, 'parameters'):
            return []
        
        try:
            mapped_flags = list(device.macros_mapped) if hasattr(device, 'macros_mapped') else []
        except Exception:
            mapped_flags = []
        
        try:
            parameters = list(device.parameters)
        except Exception:
            parameters = []
        
        macro_parameters = []
        for macro_index, is_mapped in enumerate(mapped_flags):
            parameter_index = macro_index + 1
            if not is_mapped or parameter_index >= len(parameters):
                continue
            
            parameter = parameters[parameter_index]
            if not liveobj_valid(parameter):
                continue
            if hasattr(parameter, 'is_enabled') and not parameter.is_enabled:
                continue
            if getattr(parameter, 'max', 0) == getattr(parameter, 'min', 0):
                continue
            is_protected = self._is_macro_randomize_protected_parameter(parameter)
            if protected_only != is_protected:
                continue
            
            macro_parameters.append(parameter)
        
        return macro_parameters

    def _randomize_rack_macros(self, device):
        protected_values = [
            (parameter, parameter.value)
            for parameter in self._macro_parameters_for_rack(device, protected_only=True)
        ]
        device.randomize_macros()
        for parameter, value in protected_values:
            if not liveobj_valid(parameter):
                continue
            try:
                parameter.value = max(parameter.min, min(parameter.max, value))
            except Exception:
                pass

    def _randomize_rack_macros_smoothly(self, device, duration):
        parameters = self._macro_parameters_for_rack(device)
        if not parameters:
            self._refresh_after_rack_snapshot_action(device)
            return
        
        self._cancel_smooth_macro_randomize()
        
        starts = [parameter.value for parameter in parameters]
        try:
            self._randomize_rack_macros(device)
        except Exception as e:
            self._debug_log("Smooth macro randomize target failed: {}".format(str(e)))
            return
        
        targets = [parameter.value for parameter in parameters]
        for parameter, start in zip(parameters, starts):
            parameter.value = start
            if hasattr(parameter, 'begin_gesture'):
                try:
                    parameter.begin_gesture()
                except Exception:
                    pass

        self._smooth_macro_randomize_token += 1
        token = self._smooth_macro_randomize_token
        steps = max(1, int(duration * 10))
        self._smooth_macro_randomize_state = {
            'token': token,
            'device': device,
            'parameters': parameters,
            'starts': starts,
            'targets': targets,
            'step': 0,
            'steps': steps
        }
        self._schedule_smooth_macro_randomize_step(token)

    def _cancel_smooth_macro_randomize(self):
        self._smooth_macro_randomize_token += 1
        state = getattr(self, '_smooth_macro_randomize_state', None)
        parameters = state.get('parameters', []) if state else []
        for parameter in parameters:
            if hasattr(parameter, 'end_gesture'):
                try:
                    parameter.end_gesture()
                except Exception:
                    pass
        self._smooth_macro_randomize_state = None

    def _remove_parameter_from_smooth_macro_randomize(self, parameter):
        if not liveobj_valid(parameter):
            return
        
        state = getattr(self, '_smooth_macro_randomize_state', None)
        if not state:
            return
        
        parameters = state.get('parameters', [])
        if not any(parameter == smooth_parameter for smooth_parameter in parameters):
            return
        
        zipped_values = [
            (smooth_parameter, start, target)
            for smooth_parameter, start, target in zip(
                state.get('parameters', []),
                state.get('starts', []),
                state.get('targets', [])
            )
            if smooth_parameter != parameter
        ]
        
        if hasattr(parameter, 'end_gesture'):
            try:
                parameter.end_gesture()
            except Exception:
                pass
        
        if not zipped_values:
            self._smooth_macro_randomize_token += 1
            self._smooth_macro_randomize_state = None
            return
        
        state['parameters'] = [item[0] for item in zipped_values]
        state['starts'] = [item[1] for item in zipped_values]
        state['targets'] = [item[2] for item in zipped_values]

    def _schedule_smooth_macro_randomize_step(self, token):
        self.schedule_message(1, lambda: self._smooth_macro_randomize_step(token))

    def _smooth_macro_randomize_step(self, token):
        state = getattr(self, '_smooth_macro_randomize_state', None)
        if not state or token != self._smooth_macro_randomize_token or token != state.get('token'):
            return
        
        state['step'] += 1
        progress = min(1.0, float(state['step']) / float(state['steps']))
        eased_progress = 1.0 - pow(1.0 - progress, 3)
        
        try:
            for parameter, start, target in zip(state['parameters'], state['starts'], state['targets']):
                if not liveobj_valid(parameter):
                    continue
                value = start + ((target - start) * eased_progress)
                parameter.value = max(parameter.min, min(parameter.max, value))
        except Exception as e:
            self._debug_log("Smooth macro randomize step failed: {}".format(str(e)))
            self._cancel_smooth_macro_randomize()
            return
        
        if progress < 1.0:
            self._schedule_smooth_macro_randomize_step(token)
            return
        
        for parameter in state['parameters']:
            if hasattr(parameter, 'end_gesture'):
                try:
                    parameter.end_gesture()
                except Exception:
                    pass
        device = state.get('device')
        self._smooth_macro_randomize_state = None
        self._refresh_after_rack_snapshot_action(device)

    def _refresh_after_rack_snapshot_action(self, device):
        selected_track = self.song().view.selected_track
        selected_device = selected_track.view.selected_device if selected_track else None
        if selected_device == device:
            self._on_device_changed(False)
        self._send_rack_snapshot_state()

    def _move_device_after_device(self, source_device, target_device):
        if not liveobj_valid(source_device) or not liveobj_valid(target_device):
            return False
        if source_device == target_device or self._is_instrument_device(source_device):
            return False

        song = self.song()
        selected_track = song.view.selected_track
        source_location = self._find_device_location(selected_track, source_device)
        target_location = self._find_device_location(selected_track, target_device)
        if not source_location or not target_location:
            return False

        try:
            song.move_device(source_device, target_location['container'], target_location['index'] + 1)
            return True
        except Exception as e:
            self._debug_log("Move after failed: {}".format(str(e)))
            return False

    def _devices_changed_since(self, before_devices, after_devices):
        return [device for device in after_devices if not any(device == before for before in before_devices)]

    def _load_item_after_device(self, item, target_index):
        selected_track = self.song().view.selected_track
        before_devices = self._get_all_nested_devices(selected_track.devices)[0]
        target_index = self._app_device_index_to_live_index(target_index)
        if target_index < 0 or target_index >= len(before_devices):
            return False

        target_device = before_devices[target_index]
        self.application().browser.load_item(item)

        after_devices = self._get_all_nested_devices(selected_track.devices)[0]
        new_devices = self._devices_changed_since(before_devices, after_devices)
        selected_device = selected_track.view.selected_device if selected_track else None
        source_device = selected_device if selected_device and not any(selected_device == before for before in before_devices) else None
        if source_device is None and new_devices:
            source_device = new_devices[-1]

        if source_device:
            self._move_device_after_device(source_device, target_device)
            try:
                self.song().view.select_device(source_device)
            except Exception:
                pass
            return True

        return False

    def _set_browser_insert_after_device(self, value):
        self.browser_insert_after_device_index = value

    def _add_random_effect_after_device(self, value):
        if value is None:
            return
        selected_effect = self._random_audio_effect_item()
        if selected_effect:
            self._load_item_after_device(selected_effect, value)
            self._on_tracks_changed()
            self._on_device_changed()

    def _move_device_after_index(self, source_index, target_index):
        selected_track = self.song().view.selected_track
        all_devices = self._get_all_nested_devices(selected_track.devices)[0]
        source_index = self._app_device_index_to_live_index(source_index)
        target_index = self._app_device_index_to_live_index(target_index)
        if source_index < 0 or target_index < 0 or source_index >= len(all_devices) or target_index >= len(all_devices):
            return

        if self._move_device_after_device(all_devices[source_index], all_devices[target_index]):
            self._on_device_changed()

    def _delete_device(self, value):
        selected_track = self.song().view.selected_track
        all_devices = self._get_all_nested_devices(selected_track.devices)[0]
        value = self._app_device_index_to_live_index(value)
        if value < 0 or value >= len(all_devices):
            return
        device_to_delete = all_devices[value]

        # Try to find it in top-level devices first
        if device_to_delete in selected_track.devices:
            original_index = list(selected_track.devices).index(device_to_delete)
            selected_track.delete_device(original_index)
        else:
            # Device is nested, find its parent chain
            parent_chain, device_idx = self._find_parent_chain(selected_track.devices, device_to_delete)
            if parent_chain:
                parent_chain.delete_device(device_idx)
        self._on_device_changed()
        
        
    def _find_parent_chain(self, devices, target_device):
        """Find the parent chain and device index for a nested device"""
        for rack in devices:
            if hasattr(rack, 'chains'):
                for chain in rack.chains:
                    if target_device in chain.devices:
                        device_idx = list(chain.devices).index(target_device)
                        return chain, device_idx
                    # Recursively check nested racks
                    result = self._find_parent_chain(chain.devices, target_device)
                    if result[0]:
                        return result
        return None, None
        
    
    def _select_drum_pad(self, value):
        if self._drum_rack_device:
            drum_pad = self._drum_rack_device.drum_pads[value]
            self._drum_rack_device.view.selected_drum_pad = drum_pad

    def _move_device_left(self, value):
        song = self.song()
        selected_track = song.view.selected_track
        all_devices = self._get_all_nested_devices(selected_track.devices)[0]
        value = self._app_device_index_to_live_index(value)
        if value < 0 or value >= len(all_devices):
            return
        device_to_move = all_devices[value]
        if self._is_instrument_device(device_to_move):
            return
        location = self._find_device_location(selected_track, device_to_move)
        if not location:
            return
        moved = False
        
        # Check if it's a top-level device
        if location['container'] == selected_track:
            real_index = location['index']
            if real_index > 0:
                previous_device = list(selected_track.devices)[real_index - 1]
                if self._is_instrument_device(previous_device):
                    return
                chains = self._valid_chains(previous_device)
                if chains:
                    target_chain = chains[-1]
                    song.move_device(device_to_move, target_chain, len(target_chain.devices))
                    moved = True
                elif not self._is_instrument_device(previous_device):
                    song.move_device(device_to_move, selected_track, real_index - 1)
                    moved = True
        else:
            # Device is inside a rack, move within its chain
            parent_chain = location['container']
            device_idx = location['index']
            if device_idx > 0:
                previous_device = list(parent_chain.devices)[device_idx - 1]
                if self._is_instrument_device(previous_device):
                    return
                song.move_device(device_to_move, parent_chain, device_idx - 1)
                moved = True
        if moved:
            self._on_device_changed()
    
    def _move_device_right(self, value):
        song = self.song()
        selected_track = song.view.selected_track
        all_devices = self._get_all_nested_devices(selected_track.devices)[0]
        value = self._app_device_index_to_live_index(value)
        if value < 0 or value >= len(all_devices):
            return
        device_to_move = all_devices[value]
        if self._is_instrument_device(device_to_move):
            return
        location = self._find_device_location(selected_track, device_to_move)
        if not location:
            return
        moved = False
        
        # Check if it's a top-level device
        if location['container'] == selected_track:
            real_index = location['index']
            if real_index < len(selected_track.devices) - 1:
                song.move_device(device_to_move, selected_track, real_index + 2)
                moved = True
        else:
            # Device is inside a rack, move within its chain
            parent_chain = location['container']
            device_idx = location['index']
            if device_idx < len(parent_chain.devices) - 1:
                song.move_device(device_to_move, parent_chain, device_idx + 2)
                moved = True
            else:
                rack_context = location.get('rack_context')
                if rack_context:
                    rack_container = rack_context['rack_container']
                    rack_index = rack_context['rack_index']
                    song.move_device(device_to_move, rack_container, rack_index + 1)
                    moved = True
        if moved:
            self._on_device_changed()

    def _add_midi_track(self, value):
        song = self.song()
        song.create_midi_track(value)
        self._sync_follow_actions_to_track_topology()

    def _delete_midi_track(self, value):
        song = self.song()
        song.delete_track(value)
        self._sync_follow_actions_to_track_topology()

    def _toggle_group_fold(self, track_index):
        try:
            tracks = list(self.song().tracks)
            if track_index < 0 or track_index >= len(tracks):
                return

            group_track = self._foldable_group_track_for_track(tracks[track_index])
            if group_track is None:
                return

            group_track.fold_state = not bool(group_track.fold_state)
            self._send_group_fold_states_if_changed(tracks, force=True)
            if self.mixer_status:
                self._set_up_mixer_controls()
        except Exception:
            pass

    def _re_enable_automation(self, value):
        if value:
            try:
                self.song().re_enable_automation()
            except Exception:
                pass
            self._send_re_enable_automation_enabled(force=True)

    def _add_return_track(self, value):
        if value:
            self.song().create_return_track()
    
    def _update_mixer_status(self, value):
        if value:
            self._disconnect_device_controls()
        else:
            if hasattr(self, '_mixer_disconnect_timer') and self._mixer_disconnect_timer:
                self._mixer_disconnect_timer.cancel()
                self._mixer_disconnect_timer = None
            self.mixer_status = False
            self._last_visual_feedback_payload = None
            self._set_up_mixer_controls()
            self._connect_device_controls()
            self._send_selected_device_state()

    def _update_device_status(self, value):
        if value:
            self.device_status = True
            self._check_clip_playing_status(force=True)
            if not self.mixer_status:
                self._send_selected_device_state()
        else:
            self.device_status = False
    
    def _update_step_seq(self, value):
        if value:
            self.seq_status = True
            self.start_step_seq()
        else:
           self.seq_status = False
           self.stop_step_seq()
    
    def start_step_seq(self):
        # getting the highlighted clip
        song = self.song()
        selected_clip_slot = song.view.highlighted_clip_slot
        self.send_selected_clip_metadata()
        if (
            selected_clip_slot is not None
            and selected_clip_slot.has_clip
            and bool(getattr(selected_clip_slot.clip, 'is_midi_clip', False))
        ):
            self.send_selected_clip_notes()
        self._check_clip_playing_status(force=True)
        # self.log_message("Starting step seq")
        if self.last_selected_clip_slot is not selected_clip_slot:
            previous_slot = self.last_selected_clip_slot
            if previous_slot is not None:
                try:
                    if previous_slot.has_clip_has_listener(self.on_highlighted_slot_changed):
                        previous_slot.remove_has_clip_listener(self.on_highlighted_slot_changed)
                except Exception:
                    pass

            previous_clip = self._step_seq_listener_clip
            if previous_clip is not None:
                try:
                    if (
                        liveobj_valid(previous_clip)
                        and bool(getattr(previous_clip, 'is_midi_clip', False))
                        and previous_clip.notes_has_listener(self.send_selected_clip_notes)
                    ):
                        previous_clip.remove_notes_listener(self.send_selected_clip_notes)
                    if liveobj_valid(previous_clip):
                        self.remove_clip_metadata_listeners(previous_clip)
                except Exception as e:
                    self._debug_log("Exception changing step-sequencer clip listeners: {}".format(str(e)))
            self._step_seq_listener_clip = None
            
            # updating last selected clip
            self.last_selected_clip_slot = selected_clip_slot
            if selected_clip_slot is not None:
                if selected_clip_slot.has_clip:
                    # Audio clips share the selected-clip screen, but do not
                    # expose MIDI-note listeners.
                    if (
                        bool(getattr(selected_clip_slot.clip, 'is_midi_clip', False))
                        and not selected_clip_slot.clip.notes_has_listener(self.send_selected_clip_notes)
                    ):
                        selected_clip_slot.clip.add_notes_listener(self.send_selected_clip_notes)
                    self._step_seq_listener_clip = selected_clip_slot.clip
                    
                    self.add_clip_metadata_listeners(selected_clip_slot.clip)
                else:
                    # create a clip slot listener that listens to clip changes
                    if not selected_clip_slot.has_clip_has_listener(self.on_highlighted_slot_changed):
                        selected_clip_slot.add_has_clip_listener(self.on_highlighted_slot_changed)
                        # self.log_message("added a has clip listener")
    
    def add_clip_metadata_listeners(self, clip):
        if not clip.end_marker_has_listener(self.send_selected_clip_metadata):
            clip.add_end_marker_listener(self.send_selected_clip_metadata)
        if not clip.start_marker_has_listener(self.send_selected_clip_metadata):
            clip.add_start_marker_listener(self.send_selected_clip_metadata)
        if not clip.loop_end_has_listener(self.send_selected_clip_metadata):
            clip.add_loop_end_listener(self.send_selected_clip_metadata)
        if not clip.loop_start_has_listener(self.send_selected_clip_metadata):
            clip.add_loop_start_listener(self.send_selected_clip_metadata)
        if not clip.signature_denominator_has_listener(self.send_selected_clip_metadata):
            clip.add_signature_denominator_listener(self.send_selected_clip_metadata)
        if not clip.signature_numerator_has_listener(self.send_selected_clip_metadata):
            clip.add_signature_numerator_listener(self.send_selected_clip_metadata)
        if hasattr(clip, "add_name_listener") and (not hasattr(clip, "name_has_listener") or not clip.name_has_listener(self.send_selected_clip_metadata)):
            clip.add_name_listener(self.send_selected_clip_metadata)
        
    def remove_clip_metadata_listeners(self, clip):
        if clip.end_marker_has_listener(self.send_selected_clip_metadata):
            clip.remove_end_marker_listener(self.send_selected_clip_metadata)
        if clip.start_marker_has_listener(self.send_selected_clip_metadata):
            clip.remove_start_marker_listener(self.send_selected_clip_metadata)
        if clip.loop_end_has_listener(self.send_selected_clip_metadata):
            clip.remove_loop_end_listener(self.send_selected_clip_metadata)
        if clip.loop_start_has_listener(self.send_selected_clip_metadata):
            clip.remove_loop_start_listener(self.send_selected_clip_metadata)
        if clip.signature_denominator_has_listener(self.send_selected_clip_metadata):
            clip.remove_signature_denominator_listener(self.send_selected_clip_metadata)
        if clip.signature_numerator_has_listener(self.send_selected_clip_metadata):
            clip.remove_signature_numerator_listener(self.send_selected_clip_metadata)
        if hasattr(clip, "remove_name_listener") and (not hasattr(clip, "name_has_listener") or clip.name_has_listener(self.send_selected_clip_metadata)):
            clip.remove_name_listener(self.send_selected_clip_metadata)
    
    def on_highlighted_slot_changed(self):
        """
        Adding note listener on a slot has clip listener slot once it gets a clip
        """
        song = self.song()
        selected_clip_slot = song.view.highlighted_clip_slot
        if selected_clip_slot is not None and selected_clip_slot.has_clip:
            if selected_clip_slot.has_clip_has_listener(self.on_highlighted_slot_changed):
                selected_clip_slot.remove_has_clip_listener(self.on_highlighted_slot_changed)

            selected_clip = selected_clip_slot.clip
            self.send_selected_clip_metadata()
            if bool(getattr(selected_clip, 'is_midi_clip', False)):
                self.send_selected_clip_notes()
            if (
                bool(getattr(selected_clip, 'is_midi_clip', False))
                and not selected_clip.notes_has_listener(self.send_selected_clip_notes)
            ):
                selected_clip.add_notes_listener(self.send_selected_clip_notes)
            self._step_seq_listener_clip = selected_clip
            self.add_clip_metadata_listeners(selected_clip)
    
    def stop_step_seq(self):
        # The highlighted slot can lag while selection changes. Clean the slot
        # that start_step_seq actually registered, plus the current one if it
        # differs, without removing the separate playing-note cache listener.
        selected_clip_slot = self.song().view.highlighted_clip_slot
        slots_to_clean = []
        for clip_slot in (self.last_selected_clip_slot, selected_clip_slot):
            if clip_slot is not None and all(clip_slot is not item for item in slots_to_clean):
                slots_to_clean.append(clip_slot)

        clips_to_clean = []
        if self._step_seq_listener_clip is not None:
            clips_to_clean.append(self._step_seq_listener_clip)

        for clip_slot in slots_to_clean:
            try:
                if clip_slot.has_clip_has_listener(self.on_highlighted_slot_changed):
                    clip_slot.remove_has_clip_listener(self.on_highlighted_slot_changed)
            except Exception:
                pass
            try:
                if clip_slot.has_clip:
                    clip = clip_slot.clip
                    if all(clip is not item for item in clips_to_clean):
                        clips_to_clean.append(clip)
            except Exception as e:
                self._debug_log("Exception removing step-sequencer listeners: {}".format(str(e)))

        for clip in clips_to_clean:
            try:
                if (
                    liveobj_valid(clip)
                    and bool(getattr(clip, 'is_midi_clip', False))
                    and clip.notes_has_listener(self.send_selected_clip_notes)
                ):
                    clip.remove_notes_listener(self.send_selected_clip_notes)
                if liveobj_valid(clip):
                    self.remove_clip_metadata_listeners(clip)
            except Exception as e:
                self._debug_log("Exception removing step-sequencer clip listeners: {}".format(str(e)))

        self._step_seq_listener_clip = None
        self.last_selected_clip_slot = None
    
    # Use 7-bit encoding for multi-byte values below 1000
    def _to_2_7bit_bytes(self, value):
        return [
            value & 0x7F,           # Low 7 bits
            (value >> 7) & 0x7F     # High 7 bits
        ]

    def _to_5_7bit_bytes(self, value):
        """Encode a non-negative Live note ID without 14-bit truncation."""
        value = max(0, int(value))
        return [(value >> (shift * 7)) & 0x7F for shift in range(5)]

    def _from_5_7bit_bytes(self, bytes_list, start_index=0):
        if len(bytes_list) < start_index + 5:
            return 0
        return sum(
            int(bytes_list[start_index + shift]) << (shift * 7)
            for shift in range(5)
        )
    
    def _to_3_7bit_magnitude(self, value):
        """Encode an absolute magnitude from 0 through 2,097,151."""
        value = min(abs(int(value)), self.SYSEX_21_BIT_MAX_MAGNITUDE)
        return [(value >> 14) & 0x7F, (value >> 7) & 0x7F, value & 0x7F]

    def _from_3_7bit_magnitude(self, bytes_list, start_index=0):
        """Decode an unsigned 21-bit magnitude from three SysEx7 bytes."""
        if len(bytes_list) < start_index + 3:
            return 0

        return (
            ((int(bytes_list[start_index]) & 0x7F) << 14)
            | ((int(bytes_list[start_index + 1]) & 0x7F) << 7)
            | (int(bytes_list[start_index + 2]) & 0x7F)
        )

    def _signed_magnitude_flags(self, values):
        flags = 0
        for value_index, value in enumerate(values[:7]):
            if int(value) < 0:
                flags |= 1 << value_index
        return flags

    def _value_from_magnitude(self, magnitude, sign_flags, value_index):
        return -magnitude if sign_flags & (1 << value_index) else magnitude

    def _note_record_flags(self, mute, start_time, duration):
        return (
            (self.NOTE_FLAG_MUTE if mute else 0)
            | (self.NOTE_FLAG_NEGATIVE_START if start_time < 0 else 0)
            | (self.NOTE_FLAG_NEGATIVE_DURATION if duration < 0 else 0)
        )

    # MARK: - Selected audio clip

    def _selected_audio_clip_context(self, include_empty=False):
        try:
            song = self.song()
            slot = song.view.highlighted_clip_slot
            track = song.view.selected_track
            tracks = list(song.tracks)
            if slot is None or track not in tracks:
                return (None, None, -1, -1)
            track_index = tracks.index(track)
            clip_slots = list(track.clip_slots)
            if slot not in clip_slots:
                return (None, None, -1, -1)
            scene_index = clip_slots.index(slot)
            if not slot.has_clip:
                return (slot, None, track_index, scene_index) if include_empty else (None, None, -1, -1)
            clip = slot.clip
            if not bool(getattr(clip, 'is_audio_clip', False)):
                return (slot, None, track_index, scene_index) if include_empty else (None, None, -1, -1)
            return (slot, clip, track_index, scene_index)
        except Exception:
            return (None, None, -1, -1)

    def _audio_clip_float(self, clip, property_name, default=0.0):
        try:
            return float(getattr(clip, property_name))
        except Exception:
            return float(default)

    def _audio_clip_warp_mode_label(self, mode):
        names = {
            int(Live.Clip.WarpMode.beats): 'Beats',
            int(Live.Clip.WarpMode.tones): 'Tones',
            int(Live.Clip.WarpMode.texture): 'Texture',
            int(Live.Clip.WarpMode.repitch): 'Re-Pitch',
            int(Live.Clip.WarpMode.complex): 'Complex',
            int(Live.Clip.WarpMode.complex_pro): 'Complex Pro',
        }
        try:
            return names.get(int(mode), str(int(mode)))
        except Exception:
            return str(mode)

    def _audio_clip_warp_markers_payload(self, clip):
        markers = []
        try:
            for marker in list(clip.warp_markers)[:64]:
                markers.append('{:.6f}:{:.6f}'.format(
                    float(marker.beat_time),
                    float(marker.sample_time),
                ))
        except Exception:
            pass
        return ';'.join(markers)

    def _audio_clip_add_listener(self, subject, property_name, callback):
        add_listener = getattr(subject, 'add_{}_listener'.format(property_name), None)
        has_listener = getattr(subject, '{}_has_listener'.format(property_name), None)
        if not callable(add_listener):
            return
        try:
            if callable(has_listener) and has_listener(callback):
                return
            add_listener(callback)
            self._audio_clip_listener_bindings.append((subject, property_name, callback))
        except Exception:
            pass

    def _remove_audio_clip_listeners(self):
        for subject, property_name, callback in self._audio_clip_listener_bindings:
            remove_listener = getattr(subject, 'remove_{}_listener'.format(property_name), None)
            has_listener = getattr(subject, '{}_has_listener'.format(property_name), None)
            try:
                if callable(remove_listener) and (not callable(has_listener) or has_listener(callback)):
                    remove_listener(callback)
            except Exception:
                pass
        self._audio_clip_listener_bindings = []

    def _connect_audio_clip_listeners(self, clip):
        current = getattr(self, '_audio_clip_listener_clip', None)
        if current is clip:
            return
        self._remove_audio_clip_listeners()
        self._audio_clip_listener_clip = clip
        self._audio_clip_waveform_generation += 1
        if clip is None:
            return
        for property_name in (
            'looping', 'warping', 'warp_mode', 'gain', 'pitch_coarse', 'pitch_fine',
            'start_marker', 'end_marker', 'loop_start', 'loop_end', 'warp_markers',
            'name', 'is_playing',
        ):
            self._audio_clip_add_listener(clip, property_name, self._on_audio_clip_changed)
        self._audio_clip_add_listener(
            clip,
            'playing_position',
            self._on_audio_clip_playing_position_changed,
        )

    def _on_audio_clip_changed(self):
        self._send_audio_clip_state()

    def _on_audio_clip_playing_position_changed(self):
        now = time.time()
        if now - self._last_audio_clip_position_state_time >= 0.25:
            self._last_audio_clip_position_state_time = now
            self._send_audio_clip_state()

    def _send_audio_clip_state(self, force=False):
        slot, clip, track_index, scene_index = self._selected_audio_clip_context(include_empty=True)
        self._connect_audio_clip_listeners(clip)
        if slot is None:
            payload = '1|none'
        elif clip is None:
            payload = '1|empty|{}|{}'.format(track_index, scene_index)
        else:
            warping = bool(getattr(clip, 'warping', False))
            available_modes = []
            try:
                available_modes = [
                    '{}:{}'.format(int(mode), self._audio_clip_warp_mode_label(mode))
                    for mode in clip.available_warp_modes
                ]
            except Exception:
                pass
            is_playing = bool(getattr(clip, 'is_playing', False))
            name = self._escape_sysex_string(str(getattr(clip, 'name', 'Audio Clip')))
            gain_display = self._escape_sysex_string(str(getattr(clip, 'gain_display_string', '')))
            unit = 'beats' if warping else 'seconds'
            sample_length = self._audio_clip_float(clip, 'sample_length', 0.0)
            sample_rate = self._audio_clip_float(clip, 'sample_rate', 0.0)
            can_crop = callable(getattr(clip, 'crop', None)) and not is_playing
            can_convert = bool(
                hasattr(Live, 'Conversions')
                and not bool(getattr(clip, 'is_recording', False))
            )
            can_set_one = bool(
                callable(getattr(clip, 'set_one_one_one', None))
                or (
                    bool(getattr(clip, 'warp_markers', ()))
                    and callable(getattr(clip, 'move_warp_marker', None))
                )
            )
            can_warp_to_grid = any(
                callable(getattr(clip, method_name, None))
                for method_name in ('warp_to_grid', 'warp_to_current_tempo')
            )
            values = (
                '1', 'audio', track_index, scene_index, name,
                1 if bool(getattr(clip, 'looping', False)) else 0,
                1 if warping else 0,
                int(getattr(clip, 'warp_mode', 0)) if warping else -1,
                ';'.join(available_modes),
                self._audio_clip_float(clip, 'gain', 1.0),
                gain_display,
                int(getattr(clip, 'pitch_coarse', 0)),
                int(getattr(clip, 'pitch_fine', 0)),
                self._audio_clip_float(clip, 'start_marker'),
                self._audio_clip_float(clip, 'end_marker'),
                self._audio_clip_float(clip, 'loop_start'),
                self._audio_clip_float(clip, 'loop_end'),
                sample_length,
                sample_rate,
                unit,
                1 if is_playing else 0,
                self._audio_clip_float(clip, 'playing_position'),
                1 if can_crop else 0,
                1 if can_convert else 0,
                1 if can_set_one else 0,
                1 if can_warp_to_grid else 0,
                self._audio_clip_warp_markers_payload(clip),
            )
            payload = '|'.join(str(value) for value in values)
        state_changed = force or payload != self._last_audio_clip_state
        if state_changed:
            self._last_audio_clip_state = payload
            self._send_sys_ex_message(payload, 0x50)
        if clip is not None:
            self._request_audio_clip_waveform()
        elif state_changed:
            self._audio_clip_waveform_generation += 1
            self._send_binary_sys_ex_message((0x01, self._audio_clip_waveform_generation & 0x7F), 0x51)

    def _send_audio_clip_action_result(self, action, succeeded, message):
        payload = '{}|{}|{}'.format(
            self._escape_sysex_string(action),
            1 if succeeded else 0,
            self._escape_sysex_string(message),
        )
        if payload != self._last_audio_clip_action_result or not succeeded:
            self._last_audio_clip_action_result = payload
            self._send_sys_ex_message(payload, 0x53)

    def _send_audio_clip_waveform(self, generation, peaks):
        if generation != self._audio_clip_waveform_generation:
            return
        peaks = list(peaks)[:112]
        self._send_binary_sys_ex_message(
            (0x01, generation & 0x7F) + tuple(max(0, min(127, int(value))) for value in peaks),
            0x51,
        )

    def _request_audio_clip_waveform(self):
        _, clip, _, _ = self._selected_audio_clip_context()
        if clip is None:
            return
        try:
            file_path = str(clip.file_path)
        except Exception:
            file_path = ''
        if not file_path or not os.path.isfile(file_path):
            return
        generation = self._audio_clip_waveform_generation
        cached = self._simpler_waveform_cache.get(file_path)
        if cached:
            self._send_audio_clip_waveform(generation, cached)
            return
        pending_key = ('audio', generation, file_path)
        if pending_key in self._simpler_waveform_pending:
            return
        self._simpler_waveform_pending.add(pending_key)

        def build():
            peaks = self._decode_audio_waveform(file_path, 'tap-audio-clip-')
            with self._simpler_waveform_lock:
                if peaks:
                    self._cache_simpler_waveform(file_path, peaks)
                self._simpler_waveform_pending.discard(pending_key)

        worker = threading.Thread(target=build, name='TapAudioClipWaveform')
        worker.daemon = True
        worker.start()

        def poll(attempt=0):
            if generation != self._audio_clip_waveform_generation:
                return
            cached_peaks = self._simpler_waveform_cache.get(file_path)
            if cached_peaks:
                self._send_audio_clip_waveform(generation, cached_peaks)
            elif pending_key in self._simpler_waveform_pending and attempt < 120:
                self.schedule_message(5, lambda: poll(attempt + 1))
        self.schedule_message(5, poll)

    def _set_audio_clip_property(self, clip, property_name, raw_value):
        boolean_properties = ('looping', 'warping')
        integer_properties = ('warp_mode', 'pitch_coarse', 'pitch_fine')
        allowed = boolean_properties + integer_properties + (
            'gain', 'start_marker', 'end_marker', 'loop_start', 'loop_end',
        )
        if property_name not in allowed:
            raise ValueError('Unknown audio clip property: {}'.format(property_name))
        if property_name in boolean_properties:
            value = str(raw_value).lower() in ('1', 'true', 'on')
        elif property_name in integer_properties:
            value = int(float(raw_value))
        else:
            value = float(raw_value)
        if property_name == 'gain':
            value = max(0.0, min(1.0, value))
        elif property_name == 'pitch_coarse':
            value = max(-48, min(48, value))
        elif property_name == 'pitch_fine':
            value = max(-50, min(50, value))
        elif property_name == 'warp_mode':
            available = list(getattr(clip, 'available_warp_modes', ()))
            matching = next((mode for mode in available if int(mode) == value), None)
            if matching is None:
                raise ValueError('Warp mode is not available for this clip.')
            value = matching
        setattr(clip, property_name, value)

    def _set_audio_clip_one(self, clip):
        method = getattr(clip, 'set_one_one_one', None)
        if callable(method):
            method()
            return True
        markers = list(getattr(clip, 'warp_markers', ()))
        if not markers:
            return False
        marker = min(markers, key=lambda item: abs(float(item.beat_time)))
        move_marker = getattr(clip, 'move_warp_marker', None)
        if not callable(move_marker):
            return False
        for args in (
            (float(marker.beat_time), 0.0),
            (marker, 0.0),
        ):
            try:
                move_marker(*args)
                return True
            except Exception:
                pass
        return False

    def _warp_audio_clip_to_grid(self, clip):
        for method_name in ('warp_to_grid', 'warp_to_current_tempo'):
            method = getattr(clip, method_name, None)
            if callable(method):
                method()
                return 'Warped to Set tempo'
        raise RuntimeError(
            'Warp to Grid is a private Push operation and is not exposed by this Live version.'
        )

    def _convert_selected_audio_clip(self, conversion):
        _, clip, _, _ = self._selected_audio_clip_context()
        if clip is None:
            raise RuntimeError('No selected audio clip.')
        conversions = getattr(Live, 'Conversions', None)
        if conversions is None:
            raise RuntimeError('Audio conversion is unavailable in this Live version.')
        song = self.song()
        if conversion == 'simpler':
            conversions.create_midi_track_with_simpler(song, clip)
        elif conversion == 'drum_pad':
            conversions.create_drum_rack_from_audio_clip(song, clip)
        else:
            type_names = {
                'harmony': 'harmony_to_midi',
                'melody': 'melody_to_midi',
                'drums': 'drums_to_midi',
            }
            type_name = type_names.get(conversion)
            audio_to_midi_type = getattr(conversions, 'AudioToMidiType', None)
            conversion_type = getattr(audio_to_midi_type, type_name, None) if type_name else None
            if conversion_type is None:
                raise RuntimeError('This audio-to-MIDI conversion is unavailable.')
            if not conversions.is_convertible_to_midi(song, clip):
                raise RuntimeError('Live cannot convert this clip to MIDI.')
            conversions.audio_to_midi_clip(song, clip, conversion_type)

    def _handle_audio_clip_command(self, message):
        try:
            payload = bytes(message[2:-1]).decode('ascii', errors='ignore')
            fields = [
                self._unescape_sysex_string(value)
                for value in self._split_escaped_sysex_fields(payload, '|')
            ]
            action = fields[0] if fields else ''
            if action == 'request':
                self._send_audio_clip_state(force=True)
                return
            if action == 'browse' and len(fields) >= 3:
                self.browser_audio_clip_target = (int(fields[1]), int(fields[2]))
                self._send_audio_clip_action_result(action, True, 'Choose a sample')
                return
            if action == 'simplerWarpAs' and len(fields) >= 2:
                beats = max(0.125, min(128.0, float(fields[1])))
                if not liveobj_valid(self._simpler_device) or not bool(getattr(self._simpler_device, 'can_warp_as', False)):
                    raise RuntimeError('Warp As is unavailable for the selected Simpler.')
                self._simpler_warp_as_beats = beats
                self._simpler_device.warp_as(beats)
                self._send_simpler_state()
                self._send_audio_clip_action_result(action, True, 'Warped as {} beats'.format(beats))
                return

            _, clip, _, _ = self._selected_audio_clip_context()
            if clip is None:
                raise RuntimeError('No selected audio clip.')
            if action == 'set' and len(fields) >= 3:
                self._set_audio_clip_property(clip, fields[1], fields[2])
            elif action == 'scrub' and len(fields) >= 2:
                clip.scrub(float(fields[1]))
            elif action == 'stopScrub':
                clip.stop_scrub()
            elif action == 'crop':
                clip.crop()
                self._audio_clip_waveform_generation += 1
            elif action == 'setOne':
                if not self._set_audio_clip_one(clip):
                    raise RuntimeError('Set 1.1.1 is not exposed by this Live version.')
            elif action == 'warpGrid':
                message_text = self._warp_audio_clip_to_grid(clip)
                self._send_audio_clip_action_result(action, True, message_text)
                self._send_audio_clip_state(force=True)
                return
            elif action == 'convert' and len(fields) >= 2:
                self._convert_selected_audio_clip(fields[1])
            elif action == 'waveform':
                self._audio_clip_waveform_generation += 1
                self._request_audio_clip_waveform()
            else:
                raise ValueError('Unknown audio clip action: {}'.format(action))
            self._send_audio_clip_action_result(action, True, 'Done')
            self._send_audio_clip_state(force=True)
        except Exception as error:
            self._send_audio_clip_action_result(
                fields[0] if 'fields' in locals() and fields else 'command',
                False,
                str(error),
            )
    
    def send_selected_clip_metadata(self):
        """
        Encode clip metadata into a compact SysEx message and send it out.
        """
        self._send_audio_clip_state()
        if self._selected_clip_updates_are_suppressed():
            self._selected_clip_update_pending_metadata = True
            return
        if self.seq_status:
            # self.log_message("sending clip metadata")
            status_byte = 0xF0
            end_byte = 0xF7
            manufacturer_id = 0x0E
            device_id = 0x01
            
            song = self.song()
            clip_slot = song.view.highlighted_clip_slot
            if clip_slot is not None:
                if clip_slot.has_clip:
                    selected_clip = clip_slot.clip
                    # Extract clip metadata, make ints
                    start_marker = int(selected_clip.start_marker * 1000)
                    end_marker = int(selected_clip.end_marker * 1000)
                    loop_start = int(selected_clip.loop_start * 1000)
                    loop_end = int(selected_clip.loop_end * 1000)
                    signature_denominator = int(selected_clip.signature_denominator)
                    signature_numerator = int(selected_clip.signature_numerator)
                    decoupled_info = self._decoupled_automation_info(selected_clip)
                    marker_values = (
                        start_marker,
                        end_marker,
                        loop_start,
                        loop_end
                    )
                    
                    note_data = [
                        self._signed_magnitude_flags(marker_values),
                        *self._to_3_7bit_magnitude(start_marker),
                        *self._to_3_7bit_magnitude(end_marker),
                        *self._to_3_7bit_magnitude(loop_start),
                        *self._to_3_7bit_magnitude(loop_end),
                        signature_denominator,
                        signature_numerator
                    ]
                    if decoupled_info:
                        control_lengths = []
                        for control_index in range(8):
                            device_param = self._current_connected_parameter_for_control(control_index)
                            parameter_key = self._decoupled_automation_parameter_key(device_param)
                            if parameter_key in decoupled_info.get("automation_lengths", {}):
                                control_lengths.append((control_index, decoupled_info["automation_lengths"][parameter_key]))
                        decoupled_values = (
                            int(decoupled_info["note_start"] * 1000),
                            int(decoupled_info["note_end"] * 1000),
                            int(decoupled_info["note_length"] * 1000),
                            int(decoupled_info["physical_end"] * 1000)
                        )
                        decoupled_flags = (
                            self.DECOUPLED_FLAG_ACTIVE
                            | (
                                self.DECOUPLED_FLAG_NEGATIVE_NOTE_START
                                if decoupled_values[0] < 0 else 0
                            )
                            | (
                                self.DECOUPLED_FLAG_NEGATIVE_NOTE_END
                                if decoupled_values[1] < 0 else 0
                            )
                            | (
                                self.DECOUPLED_FLAG_NEGATIVE_NOTE_LENGTH
                                if decoupled_values[2] < 0 else 0
                            )
                            | (
                                self.DECOUPLED_FLAG_NEGATIVE_PHYSICAL_END
                                if decoupled_values[3] < 0 else 0
                            )
                        )
                        note_data.extend([
                            decoupled_flags,
                            *self._to_3_7bit_magnitude(decoupled_values[0]),
                            *self._to_3_7bit_magnitude(decoupled_values[1]),
                            *self._to_3_7bit_magnitude(decoupled_values[2]),
                            *self._to_3_7bit_magnitude(decoupled_values[3]),
                            len(control_lengths),
                        ])
                        for control_index, automation_length in control_lengths:
                            note_data.extend([
                                control_index,
                                *self._to_3_7bit_magnitude(
                                    max(0, int(automation_length * 1000))
                                ),
                            ])
                    else:
                        note_data.append(0)

                    mutator_info = self._mutator_info(selected_clip)
                    if mutator_info:
                        note_data.extend([
                            1,
                            *self._to_3_7bit_magnitude(
                                max(0, int(mutator_info.get("original_loop_length", 0.0001) * 1000))
                            ),
                            *self._to_3_7bit_magnitude(
                                max(0, int(mutator_info.get("structure_length", 0.0001) * 1000))
                            ),
                            int(mutator_info.get("preset", 9)) & 0x7F,
                            min(32, len(mutator_info.get("sections", []))),
                        ])
                        for section in mutator_info.get("sections", [])[:32]:
                            section_start = int(section.get("start", 0.0) * 1000)
                            section_length = max(
                                0,
                                int(section.get("length", 0.0) * 1000)
                            )
                            section_flags = (
                                int(section.get("role", 1)) & self.MUTATOR_SECTION_ROLE_MASK
                            ) | (
                                self.MUTATOR_SECTION_FLAG_NEGATIVE_START
                                if section_start < 0 else 0
                            )
                            note_data.extend([
                                section_flags,
                                *self._to_3_7bit_magnitude(section_start),
                                *self._to_3_7bit_magnitude(section_length),
                        ])
                        target_pitches = [max(0, min(127, int(pitch))) for pitch in mutator_info.get("target_pitches", [])[:16]]
                        operation_order = [int(slot.get("operation", 0)) for slot in self._mutator_active_slots(mutator_info)]
                        mutator_slots = self._mutator_visible_slots(mutator_info)
                        mutator_slot_count = self._mutator_slot_count_from_value(
                            mutator_info.get("mutator_slot_count", ""),
                            self._mutator_normalized_slots(mutator_info)
                        )
                        note_data.extend([
                            9,
                            int(mutator_info.get("algorithm_code", self._mutator_algorithm_code(mutator_info.get("algorithm", "mutator")))) & 0x7F,
                            int(mutator_info.get("regenerate_mode", 0)) & 0x7F,
                            int(mutator_info.get("source_mode", 2)) & 0x7F,
                            max(0, min(100, int(round(float(mutator_info.get("depth", 0.0)) * 100.0)))),
                            int(mutator_info.get("root", 0)) & 0x7F,
                            int(mutator_info.get("scale_index", 2)) & 0x7F,
                            int(mutator_info.get("settings_preset", mutator_info.get("preset", 9))) & 0x7F,
                            int(mutator_info.get("companion_mode_code", self._mutator_companion_mode_code(mutator_info.get("companion_mode", "melody")))) & 0x7F,
                            len(target_pitches),
                        ])
                        note_data.extend(target_pitches)
                        for key in self._mutator_operation_depth_keys():
                            note_data.append(max(0, min(100, int(round(self._mutator_depth_value(mutator_info, key, 0.0) * 100.0)))))
                        note_data.append(len(operation_order))
                        note_data.extend(max(0, min(self._mutator_max_operation_index(), int(index))) for index in operation_order)
                        note_data.append(len(mutator_slots))
                        for slot in mutator_slots:
                            if not slot:
                                note_data.extend([127, 0, 0, 0])
                            else:
                                operation = max(0, min(self._mutator_max_operation_index(), int(slot.get("operation", 0))))
                                note_data.extend([
                                    operation,
                                    max(0, min(100, int(round(self._mutator_depth_value(slot, "activation_probability", 1.0) * 100.0)))),
                                    max(0, min(100, int(round(self._mutator_depth_value(slot, "probability_depth", 0.0) * 100.0)))),
                                    max(0, min(100, int(round(self._mutator_depth_value(slot, "range_depth", 0.5) * 100.0)))),
                                ])
                        note_data.append(mutator_slot_count)
                        note_data.append(1 if mutator_info.get("pending_settings_update", False) else 0)
                    else:
                        note_data.append(0)

                    flin_info = self._flin_info(selected_clip)
                    if flin_info:
                        columns = self._flin_visible_columns(flin_info)
                        minimum_pitch, maximum_pitch = self._flin_pitch_bounds(flin_info)
                        note_data.extend([
                            1,
                            int(flin_info.get("kind", 0)) & 0x7F,
                            int(flin_info.get("quantization", 1)) & 0x7F,
                            int(flin_info.get("base_quarters", 16)) & 0x7F,
                            int(flin_info.get("rate_mode", 0)) & 0x7F,
                            int(flin_info.get("bottom_rate", 1)) & 0x7F,
                            int(flin_info.get("row_interval", 4)) & 0x7F,
                            int(flin_info.get("horizon_bars", 64)) & 0x7F,
                            int(flin_info.get("mapping_mode", 0)) & 0x7F,
                            max(0, min(127, int(flin_info.get("global_offset", 0)) + 64)),
                            max(0, min(127, int(flin_info.get("view_page", 0)) + 64)),
                            max(0, min(127, int(flin_info.get("base_pitch", 60)))),
                            1 if flin_info.get("limited", False) else 0,
                            *self._to_3_7bit_magnitude(
                                max(0, int(flin_info.get("seed", 1)))
                            ),
                            max(1, min(127, int(flin_info.get("default_velocity", 100)))),
                            minimum_pitch,
                            maximum_pitch,
                            len(columns),
                        ])
                        for column in columns:
                            note_data.extend([
                                max(0, min(15, int(column.get("id", 0)))),
                                1 if column.get("active", False) else 0,
                                max(0, min(15, int(column.get("rate_row", 0)))),
                                max(1, min(16, int(column.get("duration_steps", 1)))),
                                *self._to_3_7bit_magnitude(
                                    max(0, int(column.get("phase_ticks", 0)))
                                ),
                                max(0, min(127, int(column.get("scale_degree", 0)) + 64)),
                                max(0, min(127, int(column.get("octave_offset", 0)) + 64)),
                                max(0, min(127, int(column.get("pad_offset", 0)) + 64)),
                                max(1, min(127, int(column.get("velocity", 100)))),
                                max(0, min(100, int(column.get("probability", 100)))),
                            ])
                    else:
                        note_data.append(0)
                    
                    # Send the SysEx message
                    sys_ex_message = (status_byte, manufacturer_id, device_id) + tuple(note_data) + (end_byte,)
                    self._send_midi(sys_ex_message)
    
    def send_selected_clip_notes(self):
        """
        Encode a full clip with all notes into a compact SysEx message and send it out.
        """
        if self._selected_clip_updates_are_suppressed():
            self._selected_clip_update_pending_notes = True
            return
        if self.seq_status:
            status_byte = 0xF0
            end_byte = 0xF7
            manufacturer_id = 0x0D
            device_id = 0x01
            max_chunk_length = 240
            data = bytearray()
                
            song = self.song()
            clip_slot = song.view.highlighted_clip_slot
            
            if clip_slot is not None:
                if clip_slot.has_clip:
                    selected_clip = clip_slot.clip
                
                    # Extract clip metadata
                    clip_start = min(selected_clip.start_time, selected_clip.start_marker, selected_clip.loop_start) - self.clip_length_trick
                    clip_length = (max(selected_clip.loop_end, selected_clip.end_marker, selected_clip.length) + self.clip_length_trick) - clip_start
                    
                    # Get notes
                    notes = selected_clip.get_notes_extended(0, 128, clip_start, clip_length)
                    decoupled_info = self._decoupled_automation_info(selected_clip)
                    if decoupled_info:
                        notes = [
                            note for note in notes
                            if note.start_time >= decoupled_info["note_start"] - 0.000001
                            and note.start_time < decoupled_info["note_end"] - 0.000001
                        ]
                    # self.log_message(f"Number of notes found: {len(notes)}")
                    for note in notes:
                        note_id = int(note.note_id)
                        pitch = int(note.pitch)
                        start_time = int(note.start_time * 1000)
                        duration = int(note.duration * 1000)
                        velocity = int(note.velocity)
                        note_flags = self._note_record_flags(
                            bool(note.mute),
                            start_time,
                            duration
                        )
                        probability = int(note.probability * 127)
                    
                        note_data = [
                            *self._to_5_7bit_bytes(note_id),   # 5 bytes, 7-bit encoded
                            pitch,                      # 1 byte
                            *self._to_3_7bit_magnitude(start_time),# 3 bytes, 7-bit encoded
                            *self._to_3_7bit_magnitude(duration),  # 3 bytes, 7-bit encoded
                            velocity,
                            probability,
                            note_flags
                        ]
                    
                        data.extend(note_data)
                else:
                    # Indicate no clip selected by adding a recognizable marker
                    data.extend([0x7F, 0x7F, 0x7F])
                    if not clip_slot.has_clip_has_listener(self.on_highlighted_slot_changed):
                        clip_slot.add_has_clip_listener(self.on_highlighted_slot_changed)
                
            # Split data if it's too large for a single SysEx message
            num_of_chunks = max(1, (len(data) + max_chunk_length - 1) // max_chunk_length)
            for chunk_index in range(num_of_chunks):
                start_index = chunk_index * max_chunk_length
                end_index = start_index + max_chunk_length
                chunk_data = data[start_index:end_index]
                
                # Add prefix and suffix to chunks
                prefix = "_" if chunk_index == num_of_chunks - 1 else "$"
                chunk_data = prefix.encode('ascii') + chunk_data
            
                # Send the SysEx message
                sys_ex_message = (status_byte, manufacturer_id, device_id) + tuple(chunk_data) + (end_byte,)
                self._send_midi(sys_ex_message)
    
    def send_out_playing_pos(self, value, beats_per_bar, force=False, hidden=False):
        if hidden:
            cc_pair = (127, 0)
            if not force and self._last_sent_playing_pos_cc_pair == cc_pair:
                return
            self._last_sent_playing_pos_cc_pair = cc_pair
            self.send_cc(65, 11, cc_pair[0])
            self.send_cc(66, 11, cc_pair[1])
            return

        if beats_per_bar <= 0:
            return

        beats_per_bar = float(beats_per_bar)
        position = max(0.0, float(value))
        bar_index = int(math.floor(position / beats_per_bar))
        bar_position = position - (bar_index * beats_per_bar)
        fine_value = max(0.0, min(1.0, bar_position / beats_per_bar))

        cc_pair = (
            max(0, min(126, bar_index)),
            max(0, min(127, int(round(fine_value * 127.0))))
        )
        if not force and self._last_sent_playing_pos_cc_pair == cc_pair:
            return

        self._last_sent_playing_pos_cc_pair = cc_pair
        self.send_cc(65, 11, cc_pair[0])
        self.send_cc(66, 11, cc_pair[1])
            
    
    def _delete_return_track(self, value):
        song = self.song()
        song.delete_return_track(value)

    def _add_random_synth(self, value):
        if value:
            browser = self.application().browser
            excluded = {
                "CV Instrument", "CV Triggers", "External Instrument",
                "Ext. Instrument", "Drum Rack", "Instrument Rack",
                "Sampler", "Simpler", "Impulse"
            }
            candidates = []
            for instrument in browser.instruments.children:
                if instrument.name in excluded:
                    continue
                if instrument.is_device or len(instrument.children) > 0:
                    candidates.append(instrument)
            if not candidates:
                return
            rand_instrument = random.choice(candidates)
            if not rand_instrument.is_device:
                rand_instrument = random.choice(rand_instrument.children)
            browser.load_item(rand_instrument)
            self._on_tracks_changed()
            self._on_device_changed()

    def _add_random_drums(self, value):
        if value:
            browser = self.application().browser
            candidates = [
                drum for drum in browser.drums.children
                if drum.name not in ("Drum Hits", "Drum Rack")
            ]
            if not candidates:
                return
            random_drum = random.choice(candidates)
            browser.load_item(random_drum)
            self._on_tracks_changed()
            self._on_device_changed()

    def _add_random_sound(self, value):
        if value:
            browser = self.application().browser
            # selecting a random device from the sounds folder
            sounds = browser.sounds
            number_of_sounds = len(sounds.children)
            random_index = random.randint(0, number_of_sounds - 1)
            selected_sounds_folder = sounds.children[random_index]
            number_of_sounds = len(selected_sounds_folder.children)
            random_sound_index = random.randint(0, number_of_sounds - 1)
            selected_sound = selected_sounds_folder.children[random_sound_index]
            browser.load_item(selected_sound)
            self._on_tracks_changed()
            self._on_device_changed()

    def _random_audio_effect_item(self):
        browser = self.application().browser
        # Tried loading max for live effects but gave up
        # random_index = random.randint(0, 1)
        # if random_index == 0:
        #     max_effects = browser.max_for_live.children
        #     max_number = len(max_effects)
        #     random_max = random.randint(0, max_number - 1)
        #     selected_folder = max_effects[random_max].children
        #     max_number = len(selected_folder)
        #     finished = False
        #     number_of_tries = 0
        #     if max_number == 0:
        #         selected_effect = selected_folder
        #         finished = True
        #     while not finished and number_of_tries < 10:
        #         random_max = random.randint(0, max_number - 1)
        #         selected_effect = selected_folder[random_max]
        #         number_of_tries += 1
        #         self.log_message("Selected Device: {}".format(selected_effect.name))
        #         if not any(selected_effect.name.lower().startswith(substring.lower()) for substring in ["IR", "Api", "Map8", "Max Audio Effect"]):
        #             finished = True

        # else:
        effects = browser.audio_effects
        effect_children = effects.children
        number_of_effects = len(effect_children)
        if number_of_effects == 0:
            return None
        # check if effects are in folders or not
        if number_of_effects >= 10:
            return random.choice(effect_children)

        eligible_folders = [
            folder for folder in effect_children
            if folder.name != "Utilities" and len(folder.children) > 0
        ]
        if not eligible_folders:
            return None
        selected_folder = random.choice(eligible_folders)
        self._debug_log("Selected Folder: {}".format(selected_folder.name))
        return random.choice(selected_folder.children)

    def _add_random_effect(self, value):
        if value:
            selected_effect = self._random_audio_effect_item()
            if selected_effect:
                self.application().browser.load_item(selected_effect)
            self._on_tracks_changed()
            self._on_device_changed()

    def _start_browser(self, folder_index):
        """
        Start browsing a specific browser folder.

        Triggered by MIDI CC on channel 1, CC 25. The value corresponds to a folder mapping:
        0 = audio_effects, 1 = colors, 2 = current_project, 3 = drums,
        4 = instruments, 5 = max_for_live, 6 = midi_effects, 7 = packs,
        8 = plugins, 9 = sounds, 10 = user_folders, 11 = user_library,
        12 = samples, 13 = clips

        Collects all items from the requested folder, resets pagination, and sends the first page
        via SysEx with manufacturer ID 0x13.

        Args:
            folder_index: Integer (0-11) corresponding to the folder to browse
        """
        browser = self.application().browser

        if folder_index not in self.browser_folder_mapping:
            return

        folder_name = self.browser_folder_mapping[folder_index]

        try:
            # Clear history when starting fresh
            self.browser_history = []
            self.browser_search_restore_state = None
            self.browser_search_query = ''
            self.browser_search_tag_indices = []
            self.browser_search_generation += 1
            self.browser_search_work = None
            self.browser_previewable_keys = set()
            self.browser_search_group_by_key = {}
            self.browser_search_result_items = []
            self.browser_showing_search_results = False
            self.browser_search_scope = ''
            self.browser_current_path = [self.browser_folder_labels.get(folder_index, folder_name)]

            # Get the browser item for the requested folder
            if folder_name in ['colors', 'user_folders']:
                # These return lists instead of BrowserItem
                folder_items = getattr(browser, folder_name)
                self.browser_current_items = list(folder_items)
            else:
                # These return a BrowserItem with children
                folder_item = getattr(browser, folder_name)
                if hasattr(folder_item, 'children'):
                    self.browser_current_items = list(folder_item.children)
                else:
                    self.browser_current_items = [folder_item]

            # Reset pagination and send first page
            self.browser_current_page = 0
            self.browser_pages_count = (len(self.browser_current_items) + self.browser_items_per_page - 1) // self.browser_items_per_page
            self._send_browser_page(self.browser_current_page)

        except Exception as e:
            self._debug_log(f"Error starting browser: {str(e)}")
            self.browser_current_items = []
            self._send_browser_page(0)

    def _get_browser_item_type(self, item):
        """
        Determine the type suffix for a browser item.

        Checks the browser item's properties and returns the appropriate suffix for display
        in the app. The type can be inferred from which folder was requested.

        Args:
            item: A BrowserItem object from Live's browser

        Returns:
            String suffix: '//' for folders, '||<' for devices with children, '||' for devices without children,
            '<' for items with children that are neither folders nor devices, empty string otherwise
        """
        if hasattr(item, 'is_folder') and item.is_folder:
            return '//'
        elif hasattr(item, 'is_device') and item.is_device:
            if hasattr(item, 'children') and item.children:
                return '||<'
            else:
                return '||'
        elif hasattr(item, 'children') and item.children:
            return '<'
        else:
            return ''

    def _send_browser_page(self, page_number):
        """
        Send a paginated list of browser items via SysEx.

        Sends up to 12 items (browser_items_per_page) from the current browser folder.
        Items are formatted with type suffixes: '//' for folders, '||<' for devices with children,
        '||' for devices without children, '<' for non-folder non-device items with children.

        SysEx message format (manufacturer ID 0x13):
            current_page^total_pages^item1//,item2||<,item3||,item4<,...

        Args:
            page_number: The page number to send (0-indexed)
        """
        if not self.browser_current_items:
            self.browser_current_page = 0
            self.browser_pages_count = 0
            self._send_sys_ex_message("0^0^", 0x13)
            return

        if page_number < 0 or page_number >= self.browser_pages_count:
            return

        self.browser_current_page = page_number

        start_index = page_number * self.browser_items_per_page
        end_index = min(start_index + self.browser_items_per_page, len(self.browser_current_items))
        page_items = self.browser_current_items[start_index:end_index]

        # Build item strings with type suffixes
        item_strings = []
        for item in page_items:
            if hasattr(item, 'name'):
                item_name = item.name
                item_type = self._get_browser_item_type(item)
                preview_marker = '&' if self._browser_item_can_preview(item) else ''
                group_label = ''
                if self.browser_showing_search_results:
                    group_label = self.browser_search_group_by_key.get(self._browser_item_search_key(item), '')
                group_marker = '%{}'.format(self._escape_sysex_string(group_label)) if group_label else ''
                item_strings.append(f"{self._escape_sysex_string(item_name)}{item_type}{preview_marker}{group_marker}")

        # Format: current_page^total_pages^item1//,item2||,item3||,...
        items_string = ','.join(item_strings)
        message = f"{self.browser_current_page}^{self.browser_pages_count}^{items_string}"

        # Send using manufacturer ID 0x13
        self._send_sys_ex_message(message, 0x13)

    def _send_browser_search_progress(self, state, traversed=0, matches=0, location=''):
        """Send compact search progress: state^checked^matches^current scope."""
        safe_location = self._escape_sysex_string(str(location)[:48])
        self._send_sys_ex_message(
            '{}^{}^{}^{}'.format(int(state), int(traversed), int(matches), safe_location),
            0x3E
        )

    def _browser_decode_search_payload(self, message):
        try:
            payload = bytes(self.extract_values_from_sysex_message(message)).decode('ascii', errors='ignore')
        except Exception:
            payload = ''
        fields = self._split_escaped_sysex_fields(payload, '|')
        query = self._unescape_sysex_string(fields[0]).strip() if fields else ''
        tag_indices = []
        if len(fields) > 1:
            for raw_index in fields[1].split(','):
                try:
                    index = int(raw_index)
                    if index in self.browser_searchable_tag_indices and index not in tag_indices:
                        tag_indices.append(index)
                except Exception:
                    pass
        search_scope = ''
        if len(fields) > 2:
            candidate_scope = self._unescape_sysex_string(fields[2]).strip().casefold()
            if candidate_scope == 'samples':
                search_scope = candidate_scope
        return query, tag_indices, search_scope

    def _browser_state_snapshot(self):
        return {
            'items': list(self.browser_current_items),
            'page': self.browser_current_page,
            'pages_count': self.browser_pages_count,
            'history': list(self.browser_history),
            'path': list(self.browser_current_path)
        }

    def _restore_browser_state_after_search(self):
        self.browser_search_generation += 1
        self.browser_search_work = None
        state = self.browser_search_restore_state
        self.browser_search_restore_state = None
        self.browser_search_query = ''
        self.browser_search_tag_indices = []
        self.browser_previewable_keys = set()
        self.browser_search_group_by_key = {}
        self.browser_search_result_items = []
        self.browser_showing_search_results = False
        self.browser_search_scope = ''
        if state is None:
            self.browser_current_items = []
            self.browser_current_page = 0
            self.browser_pages_count = 0
            self.browser_history = []
            self.browser_current_path = []
            self._send_browser_page(0)
            self._send_browser_search_progress(2)
            return
        self.browser_current_items = state['items']
        self.browser_current_page = state['page']
        self.browser_pages_count = state['pages_count']
        self.browser_history = state['history']
        self.browser_current_path = state['path']
        self._send_browser_page(self.browser_current_page)
        self._send_browser_search_progress(2)

    def _browser_items_for_category(self, category_index):
        browser = self.application().browser
        if category_index == 14:
            try:
                for item in browser.drums.children:
                    if str(getattr(item, 'name', '')).casefold() == 'drum hits':
                        return list(item.children)
            except Exception as error:
                self._debug_log('Browser category Drum Hits unavailable: {}'.format(error))
            return []

        folder_name = self.browser_folder_mapping.get(category_index)
        if folder_name is None:
            return []
        try:
            root = getattr(browser, folder_name)
            if folder_name in ('colors', 'user_folders'):
                return list(root)
            if hasattr(root, 'children'):
                return list(root.children)
            return [root]
        except Exception as error:
            self._debug_log('Browser category {} unavailable: {}'.format(folder_name, error))
            return []

    def _browser_search_roots(self, tag_indices, search_scope=''):
        if search_scope == 'samples':
            roots = []
            for category_index in (10, 11, 12):
                label = self.browser_folder_labels.get(category_index, '')
                roots.extend((item, (label,)) for item in self._browser_items_for_category(category_index))
            return roots

        if tag_indices:
            roots = []
            for category_index in tag_indices:
                label = self.browser_folder_labels.get(category_index, '')
                roots.extend((item, (label,)) for item in self._browser_items_for_category(category_index))
            return roots

        state = self.browser_search_restore_state
        if state and state['items']:
            base_path = tuple(state.get('path', ()))
            return [(item, base_path) for item in state['items']]

        # Leave the largest unfiltered roots until the end so common browser
        # categories can publish matches first. Explicit tag searches keep the
        # selected tag order above, including when Samples is selected.
        category_indices = [
            category_index for category_index in self.browser_searchable_tag_indices
            if category_index not in (10, 11, 12, 14)
        ] + [10, 11, 12, 14]
        roots = []
        for category_index in category_indices:
            label = self.browser_folder_labels.get(category_index, '')
            items = self._browser_items_for_category(category_index)
            if category_index == 3:
                items = [
                    item for item in items
                    if str(getattr(item, 'name', '')).casefold() != 'drum hits'
                ]
            roots.extend((item, (label,)) for item in items)
        return roots

    def _browser_item_search_key(self, item):
        try:
            uri = str(item.uri)
            if uri:
                return uri
        except Exception:
            pass
        try:
            source = str(item.source)
        except Exception:
            source = ''
        return '{}|{}'.format(source, str(getattr(item, 'name', '')))

    def _browser_item_is_loadable(self, item):
        try:
            return bool(item.is_loadable)
        except Exception:
            try:
                return not bool(item.is_folder) and not bool(list(item.children))
            except Exception:
                return not bool(getattr(item, 'is_folder', False))

    def _browser_item_is_sample(self, item):
        name = str(getattr(item, 'name', '')).casefold()
        uri = str(getattr(item, 'uri', '')).casefold()
        sample_extensions = ('.wav', '.aif', '.aiff', '.flac', '.mp3', '.m4a', '.ogg', '.caf')
        return name.endswith(sample_extensions) or any(extension in uri for extension in sample_extensions)

    def _browser_item_file_path(self, item):
        """Resolve file-backed BrowserItem URIs without assuming every URI is a file."""
        try:
            raw_uri = str(item.uri)
        except Exception:
            return ''
        if not raw_uri:
            return ''

        decoded_uri = unquote(raw_uri)
        candidates = []
        try:
            parsed_uri = urlparse(decoded_uri)
            if parsed_uri.scheme.casefold() == 'file':
                candidates.append(parsed_uri.path)
        except Exception:
            pass
        if decoded_uri.startswith('/'):
            candidates.append(decoded_uri.split('?', 1)[0].split('#', 1)[0])
        else:
            path_match = re.search(r'(/[^?#]+\.(?:adv|adg))(?:[?#]|$)', decoded_uri, re.IGNORECASE)
            if path_match:
                candidates.append(path_match.group(1))

        for candidate in candidates:
            candidate = os.path.normpath(candidate)
            if os.path.isfile(candidate):
                return candidate
        return ''

    def _browser_preset_has_preview(self, item):
        """Check Ableton's on-disk preview location for an .adv or .adg preset."""
        preset_path = self._browser_item_file_path(item)
        if not preset_path:
            return False

        direct_preview = preset_path + '.ogg'
        if os.path.isfile(direct_preview):
            return True

        parent = os.path.dirname(preset_path)
        for _ in range(16):
            relative_path = os.path.relpath(preset_path, parent)
            preview_path = os.path.join(parent, 'Ableton Folder Info', 'Previews', relative_path + '.ogg')
            if os.path.isfile(preview_path):
                return True
            next_parent = os.path.dirname(parent)
            if next_parent == parent:
                break
            parent = next_parent
        return False

    def _browser_item_can_preview(self, item, path=None):
        """Approximate Live's prehear support from item kind and browser scope."""
        key = self._browser_item_search_key(item)
        if key in self.browser_previewable_keys:
            return True
        if not self._browser_item_is_loadable(item):
            return False
        try:
            if bool(item.is_folder):
                return False
        except Exception:
            pass

        name = str(getattr(item, 'name', '')).casefold()
        uri = str(getattr(item, 'uri', '')).casefold()
        if name.endswith('.alc') or '.alc' in uri:
            return False
        item_path = tuple(path) if path is not None else tuple(self.browser_current_path)
        root = str(item_path[0]).casefold() if item_path else ''
        preview_roots = ('sounds', 'drums', 'instruments', 'samples')
        audio_extensions = ('.wav', '.aif', '.aiff', '.flac', '.mp3', '.m4a', '.ogg')
        if name.endswith(audio_extensions) or any(extension in uri for extension in audio_extensions):
            return True
        preset_extensions = ('.adv', '.adg')
        if name.endswith(preset_extensions) or any(extension in uri for extension in preset_extensions):
            # Pack and library URIs are often virtual, so a preset may have a
            # working Live preview even when no local path can be resolved.
            return self._browser_preset_has_preview(item) or root in preview_roots

        try:
            if bool(item.is_device):
                return False
        except Exception:
            pass

        return root in preview_roots

    def _publish_browser_search_matches(self, work):
        # Search walks one root folder at a time. Keeping discovery order makes
        # every partial update append-only, so visible rows never jump around.
        ordered_matches = list(work['matches'])
        self.browser_search_result_items = [value[2] for value in ordered_matches]
        self.browser_previewable_keys = set(
            self._browser_item_search_key(value[2]) for value in ordered_matches if value[3]
        )
        self.browser_search_group_by_key = {
            self._browser_item_search_key(value[2]): value[4] for value in ordered_matches if value[4]
        }
        pages_count = (
            (len(self.browser_search_result_items) + self.browser_items_per_page - 1) // self.browser_items_per_page
        )

        if self.browser_showing_search_results:
            self.browser_current_items = list(self.browser_search_result_items)
            self.browser_pages_count = pages_count
            self.browser_current_page = min(self.browser_current_page, max(0, pages_count - 1))
            self._send_browser_page(self.browser_current_page)
        else:
            for state in self.browser_history:
                if state.get('is_search_results', False):
                    state['items'] = list(self.browser_search_result_items)
                    state['pages_count'] = pages_count
                    state['page'] = min(state.get('page', 0), max(0, pages_count - 1))

    def _continue_browser_search(self, generation):
        work = self.browser_search_work
        if work is None or generation != self.browser_search_generation:
            return

        processed = 0
        while (
            work['stack'] and
            work['traversed'] < self.browser_search_max_items and
            processed < self.browser_search_batch_size
        ):
            item, parent_path = work['stack'].pop()
            processed += 1
            key = self._browser_item_search_key(item)
            if key in work['visited']:
                continue
            work['visited'].add(key)
            work['traversed'] += 1

            name = str(getattr(item, 'name', ''))
            path = parent_path + ((name,) if name else tuple())
            try:
                source = str(item.source)
            except Exception:
                source = ''
            haystack = ' '.join(path + ((source,) if source else tuple())).casefold()
            matches_scope = work['search_scope'] != 'samples' or self._browser_item_is_sample(item)
            if self._browser_item_is_loadable(item) and matches_scope and all(term in haystack for term in work['terms']):
                normalized_name = name.casefold()
                query = work['normalized_query']
                if query and normalized_name == query:
                    rank = 0
                elif query and normalized_name.startswith(query):
                    rank = 1
                elif query and query in normalized_name:
                    rank = 2
                else:
                    rank = 3
                group_label = str(path[1]) if len(path) > 1 else (str(path[0]) if path else '')
                work['matches'].append((rank, normalized_name, item, self._browser_item_can_preview(item, path), group_label))

            try:
                children = list(item.children)
            except Exception:
                children = []
            for child in reversed(children):
                work['stack'].append((child, path))

        now = time.time()
        location = ''
        if work['stack']:
            next_path = work['stack'][-1][1]
            location_parts = [str(part) for part in next_path if part]
            location = ' / '.join(location_parts[-2:])
        match_count = len(work['matches'])
        should_publish = match_count and (
            not work['published_results'] or
            match_count >= work['published_match_count'] + self.browser_items_per_page or
            now - work['last_publish_time'] >= 0.6
        )
        if should_publish:
            self._publish_browser_search_matches(work)
            work['published_results'] = True
            work['published_match_count'] = match_count
            work['last_publish_time'] = now

        if location != work['last_location'] or now - work['last_progress_time'] >= 0.35:
            work['last_location'] = location
            work['last_progress_time'] = now
            self._send_browser_search_progress(1, work['traversed'], match_count, location)

        if work['stack'] and work['traversed'] < self.browser_search_max_items:
            self.schedule_message(1, lambda: self._continue_browser_search(generation))
            return

        self._publish_browser_search_matches(work)
        self.browser_search_work = None
        self._send_browser_search_progress(2, work['traversed'], len(work['matches']), location)

    def _browser_search(self, message):
        query, tag_indices, search_scope = self._browser_decode_search_payload(message)
        if not query and not tag_indices:
            self._restore_browser_state_after_search()
            return

        if self.browser_search_restore_state is None:
            self.browser_search_restore_state = self._browser_state_snapshot()
        self.browser_search_query = query
        self.browser_search_tag_indices = tag_indices
        self.browser_search_scope = search_scope
        self.browser_search_generation += 1
        generation = self.browser_search_generation
        self.browser_showing_search_results = True

        # Selecting a main group without a query is browsing, not a full-tree
        # flattening operation. Return that group's first level immediately.
        if not query and len(tag_indices) == 1:
            category_index = tag_indices[0]
            self.browser_search_work = None
            self.browser_current_items = self._browser_items_for_category(category_index)
            self.browser_current_page = 0
            self.browser_pages_count = (
                (len(self.browser_current_items) + self.browser_items_per_page - 1) // self.browser_items_per_page
            )
            self.browser_current_path = [self.browser_folder_labels.get(category_index, '')]
            self.browser_previewable_keys = set()
            self.browser_search_group_by_key = {}
            self.browser_search_result_items = list(self.browser_current_items)
            self._send_browser_page(0)
            self._send_browser_search_progress(2, len(self.browser_current_items), len(self.browser_current_items), '')
            return

        normalized_query = query.casefold()
        roots = self._browser_search_roots(tag_indices, search_scope)
        initial_location = str(roots[0][1][0]) if roots and roots[0][1] else ''
        self.browser_current_items = []
        self.browser_current_page = 0
        self.browser_pages_count = 0
        self.browser_previewable_keys = set()
        self.browser_search_group_by_key = {}
        self.browser_search_result_items = []
        self.browser_search_work = {
            'stack': list(reversed(roots)),
            'visited': set(),
            'matches': [],
            'traversed': 0,
            'terms': [term for term in normalized_query.split() if term],
            'normalized_query': normalized_query,
            'search_scope': search_scope,
            'published_results': False,
            'published_match_count': 0,
            'last_publish_time': 0.0,
            'last_progress_time': 0.0,
            'last_location': initial_location
        }
        self._send_browser_search_progress(0, 0, 0, initial_location)
        self.schedule_message(1, lambda: self._continue_browser_search(generation))

    def _browser_preview(self, value):
        browser = self.application().browser
        if value == 0:
            try:
                browser.stop_preview()
            except Exception:
                pass
            return
        index = (self.browser_current_page * self.browser_items_per_page) + (value - 1)
        if index < 0 or index >= len(self.browser_current_items):
            return
        if not self._browser_item_can_preview(self.browser_current_items[index]):
            return
        try:
            browser.preview_item(self.browser_current_items[index])
        except Exception as error:
            self._debug_log('Browser preview failed: {}'.format(error))

    def _browser_navigate(self, value):
        """
        Navigate between browser pages using a MIDI note button.

        Triggered by MIDI note on channel 15, note 82.
        - Note on (value != 0): Go to next page
        - Note off (value == 0): Go to previous page

        Validates boundaries and only sends pages that exist.

        Args:
            value: MIDI note velocity (0-127). Non-zero = note on, zero = note off
        """
        if not self.browser_current_items:
            return

        if value != 0:
            # Note on: go to next page
            if self.browser_current_page < self.browser_pages_count - 1:
                self._send_browser_page(self.browser_current_page + 1)
        else:
            # Note off: go to previous page
            if self.browser_current_page > 0:
                self._send_browser_page(self.browser_current_page - 1)

    def _browser_open_item(self, value):
        """
        Open and action on a browser item based on MIDI note velocity.

        Triggered by MIDI note on channel 15, note 81. The velocity is sent as
        (index + 1) to avoid velocity 0 issues.

        The actual item index is calculated as: (current_page * items_per_page) + (value - 1)

        Action depends on item type:
        - Folder (is_folder): Load folder contents and send new browser page
        - Has children but not a folder: Try to display children
        - Other (no children or can't display): Attempt to load the item

        After loading a device, updates track and device views to reflect changes.

        Args:
            value: MIDI note velocity (1-12), sent as index + 1
        """
        if not self.browser_current_items:
            return

        index = (self.browser_current_page * self.browser_items_per_page) + (value - 1)
        if index >= len(self.browser_current_items):
            return

        item = self.browser_current_items[index]
        browser = self.application().browser

        def load_item(item_to_load):
            target_index = self.browser_insert_after_device_index
            self.browser_insert_after_device_index = None
            if target_index is not None:
                self._load_item_after_device(item_to_load, target_index)
            else:
                browser.load_item(item_to_load)

        if hasattr(item, 'is_folder') and item.is_folder:
            if hasattr(item, 'children'):
                # Save current state to history before navigating
                self.browser_history.append({
                    'items': self.browser_current_items,
                    'page': self.browser_current_page,
                    'pages_count': self.browser_pages_count,
                    'path': list(self.browser_current_path),
                    'is_search_results': self.browser_showing_search_results
                })
                self.browser_current_items = list(item.children)
                self.browser_showing_search_results = False
                self.browser_current_path.append(str(getattr(item, 'name', '')))
                self.browser_current_page = 0
                self.browser_pages_count = (len(self.browser_current_items) + self.browser_items_per_page - 1) // self.browser_items_per_page
                self._send_browser_page(self.browser_current_page)
        elif hasattr(item, 'children'):
            try:
                children = list(item.children)
                if children:
                    # Save current state to history before navigating
                    self.browser_history.append({
                        'items': self.browser_current_items,
                        'page': self.browser_current_page,
                        'pages_count': self.browser_pages_count,
                        'path': list(self.browser_current_path),
                        'is_search_results': self.browser_showing_search_results
                    })
                    self.browser_current_items = children
                    self.browser_showing_search_results = False
                    self.browser_current_path.append(str(getattr(item, 'name', '')))
                    self.browser_current_page = 0
                    self.browser_pages_count = (len(self.browser_current_items) + self.browser_items_per_page - 1) // self.browser_items_per_page
                    self._send_browser_page(self.browser_current_page)
                else:
                    load_item(item)
                    self._on_tracks_changed()
                    self._on_device_changed()
            except Exception:
                load_item(item)
                self._on_tracks_changed()
                self._on_device_changed()
        else:
            load_item(item)
            self._on_tracks_changed()
            self._on_device_changed()

    def _browser_load_item(self, value):
        """
        Load a browser item based on MIDI note velocity, never opening children.

        Triggered by MIDI note on channel 15, note 80. The velocity is sent as
        (index + 1) to avoid velocity 0 issues.

        The actual item index is calculated as: (current_page * items_per_page) + (value - 1)

        Always attempts to load the item, regardless of whether it's a folder, device with children, etc.
        After loading, updates track and device views to reflect changes.

        Args:
            value: MIDI note velocity (1-12), sent as index + 1
        """
        if not self.browser_current_items:
            return

        index = (self.browser_current_page * self.browser_items_per_page) + (value - 1)
        if index >= len(self.browser_current_items):
            return

        item = self.browser_current_items[index]
        browser = self.application().browser
        audio_clip_target = self.browser_audio_clip_target
        self.browser_audio_clip_target = None
        if audio_clip_target is not None:
            file_path = self._browser_item_file_path(item)
            try:
                track_index, scene_index = audio_clip_target
                tracks = self.song().tracks
                if not file_path or track_index < 0 or track_index >= len(tracks):
                    raise RuntimeError('The selected browser item is not a readable audio file.')
                clip_slots = tracks[track_index].clip_slots
                if scene_index < 0 or scene_index >= len(clip_slots):
                    raise RuntimeError('The destination clip slot no longer exists.')
                clip_slot = clip_slots[scene_index]
                if clip_slot.has_clip:
                    raise RuntimeError('The destination clip slot is no longer empty.')
                clip_slot.create_audio_clip(file_path)
                self.song().view.highlighted_clip_slot = clip_slot
                self._send_audio_clip_action_result('load', True, 'Audio clip created')
                self._send_audio_clip_state(force=True)
                return
            except Exception as error:
                self._send_audio_clip_action_result('load', False, str(error))
                return
        target_index = self.browser_insert_after_device_index
        self.browser_insert_after_device_index = None
        if target_index is not None:
            self._load_item_after_device(item, target_index)
        else:
            browser.load_item(item)
        self._on_tracks_changed()
        self._on_device_changed()

    def _browser_go_back(self, value):
        """
        Go back one or more levels in the browser history, restoring the page state.

        Triggered by MIDI note on channel 15, note 79.

        The velocity determines how many steps to go back:
        - Velocity 1 = go back 1 step
        - Velocity 2 = go back 2 steps
        - etc.

        Restores the previous level's items and page number from the history stack.
        Only works if there's history available.

        Args:
            value: MIDI note velocity (1-127). Determines number of steps to go back.
        """
        if value == 0 or not self.browser_history:
            return

        # Determine number of steps to go back
        steps = min(value, len(self.browser_history))

        # Pop the last state(s) from history
        for _ in range(steps - 1):
            self.browser_history.pop()

        previous_state = self.browser_history.pop()

        # Restore the previous state
        self.browser_current_items = previous_state['items']
        self.browser_current_page = previous_state['page']
        self.browser_pages_count = previous_state['pages_count']
        self.browser_current_path = previous_state.get('path', self.browser_current_path[:-1])
        self.browser_showing_search_results = previous_state.get('is_search_results', False)

        # Send the page we were at
        self._send_browser_page(self.browser_current_page)

    def disconnect(self):
        # Cancel all pending timers
        self._apply_note_repeat_engine(False, self.NOTE_REPEAT_DEFAULT_INDEX)
        self._decoupled_automation_recording_active = False
        self._decoupled_automation_recording_snapshots = {}
        self._decoupled_automation_recording_generation += 1
        self._simpler_waveform_generation += 1
        self._remove_simpler_listeners()
        self._disconnect_simpler_decorator()
        self._simpler_device = None
        self._simpler_sample = None
        self._remove_meld_engine_listener()
        if self._metadata_recheck_timer:
            self._metadata_recheck_timer.cancel()
            self._metadata_recheck_timer = None
        if self._automation_metadata_update_timer:
            self._automation_metadata_update_timer.cancel()
            self._automation_metadata_update_timer = None
        if hasattr(self, '_mixer_disconnect_timer') and self._mixer_disconnect_timer:
            self._mixer_disconnect_timer.cancel()
            self._mixer_disconnect_timer = None
        self._cancel_bank_metadata_refreshes()
        self._cancel_smooth_macro_randomize()
        if hasattr(self, '_periodic_timer_ref') and self._periodic_timer_ref:
            self._periodic_timer_ref.cancel()
            self._periodic_timer_ref = None
        self._remove_follow_action_runtime_listeners()
        self._remove_follow_action_name_listeners()
        self._remove_follow_action_song_listeners()
        self._remove_all_notes_playing_listeners()
        self._mutator_regeneration_states.clear()
        self._mutator_generation_in_progress.clear()
        self._mutator_generation_scheduled.clear()
        self._queued_mutator_work.clear()
        self._last_mutator_generation_times.clear()
        self._last_mutator_generation_request_times.clear()
        self._last_mutator_generation_signatures.clear()
        
        # Stop periodic execution
        self.periodic_timer = 0
        
        # Clear caches
        self._metadata_cache.clear()
        self._metadata_send_seq_by_device.clear()
        for control_index in list(getattr(self, '_active_high_resolution_gestures', set())):
            mapped_parameter = self._mapped_parameter_for_device_control(control_index)
            if mapped_parameter and hasattr(mapped_parameter, 'end_gesture'):
                try:
                    mapped_parameter.end_gesture()
                except Exception:
                    pass
        self._active_high_resolution_gestures.clear()
        for control_index in list(getattr(self, '_active_high_resolution_undo_steps', set())):
            self._end_high_resolution_undo_step(control_index)
        
        self._remove_parameter_value_listeners()
        self._remove_parameter_name_listeners()
        self._remove_parameter_source_listener()
        self._remove_wavetable_virtual_property_listeners()
        self._remove_dynamic_parameter_state_listeners()
        self._remove_disabled_parameter_listeners()
        self._remove_automation_state_listeners()
        self._remove_mixer_automation_state_listeners()
        self._cancel_mixer_automation_status_resends()
        self._unregister_clip_and_audio_listeners()
#        self.quantize_button.remove_value_listener(self._quantize_button_value)
        if hasattr(self, 'duplicate_button'):
            self.duplicate_button.remove_value_listener(self._duplicate_button_value)
        if hasattr(self, 'duplicate_scene_button'):
            self.duplicate_scene_button.remove_value_listener(self._duplicate_scene_button_value)
        if hasattr(self, 'sesh_record_button'):
            self.sesh_record_button.remove_value_listener(self._sesh_record_value)
        if hasattr(self, 'redo_button'):
            self.redo_button.remove_value_listener(self._redo_button_value)
        if hasattr(self, 'undo_button'):
            self.undo_button.remove_value_listener(self._undo_button_value)
        if hasattr(self, 'transport_toggle_button'):
            self.transport_toggle_button.remove_value_listener(self._transport_toggle_value)
        # browser buttons cleanup
        if hasattr(self, 'browser_start_button'):
            self.browser_start_button.remove_value_listener(self._start_browser)
        if hasattr(self, 'browser_navigate_button'):
            self.browser_navigate_button.remove_value_listener(self._browser_navigate)
        if hasattr(self, 'browser_open_button'):
            self.browser_open_button.remove_value_listener(self._browser_open_item)
        if hasattr(self, 'browser_load_button'):
            self.browser_load_button.remove_value_listener(self._browser_load_item)
        if hasattr(self, 'browser_back_button'):
            self.browser_back_button.remove_value_listener(self._browser_go_back)
        if hasattr(self, 're_enable_automation_button'):
            self.re_enable_automation_button.remove_value_listener(self._re_enable_automation)
        if hasattr(self, 'remove_automation_button'):
            self.remove_automation_button.remove_value_listener(self._arm_remove_automation_from_next_encoder)
        if hasattr(self, 're_enable_parameter_automation_button'):
            self.re_enable_parameter_automation_button.remove_value_listener(self._arm_re_enable_automation_from_next_encoder)
        song = self.song()
        # periodic_check_button.remove_value_listener(self._periodic_check)
        self._remove_song_listener(song, "tracks", self._on_tracks_changed)
        # self.song().view.remove_selected_track_listener(self._on_selected_track_changed)
        # self.remove_midi_listener(self._midi_listener)
        # self.song().view.remove_selected_scene_listener(self._on_selected_scene_changed)
        self._remove_song_listener(song, "scale_name", self._on_scale_changed)
        self._remove_song_listener(song, "root_note", self._on_scale_changed)
        self._remove_song_listener(song, "swing_amount", self._update_swing_amount)
        self._remove_song_listener(song, "metronome", self._update_metronome)
        self._remove_song_listener(song, "session_record", self._on_session_record_changed)
        self._remove_song_listener(song, "re_enable_automation_enabled", self._on_re_enable_automation_enabled_changed)
        try:
            if hasattr(song, 'remove_is_playing_listener') and (
                not hasattr(song, 'is_playing_has_listener')
                or song.is_playing_has_listener(self._on_song_is_playing_changed)
            ):
                song.remove_is_playing_listener(self._on_song_is_playing_changed)
        except Exception:
            pass
        # Clean up level listeners
        for track, (left_listener, right_listener) in self._track_level_listeners.items():
            self._remove_output_meter_listener_pair(track, left_listener, right_listener)

        for track, (left_listener, right_listener) in self._return_level_listeners.items():
            self._remove_output_meter_listener_pair(track, left_listener, right_listener)

        if self._master_level_listeners:
            master_track = self.song().master_track
            left_listener, right_listener = self._master_level_listeners.get(master_track, (None, None))
            self._remove_output_meter_listener_pair(master_track, left_listener, right_listener)
        
        super(Tap, self).disconnect()
